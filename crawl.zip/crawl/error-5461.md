## Error 5461

Source: https://sellercentral.amazon.com/help/hub/reference/G7BA3K25ZRY56U6Z 

For example, you may not create a new ASINs for the brand. The seller is not authorized to create new ASINs for the brand name they have used when attempting to list.

---
You may not create a new ASINs for the brand XX. If you believe the product you want to sell is not currently in the Amazon catalog and should be added as a new ASIN. Copy and paste the following URL in a separate window and complete the form:

[https://sellercentral.amazon.es/hz/approvalrequestrestrictionScope=CONTRIBUTION&brandName=Maidenform&brandId=24767&operationFilter=create\_asin](https://sellercentral.amazon.es/hz/approvalrequestrestrictionScope=CONTRIBUTION&brandName=Maidenform&brandId=24767&operationFilter=create_asin)

If you receive this error, it is because you are attempting to create a new ASIN for a brand for which you are not pre-approved to create new ASINs.

Creation of new ASINs may be restricted to brand owners and their affiliates, retail and pre-approved sellers if we have verified that brands have listed their complete catalog on Amazon.

This restriction helps accurately to represent a brand’s entire catalog on Amazon, protecting brands from possible misuse of trademarks and listing policy violations, and providing customers with a trusted buying experience. This does not impact your ability to list an offer on exiting ASINs.

If you believe the product you want to sell is not currently in the Amazon catalog and should be added as a new ASIN, click this URL and complete the form: [https://sellercentral.amazon.es/hz/approvalrequestrestrictionScope=CONTRIBUTION&brandName=Maidenform&brandId=24767&operationFilter=create\_asin](https://sellercentral.amazon.es/hz/approvalrequestrestrictionScope=CONTRIBUTION&brandName=Maidenform&brandId=24767&operationFilter=create_asin)

Top

Was this article helpful?