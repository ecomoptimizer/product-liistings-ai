# FBA Subscribe & Save

Source: https://sellercentral.amazon.com/gp/help/external/G201620110

This article applies to selling in: **United States**

#  FBA Subscribe & Save

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201620110)

On this page

Eligibility requirements

Seller-funding requirements

How base discounts and tiered status work

Subscribe & Save orders

Seller performance metrics

Additional resources

##

FBA Subscribe & Save lets Amazon customers sign up for recurring, scheduled
deliveries of products that they use frequently.

Subscribers get a **base discount** on their deliveries, which is funded by
you as the seller.  Customers who receive five or more subscriptions in a
delivery reach **tiered status** , unlocking additional savings on all
products in their delivery.  (See **How base discounts and tiered status
work** below.)

By participating in Subscribe & Save, you agree to the [ program’s terms and
conditions ](/gp/help/external/201620160) . See eligibility and seller-funding
requirements below for more details.

**Note:** Subscribe & Save offers are also available to Amazon Business
customers. Business customers can place program orders using [ recurring
deliveries
](https://www.amazon.com/gp/help/customer/display.html/ref=&nodeId=201733120)
. They get a 5% discount on Subscribe & Save orders regardless of the product
category or number of subscriptions.

##  Eligibility requirements

To participate in the program, you must have an FBA account in good standing.
Effective  December 18, 2019  , enrollment of new products is limited to brand
owners. Any product enrolled before  December 18  remains eligible for
Subscribe & Save. For information on registering brands, visit [ Amazon Brand
Registry ](https://brandservices.amazon.com/) .

If the option to enable Subscribe & Save does not appear in your settings and
you believe that you have eligible, replenishable items, contact [ Selling
Partner Support ](/help/hub/support) .

Amazon uses the following criteria to determine product eligibility:

  * Fulfillment history and in-stock rate 
  * Sales performance 
  * Product category 
  * Average selling price 

##  Seller-funding requirements

You can choose from three base funding options: 0%, 5%, or 10%.  Subscribers
who receive five or more subscriptions in a delivery reach tiered status, and
Amazon will, for a limited time, fund an additional 5% discount.  You can
update funding and manage your selection on the [ Manage Products
](/fba/programs/sns/manage) page.

If we enroll your products at 0% base discount plus the Amazon-funded 5%
discount, we will continue funding subscriptions with these discounts
indefinitely. When the limited-time Amazon discount ends, we will stop
automatically enrolling new products.

The new funding structure applies to all of your Subscribe & Save items,
including those already enrolled and new selections. All subscriptions created
before  November 5, 2019  , will continue to be funded per the previous
category-specific fee structure.

**Note:** Starting in  December 2019  , for a limited time, eligible,
replenishable items will be automatically enrolled at a 0% base discount and
Amazon will fund the 5% tier discount. With this change, there is no cost to
you and you will no longer have to manually enroll products in Subscribe &
Save to benefit from the program. If you don’t want to take advantage of
automatic enrollment, you can opt out at any time by clicking **Opt out of
automatic enrollment** on the [ Manage Products ](/fba/programs/sns/manage)
page.

##  How base discounts and tiered status work

The base discount and funding information below applies to all subscriptions
created after  November 5, 2019  . Five or more subscriptions in a delivery
unlocks tiered status, meaning additional savings for customers.

**Seller funded at 0%**

Four subscriptions on the same delivery date earns customers no discount.
Five or more subscriptions on the same delivery date earns a 5% discount
(funded by Amazon for a limited time)  ).

**Seller funded at 5%**

Four subscriptions on the same delivery date earns customers a 5% discount.
Five or more subscriptions on the same delivery date earns a 5% discount
(funded by you), plus an additional 5% discount (funded by Amazon for a
limited time)—unlocking customer savings of 10%.

**Seller funded at 10%**

Four subscriptions on the same delivery date earns customers a 10% discount.
Five or more subscriptions on the same delivery date earns a 10% discount
(funded by you), plus an additional 5% discount (funded by Amazon for a
limited time)—unlocking customer savings of 15%.

For all subscriptions created before  November 5, 2019  , the following
product category fee structure applies:

Product category  |  Seller-funded discount for customers** receiving
deliveries for 1-4 product subscriptions  1  in one auto-delivery to the same
address  |  Seller-funded discount for customers** receiving deliveries for 5
or more product subscriptions  1  in one auto-delivery to the same address  
---|---|---  
Beauty  |  5%  |  15%  
Grocery  |  5%  |  15%  
Health & Baby Care  |  5%  |  15%  
Automotive Parts & Tools  |  5%  |  10%  
Electronics  |  5%  |  10%  
Home Tools & Home Improvement  |  5%  |  10%  
Industrial Supplies  |  5%  |  10%  
Kitchen  |  5%  |  10%  
Lawn & Garden  |  5%  |  10%  
Musical Instruments  |  5%  |  10%  
Office Supplies  |  5%  |  10%  
Outdoors  |  5%  |  10%  
Pet supplies  |  5%  |  10%  
Sports  |  5%  |  10%  
Toys  |  5%  |  10%  
  
1  Subscriptions per auto-delivery includes subscriptions for products sold by
other sellers.

**  The discount rates listed above do not apply for Amazon Business
customers, who get a 5% discount on each product regardless of the category or
number of subscriptions.

Seller coupons and promotional discounts are added to Subscribe & Save
discounts. For example, if you run a [ Lightning Deal
](/gp/help/external/202111490) on a product in Subscribe & Save, you must
provide the program discount in addition to the deal price.

##  Subscribe & Save orders

There are two types of Subscribe & Save orders:

  * **Sign-up orders** are the customer's initial order subscribing to a product in the Subscribe & Save program.  In order for your Subscribe & Save offer to appear for a product, your offer must be the Featured Offer. For more information, see [ How the Featured Offer works ](/gp/help/external/37911) . 
  * **Replenishment orders** are automatically created according to the frequency set by the customer. Subscribe & Save customers can set deliveries at monthly intervals, from one to six months. 

You can view your Subscribe & Save orders in the [ Transaction View
](/gp/payments-account/view-transactions.html) of the **Payments** report
page.

##  Seller performance metrics

Seller performance reviews are ongoing in order to ensure a positive Amazon
customer experience. When evaluating performance, we consider such things as
your ability to maintain inventory levels sufficient to meet customer demand,
customer feedback, and Subscribe & Save order cancellations. Poor performance
metrics may affect your ability to participate in the program.

You can go to [ Subscribe & Save Manage products ](/fba/programs/sns/manage)
to access your performance dashboard and review the following metrics for
weekly, monthly, quarterly, and yearly time frames:

  * **Shipped units:** The number of units for shipped subscription orders over a given time period. 
  * **Shipped revenue:** The sum of your revenue from shipped subscription orders over a given time period. 
  * **Subscriptions count:** The number of active subscriptions at the end of a given time period. 
  * **Not delivered due to OOS:** The percentage of your units that were not delivered because the ASINs were out of stock. 
  * **Average revenue per customer:** A comparison of your average revenue from subscribers versus non-subscribers. 
  * **Planned revenue:** The sum of your revenue from orders expected to ship for your active subscriptions in the upcoming 30, 60, or 90 days. 
  * **Planned units:** The number of units for orders expected to ship for your active subscriptions in the upcoming 30, 60, or 90 days. 

**Note:** Planned revenue and planned units are estimated projections, not a
guarantee of future sales.

You can also get these performance metrics at the ASIN level by using the
search option on the dashboard. You can search up to 20 ASINs at a time.

For tips on managing your Subscribe & Save offers, see [ Add or remove
Subscribe & Save products ](/gp/help/external/201958650) .

##  Additional resources

  * [ Subscribe & Save dashboard ](/fba/programs/sns/manage)
  * [ Performance report ](/gp/ssof/reports/search.html#orderAscending=&recordType=SnSPerformance)
  * [ Forecasting report ](/gp/ssof/reports/search.html#orderAscending=&recordType=SnSForecasting)

Top

##  FBA Subscribe & Save

* [ Manage Subscribe & Save products  ](/help/hub/reference/external/G201958650)
* [ FBA Subscribe & Save Terms and Conditions  ](/help/hub/reference/external/G201620160)
* [ Manage user permissions for Subscribe & Save  ](/help/hub/reference/external/GKJ8BCBE7PT6HX8R)

