# Manage FBA inventory

Source: https://sellercentral.amazon.com/gp/help/external/200169480

This article applies to selling in: **United States**

#  Manage FBA inventory

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200169480)

You can use the tools on the **Manage Inventory** page for routine inventory
management tasks, including specific FBA tasks such as creating a shipping
plan or submitting Multi-Channel Fulfillment orders. You can also set filters
and preferences to create customized displays of your [ FBA inventory
](/gp/help/external/G201074410) .

On the [ Manage Inventory ](https://sellercentral.amazon.com/hz/inventory)
page, you can:

  * [ View ](/gp/help/external/G8GKMW7345AV3LCY) and sort your inventory 
  * [ Create ](/gp/help/external/G39EFY66ZLSJQ7PM) , [ copy ](/gp/help/external/GJAQ5MM8LB7MMZB7) , and [ edit ](/gp/help/external/GSGKAPSNT53G5B2P) listings 
  * [ Manage pricing ](/gp/help/external/GPTFQ566449VXXCP)
  * Add and remove images under edit listings 
  * [ Close ](/gp/help/external/GDJZDBNYUAS8C7QB) and [ delete ](/gp/help/external/G202010040) listings 

For more information, see [ Update your listings from the Manage Inventory
page ](/gp/help/external/G201186860) .

**Note:** Deleted listings do not show on this page. If you believe you have
FBA inventory associated with a deleted listing, review the [ Stranded
Inventory Overview ](/gp/help/external/G201436600) page. Here you can also
identify available FBA inventory associated with a merchant fulfilled listing.

Top

##  Manage FBA inventory

* [ FBA Inventory Management Features  ](/help/hub/reference/external/GKCHLNKSLXTWLBLY)
* [ FBA Inventory Management Tasks  ](/help/hub/reference/external/G4HKUC974Z79ZG9L)
* [ Additional Inventory Management Tasks  ](/help/hub/reference/external/GC5894HL7B2AGHK2)
* [ ](/help/hub/reference/external/G200372710)
* [ List products for Fulfillment by Amazon  ](/help/hub/reference/external/G200141220)
* [ Fix a "no listing" error  ](/help/hub/reference/external/G200252930)
* [ Stranded inventory overview  ](/help/hub/reference/external/G201436600)
* [ Amazon-fulfilled inventory  ](/help/hub/reference/external/G201972720)
* [ List FBA products in bulk  ](/help/hub/reference/external/G200327780)
* [ FBA Inventory overview  ](/help/hub/reference/external/GTMXYZN64UJL7TT6)
* [ Change a listing to Fulfilled by Amazon  ](/help/hub/reference/external/GR72LTU4JDT7G25L)

