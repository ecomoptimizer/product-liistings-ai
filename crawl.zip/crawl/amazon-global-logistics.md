# Amazon Global Logistics

Source: https://sellercentral.amazon.com/gp/help/external/202187670

This article applies to selling in: **United States**

#  Amazon Global Logistics

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202187670)

On this page

How to get started

Air and ocean shipping

Rates

Typical transit times

Streamlined inventory placement

Service Provider Network

Amazon Global Logistics helps you send your FBA inventory to Amazon
fulfillment centers worldwide. You can ship from China to the US via ocean
(full-container and less-than-container loads) and air. The program also
offers shipping to the UK, France, Germany, Italy, and Spain.

To use Amazon Global Logistics, you first create an FBA shipment as usual.
Then you generate cross-border documentation and pay for customs, duties, and
related charges. You can track your shipment from its origin until it arrives
at a fulfillment center.

##  How to get started

Create an [ Amazon Global Logistics profile
](https://sellercentral.amazon.com/global-selling/dashboard/) by following the
steps below. This will be your shipping account for imports into the US. If
you already have an account with Amazon Global Logistics, set up your profile
by linking to that account.

  

  1. Choose a [ payment method ](/gp/help/external/GZJ4B4HXDUEWP4PC) . 
  2. Set up an [ importer of record (IOR) ](/gp/help/external/GASFW4BD897LNTNN) , who will facilitate customs clearance. 

When you book transportation with Amazon Global Logistics, you’ll also be
asked to provide additional contacts for your shipment, including an exporter
of record (EOR). For more information, go to **Step 4: Provide shipment
contact details** on [ Booking transportation with Amazon Global Logistics
](/gp/help/external/G5NQMLZ7E6UBPVNE) .

For step-by-step instructions on creating a profile, download "Using Amazon
Global Logistics in Seller Central" in [ English ](https://m.media-
amazon.com/images/G/01/AGL/AGL_onboarding_US_FINAL-en_us1.pdf) or [ Chinese
](https://m.media-amazon.com/images/G/01/AGL/AGL_onboarding_US_FINAL-
zh_cn.pdf) .

##  Air and ocean shipping

You can ship your inventory using air or ocean freight via Amazon Global
Logistics. For ocean, you can choose either full-container load (FCL) or less-
than-container load (LCL).

When you create an FBA shipment, the **Ship from** location will show the
available shipping modes. Be sure to confirm that you want to ship with Amazon
Global Logistics [ when you create your shipping plan ](/gssportal/index.html)
. Then, complete your freight booking on the **Book transportation** page or
in the Send to Amazon workflow.

For more information, go to [ Booking transportation with Amazon Global
Logistics ](/gp/help/external/G5NQMLZ7E6UBPVNE) and [ Using Send to Amazon to
book transportation with Amazon Global Logistics
](/gp/help/external/GV6DMTQ3AKGYUWWN) .

##  Rates

Rates for Amazon Global Logistics vary by origin, destination, and weight. For
a complete list of rates, go to the [ Amazon Global Logistics portal
](https://sellercentral.amazon.com/global-selling/dashboard/) . You can also [
get a quote for your shipment ](/gp/help/external/G5NQMLZ7E6UBPVNE) while you
are booking transportation.

##  Typical transit times

Estimated transit time is the time between receipt of the cargo at the point
of origin and delivery or arrival at the destination, either cross-dock or
fulfillment center. Estimated transit time may also include time spent in
customs clearance. Volume and external market conditions might affect the
actual transit time.

Transit time also varies depending on the place of origin, destination, and
shipping mode. For your planning purposes, be sure to check the estimated
transit lead time when you are booking transportation.

Mode  |  Origin ports in China  |  Destinations  |  Estimated transit time
(days)  
---|---|---|---  
Standard ocean (FCL)  |  Fuzhou, Hong Kong, Ningbo, Qingdao, Shanghai,
Tianjin, Xiamen, Yantian  |  UK  |  50–55 days  
Germany, France, Italy, Spain  |  60–65 days  
Fuzhou, Guangzhou, Hong Kong, Lianyungang, Nansha, Ningbo, Qingdao, Shanghai,
Tianjin, Xiamen, Yantian, Zhuhai  |  US – West Coast  |  60–65 days  
US – Central  |  60–65 days  
US – East Coast  |  55–65 days  
Fast ocean (FCL)  |  Ningbo, Shanghai, Yantian  |  US – West Coast  |  30–35
days  
Standard ocean (LCL)  |  Ningbo, Qingdao, Shanghai, Shenzhen, Xiamen,  |  UK
|  70–75 days  
Germany  |  85–90 days  
Ningbo, Qingdao, Shanghai, Shenzhen, Tianjin, Xiamen  |  US – West Coast  |
55–60 days  
US – Central  |  60–65 days  
US – East Coast  |  55–65 days  
Fast ocean (LCL)  |  Ningbo, Shanghai, Shenzhen, Xiamen  |  US – West Coast  |
40–45 days  
Air  |  Guangzhou, Hong Kong, Shanghai, Shenzhen, Xiamen  |  UK, Germany,
France, Italy, Spain  |  10–12 days  
US – West Coast, Central, East Coast  |  8–10 day  
`

##  Streamlined inventory placement

With streamlined inventory placement, your sortable, non-sortable, and
specialty products arrive at a single, designated fulfillment center when they
first reach the US. Streamlining reduces your fees and consolidates services.
If streamlined inventory placement is not an automatic part of your shipment
workflow, [ contact us ](/help/hub/support/SOA) .

**Fulfillment centers by cargo type**

If delivery or processing is delayed at the fulfillment centers below,
inventory might be sent to a different fulfillment center at no added cost to
you.

**Sortable (standard-size) cargo:** ONT8/LGB8

**Non-sortable (larger-size) cargo:**

  * Standard non-sort: IND2/5, MDW6/9 
  * Heavy bulky (extra-large and oversize): MDW8 

**Specialty cargo:** SD8, ABE2/3

You can confirm which fulfillment center your inventory is being shipped to
each time you book transportation. Review the **Ship to** address at the top
of the **Book transportation** page.

**Cargo type details**

**Sortable:** Any product that measures 45.72 cm x 35.56 cm x 20.32 cm or less
and weighs no more than 9.07 kg.

**Heavy bulky:** Any product with one or more of the conditions listed below.

  * The product weighs more than 23 kg per unit. 
  * The length of one side exceeds 274 cm. 
  * The circumference exceeds 419 cm. 

**Specialty:** Includes clothing, jewelry, and shoes.

##  Service Provider Network

The [ Service Provider Network ](/gspn?ld=ASCNAGSDirect&ref_=sc_gspn_na_hp) is
a directory of services offered by third parties. The services that are listed
are available to all Amazon sellers and are organized by categories, including
account management, accounting, taxes, storage, training, and translation.

Services that are listed in the network's [ international shipping category
](/tsba/searchpage/International%20Shipping?ref_=sc_spn_hp_islst&sellFrom=US&sellIn=US)
may be useful for China-based sellers who are seeking help with EOR
requirements. Under **Value added service** on the left-hand side, select
**Customs brokerage** , and then review listings for EOR services. EOR service
providers can help sellers with EOR qualifications who prefer to use a third-
party EOR. Some EOR service providers also offer value-added services like
foreign-exchange receipts, tax-refund services, transportation services, and
consulting services.

Top

##  Amazon Global Logistics

* [ Restricted products and dangerous goods (hazmat) for Amazon Global Logistics  ](/help/hub/reference/external/GARDA2ALG9F4BNR3)
* [ Amazon Global Logistics Freight Terms and related Program Policies  ](/help/hub/reference/external/G5N72FX7B37YJ3AT)
* [ GSS Freight program common errors  ](/help/hub/reference/external/G764JUN3YHHYV6W4)
* [ Amazon Global Logistics importer setup and customs compliance  ](/help/hub/reference/external/GASFW4BD897LNTNN)
* [ Amazon Global Logistics product compliance  ](/help/hub/reference/external/G63ELGKVHKN2NPTF)
* [ Booking transportation with Amazon Global Logistics  ](/help/hub/reference/external/G5NQMLZ7E6UBPVNE)
* [ Value-added services for Amazon Global Logistics  ](/help/hub/reference/external/G4R925S74NFMCLXA)
* [ After you book with Amazon Global Logistics: Bill of lading, shipment tracking, and changing a booking  ](/help/hub/reference/external/GH34CM95UF7CCXKM)
* [ Paying for Amazon Global Logistics  ](/help/hub/reference/external/GZJ4B4HXDUEWP4PC)
* [ Claims and reimbursements through Amazon Global Logistics  ](/help/hub/reference/external/GR384ESWC8HH8667)

