# NIOSH-Approved Filtering Facepiece Respirators

Source: https://sellercentral.amazon.com/gp/help/external/93NM4S8RDEDNPAA

This article applies to selling in: **United States**

#  NIOSH-Approved Filtering Facepiece Respirators

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F93NM4S8RDEDNPAA)

The National Institute for Occupational Safety and Health (NIOSH), a research
agency of the U.S. Centers for Disease Control and Prevention under the U.S.
Department of Health and Human Services, has a set of requirements to approve
filtering facepiece respirators.

A filtering facepiece respirator is any device worn to help protect your lungs
from airborne particles, including some types of dusts, sprays, and wildfire
smoke. It’s important to follow all manufacturer instructions on the use,
maintenance, cleaning, and warnings about the respirators limitations as some
respirators aren’t designed to protect against certain contaminants. For
example, a respirator designed to filter dust particles will not protect you
against gases, vapors, or very small solid particles of fumes or smoke.

A NIOSH-approved filtering facepiece respirator is required to have the
following markings:

  * Name of approval holder/manufacturer business name, a registered trademark, or an easily understood abbreviation of the approval holder business name as recognized by NIOSH. 
  * "NIOSH" in block letters or the NIOSH logo. 
  * NIOSH Testing and Certification approval number (e.g., TC-84A-XXXX). 
  * NIOSH filter series and filter efficiency level (e.g., N95, N99, N100, R95, P95, P99, P100). 
  * Model number or part number (e.g., 8577 or 8577A). 

##  Additional information

For more information on NIOSH-Approved particulate filtering facepiece
respirators, visit the [ The National Personal Protective Technology
Laboratory (NPPTL)
](https://www.cdc.gov/niosh/npptl/topics/respirators/disp_part/default.html)
website.

Top

