# Handmade Jewelry & Watches guidelines

Source: https://sellercentral.amazon.com/gp/help/external/G201817790

This article applies to selling in: **United States**

#  Handmade Jewelry & Watches guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201817790)

As a Maker, your handmade Jewelry and Watches products must adhere to the
following guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must meet the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * Be authentic. We do not allow any counterfeit, replica, or knock-off products. 
  * All products must meet North America product safety standards. (For more information, go to [ CPSIA Choking Hazard Warnings and Material Content Limits ](/gp/help/external/200292910) ) 
  * If you supply products for sale on Amazon, you must comply with all federal, state, and local laws and Amazon policies applicable to those products and product listings. For [ Children’s Jewelry ](/gp/help/external/GT3XLUHYCWPM3THX) , review the policy for more details. 

Top

