# FBA Business Report

Source: https://sellercentral.amazon.com/gp/help/external/G201074420

This article applies to selling in: **United States**

#  FBA business reports

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201074420)

On this page

Inventory reports

Sales reports

Payments reports

Customer concessions reports

Removal reports

Amazon Global Logistics

FBA business reports provide data to help you track how your business is
performing. Below, you’ll find information about your FBA reports in Seller
Central.

In addition, the [ Amazon fulfillment reports ](/reportcentral/WelcomePage)
page has been redesigned to help you find report information more easily, with
new sections that include the following:

  * “What’s new”: This section displays announcements about changes being made to individual reports or the fulfillment reports homepage. The latest announcements will appear at the top of the section. Each announcement will appear for at least 60 days. 
  * “Recently viewed”: This section shows a list of reports that you have viewed recently. The report pages are listed in chronological order, with the most recently viewed page at the top. To open a page in a new tab, click the name of the report. 
  * “Most popular reports”: This section displays the five most popular FBA fulfillment reports from the past 30 days. Popularity is measured by the number of sellers who download or view the report online. To open a report in a new tab, click the report name. 

##  Inventory reports

  * [ Inventory Ledger ](/reportcentral/LEDGER_REPORT/0) : A comprehensive view of beginning inventory balance, inventory that was received at fulfillment centers, customer orders, customer returns, adjustments, reconciliation events, removals, and ending balance. The Inventory Ledger report consolidates information from the Daily Inventory History, Monthly Inventory History, Inventory Event Detail, Inventory Adjustments, Inventory Reconciliation, and Received Inventory reports. Those reports will be discontinued effective January 31, 2023. 
  * [ Multi-Channel Fulfillment Inventory ](/gp/help/external/200332450) : Products specific to Multi-Channel Fulfillment, such as unbranded packaging and current inventory levels 
  * [ Dangerous Goods Status ](/gp/help/external/GUW88PRBDJPQ5M5N) : Details about which of your products have been classified as dangerous goods, are under dangerous-goods review, or have changed status recently 
  * [ Restock Inventory ](/gp/help/external/202105670) : Details about products to restock to prevent lost sales 
  * [ Stranded Inventory ](/gp/help/external/201835130) : A breakdown of units in your inventory that are in stranded status 
  * [ Reserved Inventory ](/gp/help/external/201723860) : A breakdown of units in your inventory that are in reserved status 
  * [ Small and Light Inventory ](/gp/help/external/G201706140) : Products enrolled in FBA Small and Light, and current inventory levels 
  * [ Multi-Country Inventory ](/gp/help/external/G201491370) : Inventory condition and quantity by country 
  * [ Inventory Health ](/gp/help/external/200537120) : An assessment of your sales, current sellable and unsellable inventory, inventory age, weeks of cover left, and comparisons to other offers on the same products. 
  * [ Inventory Age ](/gp/help/external/201979220) : Identifies aged inventory so you can take action to avoid paying long-term storage fees 
  * [ Amazon-Fulfilled Inventory ](/gp/help/external/200453180) : A snapshot of your inventory in fulfillment centers at the time the report is generated 
  * [ Manage FBA Inventory ](/gp/help/external/200740930) : Current listing details, including condition, disposition, and quantity 
  * [ Manage FBA Inventory - Archived ](/gp/help/external/200740940) : Listing details, including condition, disposition, and quantity, including listings that have been archived 
  * [ Inbound Performance ](/gp/help/external/200875520) : Information about inventory you have shipped to fulfillment centers 
  * [ Excess Inventory ](/gp/help/external/201835150) : Identifies listings with excess inventory so you can take action to sell through faster 
  * [ Exportable Inventory ](/gp/help/external/200149570) : Lists inventory that is eligible for FBA Export. Products that are eligible for export are subject to change. 
  * [ Bulk Fix Stranded Inventory ](/gp/help/external/201968550) : Generates a stranded inventory file that can be used to relist your products in bulk with the Add Products via Upload tool (available only to Pro sellers) 
  * [ FBA Inventory ](/gp/help/external/GKT9YKCHXMSDVJKB) : Current overview of your sales, available inventory, shipment statuses, inventory age, excess units, and weeks of cover 

##  Sales reports

  * [ Outlet Deals ](/gp/help/external/GHLYT4TPVCY2MJE3) : Status of your Outlet deals 
  * [ Subscribe & Save Performance ](/gp/help/external/201711700) : Weekly overview of performance data for FBA Subscribe & Sav 
  * [ Amazon Fulfilled Shipments ](/gp/help/external/200453120) : Product-level details on completed customer orders, including purchase price, quantity, tracking, and shipping information 

  * [ All Orders ](/gp/help/external/200547170) : Review information on both FBA and seller-fulfilled orders, including order status, fulfillment and sales channel information, and product details 
  * [ Customer Shipment Sales ](/gp/help/external/G200453140) : Get product-level data on shipped FBA customer orders, including price, quantity, and destination 
  * [ Promotions ](/gp/help/external/200453160) : View promotions applied to your sales on Amazon 
  * [ Customer Taxes ](/gp/help/external/200852210) : Includes destination information, tax jurisdiction details, and the amount of sales tax collected by revenue type 

##  Payments reports

  * [ Fee Preview ](/gp/help/external/201115050) : Estimates the selling on Amazon and fulfillment fees for your current FBA inventory 
  * [ Inventory storage overage fees ](/gp/help/external/GV8JEETWV9Q33CMX) : Estimated inventory storage overage fees for each storage type of your inventory in fulfillment centers that exceeds your storage limits 
  * [ Monthly Storage Fees ](/gp/help/external/G202086720) : Estimated monthly storage fees for each ASIN of your inventory stored in fulfillment centers. 
  * [ Long-Term Storage Fee ](/gp/help/external/200725880) : Details about your most recent long-term storage fees, including which items the fee was applied to, the condition, number in stock, size, and the total per-SKU fee amount 
  * [ Reimbursements ](/gp/help/external/200732720) : Includes details of inventory reimbursements that you initiated and those generated automatically. For reimbursements that you requested, click the case ID to view the details. 
  * [ Incentive Rewards ](/gp/help/external/G46WGRPY3HXUFZNG) : Incentive rewards assignment history 

##  Customer concessions reports

  * [ FBA Customer Returns ](/gp/help/external/200453320) : Customer returns received at a fulfillment center, with the reason for the return and the condition of the returned product 
  * [ Replacements ](/gp/help/external/200453300) : Details about replacements sent to customers for returned products. 
  * [ FBA Grade and Resell report ](/gp/help/external/GUA6RV6UA4DR2MFK) : Inventory that has been processed through the FBA Grade and Resell program via automated unfulfillable settings 

##  Removal reports

  * [ Recommended Removal ](/gp/help/external/200688550) : Lists inventory in fulfillment centers that would be subject to a long-term storage fee at the next inventory cleanup 
  * [ Removal Order Detail ](/gp/help/external/200989110) : Details for individual removal orders, including the removal type, status of removal orders, and fees 
  * [ Removal Shipment Detail ](/gp/help/external/200989100) : Shipment details for removal orders, including carrier details and tracking numbers. 

##  Amazon Global Logistics

  * Fapiao statements: List of fapiaos issued in a particular month 
  * Monthly debit statement: Summary of your debit notes for shipments paid in Chinese yuan 

Top

##  FBA business reports

* [ Subscribe & Save performance report  ](/help/hub/reference/external/G201711700)
* [ Subscribe & Save Forecasting report  ](/help/hub/reference/external/G201711710)
* [ Inventory reports  ](/help/hub/reference/external/G200885390)
* [ Payments Reports  ](/help/hub/reference/external/G200885400)
* [ Customer Concessions Reports  ](/help/hub/reference/external/G200885410)
* [ Removal Reports  ](/help/hub/reference/external/G200989090)
* [ ](/help/hub/reference/external/G200885380)
* [ Amazon Fulfillment Reports  ](/help/hub/reference/external/G201104750)

