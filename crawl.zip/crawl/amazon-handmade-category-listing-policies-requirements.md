# Amazon Handmade- Category listing policies & requirements

Source: https://sellercentral.amazon.com/gp/help/external/GNGMMFQ5FPLJFBJP

This article applies to selling in: **United States**

#  Amazon Handmade: Category listing policies & requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGNGMMFQ5FPLJFBJP)

In order to be listed in Amazon Handmade, your products need to meet the
eligibility requirements described in [ Amazon Handmade Product Eligibility
](/gp/help/external/G201817090) and our [ Title
](/gp/help/external/GRLUNACJV3JB23G2) , [ Image
](/gp/help/external/GNRP6DDJV79DUHRD) , and [ Customization
](/gp/help/external/G201817850) standards for Handmade products. All Handmade
listings must comply with the following category specific listing policies and
requirements:

  * [ Handmade Artwork guidelines ](/gp/help/external/GW5Y4K4TBPVLLNQX)
  * [ Handmade Baby guidelines ](/gp/help/external/GDLH7JE6U8WXKCFH)
  * [ Handmade Beauty & Grooming guidelines ](/gp/help/external/G202102450)
  * [ Handmade Clothing, Shoes & Accessories guidelines ](/gp/help/external/G202175100)
  * [ Handmade Electronics Accessories guidelines ](/gp/help/external/GVQT5YS63MG8TJW4)
  * [ Handmade Health & Personal Care guidelines ](/gp/help/external/GQEW7ZE8DX838YG4)
  * [ Handmade Jewelry & Watches guidelines ](/gp/help/external/G201817790)
  * [ Handmade Pet Supplies guidelines ](/gp/help/external/G202102470)
  * [ Handmade Home & Kitchen guidelines ](/gp/help/external/GVA9JWUJ37GWA57B)
  * [ Handmade Sports & Outdoors guidelines ](/gp/help/external/GNBPK6NFHKZJ66U3)
  * [ Handmade Stationery & Party Supplies guidelines ](/gp/help/external/GSEBFHFCAWN43DUH)
  * [ Handmade Toys & Games guidelines ](/gp/help/external/GZ9D44DRSKGCYAJ7)

Besides these category specific policies and requirements, all products listed
in Amazon Handmade must also adhere to Amazon selling and listing policies,
including:

  * [ Selling Policies and Seller Code of Conduct ](/gp/help/external/G1801)
  * [ Product Detail Page Rules ](/gp/help/external/G200390640)
  * [ Condition Guidelines ](/gp/help/external/G200339950) (Exception given for up-cycled or re-purposed items) 
  * [ Intellectual Property Policy for Sellers ](/gp/help/external/G201361070)
  * [ Adult Product Polices & Guidelines ](/gp/help/external/G200339940)
  * [ Restricted products ](/gp/help/external/G200164330)
  * [ Offensive and Controversial Materials ](/gp/help/external/G200164670)

In addition to existing policies, the following are not permitted in Amazon
Handmade:

  * Outsourcing of product production 
  * Drop-shipping of products 
  * Reselling products by third parties 
  * The following items are not allowed to be sold in the Amazon Handmade store: 
    * Digital or downloadable products 
    * Food or other ingestible products 
    * Electronics 
    * Live plants – other than ‘air plants’ which may be included with hand-crafted planters or containers 
  * Raw materials and crafting supplies are not allowed to be sold in the Handmade store, with the following exceptions: 
    * Crafting supplies that are included in a DIY kit 
    * Crafting supplies that have been made by you, the maker, for example, hand-crafted yarn or felt 
    * Crafting supplies that have been altered by you, the maker, for example, pre-purchased wool or yarn that you have dyed 

Top

##  Amazon Handmade: Category listing policies & requirements

* [ Handmade Artwork guidelines  ](/help/hub/reference/external/GW5Y4K4TBPVLLNQX)
* [ Handmade Baby guidelines  ](/help/hub/reference/external/GDLH7JE6U8WXKCFH)
* [ Handmade Beauty & Grooming guidelines  ](/help/hub/reference/external/G202102450)
* [ Handmade Clothing, Shoes & Accessories guidelines  ](/help/hub/reference/external/G202175100)
* [ Handmade Electronics Accessories guidelines  ](/help/hub/reference/external/GVQT5YS63MG8TJW4)
* [ Handmade Health & Personal Care guidelines  ](/help/hub/reference/external/GQEW7ZE8DX838YG4)
* [ Handmade Jewelry & Watches guidelines  ](/help/hub/reference/external/G201817790)
* [ Handmade Pet Supplies guidelines  ](/help/hub/reference/external/G202102470)
* [ Handmade Home & Kitchen guidelines  ](/help/hub/reference/external/GVA9JWUJ37GWA57B)
* [ Handmade Sports & Outdoors guidelines  ](/help/hub/reference/external/GNBPK6NFHKZJ66U3)
* [ Handmade Stationery & Party Supplies guidelines  ](/help/hub/reference/external/GSEBFHFCAWN43DUH)
* [ Handmade Toys & Games guidelines  ](/help/hub/reference/external/GZ9D44DRSKGCYAJ7)

