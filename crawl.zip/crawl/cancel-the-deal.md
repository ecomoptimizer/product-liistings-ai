# cancel the Deal

Source: https://sellercentral.amazon.com/gp/help/external/G202111610

This article applies to selling in: **United States**

#  Cancel a Deal

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202111610)

You may cancel a proposed Deal at any time; however, we recommend you cancel
your deal at least 25 hours before the start time  to avoid [ paying a fee
](/gp/help/external/202111590) and  to avoid being blocklisted from creating
Deals in the future. Upcoming Deals will be visible to customers on Amazon 24
hours before the Deal is scheduled to run and can be found in the **Upcoming
Deals** page. If you ever need to cancel your Deal, do so before it becomes
visible to customers.

To cancel a Deal:

  

  1. From the [ Deals Dashboard ](/merchandising) , filter your Deals by Status to show only Deals that  **Needs Attention** or are **Upcoming.** For the Deals that you wish to cancel, click on the drop-down button next to **Edit** . 
  2. Select **Cancel Deal** from the menu. 

**Note:** Once a Deal is canceled, it cannot be reactivated or reinstated.

Top

