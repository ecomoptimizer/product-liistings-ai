# Add, view, and update your bank account information

Source: https://sellercentral.amazon.com/gp/help/external/GWHNLFB8G85QAZ5W

This article applies to selling in: **United States**

#  Add, view, and update your bank account information

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGWHNLFB8G85QAZ5W)

On this page

Add your bank account information

Update existing bank account information

View your bank account information

**Important:** Whenever you add or change your bank account information, a
three-day security hold goes into effect. Fund transfers cannot be initiated
until the hold expires, including those from any settlement cycles that close
during the hold period. We recommend that you do not update your bank account
within three days of your next regularly scheduled disbursement to avoid any
delays in payments. Only the primary account owner can make changes related to
payment information.

##  Add your bank account information

  * Go to **Settings** , and click **Account Info** . 
  * On the **Seller Account Information** page, under **Payment Information** , click **Deposit Methods** . 
  * Click **Add new deposit method** . 
  * Select the appropriate store. 
  * Use the drop-down list to select your **Bank Location Country** . 
  * Enter the information requested in **Where You Will Be Paid** . 
  * If you selected a country with a currency other than the store you are selling in, go to **Currency Conversion Payment Agreement** , click **Agreement** , and read the agreement. 
  * Check the **Currency Conversion Payment Agreement** box to accept the terms of the agreement. 
  * Click **Submit** . 

**Note:** To edit your bank account for a store, click **Replace deposit
method** . If you need to edit other bank account information, click **Manage
Deposit Methods** .

If you would like to add an additional deposit method to your account, go to [
Adding more than one bank account ](/gp/help/external/GW2QZPWB284AMMSM) .

##  Update existing bank account information

  * Go to **Settings** , and click **Account Info** . 
  * On the **Seller Account Information** page, under **Payment Information** , click **Deposit Methods** . 
  * Click **Replace deposit method** . If you need to edit other bank account information, click **Manage Deposit Methods** . 

**Note:** To confirm that your bank account information has been updated, view
the [ Deposit Methods
](/sw/AccountInfo/DepositMethodView/step/DepositMethodView) page in Seller
Central. It may take up to two business days for information to be updated.

##  View your bank account information

To view your account information, go to **Settings** of Seller Central, and
then select [ Account Info ](/hz/sc/account-information) from the drop-down
menu.

On the **Seller Account Information** page, along with your seller profile and
other information, you can also access payment information (Deposit methods,
Charge methods, Invoiced order payment setting).

Watch the video on [ Account Info
](/learn/courses?moduleId=2&sid=SU_SEARCH_2f42f908-8a13-450f-a88f-cc224df29304&modLanguage=English&videoPlayer=youtube)
for more information.

Top

