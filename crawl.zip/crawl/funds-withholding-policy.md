# Funds withholding policy

Source: https://sellercentral.amazon.com/help/hub/reference/external/G9RA9LYBJ3QP27M6

This article applies to selling in: **United States**

#  Funds withholding policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG9RA9LYBJ3QP27M6)

Customer trust is paramount to Amazon, and we strictly prohibit the sale of
counterfeit goods and other deceptive, fraudulent, and illegal activity. If we
find that you have engaged in such activity, we may deactivate your seller
account and withhold any funds that may be in your account, in order to
protect our customers and sellers.

When we deactivate an account, we withhold funds to settle outstanding
transactions, including product returns or refunds, A-to-z claims from
customers, inventory removal costs, and outstanding fees. You may appeal your
account deactivation by following the instructions provided to you in the
notice of account deactivation or in Seller Central. If your account is
reinstated as a result of the appeal, funds will be released and disbursed
according to your disbursement schedule.

If your account is not reinstated following an appeal or you choose not to
appeal the deactivation, after 90 days from when your account was deactivated,
you may separately request funds disbursement by contacting [ disbursement-
appeals@amazon.com ](mailto:disbursement-appeals@amazon.com) .  We will
conduct a separate investigation to evaluate your account for abusive,
fraudulent, or other prohibited activity. During this process, we may request
that you provide additional information or documentation regarding your
identity, financial instruments, and product sourcing. We may validate any
information that you provide with third parties or government agencies.

If we find that you have **engaged in deceptive, fraudulent, or illegal
activity, have abused our systems, or repeatedly violated our policies that
protect our customers and sellers, we may withhold some or all funds in your
account** . Examples of deceptive, fraudulent, or illegal activities include,
but are not limited to: falsifying or misrepresenting your identity, violating
Amazon’s anti-counterfeit policy, or submitting forged documents to Amazon.

Top

