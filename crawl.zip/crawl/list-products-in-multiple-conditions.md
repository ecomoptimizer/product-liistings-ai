# List products in multiple conditions

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> If you offer the same product in multiple conditions (new or used) you must create separate listings for each condition. If you add a listing which has same basic product information like product name, brand name, etc., then it must have at least one different inventory attribute such as condition, condition note, or price, and it should have a unique SKU provided by seller.

---
If you offer the same product in multiple conditions (new or used) you must create separate listings for each condition. If you add a listing which has same basic product information like product name, brand name, etc., then it must have at least one different inventory attribute such as condition, condition note, or price, and it should have a unique SKU provided by seller.

If you have multiple listings for the same product, and condition, you can increase the quantity for each listing. For example: 3 new, and 4 used digital cameras.

Each listing has a unique SKU. However, they are displayed on the same product detail page as they are same product with different conditions.

To create a separate listing for each condition type, follow these steps:  

1.  Go to **Inventory**, click **Manage Inventory**.
2.  Click on **Edit** for the item you want to add a new condition.
3.  Select **Add another condition** from the drop-down.
4.  Go to **Offer** tab, enter appropriate information for the product, such as product condition, price, inventory, sale price, etc.
5.  Click **Save and finish**.

To add more listings, click **Create another listing**. Each new listing must have its own SKU.

## Match low price

When you list a product that has at least one other offer, **Add a Product** lets you match the price of your listing to the current lowest priced other listing with the same condition. For more information, see [Match Low Price](https://sellercentral.amazon.com/gp/help/200836360).

Top

Was this article helpful?
