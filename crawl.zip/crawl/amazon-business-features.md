# Amazon Business features

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201741830

This article applies to selling in: **United States**

#  Amazon Business features

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201741830)

Amazon Business provides access to exclusive benefits and features to help
grow your sales to business customers.

The following features are available to sellers as part of Amazon Business:

##  Features

  * [ Amazon Tax Exemption program ](/gp/help/external/201641810)
  * [ Business-only offers ](/gp/help/external/201740310)
  * [ Business prices and quantity discounts ](/gp/help/external/201740300)
  * [ Manage quotes ](/gp/help/external/G202173820)
  * [ Business-only selections ](/gp/help/external/201958670)
  * [ Feeds ](/gp/help/external/201951010)
  * [ Order reports ](/gp/help/external/201860030)
  * [ Payment options ](/gp/help/external/201950990)
  * [ Seller Credential program ](/gp/help/external/201740330)

Top

##  Amazon Business features

* [ Manage Quotes  ](/help/hub/reference/external/G202173820)
* [ Business-Only Offers  ](/help/hub/reference/external/G201740310)
* [ Amazon Tax Exemption Program  ](/help/hub/reference/external/G201756930)
* [ Negotiated pricing  ](/help/hub/reference/external/G202087730)
* [ Business prices and quantity discounts  ](/help/hub/reference/external/G201740300)
* [ Price types in your business orders  ](/help/hub/reference/external/G202141420)
* [ Business-Only Selection  ](/help/hub/reference/external/G201958670)
* [ Pay by Invoice  ](/help/hub/reference/external/G202085530)
* [ Product documents  ](/help/hub/reference/external/G201818520)
* [ Feeds  ](/help/hub/reference/external/G201951010)
* [ Payment Options  ](/help/hub/reference/external/G201950990)
* [ Credentials and Certifications  ](/help/hub/reference/external/G201740330)
* [ Manage Quotes feed files  ](/help/hub/reference/external/GKU8F3E92RG6HEJM)

