# Options for managing orders

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200198170

This article applies to selling in: **United States**

#  Options for managing orders

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200198170)

You have several options for managing orders depending on the number of orders
you receive and your familiarity with Amazon MWS API requests.

####  [ Manage Orders tool ](/gp/orders-v2/list)

See a list of your orders, and view details about a selected order, such as
the product, buyer, and shipping information. You can also perform order-
related tasks such as print packing slips and issue refunds.

####  [ Order Reports ](/gp/help/external/651)

Receive order fulfillment information for multiple orders by running a single
report. You can schedule order reports to run automatically or you can run one
at a time.

####  [ Amazon Marketplace Web Service (Amazon MWS)
](https://developer.amazonservices.com/index.html)

**Important:** You must be an Amazon MWS developer in order to send an Orders
request.

Amazon MWS supports seller API requests that are broader in scope and
functionality than any APIs Amazon has previously offered sellers. If you have
developer services available, and you have a Professional selling plan,
consider using the **Marketplace Web Service Orders API** to retrieve
information about events (including new orders) in your seller account. To
learn more about Amazon MWS, go to the [ Amazon MWS
](https://developer.amazonservices.com/index.html) site and click the
**Orders** link.

Top

