# Becoming the Featured Offer

Source: https://sellercentral.amazon.com/gp/help/external/201687550

This article applies to selling in: **United States**

#  Becoming the Featured Offer

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201687550)

On this page

I. Price your items competitively

II. Offer faster shipping and free shipping

III. Provide great customer service

IV. Keep stock available

Other options if you don’t become the Featured Offer

Featured Offers are offers for new products that we display on a product
detail page with an Add to Cart option that customers can use to add items to
their shopping carts. When one of your items appears in this way on a product
page, we call it the Featured Offer.

There are two steps to select offers to feature. First, we determine which
items are eligible to be featured based on criteria that are designed to give
customers a great shopping experience. Second, from this pool of eligible
offers, we choose compelling offers to feature.

This help topic deals with the second step, selection. To be considered for
selection as the Featured Offer, first make sure that both you and your listed
items are [ eligible ](/gp/help/external/200418100) . Selection then looks at
a number of factors to identify the offers that customers are most likely to
want, including price, availability, delivery speed, and customer service.

Watch the Video to Learn "How to Become the Featured Offer?"

##  I. Price your items competitively

There are a few ways to check and make sure you're pricing your items
competitively.

  * Visit the [ Manage Pricing ](/inventory?viewId=PRICING&ref_=myi_mp_vl_fba) page where the Featured Offer is indicated, even if it isn’t yours. 
  * See the [ Pricing Dashboard ](/hz/pricing/dashboard) for real-time data about your prices and how they compare to other offers. 
  * View your pricing recommendations in the [ Selling Coach Pricing report ](/hz/sellingcoach) . 

##  II. Offer faster shipping and free shipping

Sellers who offer faster shipping options are more likely to be the Featured
Offer. You can look up your available options in [ Shipping Settings
](/hz/shipping) .

##  III. Provide great customer service

We measure customer service in several different ways, and you can check your
[ Account Health ](/gp/seller-rating/pages/account-health.html) to see how
you're doing.

For example, look at metrics such as [ Order Defect Rate
](/gp/help/external/200285170) , [ Cancellation Rate
](/gp/help/external/200285210) , and [ Late Shipment Rate
](/gp/help/external/200285190) .

Staying tuned in to all aspects of your account health is a great way to
ensure you are working toward becoming the Featured Offer and earning customer
respect and trust.

##  IV. Keep stock available

You can't become the Featured Offer if you're out of stock and none is on
order. Keep your inventory updated and plan accordingly for things that sell
quickly.

The [ Amazon Selling Coach ](/gp/help/external/200380250) can show you low and
out-of-stock inventory alerts, letting you know, in real time, when it's time
to stock up.

##

##  Other options if you don’t become the Featured Offer

Listings that are not the Featured Offer are eligible for placement in the [
Other sellers on Amazon ](/gp/help/external/200418110) box. However, Amazon
does not guarantee placement in either of these locations.

Top

