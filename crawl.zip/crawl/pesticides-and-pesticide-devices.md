# Pesticides and Pesticide Devices

Source: https://sellercentral.amazon.com/gp/help/external/G202115120

This article applies to selling in: **United States**

#  Pest control products and pesticides

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202115120)

On this page

Examples of permitted listings

Examples of prohibited listings

Are any products excluded from EPA registration requirements?

How to apply to sell these products on Amazon

How to add EPA information to a listing

Additional useful information

Washington State disposable wipes

**Important:** If you supply products for sale on Amazon, you must comply with
all federal, state, and local laws and Amazon policies applicable to those
products and product listings. Per Amazon policy, only U.S. residents may sell
pesticides and pesticide devices on Amazon.com. Please see the related [
Pesticide Claims and Listings
](https://sellercentral.amazon.com/learn/courses?moduleId=bc46a58a-23f2-4f66-88e4-f581a8e1ccfd&ref_=su_refined_search&modLanguage=English&videoPlayer=airy)
eLearning to help you understand what is and is not a pesticide or a pesticide
device according to EPA and FIFRA regulations.

In the United States, pesticides and pesticide devices must comply with the
Federal Insecticide, Fungicide, and Rodenticide Act (“FIFRA”) and applicable
state and local laws, including [ registration and labeling requirements
](https://www.epa.gov/pesticide-registration/labeling-requirements) .
Pesticides and pesticide devices include: (1) any product intended for
preventing, destroying, repelling, or mitigating any pest and (2) any product
that makes any antimicrobial, antifungal, antibacterial, anti-mold, or
pesticide claims.

Common examples of conventional pesticides include:

  * Insecticides 
  * Rodenticides 
  * Herbicides 
  * Fungicides 
  * Repellants 
  * Antimicrobial pesticides 

Common examples of pesticide devices include:

  * Ultraviolet light units 
  * Sound generators 
  * Insect traps 
  * Ground vibrators 
  * Water-treatment units 
  * Air-treatment units 

**_I do not believe my product is a pesticide, why was I sent here?_ **

Products that make any antimicrobial, antifungal, antibacterial, or other
**pesticide claim** (for example, products marketed to disinfect, repel
insects, remove allergens, or prevent bacteria) may be considered pesticides
or pesticide devices under Environmental Protection Agency (EPA) regulations.
For more information, go to the EPA page on [ Pesticides
](https://www.epa.gov/pesticides) .

**Pesticide Claims**

A product may be classified by the EPA as a pesticide if the product claims,
states or implies, even indirectly, that it can or should be used to prevent,
destroy, repel, mitigate, or take any other similar action against any kind of
pest. Examples of “pests” include insects, mold, bacteria, mites, mildew, and
animals. For listings on Amazon.com, this could appear anywhere in detail page
text, on an image, or both.

Some common pesticide claims include:

  * Prevents, blocks, removes, neutralizes or controls bacteria or other pests 
  * Sanitizes, disinfects or sterilizes 
  * Resists mildew 
  * Removes or prevents mold 

In addition to these more common claims, there is a very broad range of
products that are also identified as pesticides by FIFRA due to specific terms
used in describing the product. A few examples of these less common claims
are:

  * A door knob claiming to resist bacteria 
  * Socks or shoes that claim antimicrobial properties 
  * A boat or automobile cover claiming to prevent mildew 
  * A mattress claiming to be antibacterial 
  * A dehumidifier claiming to mechanically prevent mold 
  * A pillow case claiming to be resistant to dust mites 
  * A “mildew resistant” shower curtain 

##  Examples of permitted listings

Pesticides and pesticide devices that comply with FIFRA and all applicable
state and local laws, including registration and labeling requirements. To be
eligible for sale in the US, all pesticides must be labeled with a valid EPA
registration number and EPA establishment number, or qualify for one of the
exemptions specified below. Pesticide devices must be labeled with an EPA
establishment number.

##  Examples of prohibited listings

  * Unregistered pesticides (for example, insecticide chalk, tres pasitos) 
  * Pesticide products and pesticide devices sold by non-U.S. residents 
  * Pesticide products not intended for sale in the U.S. (these may look like recognized brands, but they do not have an EPA registration or establishment number) 
  * Pesticide listings without EPA information in the Pesticide Marking attribute 
  * Pesticide devices that were manufactured in a location or facility other than an EPA-registered establishment, that lack a clearly visible EPA establishment number on the label, or that make false or misleading claims 
  * Restricted use pesticides, which are not to be available for purchase or use by the general public 
  * Products labeled for professional use only 
  * Products labeled for use by individuals/firms licensed or registered by the state to apply termiticide products 
  * Products not registered with the EPA and all applicable state and local laws that make a pesticide claim, including those that may be subject to specific state registration requirements, unless subject to one of the limited exclusions below 
  * Pesticide products that make false or misleading claims or are otherwise misbranded (for example, claims regarding the safety of the pesticide or its ingredients, such as “safe”, “non-poisonous", “non-injurious”, “harmless”, “non-toxic”, or “all natural”) 
  * Pesticide products that make public health claims (for example, products marketed to control or mitigate any disease, infection, or pathological condition) 
  * Mosquito repellent bracelets and stickers that are not approved brands per Amazon policy. Approved Brands: Bugables, BugBand, BuggyBands, BuggyBeds, Cliganic, Coleman, Cutter, Evergreen Research, Mosquitno, Mosquito Guard, OFF!, Ortho, Para’Kito, Pic, Repel, RiptGear, Safer Brand, Sawyer, Scentpellent, Summit, Superband, Terro, Thermacell 
  * Pesticide products that are in broken packaging or are being sold in a quantity or amount different from what is listed on the label approved by the EPA 

##  Are any products excluded from EPA registration requirements?

Exclusions from EPA registration requirements are narrow and primarily apply
to:

  * Items treated with a pesticide that has been registered for that use and that do not make any public health claims or pesticide claims beyond preservation of the article itself (see EPA requirements for [ Treated Articles ](https://www.epa.gov/safepestcontrol/consumer-products-treated-pesticides) ) 
  * Pesticide products made exclusively from a specific list of active and inert ingredients and that meet specific labeling and other requirements (see EPA requirements for [ Minimum Risk Pesticides ](https://www.epa.gov/minimum-risk-pesticides/conditions-minimum-risk-pesticides) ) 
  * Human and animal drugs regulated by the U.S. Food and Drug Administration (for more information, go to [ Restricted products: Drugs & drug paraphernalia ](/gp/help/external/200164490) ) 

Please also remember that some pesticides may be hazardous materials and
therefore ineligible for Fulfillment by Amazon. For more information, please
review the [ Dangerous goods identification guide
](/gp/help/external/201003400) .

##  How to apply to sell these products on Amazon

Approval from Amazon is required to sell these products. As per Amazon policy,
**only U.S. residents are eligible to list pesticide products on Amazon.com**
, and must complete a training. For each pesticide product, an EPA
registration must be provided.

**Qualifying to sell pesticides:**  

  1. In Seller Central, select **Inventory** and click **Add a product** . 
  2. Run a search for the ASIN you wish to sell. 
  3. In the search results, click the **Listing limitations apply** link across from the ASIN. 
  4. Click **Request approval** to start the application process. 
  5. Once redirected to Seller University, complete the training with an 80% or higher score. 
  6. Once you have passed the training, click **Continue** from the Results page and click **Exit the course** . 
  7. Once redirected to the application workflow, check the box to agree to the Guaranty and click **Submit** . 

**Remember:** Sellers are required to complete the training prior to listing
pesticides on Amazon. You need only pass this course once. When you have
completed the course, you must provide EPA information for applicable listings
(see below).

##  How to add EPA information to a listing

All listings of pesticides, pesticide devices, or products that make
pesticidal claims require sellers to input a [ Pesticides marking
](/gp/help/external/GLX9EJX844SNJX7J) attribute.

Listings of pesticide products and devices require evidence of an EPA
registration and/or EPA establishment number or a certification that the
product is exempt from EPA regulations.

You must provide a valid EPA registration number or EPA establishment number,
as applicable, for each pesticide or pesticide device listing, or specify that
your product qualifies for an exemption.

Detailed instructions for adding the Pesticide Marking attribute to new or
existing pesticide or pesticide device listings are available on the [
Compliance ID attribute – Pesticide Marking
](/gp/help/external/GLX9EJX844SNJX7J) page.

##  Additional useful information

To learn more about selling or supplying pesticides and pesticide devices
online, the publicly available pesticides eLearning course can be found [ here
](https://pesticide-seller.thinkingcap.com/) , or you can visit the following
links:

  * [ Restricted products ](/gp/help/external/200164330)
  * [ General listing restrictions ](/gp/help/external/201707070)
  * [ Prohibited product claims ](/gp/help/external/G202024200)
  * [ EPA Pesticide Registration Manual ](https://www.epa.gov/pesticide-registration/pesticide-registration-manual)
  * [ EPA's Pesticide Devices: A Guide for Consumers ](https://www.epa.gov/safepestcontrol/pesticide-devices-guide-consumers#2)
  * The full text of [ FIFRA ](https://www.gpo.gov/fdsys/pkg/USCODE-2011-title7/html/USCODE-2011-title7-chap6-subchapII.htm)
  * EPA’s [ summary of FIFRA ](https://www.epa.gov/laws-regulations/summary-federal-insecticide-fungicide-and-rodenticide-act) and guidance on [ Illegal Pesticide Products ](https://www.epa.gov/safepestcontrol/avoid-illegal-household-pesticide-products)
  * EPA Conditions for [ Minimum Risk Pesticides ](https://www.epa.gov/minimum-risk-pesticides/conditions-minimum-risk-pesticides)
  * EPA Requirements for [ Treated Articles ](https://www.epa.gov/safepestcontrol/consumer-products-treated-pesticides)
  * [ Labeling requirements ](https://www.epa.gov/pesticide-registration/labeling-requirements) under FIFRA 

##  Washington State disposable wipes

Beginning July 1, 2023, Washington State will begin prohibiting the sale of
all premoistened wipes marketed as disposable without the "Do Not Flush"
symbol on the display panel of the packaging. This prohibition includes FIFRA
regulated sanitizing, sterilizing, and disinfecting premoistened household and
multi-purpose wipes that are marketed as or intended to be disposable. Wipes
that do not have the "Do Not Flush" symbol on the display panel of the
packaging will not be available for sale into the state of Washington.

Note that this prohibition does not affect wipes marketed as or intended to be
disposable that are labeled "flushable", "sewer safe", "septic safe", or
otherwise indicating that the product can be disposed of in a toilet.

Visit the [ Washington State Legislature Disposable Wipes Products–Labeling
Standards ](https://app.leg.wa.gov/RCW/default.aspx?cite=70A.525&full=true)
page for additional information.

Last updated 31/12/2022

Top

##  Pest control products and pesticides

* [ California Department of Pesticide Regulation (CDPR)  ](/help/hub/reference/external/GX2ZFS3DLL64ULGW)

