# Contact a buyer

Source: https://sellercentral.amazon.com/gp/help/external/GTV8NTY5RM6N9LUN

This article applies to selling in: **United States**

#  Contact a buyer using Buyer-Seller Messages

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGTV8NTY5RM6N9LUN)

The Buyer-Seller Messages page enables you to contact customers when you need
more information to complete an order or to respond to customer service
questions.

If more than one person in your business handles buyer communications, you
will need to enable their email addresses before they can communicate with
your buyers. To enable or block an address, go to the [ Messaging Permissions
page ](/gp/help/external/G201054220) .

On the **Contact Buyer** page, certain contact reasons will be available for
you to select based on the order status and specific product categories.

To contact a buyer, follow these steps:

  1. On the **Orders** tab, select **Manage Orders** . 

  2. Locate the order that you want to contact the buyer about. 

  3. In the **Order Details** column, click the name of the buyer when it is available to open the **Contact Buyer** page. 

  4. Do one of the following: 
    * **Using your seller account:** On the next page, select the contact reason, complete the message, and click **Send** . 
    * **Using your email:** In the **To** field on the Buyer-Seller Messages page, copy the buyer’s encrypted email address. Then go to your email and use this address to contact the buyer. The buyer still won’t be able to see your email address. 
The above steps do not apply to Canceled Orders. For discrepancies or
questions about the cancellation process, the buyer should contact Customer
Service using the Contact Us form.

**Delays:** If your email provider delays sending messages to Amazon, the
Buyer-Seller Messages page will reflect this delay.

**Rejected email:** If you send an email to a buyer that doesn't come from
either your registered Buyer-Seller Messaging email address or from another
approved email address, your message will be rejected. You can resend the
message after you enable the email address you want to use. To enable or block
an address, go to the [ Messaging Permissions page
](/gp/help/external/G201054220) .

Top

##  Contact a buyer using Buyer-Seller Messages

* [ Send attachments to buyers  ](/help/hub/reference/external/GZZRT4RS676QVC6F)
* [ Request a review from a customer  ](/help/hub/reference/external/G698QJEQJZFEXSAT)

