# Inventory Requirements

Source: https://sellercentral.amazon.com/gp/help/external/201100890

This article applies to selling in: **United States**

#  FBA inventory requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201100890)

Learn about requirements for listing, preparing, and sending your FBA
inventory to Amazon fulfillment centers.

[ FBA product title requirements ](/gp/help/external/201051300) |  Learn about
the requirements for creating appropriate product titles for your FBA
listings.  
---|---  
[ Requirements for FBA products sold as new ](/gp/help/external/201147390) |
Learn about the requirements for products sold and fulfilled by Amazon as new
products and the conditions in which these products should not be received at
the fulfillment center.  
[ FBA product barcode requirements ](/gp/help/external/201100910) |  Learn
about the requirements for manufacturer barcode, Amazon barcode, and the FBA
Label Service.  
[ Product packaging requirements ](/gp/help/external/200141500) |  Learn about
the general prep requirements for sending FBA inventory to Amazon fulfillment
centers, as well as the specific product categories that require specialized
prep.  
[ Shipment label requirements ](/gp/help/external/200178470) |  Learn about
the requirements for printing and applying shipment labels to your shipping
boxes.  
[ Shipping and routing requirements ](/gp/help/external/200141510) |  Learn
about the basic shipping requirements for small parcel deliveries and less-
than-truckload and full-truckload shipments to Amazon fulfillment centers.  
[ FBA capacity limits ](/gp/help/external/GAFNWEYTJUV2GBFC) |  Learn how much
inventory you can send to and store at Amazon and how capacity limits apply to
you.  
  
[ Provide box content information ](/gp/help/external/G201967250)

|

Learn how to provide box content information for your shipments to Amazon
fulfillment centers.  
  
Top

##  FBA inventory requirements

* [ Provide box content information  ](/help/hub/reference/external/G201967250)
* [ ](/help/hub/reference/external/G201105770)
* [ Provide box content information through Amazon Marketplace Web Services  ](/help/hub/reference/external/GV2Z3J5T9N72RFC7)
* [ Shipment packing types  ](/help/hub/reference/external/GA8SGUYMN45W5CEU)
* [ FBA product barcode requirements  ](/help/hub/reference/external/G201100910)
* [ Packaging and prep requirements  ](/help/hub/reference/external/G200141500)
* [ Box content information for FBA shipments to Amazon  ](/help/hub/reference/external/G202047840)
* [ Shipment label requirements  ](/help/hub/reference/external/G200178470)
* [ Shipping and routing requirements  ](/help/hub/reference/external/G200141510)
* [ Requirements for FBA products sold as new  ](/help/hub/reference/external/G201147390)
* [ FBA product title requirements  ](/help/hub/reference/external/G201051300)

