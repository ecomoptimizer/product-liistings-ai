# Amazon Renewed Program Policies

Source: https://sellercentral.amazon.com/gp/help/external/GZZVY5QX4DZHWHSW

This article applies to selling in: **United States**

#  Amazon Renewed Program Policies

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZZVY5QX4DZHWHSW)

On this page

Application

Renewed referral fees

Catalog requirements

Listing restrictions

Renewed Premium

The Amazon Renewed Guarantee

Pricing

Product Quality Assurance

These terms apply to your ongoing participation and application to the Amazon
Renewed program.

##  Application

You must be able to meet our requirements to qualify as a seller of products
in the Renewed program. Learn more and apply for participation [ here
](/gp/help/external/G201648580) .

##  Renewed referral fees

If your selling on Amazon account is accepted in Amazon Renewed, an additional
Renewed Program fee will be added to the fees described in the [ Selling on
Amazon Fee Schedule ](/gp/help/external/G200336920) . This additional fee
applies only to Renewed product sales associated with your account and differs
by category:

  * Renewed cell phone devices and unlocked cell phones will be charged 2% on top of standard category referral fees. 
  * All other Renewed products will be charged 1% on top of standard category referral fees. 

##  Catalog requirements

Renewed sellers must comply with the following Renewed catalog requirements in
addition to the [ Product detail page rules ](/gp/help/external/200390640) :

####  Renewed Product Listing

  * Renewed products must be listed under the original brand of the product offered. You cannot use your seller name under the product’s brand attribute. 
  * You are not allowed to include references to a seller name or a seller brand on the Product Listing (detail) page. This applies to the main content as well as the product title, description, bullet points, pictures, or any other place on the detail page. Content will only contain references to the original brand of the product. 
  * Listing in bundles (such as a mobile device with a protective case) is not permitted. 

####  Renewed ASIN Creation

  * You are not allowed to create multiple ASINs for the same Renewed product. 
  * To create a Renewed ASIN you will use the Renewed ASIN Creation tool.  When an equivalent New ASIN is not available and requires you to create a new Renewed ASIN manually, you must indicate the term “(Renewed)” in parentheses in the suffix of the title  . 
  * You are not allowed to create new Renewed Apple ASINs. If you need a Renewed Apple ASIN that is not already in the Renewed Catalog, you must request creation through Renewed Selling Partner Support. 

##  Listing restrictions

All Renewed products must be capable of being repaired/refurbished and tested
to look and work like new in accordance with our Global Quality Policy.
Repair/refurbish capability means that products must have electrical or
mechanical components that can be replaced or upgraded to new or like-new
condition.

To ensure a positive customer experience, Amazon will remove any products from
Amazon Renewed that are not capable of being repaired/refurbished, pose a
hygienic or safety risk, or violate any other Amazon policies.

The following is a list of permitted products:

  * Air conditioners 
  * Audio receivers and amplifiers 
  * Audio video selectors 
  * Automotive parts: 
    * Alternators 
    * Carburetors 
    * Control modules 
    * Other modules 
    * Pumps 
    * Fuel injectors 
    * Generators 
    * Regulators 
    * Ring and pinion 
    * Sensors 
    * Shock absorber 
    * Starter 
    * Motors 
    * Torque converters 
    * Valves 
  * Blu-ray and DVD players 
  * Cameras 
  * Car stereos, security, video, and radar detectors 
  * Chain saws, pole saws, and log splitters 
  * Chippers, shredders, and mulchers 
  * Computer internal hard drives 
  * Connected home modules 
  * Dehumidifiers 
  * Digital antennas 
  * Digital musical instruments 
  * Digital picture frames 
  * Docking stations 
  * Drones 
  * Electric ceiling fans 
  * Electrical floor cleaning devices 
  * Electric household window fans 
  * Embroidery machines 
  * External hard drives 
  * External solid state drives 
  * Exercise bikes 
  * Fitness machines 
  * Fitness watches 
  * Generators 
  * Gimbal stabilizers 
  * GPS devices 
  * Graphing and scientific calculators 
  * Headphones 
  * Headsets 
  * Hobby RC quadcopters and multirotors 
  * Space heaters 
  * Home stereo equipment 
  * Home theater systems 
  * Irons 
  * Electric kitchen appliances 
  * Powered lawn mowers, hedge trimmers and edgers 
  * Media players 
  * Microphones 
  * Monitors 
  * Outdoor blowers and vacs 
  * Personal computers (PC) 
  * PC graphics cards 
  * PC keyboards, mice, game pads, and webcams 
  * PC motherboards 
  * PC digital internal power supply 
  * PC processors 
  * PC servers 
  * PC monitors 
  * Routers 
  * Modems 
  * Cell phone devices 
  * Pneumatic tools 
  * Portable media players 
  * Power tools, power drills, and power saws 
  * Pressure washers 
  * Printers 
  * Professional video stabilizers 
  * Projectors 
  * Refrigerators 
  * Scanners 
  * Security cameras and systems 
  * Sewing machines 
  * Shredders 
  * Smartwatches 
  * Snow throwers 
  * Sound and recording equipment 
  * Sound bars 
  * Speakers 
  * Tablets 
  * Televisions 
  * Thermostats 
  * Universal remote controls 
  * Vacuums 
  * Video cameras 
  * Video game consoles and controllers 
  * Virtual reality headsets 

##  Renewed Premium

Renewed Premium is a tier of renewed products that delivers an outstanding
experience to our customers by offering like-new products, with a one-year
warranty and a battery capacity of 90% and above (when applicable), all in
deluxe, OEM or renewed-branded packaging. To qualify to the Renewed Premium
program, you must meet all the requirements of the Renewed program, confirm
that you understand and acknowledge the [ Renewed Premium Quality Policy
](/gp/help/external/G202190320) , and your Renewed seller account must be in
good standing. [ Learn more ](/gp/help/external/G201648580) and apply today
for Renewed Premium.

##  The Amazon Renewed Guarantee

All Renewed products will be covered by the Amazon Renewed Guarantee and you
will be responsible for any claims under the Guarantee.

To learn more, go to [ Amazon Renewed Quality policy
](/gp/help/external/G202190320) .

##  Pricing

Customers expect Renewed products to cost less than their New equivalents.
Renewed products must be priced with a minimum 5% discount from the currently
priced New ASIN equivalents on Amazon.

The following actions may be taken on Renewed offers that are priced at a
smaller discount or are priced higher than New equivalents:

  * Ineligibility to be the featured offer on the product detail page. 
  * Removal from the Amazon Renewed catalog. 
  * Permanent loss of selling privileges for the relevant ASINs. 

We will send you one or more warning messages before we revoke your selling
privileges for those ASINs.

##  Product Quality Assurance

Renewed products must fully adhere to the [ Renewed Product Quality Policy
](/gp/help/external/G202190320) and must be inspected, repaired (if
applicable), cleaned, and tested to meet original manufacturer specifications.
Amazon frequently assesses product quality through test buys and customer
feedback.  If performance does not meet our criteria, we reserve the right to
remove selling privileges.

Top

