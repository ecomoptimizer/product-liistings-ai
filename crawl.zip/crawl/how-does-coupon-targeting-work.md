# How does coupon targeting work

Source: https://sellercentral.amazon.com/gp/help/external/G202189390

This article applies to selling in: **United States**

#  How does coupon targeting work?

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202189390)

Targeting helps you limit the audience of your coupons. For example, if you
select Amazon Prime customers as the targeted segment, only Prime customers
will see your coupon offering on the product detail page and in their carts.

**Note:** When you target a coupon to a customer segment other than "All
Customers," the orange coupon badge will not appear in the search results, for
any customer.

Top

