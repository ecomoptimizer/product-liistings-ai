# Policies, agreements, and guidelines

Source: https://sellercentral.amazon.com/help/hub/reference/external/GSNV3657R94YP9DZ

This article applies to selling in: **United States**

#  Policies, agreements, and guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGSNV3657R94YP9DZ)

Top

* [ Amazon Services Business Solutions Agreement  ](/help/hub/reference/external/G1791)
* [ Changes to the Amazon Services Business Solutions Agreement  ](/help/hub/reference/external/G47071)
* [ Program Policies  ](/help/hub/reference/external/G521)
* [ Changes to program policies  ](/help/hub/reference/external/GQHQGBTD7XB7EECN)
* [ Intellectual Property for Rights Owners  ](/help/hub/reference/external/GU5SQCEKADDAQRLZ)
* [ International selling agreements  ](/help/hub/reference/external/GEENGDB2JGLEK3PZ)
* [ Additional Guidelines  ](/help/hub/reference/external/G69G3YF8A6VG7C2Y)
* [ About seller facial data  ](/help/hub/reference/external/GVQRRK8ZNHUVNQ6Y)
* [ Use of business credit reports  ](/help/hub/reference/external/G6TS99MYVGUEAKJW)

