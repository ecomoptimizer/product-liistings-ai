# Invalid URL format error

Source: https://sellercentral.amazon.com/gp/help/external/30601

This article applies to selling in: **United States**

#  Error 15

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F30601)

We were unable to download the image because the image URL is not in a valid
format. An example of a correctly formatted image URL is:
http://www.domain.com/directory/image-file.jpg.

To correct this error, submit the image URL in a standard format, based on
this example: http://www.domain.com/directory/image-file.jpg.

**Note:**

  * An image file suffix of .gif or .jpg is not required, but is preferred. 
  * You can use http, but not https, ftp, or "file" protocols. 
  * Avoid spaces and non-alphanumeric characters such as $, ?, @, &, and so on. 

Top

