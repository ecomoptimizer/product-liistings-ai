# Amazon policies

Source: https://sellercentral.amazon.com/gp/help/external/help-page.html?itemID=521&language=en_US&ref=efph_521_bred_G200164330

This article applies to selling in: **United States**

#  Program Policies

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F521%3Fref%3Defph_521_bred_G200164330%26locale%3Den-
US)

On this page

General Policies

Intellectual Property

Product and Listing Requirements

Shipping

Tax

Optional Programs

The products you offer for sale on Amazon must comply with your [ seller
agreement ](/gp/help/external/G1791) , including all applicable Amazon
policies, and all applicable laws and regulations. Before listing products,
make sure that you understand all your responsibilities as a seller.

##  General Policies

  * [ Amazon Seller Code of Conduct ](/gp/help/external/G1801)
  * [ Communication Guidelines ](/gp/help/external/G1701)
  * [ Conditions of Use ](/gp/help/external/G201824360)
  * [ Customer Product Reviews Policies ](/gp/help/external/GYRKB5RU3FS5TURN)
  * [ Account Health Rating ](/gp/help/external/G200205250)
  * [ Referral Fees Reimbursement Policy ](/gp/help/external/GRRJCFXD6474GRLY?locale=en-US)
  * [ Standards for Brands Selling in the Amazon Store ](/gp/help/external/G201797950)
  * [ Supply Chain Standards ](/gp/help/external/G202111990)
  * [ Amazon Services Provider – Program Policies ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=%2Fgp%2Fhelp%2FG9GPDWV663AD4USD&locale=en-US)
  * [ A-to-z Claims Process for Property Damage and Personal Injury ](/gp/help/external/GTY6NYZDFD5CENYH?locale=en-US)

##  Intellectual Property

  * [ Amazon Anti-Counterfeiting Policy ](/gp/help/external/G201165970)
  * [ Amazon Intellectual Property Policy ](/gp/help/external/G201361070)
  * [ Trademark Usage Guidelines ](/gp/help/external/G200573210)
  * [ Unsuitable inventory investigations policy ](/gp/help/external/GH4YYXNDRW9BSZEN)

##  Product and Listing Requirements

  * [ Amazon Marketplace Fair Pricing Policy ](/gp/help/external/G5TUVJKZHUVMN77V)
  * [ Amazon Policy on Reference Prices ](/gp/help/external/G202170370)
  * [ ASIN creation policy ](/gp/help/external/G201844590)
  * [ Category and Product Restrictions ](/gp/help/external/G200301050)
  * [ Product Detail Page Rules ](/gp/help/external/G200390640)
  * [ Product Guidelines ](/gp/help/external/G11621)
  * [ Prohibited Product Claims ](/gp/help/external/G202024200)
  * [ Restricted Products Policy ](/gp/help/external/G200164330)

##  Shipping

  * [ Fulfillment by Amazon (FBA) Policies ](/gp/help/external/G201030350)
  * [ Drop Shipping Policy ](/gp/help/external/G201808410)
  * [ Dangerous Goods policy for seller-fulfilled products ](/gp/help/external/GN4SW35Y4KXHX8BT)

##  Tax

  * [ E.U. Value Added Tax (VAT) Registration Agreement ](/gp/help/external/G201190460)
  * [ Tax Calculation Service Terms ](/gp/help/external/G200787220)
  * [ Tax policies ](/gp/help/external/G200405820)
  * [ Taxes and regulations with Amazon Global Selling ](/gp/help/external/G201468380)

##  Optional Programs

If you participate in any optional program, the terms of that optional program
will apply.

  * [ Amazon Accelerator ](/gp/help/external/G52NQJE353XZGWN7?locale=en-US)
  * [ Amazon Brand Analytics Terms and Conditions ](/gp/help/external/GM3JKB2JPVWPVUZC)
  * [ Amazon Currency Converter for Sellers Terms and Conditions ](/gp/help/external/G200371640)
  * [ Amazon Imaging Services Terms and Conditions ](/gp/help/external/GLB92H2ZXTHU95HH)
  * [ Amazon Launchpad Program Terms ](/gp/help/external/G202007390)
  * [ Amazon Renewed Program Policies ](/gp/help/external/GZZVY5QX4DZHWHSW?locale=en-US)
  * [ Amazon Renewed Global Quality Policy ](/gp/help/external/G202190320)
  * [ Amazon Renewed Guarantee ](/gp/help/external/GU8UPULLWR2TDVVN?locale=en-US)
  * [ Amazon Vine Terms and Conditions ](/gp/help/external/G3MB5C56WDZZXHBG?locale=en-US)
  * [ Buy Shipping Services Terms and Conditions ](/gp/help/external/G200672320)
  * [ Coupons T&Cs ](/gp/help/external/J6T3TD3ULSDP9KV)
  * [ Customization Program Terms for Sellers ](/gp/help/external/G201823150)
  * [ Amazon Brand Referral Bonus Terms and Conditions ](/gp/help/external/GKPK6UXEUARLBX9Z?locale=en-US)
  * FBA 
    * [ Amazon Partnered Carrier Program ](/gp/help/external/G201119120)
    * [ FBA customer returns policy ](/gp/help/external/G200379860)
    * [ FBA customer service policy ](/gp/help/external/G200298130)
    * [ FBA Dangerous Goods (Hazmat) Terms and Conditions ](/gp/help/external/GYS2KBEE7MYVCGE3)
    * [ FBA Export ](/gp/help/external/G200149570)
    * [ FBA Inventory Placement Terms and Conditions ](/gp/help/external/G200943420)
    * [ FBA inventory requirements ](/gp/help/external/G201100890)
    * [ FBA lost and damaged inventory policy ](/gp/help/external/G200213130)
    * [ FBA product requirements and restrictions ](/gp/help/external/G200140860)
    * [ FBA Small and Light Terms and Conditions ](/gp/help/external/GZKHKFS7YLKWR5CC)
    * [ FBA Subscribe & Save Terms and Conditions ](/gp/help/external/G201620160)
    * [ Multi-Channel Fulfillment ](/gp/help/external/G200332450)
    * [ Lab Central Program Policy ](/gp/help/external/GFUQMPCZZCJ5S34E?locale=en-US)
  * Amazon Explore 
    * [ Amazon Explore Terms and Conditions ](/gp/help/external/GBUV7WZS6Z4XUW3N?locale=en-US)
    * [ Amazon Explore prohibited items ](/gp/help/external/GWLCZDZNJ7YMZNYY?locale=en-US)
    * [ Amazon Explore cancellation policy for sellers ](/gp/help/external/GBU4LH5C2MC2VJ4Y?locale=en-US)
    * [ Amazon Explore GDPR Data Processing Addendum ](/gp/help/external/G2YVG6AZ9XCRSVTF?locale=en-US)
    * [ Amazon Explore Third Party Terms of Use ](https://www.amazon.com/gp/help/customer/display.html?nodeId=GM9J7DAPZ9NKDLRZ)
  * [ Fine Jewelry Terms and Conditions ](/gp/help/external/G201622250)
  * [ Get Paid Faster Service Terms for Invoiced Orders ](/gp/help/external/G5DA4FB5YD6PD5PX)
  * [ Amazon Handmade: Terms and Conditions ](/gp/help/external/G201817290)
  * [ Home & Business Services: Service Level Requirements & Metrics ](/gp/help/external/G202043250)
  * [ Express Payout Service Terms for Sellers ](/gp/help/external/GHRCBB7RE3HSLGHC?locale=en-US)
  * [ Deals ](/gp/help/external/G202043110)
  * [ Policies and guidance for Prime Now sellers ](/gp/help/external/G85BNYWWX8R3HYLW)
  * [ Premium Shipping ](/gp/help/external/G201503640)
  * [ Prime Launches program terms ](/gp/help/external/GBJGLGMYML2BRNGV)
  * [ Pro Merchant Insurance Requirements ](/gp/help/external/G200386300)
  * [ Seller Fulfilled Prime ](/gp/help/external/G201812270)
  * [ Selling Services on Amazon Policies ](/gp/help/external/G201840340)
  * [ Selling Services Terms ](/gp/help/external/G201484410)
  * [ Ship-to-Store Policies ](/gp/help/external/GUZWLQKEGJW4QCK)
  * [ Ship-to-Store Terms ](/gp/help/external/HV3AEGYL9VHKGUQ)
  * [ Subscribe with Amazon Physical Subscription Agreement ](/gp/help/external/G22KGLCTBLGQB2SV)
  * [ Subscribe With Amazon Program Agreement ](/gp/help/external/G202072540)
  * [ Textbook Rental Policy ](/gp/help/external/G201962800)
  * [ Using Hyperwallet with Amazon/Amazon Currency Converter ](/gp/help/external/G7S55VWDZ9SQCUEX)

Top

##  Program Policies

* [ Account Health Rating program policy  ](/help/hub/reference/external/G200205250?ref=efph_521_bred_G200164330&locale=en-US)
* [ FBA inventory reimbursement policy  ](/help/hub/reference/external/G200213130?ref=efph_521_bred_G200164330&locale=en-US)
* [ Unsuitable inventory investigations policy  ](/help/hub/reference/external/GH4YYXNDRW9BSZEN?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Business invoicing policy  ](/help/hub/reference/external/GHTQ5U9J25GBF5YB?ref=efph_521_bred_G200164330&locale=en-US)
* [ U.S. Income Reporting & Tax Identity Collection FAQ  ](/help/hub/reference/external/G200663290?ref=efph_521_bred_G200164330&locale=en-US)
* [ ASIN creation policy  ](/help/hub/reference/external/G201844590?ref=efph_521_bred_G200164330&locale=en-US)
* [ Selling on Amazon fee schedule  ](/help/hub/reference/external/G200336920?ref=efph_521_bred_G200164330&locale=en-US)
* [ Product guidelines  ](/help/hub/reference/external/G11621?ref=efph_521_bred_G200164330&locale=en-US)
* [ Convenience Store Payment Service Terms of Use  ](/help/hub/reference/external/G200371490?ref=efph_521_bred_G200164330&locale=en-US)
* [ Product safety alerts, recalls, stop sales, and market withdrawal policy for sellers  ](/help/hub/reference/external/GRD4EMBNNW3P47GH?ref=efph_521_bred_G200164330&locale=en-US)
* [ Customization Program Terms for Sellers  ](/help/hub/reference/external/G201823150?ref=efph_521_bred_G200164330&locale=en-US)
* [ Important information for international sellers  ](/help/hub/reference/external/G200404870?ref=efph_521_bred_G200164330&locale=en-US)
* [ Countries accepted for seller registration  ](/help/hub/reference/external/G200405020?ref=efph_521_bred_G200164330&locale=en-US)
* [ Guidelines for use of the Available at Amazon Badge by Sellers  ](/help/hub/reference/external/G200573210?ref=efph_521_bred_G200164330&locale=en-US)
* [ Intellectual Property Policy for Sellers  ](/help/hub/reference/external/G201361070?ref=efph_521_bred_G200164330&locale=en-US)
* [ Report a Violation  ](/help/hub/reference/external/G200444420?ref=efph_521_bred_G200164330&locale=en-US)
* [ Parallel Imported Products  ](/help/hub/reference/external/G200936440?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Anti-Counterfeiting Policy  ](/help/hub/reference/external/G201165970?ref=efph_521_bred_G200164330&locale=en-US)
* [ Communication Guidelines  ](/help/hub/reference/external/G1701?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Currency Converter for Sellers Terms and Conditions  ](/help/hub/reference/external/G200371640?ref=efph_521_bred_G200164330&locale=en-US)
* [ Tax policies  ](/help/hub/reference/external/G200405820?ref=efph_521_bred_G200164330&locale=en-US)
* [ Supply Chain Standards  ](/help/hub/reference/external/G202111990?ref=efph_521_bred_G200164330&locale=en-US)
* [ Consumption Tax Indication  ](/help/hub/reference/external/G201440180?ref=efph_521_bred_G200164330&locale=en-US)
* [ Standards for Brands Selling in the Amazon Store  ](/help/hub/reference/external/G201797950?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Imaging Services Terms and Conditions  ](/help/hub/reference/external/GLB92H2ZXTHU95HH?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Points Services Terms and Conditions  ](/help/hub/reference/external/G201647680?ref=efph_521_bred_G200164330&locale=en-US)
* [ Tax Registration Agreement (VAT or GST)  ](/help/hub/reference/external/G30394?ref=efph_521_bred_G200164330&locale=en-US)
* [ E.U. Value Added Tax (EU VAT) Registration Agreement  ](/help/hub/reference/external/G201190460?ref=efph_521_bred_G200164330&locale=en-US)
* [ Fulfillment by Amazon Policies and Requirements  ](/help/hub/reference/external/G53911?ref=efph_521_bred_G200164330&locale=en-US)
* [ Cash On Delivery terms of use  ](/help/hub/reference/external/G200796940?ref=efph_521_bred_G200164330&locale=en-US)
* [ Pay by Invoice Policies  ](/help/hub/reference/external/G202105160?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Launchpad Program Terms  ](/help/hub/reference/external/G202007390?ref=efph_521_bred_G200164330&locale=en-US)
* [ Selling Services Terms  ](/help/hub/reference/external/G201484410?ref=efph_521_bred_G200164330&locale=en-US)
* [ Textbook Rental Policy  ](/help/hub/reference/external/G201962800?ref=efph_521_bred_G200164330&locale=en-US)
* [ Fine Jewelry Terms and Conditions  ](/help/hub/reference/external/G201622250?ref=efph_521_bred_G200164330&locale=en-US)
* [ FBA Inventory Placement Service Terms and Conditions  ](/help/hub/reference/external/G200943420?ref=efph_521_bred_G200164330&locale=en-US)
* [ Selling Services on Amazon Policies  ](/help/hub/reference/external/G201840340?ref=efph_521_bred_G200164330&locale=en-US)
* [ Subscribe With Amazon Program Agreement  ](/help/hub/reference/external/G202072540?ref=efph_521_bred_G200164330&locale=en-US)
* [ Tax Calculation Services Terms  ](/help/hub/reference/external/G200787220?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Renewed Quality policy  ](/help/hub/reference/external/G202190320?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Renewed Program Policies  ](/help/hub/reference/external/GZZVY5QX4DZHWHSW?ref=efph_521_bred_G200164330&locale=en-US)
* [ Seller Fee Tax Invoice  ](/help/hub/reference/external/G202162720?ref=efph_521_bred_G200164330&locale=en-US)
* [ Important information for international sellers  ](/help/hub/reference/external/G202168490?ref=efph_521_bred_G200164330&locale=en-US)
* [ Get Paid Faster Service Terms for Invoiced Orders  ](/help/hub/reference/external/G202192350?ref=efph_521_bred_G200164330&locale=en-US)
* [ FBA Dangerous Goods Program Terms and Conditions  ](/help/hub/reference/external/GYS2KBEE7MYVCGE3?ref=efph_521_bred_G200164330&locale=en-US)
* [ Prime Launches program terms  ](/help/hub/reference/external/GBJGLGMYML2BRNGV?ref=efph_521_bred_G200164330&locale=en-US)
* [ Get Paid Faster service terms for invoiced orders  ](/help/hub/reference/external/G5DA4FB5YD6PD5PX?ref=efph_521_bred_G200164330&locale=en-US)
* [ Ship-to-Store Terms  ](/help/hub/reference/external/GHV3AEGYL9VHKGUQ?ref=efph_521_bred_G200164330&locale=en-US)
* [ Ship-to-Store Policies  ](/help/hub/reference/external/GGUZWLQKEGJW4QCK?ref=efph_521_bred_G200164330&locale=en-US)
* [ Customer product reviews policies  ](/help/hub/reference/external/GYRKB5RU3FS5TURN?ref=efph_521_bred_G200164330&locale=en-US)
* [ EU Geo-blocking regulation  ](/help/hub/reference/external/G4QVDR2M6RV4NP5W?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Brand Analytics Terms and Conditions  ](/help/hub/reference/external/GM3JKB2JPVWPVUZC?ref=efph_521_bred_G200164330&locale=en-US)
* [ Additional policies and guidance for Prime Now sellers  ](/help/hub/reference/external/G85BNYWWX8R3HYLW?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Vine Terms and Conditions  ](/help/hub/reference/external/G3MB5C56WDZZXHBG?ref=efph_521_bred_G200164330&locale=en-US)
* [ Referral fees reimbursement policy  ](/help/hub/reference/external/GRRJCFXD6474GRLY?ref=efph_521_bred_G200164330&locale=en-US)
* [ Customer Service by Amazon Terms & Conditions  ](/help/hub/reference/external/G65T4N3XGC3MJB38?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Services Provider – Program Policies  ](/help/hub/reference/external/G9GPDWV663AD4USD?ref=efph_521_bred_G200164330&locale=en-US)
* [ Selling on Amazon fees guide  ](/help/hub/reference/external/G6F7CN3EQS7MEGCN?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Accelerator  ](/help/hub/reference/external/G52NQJE353XZGWN7?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Brand Referral Bonus Terms and Conditions  ](/help/hub/reference/external/GKPK6UXEUARLBX9Z?ref=efph_521_bred_G200164330&locale=en-US)
* [ A-to-z Claims Process for Property Damage and Personal Injury  ](/help/hub/reference/external/GTY6NYZDFD5CENYH?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Services Provider – program policies  ](/help/hub/reference/external/GFJV7WJSANEJ6MJ4?ref=efph_521_bred_G200164330&locale=en-US)
* [ Local Selling Program Policies  ](/help/hub/reference/external/GALGRJ45NC438BPK?ref=efph_521_bred_G200164330&locale=en-US)
* [ Local Selling Terms  ](/help/hub/reference/external/GUGFQ9HS2JBLN7XZ?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Generic Product Policy  ](/help/hub/reference/external/G84H3T69ZX762NWT?ref=efph_521_bred_G200164330&locale=en-US)
* [ Lab Central Program Policy  ](/help/hub/reference/external/GFUQMPCZZCJ5S34E?ref=efph_521_bred_G200164330&locale=en-US)
* [ Black-Owned Business badge  ](/help/hub/reference/external/GBYJYA8MG6FV4XYC?ref=efph_521_bred_G200164330&locale=en-US)
* [ Amazon Warehousing and Distribution terms and conditions  ](/help/hub/reference/external/GHV89YC29VWN6SBM?ref=efph_521_bred_G200164330&locale=en-US)
* [ Dangerous Goods policy for seller-fulfilled products  ](/help/hub/reference/external/GN4SW35Y4KXHX8BT?ref=efph_521_bred_G200164330&locale=en-US)

