# Novelty SKU Limits

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> For all Novelty sellers who have an inventory SKU limit assigned to their account, the cap is 2 million active non-media SKUs.

---
## Novelty SKU Limits

For all Novelty sellers who have an inventory SKU limit assigned to their account, the cap is 2 million active non-media SKUs.

You can monitor your SKU count using data provided in the **Business Reports** section of your Seller Central account. The "By Date - Sales and Traffic" report includes an "Average Offer Count" column with your total active SKUs for each day. The count includes both media and non-media products. Media products include books, music, video, DVD, software, and video games. To get the count for active non-media SKUs, subtract your media SKUs from the total in the report.

Additionally, the High-Volume Listing Fee will apply to all sellers, including Novelty sellers, who have more than 100,000 active non-media SKUs. For more information on how we identify active SKUs and calculate the fee, see the [Selling on Amazon Schedule of Fees](https://sellercentral.amazon.com/gp/help/200336920).

Top

Was this article helpful?
