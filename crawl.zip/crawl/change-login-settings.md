# Change login settings

Source: https://sellercentral.amazon.com/gp/help/external/G831

This article applies to selling in: **United States**

#  Change login settings

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG831)

To change your account email address , follow these steps:

  

  1. In your seller account, go to **Settings** and click [ Login Settings ](/gp/seller/configuration/login-settings.html/) . 
  2. Click **Edit** next to the **Email** field to bring up the **Change Email** form. 
  3. Enter your new email address, re-enter your new email address, and enter your password in the fields where indicated. 
  4. Click **Save Changes** . 

To change your account password, follow these steps:

  

  1. In your seller account, go to **Settings** and click [ Login Settings ](/gp/seller/configuration/login-settings.html/) . 
  2. Click **Edit** next to the **Password** field to bring up the **Change Password** form. 
  3. Enter your current password, enter your new password, and re-enter your new password in the fields where indicated. 
  4. Click **Save Changes** . 

If you have two-step verification enabled, we might require you to enter a
security code to make changes to your Advanced Security Settings.  Learn more
about [ two-step verification ](/gp/help/external/202110760) .

##  See also

[ Choose a Strong Password
](https://www.amazon.com/gp/help/customer/display.html?nodeId=10412241)

Top

