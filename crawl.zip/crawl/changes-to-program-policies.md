# Changes to program policies

Source: https://sellercentral.amazon.com/help/hub/reference/external/GQHQGBTD7XB7EECN

This article applies to selling in: **United States**

#  Changes to program policies

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGQHQGBTD7XB7EECN)

On this page

Changes to program policies 2023 - US

New policy: Magnet products

New policy: Button cell and coin batteries

Update to Drop Shipping Policy

Express Payout Program Policy

Update to Amazon Supply Chain Standards

Updates to the Merchant Fulfillment API service terms

New policy: corded window coverings

Updates to the FBA inventory reimbursement policy for fulfillment center
operations claims

New policy: Amazon Warehousing and Distribution

New MFN meltable product shipping policy

New policy: Express Payouts

Updates to the Commercial Liability Insurance program policy

Updates to fee category names

Updates to product safety alerts, recalls, stop sales, and market withdrawal
policy for sellers

Updates to Monitor Your Account Health policy and expansion of the Account
Health Rating policy

Updates to Adult Products Policies

Update to the FBA inventory reimbursement policy

Updates to the commercial liability insurance program policy

Update to policy for shipment of dangerous goods in limited quantities

Update on countries accepted for seller registration

Introducing fee category guidelines

New policy: Strike anywhere matches

Referral fees reimbursement policy

Free returns on Fashion items for seller-fulfilled orders

Upcoming changes to program policies

Upcoming changes to program policies

Update to selling services terms and policies – September 2020

Update to communication guidelines

Update to restricted products policy

Sold by Amazon terms and conditions

Amazon Vine legal entity change

Update to tax policies

Referral fees reimbursement policy

##  Changes to program policies 2023 - US

Listed below are upcoming changes to Amazon’s program policies.

##  New policy: Magnet products

The US Consumer Product Safety Commission launched a new Safety Standard for
Magnets (Magnets Rule) on November 15, 2022. The Magnets Rule contains
requirements to reduce the risk of death or injury to consumers who ingest one
or more small, high-powered magnets.

Amazon requires selling partners to comply with this rule and will begin
requiring selling partners to submit safety and compliance documentation for
new listings and existing listings on March 23, 2023.

For more information, go to [ Magnet products
](/gp/help/external/GXDAVVP3RBLKV4GP) .

##  New policy: Button cell and coin batteries

Last August, the United States Congress passed Reese's Law, containing
requirements to eliminate or reduce the risk of harm from battery ingestion by
children six years of age or younger. This law applies to any product
manufactured after February 12, 2023.

Amazon requires selling partners to comply with this regulation and will begin
requiring selling partners to submit safety and compliance documentation for
new listings and existing listings by March 2, 2023.

For more information, go to [ Reese’s Law
](https://www.congress.gov/bill/117th-congress/house-bill/5313) and the [
Button cell and coin batteries help page ](/gp/help/external/GUBLQYWAJDBADUVK)
.

##  Update to Drop Shipping Policy

Effective March 13, 2023, we are updating our Drop Shipping Policy page to
provide additional details about our existing policy and help you adhere to
the guidelines. We have updated our examples of drop shipping policy
violations and have added additional requirements needed to fulfill orders
using a drop shipper.

For more information, go to [ Drop Shipping Policy
](/gp/help/external/G201808410)

Listed below are upcoming changes to Amazon’s program policies.

##  Express Payout Program Policy

Effective February 15, 2023, we will expand Express Payouts to offer Express
Payout (Visa Debit Card) in addition to Express Payout (Bank Account) launched
in 2022. With Express Payout (Visa Debit Card), a seller will receive payout
deposits within 24 hours. In order to enroll in Express Payout (Visa Debit
Card), a seller must set their Visa debit card as their primary deposit
method. Debit card eligibility criteria and more information about our 24-hour
program may be found via our [ Express Payout FAQ
](/gp/help/external/GA24UN79VBPKXZXX) and [ Express Payout Policy.
](/gp/help/external/GHRCBB7RE3HSLGHC#Section2)

##  Update to Amazon Supply Chain Standards

We’ve updated our Supply Chain Standards, which take effect on January 19,
2023. These standards are updated every three years as part of a regular
review.

Our Supply Chain Standards apply to all selling partners and suppliers.
Products sold in Amazon stores must comply with these standards and be
produced in a way that respects human rights and the environment and protects
the fundamental dignity of workers.

The updates include additional requirements, expectations, and clarifications,
such as:

  * Additional requirements to protect workers from harmful recruitment and engagement practices, which include providing workers with clear, understandable documentation of the employment terms and conditions before the start of their employment 
  * Further clarification that suppliers must have effective grievance mechanisms that workers can use to raise concerns without retaliation 
  * Mandatory remediation if any cases of child labor are identified 
  * Further clarification that suppliers must provide workers with a safe and healthy work environment that avoids harm to workers' health 
  * The prohibition of land-grabbing and any illegal use of natural resources 
  * Clearer specifications that suppliers must comply with applicable privacy and information security laws and regulations 

To learn more, review the updated [ Amazon Supply Chain Standards
](http://amzn.to/supply-chain-standards) .

##  Updates to the Merchant Fulfillment API service terms

Beginning on December 30, 2022, the Merchant Fulfillment API service terms
will have the following updates applied:  

  1. Prohibit the charging of certain fees for use or access to the Merchant Fulfillment API. 
  2. Limit certain modifications to the content obtained through the Merchant Fulfillment API. 
  3. Require communication of certain notices to end users. 
  4. Define the acceptable use cases for access to the Merchant Fulfillment API. 

For more information, see [ Merchant Fulfillment API service terms
](/help/hub/reference/external/G202123940) .

##  New policy: corded window coverings

In an effort to reduce the risk of strangulation deaths and serious life-
threatening injuries to children from corded window coverings, the U.S.
Consumer Product Safety Commission (CPSC) voted to approve a new federal
safety standard for operating cords on custom window coverings. Amazon will
launch a policy on November 25, 2022 requiring all stock corded window
coverings have been tested to and comply with the new standard.

##  Updates to the FBA inventory reimbursement policy for fulfillment center
operations claims

Effective November 11, 2022, we are changing the FBA inventory reimbursement
policy to update how we calculate reimbursement value for fulfillment center
operations claims for items that are in an unsellable condition at the time
they are lost or damaged. For unsellable items, Amazon will reimburse you at a
valuation consistent with the estimated proceeds of the discounted sale of the
unit. For more information, go to the [ FBA inventory reimbursement policy
](/gp/help/external/G200213130) .

##  New policy: Amazon Warehousing and Distribution

The Amazon Warehousing and Distribution terms and conditions will be added to
the Change to program policies page on November 15, 2022.

##  New MFN meltable product shipping policy

To ensure a positive customer experience, Amazon is implementing a policy on
seller-fulfilled products identified as meltable. **Meltable** refers to all
heat-sensitive products, including but not limited to chocolate, power bars,
gummies, and select jelly- and wax-based products.

As of September 21, 2022, all sellers must take precautions to ensure meltable
products are received in satisfactory condition by the customer at all times.
If a seller has received multiple melted product complaints, we may terminate
corresponding offers and suspend or terminate your Amazon selling account (and
any related accounts).

Amazon products must maintain quality standards when exposed to high
temperatures (75 to 155°F) to ensure a positive customer experience. This
temperature range is set to protect product integrity during product storage
and shipping.

##  New policy: Express Payouts

The [ Express Payout terms and conditions
](/gp/help/external/GHRCBB7RE3HSLGHC) page will be added to the Program
Policies page on September 14, 2022.

##  Updates to the Commercial Liability Insurance program policy

We will no longer be making changes to our [ Commercial Liability Insurance
program policy
](https://sellercentral.amazon.com/help/hub/reference/external/G200386300)
that we previously posted on June 13, 2022 with an effective date of August 1,
2022. On August 15, 2022, our commercial liability insurance program policy
will be updated with the following changes:

  * We have removed the restriction on policies with no deductibles for sellers with gross proceeds of less than $1 million. 
  * We have reinstated our previous requirement stating that deductibles for any policy(ies) must not be greater than $10,000. Any deductible amount must be listed on your Certificate of Insurance. 
  * We will not be changing our new requirements for single-member LLCs, and will continue to allow the insured name to match either your legal entity name or the name you publicly use to identify your business ("trade name", "doing business as", or “DBA"). 

For more information, go to the ‘frequently asked questions’ section on the [
Business Insurance
](https://sellercentral.amazon.com/mario/v2/az/flow/BusinessInsurance/page/InsuranceEstablishment/global/render?view=up)
page or the [ Seller Forums announcement
](https://sellercentral.amazon.com/forums/t/update-on-commercial-liability-
insurance-policies-for-sellers/1169831) .

##  Updates to fee category names

On August 10, 2022, we are renaming a number of fee categories on the Amazon
fee schedule to provide clarity to the categories. For example, “Industrial &
Scientific (including Food Service and Janitorial & Sanitation)” will become
“Business, Industrial, and Scientific Supplies.” There are no rate changes
associated with these updates.

##  Updates to product safety alerts, recalls, stop sales, and market
withdrawal policy for sellers

Effective August 8, 2022, Amazon is updating its Product safety alerts,
recalls, stop sales, and market withdrawal policy. The policy pertains to your
responsibilities as a seller and the actions we take when we learn of a
potential product safety defect. To learn more, go to [ Product safety alerts,
recalls, stop sales, and market withdrawal policy for sellers
](/gp/help/external/GRD4EMBNNW3P47GH) .

##  Updates to Monitor Your Account Health policy and expansion of the Account
Health Rating policy

Effective August 9, 2022, with the launch of additional features to the
Account Health Rating, we are making the following updates to the Monitor Your
Account Health program policy:

  * We are removing the Monitor Your Account Health policy and converting it into two separate policies: the **Account Health Rating policy** and the **Order Performance policy** . 
  * The Account Health Rating policy has been expanded. Please review the full policy as it includes detailed information regarding new and existing Account Health Rating features. 
  * The Order Performance policy was previously part of the Monitor Your Account Health policy. We have moved that content into its own policy page and renamed the policy, but it has not significantly changed. 

**Note:** The Order Performance policy requirements are not currently included
in the Account Health Rating.

To learn more, please see the following:

  * [ Account Health Rating policy ](/gp/help/external/G200205250)
  * [ Frequently asked questions about Account Health Rating ](/gp/help/external/GR786P4BPEVKTBAG)
  * [ Order Performance policy ](/gp/help/external/GGJVNFDXQT8C3RA8)

##  Updates to Adult Products Policies

Effective July 26, 2022, our adult products policies and guidelines will be
updated with clarifications about adult products and explicit sexual imagery.

Effective January 17, 2022, all wand massagers and kegel/ben wa balls will be
classified as adult products. These items will continue to be available for
sale and discoverable to all customers searching for them within their current
listing category.

For more information, go to [ Adult products policies & guidelines
](/gp/help/external/G200339940) .

##  Update to the FBA inventory reimbursement policy

Effective July 21, 2022, the eligibility criteria in the FBA inventory
reimbursement policy will be updated. For an item to be eligible under this
policy, the following must be true:

  * The shipment for the item is not in canceled or deleted status. 
  * When a lost or damaged item claim is filed, under review, and during any appeals, the seller’s account must be in normal status. 

For more information, go to [ FBA inventory reimbursement policy
](/gp/help/external/200213130) .

##  Updates to the commercial liability insurance program policy

Effective August 1, 2022, our United States commercial liability insurance
program policy will be updated with the following changes:

  * Your policy can include a deductible if (i) your gross proceeds from sales of your products in the Amazon.com store exceed USD 1 million in the last 12 months, and (ii) the deductible is listed on your Certificate of Insurance; 
  * For single-member LLCs, the insured name can match either your legal entity name or the name you publicly use to identify your business (“trade name,” “doing business as,” or “DBA”); 
  * We will provide guidance on how you can obtain a commercial liability insurance if you currently do not have one or are looking for a new policy; 
  * We will delete the frequently asked questions section from the current program policy page, have them updated, and move them to a newly created help page. 

For more information, go to the ‘frequently asked questions’ section on the [
Business Insurance
](https://sellercentral.amazon.com/mario/v2/az/flow/BusinessInsurance/page/InsuranceEstablishment/global/render)
page.

##  Update to policy for shipment of dangerous goods in limited quantities

Effective April 25, 2022, we will no longer allow limited quantities of
dangerous goods to be shipped to offshore US island destinations through FBA.
Sellers must use third-party shippers to ship all dangerous goods to those
destinations.

##  Update on countries accepted for seller registration

Effective March 11, 2022, we are not accepting registrations from Russia or
Belarus. For more information, see [ Countries accepted for seller
registration ](/gp/help/external/G200405020) .

##  Introducing fee category guidelines

As part of our efforts to make fee categories easier to understand, we are
introducing [ fee category guidelines ](/gc/fee-category-guidelines) . These
guidelines, effective March 16, 2022, provide detailed lists of products
mapped to each fee category, allowing you to quickly find the fee category for
a specific item.

For more information, go to [ Understanding fee categories
](/gp/help/external/GNJSJ7GP26PD5XWJ) .

##  New policy: Strike anywhere matches

Effective November 19, 2021, we will no longer allow the sale of any product
that contains "strike anywhere" matches on Amazon. To learn more, go to [
Strike anywhere matches ](/gp/help/external/GEENN56JW9QU8MJS) .

##  Referral fees reimbursement policy

Effective December 2, 2021, we are removing the 90-day dispute window
requirement for referral fee reimbursement claims. We are adding additional
clarification that we will consider claims to be invalid when the fee
transaction is contrary to the fee category guidelines in effect at the time
of the fee transaction. For more information, go to [ Referral fees
reimbursement policy ](/gp/help/external/GRRJCFXD6474GRLY) .

##  Free returns on Fashion items for seller-fulfilled orders

Effective October 26, 2021, all seller-fulfilled offers on Fashion items will
feature a free return message, and sellers will no longer be able to deduct
the return shipping fee for **Fashion items** listed under Apparel, Shoes,
Jewelry, and Watches in the US. To learn more, go to [ Free returns on Fashion
items for seller–fulfilled orders ](/gp/help/external/GEKBRFKQE38CQA6V) .

##  Upcoming changes to program policies

Effective **May 18, 2021** , the following fee-related program policy pages
will be updated in the US for clarity and the names will be changed where
indicated:

  * “FBA features, services, fees, and resources,” which will also be renamed to “FBA features, services, and fees” 
  * “FBA fulfillment fees for Amazon.com orders,” which will also be renamed to “FBA fulfillment fee” 
  * “FBA removal order fees” 
  * “FBA long-term storage fees,” which will also be renamed to “Long-term storage fees” 
  * “Inventory storage fees,” which will also be renamed to “Monthly inventory storage fees” 
  * “Returns processing fee” 
  * “Selling on Amazon fee schedule” 

There are no changes from the rates currently charged.

Further, effective on the same date mentioned above, new program policy pages
dedicated to the FBA disposal order fee, lithium batteries fee, and special
handling fee will be added in the US for clarity. There are no changes from
the rates currently charged.

##  Upcoming changes to program policies

Effective **March 19, 2021,** we are adding the [ unsuitable inventory
investigations policy ](/gp/help/external/H4YYXNDRW9BSZEN) as a new program
policy.

Under this policy, if there is suspicion that a selling partner may have been
engaged in the sale of counterfeit products or other illegal goods at Amazon,
we may require additional information regarding the affected FBA inventory. If
the requested information is not provided, or we find after investigation that
the inventory constitutes unsuitable units, we may dispose of it.

##  Update to selling services terms and policies – September 2020

The [ Selling services terms ](/gp/help/external/G201484410) and [ Selling
services on Amazon policies ](/gp/help/external/G201840340) were updated to
include product sale and delivery requirements

##  Update to communication guidelines

Effective November 6, 2020, our communication guidelines were updated with
additional information related to buyer-seller messages. For more information,
go to the [ updated guidelines ](https://m.media-
amazon.com/images/G/01/SellerCentral/CommunicationGuidelines/en_US_Communication_Guidelines.pdf)
.

##  Update to restricted products policy

The [ Animals and animal-related products ](/gp/help/external/G200164370) page
of our restricted products policy was updated to include veterinary diets as
an example of permitted listings on August 19, 2020.

##  Sold by Amazon terms and conditions

The Sold by Amazon terms and conditions page will be removed from the program
policies page on July 4, 2020.

##  Amazon Vine legal entity change

On January 24, 2020, the legal entity listed in the [ Amazon Vine terms and
conditions ](/gp/help/external/G3MB5C56WDZZXHBG) was changed to Amazon.com
Services LLC.

##  Update to tax policies

Our [ tax policies ](/gp/help/external/G200405820) are being updated with
additional information related to tax treatments that could apply based on
your use of Amazon services and selling in Amazon stores.

  * Responsibility for taxes 
  * Taxes on fees and payments 
  * Shipping products internationally 

**Note:** You are responsible for identifying your tax obligations.
Information from Amazon does not constitute tax, legal, or other professional
advice and must not be used as such. Consult your professional advisers if you
have questions.

##  Referral fees reimbursement policy

The [ Referral fees reimbursement policy ](/gp/help/external/GRRJCFXD6474GRLY)
page will be added to the program policies page on February 5, 2020.

Your continued use of selling services after February 5, 2020, constitutes
your acceptance of the updated agreement.

Top

##  Changes to program policies

* [ Seller-fulfilled meltable product policy  ](/help/hub/reference/external/GTH8F8BDZPPZTBEZ)

