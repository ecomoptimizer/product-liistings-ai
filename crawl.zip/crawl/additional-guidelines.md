# Additional Guidelines

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69G3YF8A6VG7C2Y

This article applies to selling in: **United States**

#  Additional Guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69G3YF8A6VG7C2Y)

Top

* [ Guidelines for contacting Selling Partner Support  ](/help/hub/reference/external/GK3V2JYCN2P28BFX)
* [ The California eWaste Act  ](/help/hub/reference/external/G21931)
* [ Procedure for submitting a counter-notice pursuant to the DMCA  ](/help/hub/reference/external/G202017130)
* [ Policy violations  ](/help/hub/reference/external/G200285230)
* [ Account health support FAQ  ](/help/hub/reference/external/GBMCHQ8MJ9KDYQ9A)

