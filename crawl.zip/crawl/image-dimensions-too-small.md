# Image Dimensions Too Small

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Add your favorite pages here by clicking this icon in the navigation menu.

---
Add your favorite pages here by clicking this icon in the navigation menu.

Hide

## Image Dimensions Too Small

An image will fail to upload if its longest side is smaller than 500 pixels.

To verify image size, right-click the image file and click **Properties**.

The optimal zoom experience for detail pages requires files to be 1600px or larger on the longest side. Zoom has been shown to help enhance sales. If you are unable to meet this requirement, the smallest your file can be for zoom is 1000px.

Top

Was this article helpful?
