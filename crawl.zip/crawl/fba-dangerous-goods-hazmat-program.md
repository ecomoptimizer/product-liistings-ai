# FBA Dangerous Goods Hazmat program

Source: https://sellercentral.amazon.com/gp/help/external/help.html/?itemID=GZLZBQ7W6QZRKWWK&ref_=xx_GZLZBQ7W6QZRKWWK_a_r0_cont_sgsearch

This article applies to selling in: **United States**

#  FBA Dangerous Goods program

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZLZBQ7W6QZRKWWK%3Fref_%3Dxx_GZLZBQ7W6QZRKWWK_a_r0_cont_sgsearch)

The Fulfillment by Amazon (FBA) Dangerous Goods program allows you to sell
FBA-eligible products that have been classified as dangerous goods.

Dangerous goods (also called hazmat) are regulated substances or materials
that may pose a risk during storing, handling, or transporting because they
contain flammable, pressurized, corrosive, or otherwise harmful substances.
“Dangerous goods” **also refers to consumer products** such as laptops,
smartphones, household cleaners, spray paints, and cosmetics.

**Note:** To upload safety data sheets (SDS) and exemption sheets, go to [
Manage dangerous goods classification ](/fba/compliance-dashboard/index.html)
. For detailed information about these documents, go to [ Dangerous goods
required information and documentation (hazmat)
](/gp/help/external/G201371860) .

The Dangerous Goods program in the US has a waitlist for participating.  To
join the waitlist, select **FBA Dangerous Goods program** below, click
**Next** , then click **Apply to the FBA Dangerous Goods program** .

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZLZBQ7W6QZRKWWK%3Fref_%3Dxx_GZLZBQ7W6QZRKWWK_a_r0_cont_sgsearch)

If you have inventory in an Amazon fulfillment center that becomes
reclassified as a dangerous good, you will automatically be added to the
waitlist. Once on the waitlist, you’ll be notified when a chance to
participate in the program becomes available.

Products sold through Dangerous Goods are eligible for Prime, though some may
not be eligible for two-day shipping. Due to transportation regulations, many
of these products are available for ground transport only. Therefore, they are
eligible for Prime four- to five-day shipping.

**Note:** Certain dangerous goods can be sold on Amazon but are not eligible
for FBA because they can’t be stored in fulfillment centers. Products sent to
fulfillment centers must comply with [ FBA policies and legal requirements
](/gp/help/external/GYS2KBEE7MYVCGE3) for dangerous goods, even if they’re not
currently restricted by FBA.

To learn more about dangerous goods, refer to these Help pages:

[ Dangerous goods identification guide (hazmat)
](/gp/help/external/G201003400) |  See which dangerous goods can be sold
through FBA, what’s prohibited, and how to tell if your product is a dangerous
good.  
---|---  
[ Dangerous goods required information and documentation (hazmat)
](/gp/help/external/G201371860) |  Learn about information required during FBA
listing creation and conversion, and about safety data sheets and exemption
sheets.  
[ Dangerous goods review process (hazmat) ](/gp/help/external/G201749580) |
Learn how long it takes to review ASINs converted to FBA and which documents
may be required.  
[ Intro to Dangerous Goods ](/learn/courses?moduleId=401) (video)  |  Learn
how classification affects fulfillment and shipping, when classification is
required, and product information requirements.  
[ Dangerous Goods Awareness ](/learn/courses?moduleId=402) (video)  |  Learn
about common examples of dangerous goods and what to consider when selling
dangerous goods on Amazon.  
[ Submitting Safety Data Sheets ](/learn/courses?moduleId=538) (video)  |
Learn six important rules for submitting SDS.  
  
##  Dangerous goods classification

To be sold through FBA, your products must be correctly classified, regardless
of whether you’re enrolled in the FBA Dangerous Goods program.

Products in **Unable to classify** status when received at an Amazon
fulfillment center will be set to **Inactive** . Once **Inactive** , they
can’t be sold or replenished until they’re correctly classified.

Items become **Active** (sellable) once they’re classified as allowed
dangerous goods and received at a fulfillment center that handles dangerous
goods (see **Fulfillment center storage** below). Any such inventory stored at
a standard fulfillment will be automatically transferred to one that handles
these items. We will notify you by email of the transfer, which can take
several weeks. Inventory will be in **Reserved** status while in transit.

If stored inventory becomes classified as dangerous goods prohibited for FBA,
it will be disposed of at your expense. This includes inventory in fulfillment
centers that handle dangerous goods. We will notify you by email of the
classification change.

**Note:** If you disagree with the classification, upload a new safety data
sheet or exemption sheet on [ Manage dangerous goods classification
](/fba/compliance-dashboard/index.html) .

Whether or not you’re enrolled in the program, you must do the following when
listing a product that is under classification review or is regulated as a
dangerous good:

  * Comply with safety requirements. 
  * [ Upload a safety data sheet ](/gp/fba/material-safety-data-sheet/index.html) (or SDS, previously known as a material safety data sheet).  To learn more, watch these Seller University videos: [ Introduction to Safety Data Sheets ](/learn/courses?moduleId=537) and [ Submitting Safety Data Sheets ](/learn/courses?moduleId=538) . 
  * [ Upload an exemption sheet ](/gp/fba/material-safety-data-sheet/index.html) . 

**Important:** You will have 14 business days to comply with product safety
compliance requirements. Not providing this information may result in delayed
shipments, canceled customer deliveries, or inventory disposed at your
expense. Amazon reserves the right to take the corresponding actions without
prior notice.

##  Fulfillment center storage

**Dangerous goods storage limits**

Space at fulfillment centers are designed to safely process and store
dangerous goods and are divided into two categories: **flammable** and
**aerosol**

Once enrolled in the Dangerous Goods program, you can view your dangerous
goods storage limits on [ Shipping Queue
](https://sellercentral.amazon.com/gp/fba/inbound-queue/index.html) and [
Inventory Performance ](https://sellercentral.amazon.com/inventory-
performance/dashboard) . Expand the **storage monitor** section at the bottom
of the page to view the limits for **flammable storage** and **aerosol
storage** .

Dangerous goods storage limits are based on store performance and the space
that you actively use. We regularly assess these metrics and adjust the limits
accordingly. Storage limits are not based on your [ Inventory Performance
Index ](https://sellercentral.amazon.com/gp/help/external/202174810) score.

**FBA storage limits**

FBA measures storage in volume rather than units. To see how your products are
categorized and how much cubic feet they occupy, go to [ FBA Inventory Age
](https://sellercentral.amazon.com/inventoryplanning/inventory-age) and the [
Inventory Age report
](https://sellercentral.amazon.com/reportcentral/INVENTORY_AGE/1) .

For more information, go to [ Inventory storage fees
](https://sellercentral.amazon.com/help/hub/reference/external/G3EDYEF6KUCFQTNM)
.

Top

