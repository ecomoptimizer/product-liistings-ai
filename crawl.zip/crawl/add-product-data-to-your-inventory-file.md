# Add product data to your inventory file

Source: https://sellercentral.amazon.com/gp/help/external/201576640

This article applies to selling in: **United States**

#  Add product data to your inventory file

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201576640)

**Individual sellers:** This feature is only available to sellers with a
Professional selling plan. Learn more by visiting [ Selling plan comparison
](/gp/help/external/64491) .

Once you download the appropriate inventory file template for your products,
you can add your product data. Amazon will use this data to list and offer
your products for sale in the Amazon catalog.

**Before adding product data to your inventory file**

  * Choose the appropriate [ inventory file template ](/gp/help/external/201576430) for your products. You can generate customized inventory templates specific to the type of products you sell. You can also list information for different types of products in one template. 

For more information, see [ Create your inventory file template
](/gp/help/external/202094740) .

  * Find the product data for the required fields in your inventory file template. 

You can check the **Data Definitions** tab in the template for accepted
values.

  * Update the recommended and optional fields with product data. 

See [ Improve product details ](/gp/help/external/10521) to find tips on how
to increase the visibility of your listings.

  * Evaluate the quality of your product images for better listings. 

See [ Improve product details ](/gp/help/external/10521) for more information
about the importance of quality images.

  * Optimize your listings with the right search terms for your products. 

See [ Optimize listings for search ](/gp/help/external/10471) for tips to
optimize these terms.

To find how to add products through inventory template, see [ Add your product
information to an inventory file ](/gp/help/external/201576650) .

Top

##  Add product data to your inventory file

* [ Add your product information to an inventory file  ](/help/hub/reference/external/G201576650)
* [ Modify Your Inventory File  ](/help/hub/reference/external/G201576660)

