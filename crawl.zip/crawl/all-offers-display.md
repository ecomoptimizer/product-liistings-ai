# Amazon

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> The All-Offers Display is a new experience that helps customers compare offers and make a
            purchase decision while remaining in context of the Detail Page. This new experience
            will replace the legacy Offer Listing Page (OLP). On mobile, the All-Offers Display
            provides customers access to key offer information at a glance, without navigating to a
            secondary view. On Desktop, a side sheet pops up for customers to quickly compare
            alternate offers without transiting away from Search and Detail Page. Please refer the
            screenshots below for better clarity:

---
The All-Offers Display is a new experience that helps customers compare offers and make a purchase decision while remaining in context of the Detail Page. This new experience will replace the legacy Offer Listing Page (OLP). On mobile, the All-Offers Display provides customers access to key offer information at a glance, without navigating to a secondary view. On Desktop, a side sheet pops up for customers to quickly compare alternate offers without transiting away from Search and Detail Page. Please refer the screenshots below for better clarity:

| Mobile: Earlier Experience | Mobile: All-Offers Display Experience |
| --- | --- |
| ![](https://m.media-amazon.com/images/G/01/rainier/help/US_earlier.png) | ![](https://m.media-amazon.com/images/G/01/rainier/help/US_MAOD.png) |

**Desktop – Earlier Experience**

![](https://m.media-amazon.com/images/G/01/rainier/help/US_Earlier.png)

**Desktop: All-Offers Display Experience**

![](https://m.media-amazon.com/images/G/01/rainier/help/US_AOD.png)

#### Q1. What is the need for this new experience?

With OLP (separate page from the Detail Page), the customers had to transit between distinct pages in order to compare offers and make a purchase decision. The new All-Offers Display experience allows customers to quickly view Amazon’s entire breadth of offers while remaining in context of the Detail Page.

#### Q2. Which offer do I see at the top of the All-Offers Display? Why do I see that?

The offer shown at the top of the All-Offers Display is the Featured Offer. The All-Offers Display experience allows customers to compare other offers against the Featured Offer" at a glance.

#### Q3. I use Offer Listing Page (OLP) to confirm my SKUs. How can I do that now?

You can view the All-Offers Display experience by accessing the links on the Detail Page.

#### Q4. What are some of the other updates that the team is making?

Over the past two years, our teams have been making investments that brings improved visibility for our customers into alternate offers. For example, we increased the prominence of the All-Offers Display links on the Detail Page, from a link into a button style to improve their discoverability for our customers. This has had a large impact on purchases from the All-Offers Display. We also display shipping cost at a glance for the lowest item price + shipping cost offer on the Detail Page so that customers can make quick comparisons.
