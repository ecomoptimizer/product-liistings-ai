# Manage inventory

Source: https://sellercentral.amazon.com/help/hub/reference/external/G41

This article applies to selling in: **United States**

#  Manage inventory

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG41)

The [ Manage Inventory ](/inventory) gives you access to the most important
Seller Central features.

To access the **Manage Inventory** , go to Seller Central and select **Manage
All Inventory** on the Inventory tab.

  * On the **Manage Inventory** , you can search, view, and update listings. 
  * You can find specific listing information by searching terms such as SKU, product name, and ASIN. 
  * You can filter listing information by applying filters such as active and inactive. 
  * You can also sort the results by date or price range. 

Once you identify the product, you can edit basic information about the
listing, such as price and quantity, by clicking Edit on the right side of
each listing information.

You can also add product images. For more information, go to [ Manage your
offers one at a time ](/gp/help/external/G201186860) .

Here are some more important pages: [ List Products for Fulfillment by Amazon,
](/gp/help/external/G200141220) [ Match low price,
](/gp/help/external/G200836360) or [ Stop selling a product
](/gp/help/external/G200216110) . For more information on adding new products,
go to [ Add one product at a time ](/gp/help/external/G200220550) .

For details on the product variation, go to [ Add a variation using Variation
Wizard ](/gp/help/external/G202034620) page.  Additionally, on the Manage
inventory page, you can edit multiple listing information in bulk. For more
details, go to [ Manage your offers in bulk
](/gp/help/external/G9DZLGS87GVDT94B) .

The [ Listing quality dashboard ](/quality) is also accessible from the Manage
Inventory. Use this tool to identify and fix listing issues affecting
discoverability, detail page experience, and customer returns. Go to [ Listing
quality dashboard ](/gp/help/external/GE2GNWMVK8URG8XT) for more details.

Top

##  Manage inventory

* [ Featured Offer  ](/help/hub/reference/external/G37911)
* [ Create and manage offers  ](/help/hub/reference/external/GFQ8J5JPKERTHQPP)
* [ Manage your offers one at a time  ](/help/hub/reference/external/G201186860)
* [ Manage your offers in bulk  ](/help/hub/reference/external/G9DZLGS87GVDT94B)
* [ Price your item  ](/help/hub/reference/external/G62551)
* [ Catalog and drafts  ](/help/hub/reference/external/G202078860)
* [ Custom Report Builder  ](/help/hub/reference/external/GEQ8JEWH5KJC5QCG)

