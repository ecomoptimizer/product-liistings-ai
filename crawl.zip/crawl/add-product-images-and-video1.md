# Add product images and video

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200216080

This article applies to selling in: **United States**

#  Add product images and video

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200216080)

On this page

Add an image to a new listing:

Add an image to an existing listing from Manage Inventory:

Add images in bulk to an existing listing using Upload Images

Add a video to your product:

Every detail page in the Amazon store requires at least one product image, and
we recommend you provide six images and one video. Good images makes it easy
for customers to evaluate the product. Images should be clear, informative,
and attractive. The first image on the product detail page is the "MAIN" image
and is shown to customers in search. The MAIN image must show only the product
for sale on a white background, and the product should fill the image frame.
Additional images should show the product in use or in an environment,
different angles, and different features. There are several ways to add a
product image to Amazon:

  * For new products: Use the **Add a Product** tool to add an image when you create a new listing. 
  * For existing products: Use the **Manage Inventory** tool to add an image to an existing listing. Or you can upload images in bulk using [ Upload Images ](/imaging/upload) . 
  * If you use inventory files, specify the product image URL in the inventory file. For more information, refer [ Add product data to your inventory file ](/gp/help/external/201576640) . 

It can take up to 24 hours after adding an image for it to appear on the
website.

**Note:** Uploading an image does not guarantee that it will be displayed on
the product detail page or search pages. Amazon uses algorithms to determine
display images. Follow the guidelines provided in the [ Amazon product image
requirements ](/gp/help/external/1881) to ensure your product images adhere
Amazon file and content specifications.

##  Add an image to a new listing:

  

  1. Click **Add Products** from the **Catalog** drop-down menu in Seller Central. 
  2. From the **Add Products** page, click **I’m adding a product not sold on Amazon** , located in the middle of the page. 
  3. Browse to the product category for your new product and click **Select category** . 
  4. Complete the fields under the **Vital Info** and **Offer** tabs. 
  5. On the **Images** tab, click on **Upload** for any of the empty image slots. The **MAIN** image is the top left image slot in this section of the page. 
  6. Select an image from your computer and click **Open** . 
  7. Click **Save and finish** to add your image to the listing. 

##  Add an image to an existing listing from Manage Inventory:

  

  1. From your dashboard, go to **Inventory** drop-down menu, and select **Manage Inventory** . 
  2. Click the **Edit** drop-down for each product on the far right, select **Manage Images** . 
  3. Go to the **Images** tab and scroll down to the section titled **Your image recommendations** . 
  4. Click on **Upload** for any of the empty image slots. The **MAIN** image is the top left image slot in this section of the page. 
  5. Select an image from your computer and click **Open** . 
  6. Click **Save** at the bottom right of the page to add your image to the listing. 

##  Add images in bulk to an existing listing using Upload Images

  

  1. From your dashboard, go to **Inventory** drop-down menu, and select **Upload Images** . 
  2. In the **drag & drop ** box, drag or click to add an image or zip file from your computer. If clicking to add an image, select an image from your computer and click **Open** . 
  3. Click **Submit images** . 

Are you having problems uploading images? To know more about viewing image
upload status and products removed from search due to image issues, see [
Image Issues ](/gp/help/external/GT8RSE9S9NK4LP6Z) .

If you are seeing an [ Invalid URL format error ](/gp/help/external/30601) or
if you face any other URL issues, you can search for "image error" in Help for
common image-related errors and find more information.

##  Add a video to your product:

**Note:** This feature is applicable only to Brand owners.

Video is a great way to demonstrate your product in action, describe your
product, and tell your unique brand story. Uploading videos can result in
higher conversion rates and increased sales when used effectively. You can
upload videos to your product that will display next to images of the product.
Any videos you upload must comply with Amazon’s [ Video Content Policy
](/gp/help/external/GCBBP4HK2L864N98) . Please review this policy in its
entirety before you start uploading videos for your products.

To know more, visit [ Upload and Manage Videos
](/gp/help/external/GY4LL3M3WJEFE8MZ) .

Top

