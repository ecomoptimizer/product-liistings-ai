# Business-Only Selection

Source: https://sellercentral.amazon.com/gp/help/external/G201958670

This article applies to selling in: **United States**

#  Business-Only SelectionBusiness-Only Selection

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201958670)

The Business-Only Selection program allows only business buyers to buy certain
products from certain categories. Products in the Business-Only Selection
program may require special storage or handling and should not be purchased by
consumers.

The Business-Only Selection Program is currently in beta. Contact the [
Business-Only Selection team ](mailto:Bos-rnr-inquiry@amazon.com) for more
information about participating in the beta program.

Top

