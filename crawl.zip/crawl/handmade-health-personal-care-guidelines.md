# Handmade Health & Personal Care guidelines

Source: https://sellercentral.amazon.com/gp/help/external/GQEW7ZE8DX838YG4

This article applies to selling in: **United States**

#  Handmade Health & Personal Care guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGQEW7ZE8DX838YG4)

As a Maker, your handmade Health & Personal Care products must adhere to the
following guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must meet the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * Products containing cannabis are prohibited.  Review the [ Drugs & drug paraphernalia ](/gp/help/external/G200164490) policy. 
  * Adult products must comply with the [ Adult products policies & guidelines ](/gp/help/external/G200339940) and must be flagged as Adult. 
  * Products must comply with Amazon's [ Cosmetics & Skin/Hair Care ](/gp/help/external/G200164470) policy. 

Top

