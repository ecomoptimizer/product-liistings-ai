# Amazon Global Selling

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201062890

This article applies to selling in: **United States**

#  Amazon Global Selling

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201062890)

With Amazon Global Selling, you can list and sell your products on any of our
marketplaces in the Americas, Asia-Pacific, Middle East, and Europe. Amazon
currently has over 16 marketplaces, allowing you to expand your business.

[ Learn more about global selling opportunities with Amazon
](https://sell.amazon.com/global-selling.html)

If you are already selling on any of our Amazon marketplaces, visit the [ sell
globally dashboard ](/global-selling/dashboard/?linkTab=EU) to register and
start selling on another marketplace. If you are new to selling on Amazon,
register your Seller Central account in the country you want to start selling
in using the links below:

Europe  |  Asia-Pacific  |  Middle East and North Africa  |  Americas  
---|---|---|---  
  
  * [ Europe (Germany, United Kingdom, France, Italy, Spain, Netherlands) ](https://sellercentral.amazon.co.uk/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

|

  * [ Japan ](http://www.amazon.com/start-selling-in-japan)
  * [ Australia ](https://sellercentral.amazon.com.au/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Singapore ](https://services.amazon.sg)
  * [ India ](https://services.amazon.in/)

|

  * [ Middle East ](https://sellercentral.amazon.ae/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Turkey ](https://sellercentral.amazon.com.tr/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

|

  * [ North America (United States, Canada, and Mexico) ](https://sellercentral.amazon.com/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Brazil ](https://sellercentral.amazon.com.br/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

  
  
After creating your global selling account, you can [ link your accounts
across multiple regions
](/gp/help/external/help.html?itemID=201841950&language=en_US&ref=id_201841950_cont_2)
, manage offers across marketplaces using the **[ Build International Listings
](/global-selling/listings/connect?ref_=xx_BIL_snav_agsLand) ** tool, [ ship
internationally
](/gp/help/external/help.html?itemID=201468490&language=en_US&ref=efph_201468490_cont_201062890)
, and customize your selling plan.

To get started, see the following links to learn more about how to expand your
business globally.

Top

##  Amazon Global Selling

* [ Merge accounts  ](/help/hub/reference/external/G201841950)
* [ Get started with Amazon Global Selling  ](/help/hub/reference/external/G201468440)
* [ Payments for global accounts  ](/help/hub/reference/external/G201468470)
* [ Global registration  ](/help/hub/reference/external/GKMK7CM7F9Q8FKUG)
* [ Where and what to sell with Amazon Global Selling  ](/help/hub/reference/external/G201468340)
* [ Amazon North American stores  ](/help/hub/reference/external/G201394090)
* [ Amazon EU and UK stores  ](/help/hub/reference/external/G200671260)
* [ Build International Listings  ](/help/hub/reference/external/G202121570)
* [ Ship and fulfill with Amazon Global Selling  ](/help/hub/reference/external/G201468490)
* [ Taxes and regulations for Amazon Global Selling  ](/help/hub/reference/external/G201468380)
* [ Customer support and returns for international sales  ](/help/hub/reference/external/G201468530)
* [ Find help from external solution providers with Selling Partner Appstore  ](/help/hub/reference/external/G201687890)
* [ Customer Service by Amazon program  ](/help/hub/reference/external/GYGMNGX67ZJZMZNP)
* [ Unify global accounts  ](/help/hub/reference/external/GJZJNMG4UX3DXSGV)

