# Learn more

Source: https://sellercentral.amazon.com/gp/help/external/201750810

This article applies to selling in: **United States**

#  Frequently Asked Questions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201750810)

Frequently asked questions and answers about the Amazon Business Seller
program and features.

**Note:** This feature is available to [ Amazon Business sellers
](/hz/b2bregistration) only.

##  About the program

####  What is the Amazon Business Seller program?

The Amazon Business Seller program helps you grow your business-to-business
sales on Amazon. As an Amazon Business seller, you receive benefits to help
grow your sales to business customers, including the ability to offer products
visible only to business customers, differences in search functionality to
make it easier for business customers to find your products, and pricing and
payment features that simplify buying from you in larger quantities.

####  What are the main differences between the Amazon Business Seller program
and Selling on Amazon?

The Amazon Business Seller program allows sellers to cater to the specific
requirements of business customers by providing features optimized for
business-to-business transactions.

####  Who is eligible for the Amazon Business Seller program?

Sellers who have the capability to fulfill the following requirements of
business customers.

  * High bar for performance.  Selling on Amazon  |  Amazon Business Seller program   
---|---  
    * An Order-Defect Rate (ODR) of 1% or less. [ Learn more ](/gp/seller-rating/pages/account-health.html)
    * Pre-shipment Cancellation Rate of 2.5% or less. 
    * Late Shipment Rate of 4% or less. 
    * [ Learn more ](/gp/help/external/200370550)
|

    * An Order-Defect Rate (ODR) of 0.5% or less. [ Learn more ](/gp/seller-rating/pages/account-health.html)
    * Pre-shipment Cancellation Rate of less than 1%. 
    * Late Shipment Rate of less than 1%. 
    * Few [ chargebacks ](/gp/help/external/200205250) , A-to-z Guarantee claims, and negative feedback. [ Learn more ](/gp/help/external/200370550) about chargebacks, A-to-z Guarantee claims, and negative feedback.   
  * If the seller participates in Amazon's tax calculation services, the seller must honor the customer's tax exemption through the Amazon Tax Exemption Program. 
  * There must be a tracking number on every business order package. 
  * There must be a packing slip with every business order package. 
  * There must be a purchase order number with every business order package. 

**Note:** Requirements for Amazon Business sellers may differ from
requirements for Amazon sellers. [ Learn more ](/gp/help/external/200370550)
about Selling on Amazon requirements.

####  Who is an Amazon Business customer?

Amazon Business customers have completed the business account registration
process and have been verified as businesses.

####  How do I retain business seller status?

Sellers are expected to conform to a high performance bar. Business sellers
must exceed all existing performance thresholds, as shown in the table above.
We may establish additional performance requirements specific to business
sellers in the future. You can view your current performance in the [ Account
Health ](/gp/seller-rating/pages/account-health.html) section in Seller
Central.

####  How much does it cost to list products as business seller?

Business seller fees are the same as the fees for a professional selling plan
with Amazon. Sellers are required to have a professional selling plan to
participate in the Amazon Business Seller program, and the associated monthly
subscription fee of $39.99 and other selling fees, such as referral fees
(which vary by category), apply. See the [ Selling on Amazon Business Fee
Schedule ](/gp/help/external/G201762480) for more information.

####  How much does it cost to list products as an Amazon Business Seller?

For a limited time, sellers participating in the Amazon Business Seller
program pay no additional monthly program fee to participate. For more
information on fees, please see the [ Selling on Amazon Fee Schedule
](/gp/help/external/200336920) .

We may implement fees specific to the Amazon Business Seller program in the
future.

####  How do I cancel my Amazon Business Seller status?

You may opt out of the Amazon Business Seller program at any point. Please
click [ here ](/business/b2bderegistration) to opt-out. This only removes the
business-to-business-specific features in your Seller Central account, and
does not cancel or impact your Professional seller account and you can
continue selling on Amazon.

####  Can I use Fulfillment by Amazon (FBA)?

Yes. A seller's FBA inventory can be used to fulfill orders.

####  Are there fees for using FBA with Amazon Business?

Yes. The [ Fulfillment by Amazon Fee Schedule ](/gp/help/external/201074400)
applies to business orders fulfilled by Amazon.

####  What will change in Seller Central for a business seller?

The overall functionality of Seller Central will not change. You will begin to
see new business-to-business features in Seller Central. The [ Seller
Credentials
](https://services.amazon.com/selling/businesssellercredentials.htm) program
feature is currently available, and in the coming months you will continue to
see new features.

####  Where do I add new business-to-business products?

Add business-to-business products using the same process you use to add
products in Seller Central. [ Learn more ](/gp/help/external/201576410) .

####  Where do I manage my business-to-business inventory?

Business-to-business products are managed in Seller Central. Information about
products, such as price, product description, and images, can be edited or
updated from Seller Central by completing the following steps:  

  1. From the **Inventory** dropdown menu, select **Manage Inventory** . 
  2. In the desired inventory product row, under **Actions** , select **Edit Details** . 
  3. Select the tab that corresponds to the changes you want to make. 
  4. Select **Save and Finish** . 

####  How can I identify business orders?

You can identify business orders in **Manage Orders** or in **Order Reports**
.

In **Manage Orders** :  

  1. From the **Orders** drop-down menu, select **Manage Orders** . 
  2. Look for the **Business Buyer** label to the right of the Order ID. 

In **Order Reports** :

Business transactions are listed in the **is-business-order** column.

####  How do customers view my credentials?

Your credentials, which are only visible to business customers, are showcased
on your Seller Profile page as well as on All-Offers Display pages and detail
pages that accompany your offers.

####  Why should I participate in the Seller Credential Program?

By participating in the Seller Credential Program, sellers can distinguish
themselves to Amazon business customers, many of which are tasked with meeting
quality sourcing objectives and corporate social responsibility goals.

####  Will Amazon help sellers obtain credentials?

Amazon is not a certifying body, nor does Amazon provide assistance to obtain
credentials. Sellers are expected to determine their own eligibility
requirements for a credential and how best to obtain the appropriate
supporting documentation, depending on the credential. A starting point for
each credential is provided in the [ Amazon Business Glossary
](/gp/help/external/201760900) .

####  If I already own a credential, how do I assign it to myself in the
Seller Credential Program?

Follow the instructions in [ Become a Credentialed Amazon Business Seller
](/gp/help/external/201649810) to choose from a list of credentials to claim
(assign to yourself) and provide the necessary supporting information.
Depending on the credential, you will need to provide a picture of a physical
certificate, or a business identifier number (such as a DUNS Number).

####  How will business customers find sellers' credentials?

Credentials will be exposed to customers throughout the customer's shopping
experience. Additionally, a list of each seller's credentials will be
displayed prominently on the At-a-Glance page.

####  Who can see my credentials?

Seller credentials are only visible to Amazon business customers and business
sellers.

####  How does Amazon choose the credentials it supports?

The credentials are generally chosen based on general business relevance to a
significant portion of businesses, the ability of an individual to verify a
credential, and direct feedback from Amazon business customers and business
sellers.

####  What kind of information do I need to provide in order to claim a
credential?

Generally, sellers need to provide information that would allow a buyer to
independently verify that a seller has been awarded a credential. All
credentials must be issued and/or registered under a reputable third-party
entity, such as an accredited or authoritative certifier or government entity.
Sellers provide proof of issuance in the form of a physically issued
documentation (digital image) or a reference to a third-party entity's site
(when available).

Though the type of information provided depends on the particular credential
being claimed, sellers should be prepared to have the following types of
information available:

  * Certificates issued by an authoritative or accredited certifying body 
  * Formal letters of recognition by a government entity 
  * DUNS Number, referencing formal registrations of status within a government entity; specifically, the Small Business Administration's Dynamic Small Business Search Database (DSBS) and the Department of Veteran Affairs' Vendor Information Pages ( [ VetBiz.gov ](https://www.vetbiz.gov/) ) 

####  Will Amazon consider a particular credential or form of supporting
information in the future?

Provide direct feedback and recommendations regarding seller credentials by
selecting Tell us about your credential on the Credentials and Certifications
page (from Seller Central, select **Settings** , then **Your Info & Policies
** ).

####  How can I learn more about a particular credential?

Information about particular credentials can be found in the [ Amazon Business
Glossary ](/gp/help/external/201760900) .

Top

##  Frequently Asked Questions

* [ Payments  ](/help/hub/reference/external/G201953040)
* [ Business pricing and quantity discounts FAQs  ](/help/hub/reference/external/G201824530)
* [ Business-Only Offers  ](/help/hub/reference/external/G201824540)
* [ What do I need to know about packing slips and purchase order numbers?  ](/help/hub/reference/external/GQBDHEYGMALGGASA)

