# Manage seller-fulfilled returns

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200708210

This article applies to selling in: **United States**

#  Manage seller-fulfilled returns

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200708210)

On this page

Return authorization

Prepaid return labels

Return labels for exempt items

Wrong item returned by buyers

Manage Returns tool

Appeal a return

See also

To ensure a consistent return experience for buyers, selling partners must
adhere to Amazon’s [ Return
](https://www.amazon.com/gp/help/customer/display.html?nodeId=GKM69DUUYKQWKWX7)
and [ Refund
](https://sellercentral.amazon.com/gp/help/customer/display.html?nodeId=901926)
policies not withstanding to individual terms and conditions set forth by the
Selling partners in the [ Your Information & Policies
](https://sellercentral.amazon.com/gp/help-
content/home.html/ref=xx_infopol_dnav_xx) section. Most items purchased on
Amazon.com can be returned for a refund or replacement within 30 days of the
estimated delivery date.

For more information about Fashion items, go to [ Free Returns of Fashion
Items for seller-fulfilled orders
](/help/hub/reference/external/GEKBRFKQE38CQA6V) . For more information about
international return policy, go to [ Customer returns for international sales
](/help/hub/reference/external/G201468550) .

##  Return authorization

Amazon automatically authorizes US return requests that fall within Amazon’s
return policy, including items with seller-filed SKU exemptions from the [
Prepaid returns for seller-fulfilled orders
](/help/hub/reference/external/G202072200) . Return requests that are out-of-
policy or category-exempt will be sent for manual authorization. For more
information, go to [ Authorize a return request
](/help/hub/reference/external/G9DH343PLXALFTUW) .

When a buyer requests a return, Amazon will send you an email stating the
reason for the return. If the buyer's request does not comply with our return
policies, we will inform you in the email.

**Note:** You must respond to return requests that require manual
authorization within 24 hours. You are required to issue a refund within two
business days of receipt of a return. If you do not take action regarding the
refund, Amazon may refund the buyer on your behalf and charge the amount to
your seller account. In addition, if you refuse to accept the return of an
item and Amazon determines that it is materially different, you might be held
responsible for any A-to-z Guarantee claim or chargeback dispute that is
filed.

##  Prepaid return labels

Amazon automatically enrolls US sellers in the [ Prepaid returns for seller-
fulfilled orders ](/help/hub/reference/external/G202072200) . In this program,
we provide buyers with prepaid return shipping labels on your behalf through [
Use Buy Shipping services ](/help/hub/reference/external/G200202220) .

##  Return labels for exempt items

For returns of seller-fulfilled SKUs that are exempt from the Prepaid Returns
Label program, you will have the option to upload a merchant-paid label. We
recommend that these merchant-paid labels include tracking. Go to [ Return
Settings ](https://sellercentral.amazon.com/gp/returns/settings) in Seller
Central to select the return label you want to provide for exempt items. For
more information, go to [ Request exemption from prepaid returns for Seller-
fulfilled orders ](/help/hub/reference/external/202174980) .

##  Wrong item returned by buyers

Sometimes buyers mistakenly return a different item than the one they
purchased from you. If this happens, contact the buyer to do the following:

  * Let them know that they may have accidentally returned the wrong item. 
  * Ask them if they would like you to return the item to them. 
  * Inform them that they can return the correct item for a refund. 

If the buyer indicates that they would like the wrong item back, consider
sending it back to them. If the buyer indicates that they received the wrong
item initially, consider giving them the benefit of the doubt.

##  Manage Returns tool

You can respond to return requests in the [ Manage Returns
](https://sellercentral.amazon.com/gp/returns/list/) . Below are the different
tabs you can find on Manage Returns:

  * **View All** : All return requests. 
  * **Pending Actions** : All open return requests that require you to respond, such as authorize a return request, issue a refund, or upload a prepaid return-shipping label with tracking. 
  * **Completed** : All return requests that have been completed or closed. 
  * **With A-z Claims** : All return requests with an A-to-z claims. 

For more information, go to [ Authorize a return request
](/help/hub/reference/external/G9DH343PLXALFTUW) and [ Complete or Close a
return request ](/help/hub/reference/external/WQ95DQ9UW4EF49F) . To download
the summary of returns and refunds for a specific timeframe, click **View
reports** in **Manage Returns** , or go to [ Return reports
](https://sellercentral.amazon.com/returns/report/) in Seller Central.

Before processing your returns, go to [ Returns, refunds, cancellations, and
claims ](/help/hub/reference/external/G69126) .

**Note:** Once issued, refunds can take 3-5 days to reflect in the buyer’s
account depending on their payment method. If you believe you have been
charged incorrectly, go to [ Investigate and appeal an A-to-z Guarantee Claim
](/help/hub/reference/external/G202041210) For more information, go to [
Amazon’s A-to-z Guarantee Claims ](/help/hub/reference/external/G27951) .

##  Appeal a return

You can file an appeal if Amazon authorized a return or refund on your behalf
that you believe should not have been authorized. For details, go to [
Reimbursement policy for Prepaid Return Labels (PRL) in the seller-fulfilled
network ](/help/hub/reference/external/G202175000) .

##  See also

[ Issue refunds and concessions for seller-fulfilled orders
](/help/hub/reference/external/GU7K5N5GUP67M4X9)

[ Issue Concessions ](/help/hub/reference/external/G200359070)

Top

##  Manage seller-fulfilled returns

* [ Authorize a return request  ](/help/hub/reference/external/G9DH343PLXALFTUW)
* [ Complete or Close a return request  ](/help/hub/reference/external/GWQ95DQ9UW4EF49F)
* [ Prepaid returns for seller-fulfilled orders  ](/help/hub/reference/external/G202072200)
* [ Process gift returns  ](/help/hub/reference/external/G201756900)
* [ Extended Holiday Returns policy  ](/help/hub/reference/external/G201725760)
* [ Guidelines for charging restocking fees  ](/help/hub/reference/external/G201725780)
* [ Potentially Hazardous Returns  ](/help/hub/reference/external/G201834690)
* [ Prime Now returns  ](/help/hub/reference/external/GYW2EV9FEMJ3JJGR)
* [ Returns FAQ  ](/help/hub/reference/external/G5A85XXCZDQ48A8T)
* [ Returns Performance dashboard FAQ  ](/help/hub/reference/external/GDY9EE2H8ZHFBFMP)
* [ Returns Provider program  ](/help/hub/reference/external/GX9KNCF6855SEPBN)
* [ Shipping correction charges for seller-fulfilled returns  ](/help/hub/reference/external/GD5FDC7MGAZMWTA4)

