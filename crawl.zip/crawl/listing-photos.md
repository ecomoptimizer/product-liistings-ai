# Listing photos

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Note: This feature is currently available for all category listings that are in the Used or Collectible condition, with the exception of Entertainment Collectibles, Sports Collectibles, and Art.

---
**Note:** This feature is currently available for all category listings that are in the Used or Collectible condition, with the exception of Entertainment Collectibles, Sports Collectibles, and Art.

## Overview

Using photos to help describe the items you are selling provides customers with useful information, and is especially helpful for describing the condition of used and collectible items. You can upload up to 6 photos to display as part of each listing.

## Where are the photos displayed?

The photos will be displayed on the All-Offers Display. A thumbnail of the main photo is displayed in the condition column of the All-Offers Display. When a customer clicks on the thumbnail, the full size photo will be displayed, along with thumbnails of the other photos of your item. For more information, see [All-Offers Display](https://sellercentral.amazon.com/gp/help/GYZNTFDKYWU75VZ8).

## Uploading photos

There are three ways to upload photos.  

1.  Sell on Amazon: All Sellers can upload photos through the **Sell on Amazon** page in the **Photos** section.
2.  Add a Product tool in Seller Central: Sellers can use the Add a Product tool in Seller Central. To add additional photos of an item for a specific listing, on the **Offer** tab, go to the **Photos of your item** section.
    
    **Note:** The **Images** tab of the **Add a Product** tool is where you add a Product Image to your listing, which may be displayed on the **Product Detail** Page. For more information the **Product Details** Page and Product Images, see [About Products and Listings](https://sellercentral.amazon.com/gp/help/200182950).
    
3.  Listings Loader tool Professional sellers have access to the Listings Loader tool. For information about how to use Listings Loader, see [Listings Loader](https://sellercentral.amazon.com/gp/help/200231900).

## Uploading photos of an item to My Current Listings?

Add photos of an item to your **My Current Listings** page using either Seller Central or Listings Loader. In your seller account, from the **Inventory** tab, click on **Manage Inventory** to view your listings. In the **Actions** column, click the **Actions** arrow next to the listing for which you would like to upload photos. From the drop-down, select **Edit Details**. In the **Offer** tab, scroll down to the **Photos** section.

## Photo Guidelines and Requirements

Photos of your item should be used to depict the characteristics of a specific, unique used or collectible item in your inventory. They are not intended to be photos of a new or generic product.

Listing photos of your item must meet the following requirements, which are different from Product Image Requirements

-   The photo must be of, or pertain to, the product being sold.
-   The photo must be in focus and well lit, with realistic color, and smooth edges.
-   Pure white backgrounds are preferred.
-   The photo must not contain gratuitous or confusing additional objects.
-   The photo must not contain additional text, graphics, or inset images.
-   Pornographic and offensive materials are not allowed.

Additional notes:

-   Other products or objects are allowed to help demonstrate the scale or use of the product.
-   Cropped or close-up photos are allowed.
-   Backgrounds and environments are allowed.

Before submitting listing photo files, be sure that they meet the following specifications:

| Photo Requirement | List Single Items | Book Loader Feeds |
| --- | --- | --- |
| Accepted File Types | JPEG (.jpg) and GIF (.gif) | JPEG (.jpg) and GIF (.gif) |
| Maximum File Size | 10MB | 10MB |
| Image Resolution | 72 pixels per inch | 72 pixels per inch |
| Minimum Dimensions\* | 200 x 200 pixels | One side must be at least 200 pixels but the other may be less |
| Maximum Dimensions\* | 2000 x 2000 pixels | 10,000 x 10,000 pixels |
| Maximum Dimension Ratio\* | 5 to 1 (2:1 or 1:1 preferred) | 5 to 1 (2:1 or 1:1 preferred) |

All photos submitted will be scaled to 500 x 500 pixels irrespective of the size and dimension ration of the photo provided. Photos that do not have a 1:1 dimension ratio will be padded with white space on the shorter sides.
