# Customization

Source: https://sellercentral.amazon.com/gp/help/external/G201817850

This article applies to selling in: **United States**

#  Amazon Handmade: Customizable products

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201817850)

On this page

List a customizable product

When should I offer customization options versus variations?

Examples of when to use customizations

B2B Business pricing for customizable products

Frequently asked questions

Customizable product listings offer customers an opportunity to customize
their product to their specifications beyond variation, and should be used
when you are offering personalization or multiple configuration options for
your products.

Before you can list and sell customizable products, you must [ register first
](/customization/manageCustomRegistration) .

When creating a customizable product listing, you can configure each product
with up to 10 different customization options, which are defined by you, using
one of the three different customization types:

  * **List of options** : Add a list of customization options (up to 20) for customers to choose from. For example, allowing a customer to select a shape, fabric, or leg style for a table. 
  * **Text entry** : Provide customers with a text entry box to use for engravings, monograms, or any other word-related custom features. 
  * **Number entry** : Provide customers with a number entry box to use for custom width, height, dimensions, or quantity inputs. 

**Note:** Image customization, text and font customization, customization
previews (in-cart and checkout), and displaying of real-time customization
selection in the custom product configurator are not currently enabled for
Handmade. We are working on this and hope to offer it to Handmade sellers in
2023.

_An example of a customizable product using all three customization types_ :
You handcraft tables. You might have options for various table shapes, wood
types, stain colors, and leg styles. In addition, you offer different table
heights and an option to identify how many table leaves are needed. And
finally, you may offer to engrave a gift message on the underside of the
table.

##  List a customizable product

To list a customizable product, follow these steps:  

  1. Create your listing first, as if it was not customizable, but ensure that you enter “0” in the **Quantity** field on the **Offer** tab. Setting “0” as your quantity ensures that nobody is able to purchase your item without customization. 
  2. Select **Inventory** , and then click **Manage Inventory** . 
  3. Search for the listing that you want to configure, click the down arrow next to **Edit** , and then click **Add/Edit Customization Information** . 
  4. Add the customization details for your product. 
  5. Update **Quantity** of your inventory to at least “1” once your product has been enabled with customization. This will make your product buyable. 

For more information, go to [ Listing a customizable product using Amazon
Custom ](/gp/help/external/G201822780) .

##  When should I offer customization options versus variations?

Customization options are used to provide an advanced shopping experience to
customers, allowing them to customize a product to suit their specific needs.
This can involve personalizing an item such as engraving a name on jewelry,
offering monogramming for towels, or when there are more than three
configurable options that can all be customized (for example, style, material,
color, size).

We recommend creating a variation listing when you are offering items that are
fundamentally the same, in terms of design or function. For example, candles
offered in different heights and scents, or a coat offered in different colors
and sizes. For more information, go to [ Variation relationships overview
](/gp/help/external/G8831) .

**Note:** Due to the customization aspect of these products, all orders for
customizable products must be fulfilled by you, the seller. FBA is currently
unavailable for customized products. However, your Handmade listings with
variations (without customizations) can be FBA.

##  Examples of when to use customizations

  * Configurations on a certain area of the product, such as pattern on the side of the sneaker and style of the belt buckle. 
  * Personalization such as monograms, engravings, personalized names or dates. In this example, we recommend adding a secondary product image with the font options clearly depicted. 

##  B2B Business pricing for customizable products

Handmade sellers can use Business pricing for a customizable Handmade product,
as long as Business sellers list the item with a Standard price and Business
price. However, the only exception is, if there is an additional fee for an
option, text, or number customization, the Business customer will not be
charged the additional fee. Therefore, it is recommended that you do not use
Business pricing for customizable Handmade products where you are charging an
additional fee for customizations.

##  Frequently asked questions

####  Can I use a feed upload to list customizable Handmade listings?

No. This feature is currently not enabled.

####  Can I apply customizations to multiple ASINs, in bulk?

Yes. Once you have applied a customization to an existing ASIN, you can copy
all of the customizations, such as, fonts, font colors, labels to a template
that you can downloaded as an excel file and apply, in bulk, to other ASINs.
Go to [ enable customizations in bulk ](/gp/help/external/GQMSBWT4DK5ARMXL)
for additional details.

####  Can I create an ASIN that offers a standard option and customizable one?

No. You will need to create two different ASINs. One for your standard option
and another for that same standard option, plus the customization. For example
– You sell hand-crafted cheese boards. You could create one listing just for
your cheeseboard (without customizations) and another listing that offers the
same cheeseboard with customization options. You can then create a variation
(parent-child) relationship in which one of the children is customizable and
the other child is not. To learn more about creating variations, go to [ Use
Add a Product to create variations ](/gp/help/external/G40731) .

**Note:** When creating parent-child relationships, existing reviews on
current products will not be lost.

####  How do I disable customizations on a listing?

You can follow these steps:  

  1. In Seller Central, select **Inventory** , and then click **Manage Inventory** . 
  2. Select **Custom Products** , and then find your product. 
  3. Click the down arrow next to **Edit** . 
  4. Remove customization information. 

####  How long does it take for newly-created listings to appear?

Newly-created listings typically appear on Amazon within 15 minutes, although
some details and images might not appear for 48 hours. Customizations can take
up to 36 hours to fully display on the detail page.

####  Why can’t I apply customization to an ASIN?

You cannot enable customization on a product that has more than one seller
currently offering it. If there are multiple sellers offering a product and
you would like to enable customization for it, you must create a new product
listing representing the unique customization features that you offer on the
product.

####  I have provided all the necessary information but the Customize Now
button is not displaying. What should I do?

Ensure that your product quantity is set to a value greater than zero and that
the ASIN is buyable. Additionally, ensure that there is only one offer on the
ASIN, either active or inactive.

####  In the customization enablement tool, what is the difference between
editing the parent ASIN and editing the child ASIN?

If you edit the parent ASIN using the customization enablement tool, your
edits will copy over to all child ASINs.

If you edit the child ASIN, your edits will only occur on the specific child
ASIN selected.

If you are configuring color variations, we recommend you edit each child so
that your preview image aligns to the correct color of the product.

Top

