# Customer Service by Amazon program

Source: https://sellercentral.amazon.com/help/hub/reference/external/GYGMNGX67ZJZMZNP

This article applies to selling in: **United States**

#  Customer Service by Amazon program

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGYGMNGX67ZJZMZNP)

Customer Service by Amazon (CSBA) is currently available in the following
stores:

Amazon stores  |  Applicable terms and additional information  
---|---  
Germany  |  [ Customer Service by Amazon terms and conditions
](https://sellercentral.amazon.de/gp/help/external/G65T4N3XGC3MJB38)

[ Customer service for seller-fulfilled orders (CSBA)
](https://sellercentral.amazon.de/gp/help/external/G797533XQVR4S6RG)  
  
Japan  |  [ Customer Service by Amazon terms and conditions
](https://s3.amazonaws.com/JP_AM/AGS/CSBA/Terms_CN.pdf)

[ Customer service for seller-fulfilled orders (CSBA)
](https://sellercentral.amazon.co.jp/gp/help/external/G797533XQVR4S6RG)  
  
United States  |  [ Customer Service by Amazon terms and conditions
](https://sellercentral.amazon.com/gp/help/external/G65T4N3XGC3MJB38)

[ Customer service for seller-fulfilled orders (CSBA)
](https://sellercentral.amazon.com/gp/help/external/G797533XQVR4S6RG)  
  
Top

##  Customer Service by Amazon program

* [ Customer service for seller-fulfilled orders  ](/help/hub/reference/external/G797533XQVR4S6RG)

