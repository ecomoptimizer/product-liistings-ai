# How Amazon Transfers Payments

Source: https://sellercentral.amazon.com/gp/help/external/19321

This article applies to selling in: **United States**

#  How Amazon transfers payments

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F19321)

When your seller account is settled and you have a positive balance, Amazon
sends the money to your bank account using an Automated Clearing House (ACH)
or electronic funds transfer.  It can take up to five business days for the
money to appear in your bank account after Amazon initiates a payment.

Your bank statement might show that Amazon's payments come from more than one
source. Amazon Payments, Inc. makes the payments for transactions in which
buyers agree to pay _ on or before _ the shipment of goods or completion of
services. Amazon Services LLC makes the payments for transactions in which
buyers agree to pay _ after _ the shipment of goods or completion of services.

Before we can pay you, you must provide a valid  [ Bank account
](/help/hub/reference/external/GWHNLFB8G85QAZ5W) as the Deposit Method in your
seller account settings.  We cannot make payments to a credit card or online
payment system, such as PayPal.

Top

