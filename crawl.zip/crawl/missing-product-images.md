# Missing product images

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> To troubleshoot missing images, first verify that your images were submitted properly. If, after verification, the images still do not appear, contact Amazon Seller Support and report a technical support issue. The troubleshooting steps you take depend on your submission method.

---
To troubleshoot missing images, first verify that your images were submitted properly. If, after verification, the images still do not appear, contact Amazon Seller Support and report a technical support issue. The troubleshooting steps you take depend on your submission method.

It can take up to 24 hours after adding an image for it to appear on Amazon.

**Note:** Uploading an image doesn't guarantee that it will be displayed. Amazon selects the images to display amongst all the available ones. Follow the guidelines provided in the [Product image requirements](https://sellercentral.amazon.com/help/hub/reference/G1881) help page to ensure your images are eligible to be displayed.

## Troubleshooting images in Seller Central

The "Add a Product" feature allows you to upload a product image as you create a new product. After creating a product, you can use the Manage Inventory feature to provide a new product image. .

If you use either of these features to manage your products, do the following:

  

1.  Click the **Inventory** link, and then click **Manage Inventory**.
2.  Search for or locate the product with the missing image.
3.  Click the **product name**, which will load the product’s detail page.
4.  Is there a product image(s) on this page? If so, you can choose to not upload.
5.  It takes up to 24 hours for an image to be displayed. If it has been more than 24 hours that you sent your images, then move to step 6. Otherwise check again after 24 hours.
6.  Your image might not be displayed because it does not meet the Amazon image standards, outlined [here](https://sellercentral.amazon.com/help/hub/reference/G1881) . If your image doesn't meet standards, fix the image by going to the **Manage Inventory** page, locate the product and click **Edit** and choose **Manage Images**. Follow the on-screen directions to submit a new image. Note that because we are continuously improving our image selection process, we may not yet indicate all the reasons why your image has not been selected. If you believe the current selection is incorrect, refer to the section below about contacting Amazon Services for technical support.

## Troubleshooting images with inventory files

An inventory file allows you to specify a location from which Amazon retrieves a copy of your product images. However, errors in your inventory file can block Amazon from successfully retrieving the product images.

This section lists some common errors that are related to the image:

| Symptom | Reason | Resolution |
| --- | --- | --- |
| Product image does not appear on Amazon | The most common reason is that the URL for that image does not actually capture the product image | Verify the image URL and re-submit the product image feed. |
| Amazon rejects the image. | The most common reason is that the submitted image is encoded in an invalid format. Amazon can only accept images in .jpg, .tif, or .gif formats. | Convert the file to .jpg, .tif, or .gif, revise the product image feed file, and re-submit the product image feed. |

You can refer [here](https://sellercentral.amazon.com/gp/help/G30601) to know more about correcting invalid image URL error.

**Note:** You must use a direct URL. A pop-up or a redirecting URL will not be accepted, and the upload will not be processed.

If you use inventory files to manage your products, do the following:  

1.  Check your inventory file processing reports for errors. For more information, see [Review Processing Reports](https://sellercentral.amazon.com/gp/help/201576740).
2.  [Modify](https://sellercentral.amazon.com/gp/help/201576660) your inventory file to correct any [errors](https://sellercentral.amazon.com/gp/help/17781) contained in the processing report.
3.  [Upload](https://sellercentral.amazon.com/gp/help/201576670) your modified inventory file.
4.  Repeat until your inventory file is free of errors.
5.  Allow 24 hours for your images to appear.

## Getting additional technical support

If you have followed the troubleshooting steps above and your product images still appear to be missing, contact [Amazon Selling Partner Support](https://sellercentral.amazon.com/gp/contact-us/contact-amazon.html).

In your message, include the following:

-   The troubleshooting steps you have already taken.
-   The method you use for managing your product and inventory data. Batch ID, in case you used troubleshooting steps with Inventory Files.
-   The ASIN for each product without a product image.
