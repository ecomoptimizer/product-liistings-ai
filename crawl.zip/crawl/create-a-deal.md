# Create a deal

Source: https://sellercentral.amazon.com.au/gp/help/external/202111550

This article applies to selling in: **Australia**

#  Create a deal

Sign in to use the tool and get personalised help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202111550)

[ Eligible ASINs ](/gp/help/external/G202111490) display automatically in the
**Deals Dashboard** .

There are three steps to create and submit a deal after selecting the **Create
a new deal** in the **Deals Dashboard** :  

  1. Select products 
  2. Select Amazon store and schedule 
  3. Configure deal and submit 

As you follow the prompts to create a deal, pay attention to the following:

  * **Selection of eligible products** : You can filter eligible products on the basis of deal type and eligible stores. You can also search your eligible products by ASIN. 

**Note:** The eligible ASIN that you select must participate in the deal.

  * **Deal store** : After you’ve selected the product, you can select an eligible Amazon store to run your deal. 
  * **Deal schedule** : After selecting the Amazon store to run your deal, you will see a list of available weeks for that product in the selected store. Lightning Deals will be scheduled to run on a day during the week selected and can run for up to 12 hours. Best Deals will run for seven consecutive days during the week selected. You will not be able to select the date or time for your deal. If approved, you can see the scheduled deal date and time in the **Deal Dashboard** one week before the deal is scheduled to run. 
  * **Deal price** : The maximum deal price that is suggested when creating a deal takes into consideration the lowest price from a seller offering the product in _new_ condition. The deal price may fluctuate if any changes are made to the current price and you cannot raise the price while the deal is running. 
  * **Deal Quantity** : Ensure that you have the proposed quantity at least seven days before the scheduled date. 

**Note:** Whilst a general minimum deal quantity is automatically entered for
draft Lightning Deals by Amazon, this is just a guide based on a general
product category and may not represent an appropriate minimum deal quantity

  * **Product variation** : You can select any eligible variations that you want to include in your deal that’s being recommended. However, we recommend that you include as many product variations (for example, size, colour, style) as possible to avoid rejection. For some products, such as clothing and shoes, at least  65%  of variations should be included in the deal, although this can change by locale and time of year. 
    * Once the deal has been submitted, avoid assigning new variations to the parent listing that were not originally recommended when the deal was created. Doing so might result in your deal being suppressed or cancelled. For some products, such as clothing and shoes, a minimum percentage of variations will be specified as a requirement. 

**Note:** Deals discounts will be combined with discounts from other
promotions that are running at the same time, including vouchers, promotions,
sale price, business price and giveaway. For example, if a deal offers a 20%
discount on a  $100  ASIN and that same ASIN also has a 5% off promotion
running at the same time, the 5% off discount from the promotion will combine
with the 20% discount from the deal. This will result in a total discount of
$25  .

Standard price:  $100

Deal discount: 20%

Promotion discount: 5%

Total discount: (100 * 0.2) + (100 * 0.05) =  $25

  * **Deal title** : The title for a deal comes from the product name of the ASIN participating in the deal or parent ASIN if the deal includes variations. If you want to change the deal title, you have to update the product name of the ASIN or parent ASIN before creating the deal. 
  * **Deal image** : The image for a deal comes from the images present on the **Amazon detail** page. Deal images must be on an all-white background and cannot include any text, logos or watermarks that are not a part of the product itself. Any deal with a deal image that violates Amazon’s [ Product image requirements ](/gp/help/external/1881) is subject to cancellation and may result in your account being suspended. If the available deal images when creating a deal are incorrect or do not match the images found on the detail page, you have to confirm that the correct images have been uploaded to the ASIN or parent ASIN (if the product has variations). You can [ contact Selling Partner Support ](/cu/contact-us) for image-related issues on product detail pages. 
  * **Deal frequency** : We strive to offer customers new deals every day. In order to achieve this, deals cannot run on the same ASIN within a  14-day  period, while Best Deals cannot run on the same ASIN within 21 days. Amazon may cancel any deal without notification if it does not meet these criteria. 
  * **Deal status** : Some deals may be immediately approved, while others may be suppressed at any time if they do not meet the [ eligibility criteria ](/gp/help/external/202111490) . We encourage you to monitor the [ status of your deal ](/gp/help/external/202111570) on the **Deals Dashboard** to reduce the risk of your deal being suppressed or cancelled, which could lead to an increase in FBA inventory and fees.  For more information, go to [ Troubleshooting suppressed and active deals ](/gp/help/external/GKN9A84DGTYWYHWY) . 

Top

