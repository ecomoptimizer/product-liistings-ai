# Non-white background

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Main images must be displayed against a pure white background so that the outline of the image is not visible when displayed in Amazon's search and detail pages.

---
## Non-white background

Main images must be displayed against a pure white background so that the outline of the image is not visible when displayed in Amazon's search and detail pages.

Shadows that run to the edge of the image frame or that the product or human models cast against a backdrop are not allowed. When using an image edited to remove background elements, any background areas that remain, off-white or gray backdrops, artifacts, objects, or outlines that are added around the border of the image, are not allowed.

**Note:** Alternate images may have a neutral or environment-based background.

| Allowed | Not Allowed |
| --- | --- |
| ![](https://m.media-amazon.com/images/G/01/image_requirements/white_bkgd1.jpg) | 
![](https://m.media-amazon.com/images/G/01/rainier/non-white2.jpg)

![](https://m.media-amazon.com/images/G/01/image_requirements/non_white_bkgd2.jpg)

![](https://m.media-amazon.com/images/G/01/image_requirements/non_white_bkgd3.jpg)

 |

Top

Was this article helpful?
