# Customer product reviews

Source: https://sellercentral.amazon.com/gp/help/external/G201972140

This article applies to selling in: **United States**

#  Customer product reviews

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201972140)

_Watch the video above for an introduction to Amazon’s customer product review
policies._

Amazon encourages buyers to review the products they like and dislike to help
customers make informed decisions about the products they purchase.

To ensure that reviews remain helpful, sellers must comply with [ Customer
product reviews policies ](/gp/help/external/YRKB5RU3FS5TURN) .

Sellers can add a comment to a review by clicking the **Comment** button below
the review. Comments must comply with our [ Community Guidelines
](https://www.amazon.com/gp/help/customer/display.html?nodeId=201929730&language=en_US&ref=ag_home_cont_201972160)
.

For answers to common questions about customer product reviews, see [ Answers
to questions about product reviews ](/gp/help/external/201972160) .

**Note:** As sellers and manufacturers, you are not allowed to review your own
products, or to negatively review a competitor's product. Violation of our
policies may also violate applicable laws, which can lead to legal action and
civil and criminal penalties. If you violate our policies, Amazon reserves the
right to disclose your name and other related information publicly and to
civil or criminal enforcement authorities. For additional examples, refer to [
Inappropriate product reviews ](/gp/help/external/GE8SYAZUBGVFBHCH) .

##  Report abuse

**Note:** Refer to [ Customer product reviews policies
](/gp/help/external/YRKB5RU3FS5TURN) before reporting abuse.

To report possible violations of our policies, send email to community-
help@amazon.com, specifying the location of the content and the reason you
believe it violates the guidelines.

Top

##  Customer product reviews

* [ Answers to Questions about Product Reviews  ](/help/hub/reference/external/G201972160)

