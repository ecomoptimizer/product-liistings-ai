# exclude products

Source: https://sellercentral.amazon.com/gp/help/external/202121630

This article applies to selling in: **United States**

#  Exclude offers or products from a target marketplace

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202121630)

If you do not want an offer connected to a target marketplace, you can exclude
it at the marketplace level. Excluding products is done at the SKU level. A
SKU is assigned by you or automatically generated when you create a product
offer.

If a connection exists and you exclude a product:

  * Your offer on the target marketplace will still be active, but the price will not be synchronized based on price changes to an offer on the source marketplace. 
  * The [ Build International Listings ](/global-selling/listings/connect) tool will not automatically update prices in the target marketplace based on exchange rate fluctuations. 

To exclude your offer:

  

  1. Using Build International Listings, [ create a connection ](/gp/help/external/G202121580) between the source and target marketplace. 
  2. Go to the [ Build International Listings ](/gp/global-selling/sync-offers/) tool. 
  3. If you have set up a second source marketplace, use the marketplace switcher at the top left of the page to select the source marketplace for which you want to exclude the offer. 
  4. On the left side of the page, select the target marketplace from which you want to exclude the offer. 
  5. Click **Edit** next to **Exclusions** in the **Connection settings** widget. 
  6. A window is available at the top of the page where you can enter a SKU or a list of SKUs that you want to exclude from the target marketplace. You must do this for each target marketplace from which you want to exclude your offer. A maximum of 1,000 SKUs can be excluded at a time. 
  7. Click **Exclude offers** . 

Change your offers only in the source marketplace. This allows Build
International Listings to update offers in the target marketplaces. If you
make any change in the target marketplace — for example, if you change the
price of an offer or delete an offer — the connection for the offer between
the marketplaces will be broken. When a connection is broken, it will have the
same effect as when you exclude the SKU. The SKU will be added to your
exclusion list so you can reconnect it.

Top

