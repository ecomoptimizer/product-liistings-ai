# additional regulation in the state ofCalifornia

Source: https://sellercentral.amazon.com/gp/help/external/GUDRMYJ7JL4PGNAB

This article applies to selling in: **United States**

#  California regulations

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGUDRMYJ7JL4PGNAB)

In California, a broad range of products are subject to additional regulation.
The list of regulations below is provided solely as an informational guide and
is not comprehensive. We encourage you to consult with your legal counsel if
you have questions about the laws and regulations applicable to your products.

##  Additional information

  * [ California Air Resources Board (CARB) ](/help/hub/reference/external/G202082160)
  * [ California Department of Forestry and Fire Protection (CAL FIRE) ](/help/hub/reference/external/GRE7PT254E4AFJFU)
  * [ California Energy Commission (CEC) ](/help/hub/reference/external/G7PNYFCP46WHA3RL)

Top

##  California regulations

* [ California Air Resources Board (CARB)  ](/help/hub/reference/external/G202082160)
* [ California Department of Forestry and Fire Protection (CAL FIRE)  ](/help/hub/reference/external/GRE7PT254E4AFJFU)
* [ California Energy Commission (CEC)  ](/help/hub/reference/external/G7PNYFCP46WHA3RL)

