# Best Deal & Lightning Deal Performance Results

Source: https://sellercentral.amazon.com/help/hub/reference/external/GTXD25GEG7Z6XZHC

This article applies to selling in: **United States**

#  Best Deal & Lightning Deal Performance Results

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGTXD25GEG7Z6XZHC)

The overall performance for your Best deals and Lightning Deals can be found
in the [ Manage Deals page ](/merchandising-new#search-and-filters) in Seller
Central.

Click **View** on the specific Deal to see performance for each SKU in the
Deal. The following metrics will be provided to you in the **Product Details**
and **Pricing** section of your Deal:

  * **Units Sold** : The number of deal units sold during the deal 
  * **Items Waitlisted** : The number of items that the customers added to a waitlist after a deal sells out. A high number of Items Waitlisted suggests that you could have sold more Deal units than the Quantity for Deal that was entered for the SKU 
  * **Deal Revenue** : Ordered product sales (Units Sold x Deal Price) for that SKU 
  * **Total Deal Revenue** : Ordered product sales for all SKUs that participated in the deal 

**Note:** Your sales data might take upto two hours to become available after
the deal ends.

Top

