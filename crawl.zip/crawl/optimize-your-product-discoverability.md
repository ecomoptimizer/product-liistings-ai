# Optimize your product discoverability

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> Customers must be able to find your products before they can buy them. One way customers find your products is to search by entering the keywords, which are matched against information such as title and description that you provide for a product. By providing relevant and complete information for your product, you can increase your product's visibility and sales. Below are some general guidelines to improve your product discoverability.

---
## Optimize your product discoverability

Customers must be able to find your products before they can buy them. One way customers find your products is to search by entering the keywords, which are matched against information such as title and description that you provide for a product. By providing relevant and complete information for your product, you can increase your product's visibility and sales. Below are some general guidelines to improve your product discoverability.

## Product detail page

Each individual word in the Product Name (Title) is searchable on its own. For example, a product called Laura Ashley Sophia Collection 300-Thread-Count Pillow Cases (Blue, Queen, Set of 2) is better than Blue Pillow Cases. This is because the recommended Product Name above includes this information:

-   Brand - Laura Ashley
-   Product line - Sophia Collection
-   Material or key feature - 300-Thread-Count
-   Product Type - Pillow Cases
-   Color - Blue
-   Size - Queen
-   Packaging/Quantity - Set of 2

Learn how to [improve product detail pages](https://sellercentral.amazon.com/gp/help/G10521).

## Titles

Titles should be approximately 60 characters long. You only have a moment to catch the eye of a shopper and your online title on Amazon should echo what would be on the physical packaging of a product.

## Keywords

You can add additional keywords to an ASIN's catalog data to describe that product. These are hidden from the customers.

**Note:** We recently started limiting the length of the search terms attribute to less than 250 bytes in an effort to improve the quality of shopping results. Learn more about how to make your products discoverable within those limits by [using search terms effectively](https://sellercentral.amazon.com/gp/help/G23501).

## Search Terms

Amazon provides you with an opportunity to add search terms for your products. These search terms should only include generic words that enhance the discoverability of your product. For example, if you're selling headphones, your search terms can contain synonyms such as "earphones" and "earbuds." Search terms are not required fields.

Here are some best practices for providing search terms:

-   Don't include product identifiers such as brand names, product names, compatible product names, ASINs, UPC codes, and so on.
-   Don't provide inaccurate, misleading, or irrelevant information such as the wrong product category, the wrong gender, out-of-context words, and so on.
-   Don't provide excessively long content. Respect the limits that are set for different fields.
-   Don't provide redundant information that is already captured in other fields such as title, author, brand, and so on. It won't improve your product placement in shopping results.
-   When entering several words as a search term, put them in the most logical order. A customer is more likely to search for "big stuffed teddy bears" than for "teddy stuffed bears."
-   Use a single space to separate keywords. No commas, semicolons, or carets are required.
-   Don't include statements that are only temporarily true, such as, "new," "on sale," or "available now."
-   Don't include subjective claims such as amazing, good quality, and so on, since most customers don't use subjective terms in their queries.
-   Don't include common misspellings of the product name. Our systems compensate for common customer misspellings and also offers corrective suggestions.
-   Don't provide variants of spacing, punctuation, capitalization, and pluralization ("80GB" and "80 GB,” "computer" and "computers,” and so on). Our systems automatically include different case forms, word forms, and spelling variants for searching.
-   Don't include terms that are abusive or offensive in nature.
-   Abbreviations, alternate names, topics, and key characters (for books, movies, and so on) could be included as search terms.

**Note:** Amazon reserves the right to not use all supplied keywords for retrieving products. Reasons for not using all keywords may include, but are not limited to, search computational efficiency, potential manipulation of shopping results, irrelevant search terms, and offensive or illegal terms.

Top

Was this article helpful?
