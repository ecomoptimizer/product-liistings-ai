# List your first item

Source: https://sellercentral.amazon.com/gp/help/external/201218360

This article applies to selling in: **United States**

#  Video tutorial: List your first item

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201218360)

Learn to list your first product and start selling on Amazon.

Top

