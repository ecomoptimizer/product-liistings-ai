# listings detail and category information

Source: https://sellercentral.amazon.com/gp/help/external/G200182950

This article applies to selling in: **United States**

#  About products and listings

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200182950)

####  Product information:

These details are common to every instance of the product on Amazon. For
example, several sellers list Bose speakers on Amazon, so the general details
about the product, such as the name and model number, are the same. When more
than one seller contributes data to a product, Amazon determines which
seller's product information will be displayed on the product detail page.
Learn more about fixing errors on a [ product detail page
](/gp/help/external/200335450) .

####  Listing information:

These are the details about the products that you sell. These details can
differ from other sellers' listings. For example, you might sell the same Bose
speakers as another seller, but your condition, price, or handling time may be
different.

You can use **Manage Inventory** to view and update both product and listing
information.

The combination of product and listing information is referred to as "item
information" or "inventory information."

##  Sell multiple units

All sellers have the option to list in quantity. Follow these listing
guidelines:

  * If you have multiple identical units of the same product, use the quantity field. Do not create multiple listings for the same product. 
  * If you have multiple units of the same product with different conditions or editions, create a unique listing for each version of the product. 

In addition, items that are fulfilled by Amazon may be listed separately for
each condition type.

Top

##  About products and listings

* [ Listing requirements: Product IDs (GTINs)  ](/help/hub/reference/external/G200317470)
* [ Review category requirements  ](/help/hub/reference/external/G200316110)
* [ Classify your products  ](/help/hub/reference/external/G23531)
* [ Add a product video tutorials  ](/help/hub/reference/external/G200999830)
* [ Stop selling a product  ](/help/hub/reference/external/G200216110)
* [ Guidelines for UPC and GTIN  ](/help/hub/reference/external/G5JQC6VY6BVYWDPT)

