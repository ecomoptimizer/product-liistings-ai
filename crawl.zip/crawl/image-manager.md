# Image manager.md

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Every product detail page requires at least one product image, and we recommend you provide six images and one video. Good images make it easy for customers to evaluate the product. Images should be clear, informative, and attractive. The first image on the product detail page is the "MAIN" image and is shown to customers in search. The MAIN image must show only the product for sale on a white background, and the product should fill the image frame. Additional images called Image variants should show the product in use or in an environment, different angles, and different features. There are several ways to add product images:

---
Every product detail page requires at least one product image, and we recommend you provide six images and one [video](https://sellercentral.amazon.com/gp/help/GWJRQF3C34G4PRA2). Good images make it easy for customers to evaluate the product. Images should be clear, informative, and attractive. The first image on the product detail page is the "MAIN" image and is shown to customers in search. The MAIN image must show only the product for sale on a white background, and the product should fill the image frame. Additional images called Image variants should show the product in use or in an environment, different angles, and different features. There are several ways to add product images:

-   Use the [Image manager tool](https://sellercentral.amazon.com/imaging/manage) to upload and manage listing images.
-   You can also upload images in bulk to your listings using [Bulk image upload](https://sellercentral.amazon.com/imaging/upload).

It can take up to 24 hours after adding an image for it to appear on the website.

## Upload and manage listing images:

1.  From Seller Central, click the **Inventory** tab and select **Upload images**.
2.  Click the **Image manager** tab.
3.  In the left pane, search for your product using either ASIN or SKU.
4.  From the search results, select your product for which you want change the images.
    
    **Note:** To preview the current images associated with your product, click the **Live images** drop-down.
    
5.  To change various image variants (main, front, side back, and so on) for your product, under **Images submitted by you**, click **Upload**.
    
    For more information about image variants, go to [Image variants](https://sellercentral.amazon.com/gp/help/G8HQAHPDXA9ANPH4).
    
    **Note:** The pre-selected image variant recommendations are specific to your product category style guide. To include a variant that is not pre-selected, select the drop-down next to the variant name to replace it with another variant ID code before uploading an image.
    
6.  Select an image from your computer and click **Open**. This will submit the image to that variant.
7.  To delete an image previously submitted by you, click the trash icon under the image thumbnail and confirm the deletion. Images shared between child ASINs will need to be deleted individually from each ASIN. You cannot delete the main images because all ASINs require a main image. Instead, you can replace the main image with a new image by clicking on the camera icon under the main thumbnail, which will delete the original image.

## Add images in bulk to an existing listing

1.  From Seller Central, click the **Inventory** tab and select **Upload images**.
2.  Click the **Bulk image upload** tab and review the image requirements.
3.  Under **Upload Images**, drag or click to add an image or zip file from your computer.
4.  Click **Open** and select the image file from your computer.
5.  Click **Submit images**.

To learn more about viewing image upload status and products removed from search due to image issues, go to [Image Issues](https://sellercentral.amazon.com/gp/help/GT8RSE9S9NK4LP6Z). To learn more about providing video, go to [Upload a video](https://sellercentral.amazon.com/gp/help/GWJRQF3C34G4PRA2).
