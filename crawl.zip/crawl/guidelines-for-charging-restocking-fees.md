# Guidelines for charging restocking fees

Source: https://sellercentral.amazon.com/gp/help/external/201725780

This article applies to selling in: **United States**

#  Guidelines for charging restocking fees

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201725780)

In some circumstances, you can charge a restocking fee when a buyer returns an
item. These circumstances include when an item is returned outside of [
Amazon’s return policy
](/gp/help/customer/display.html/?nodeId=15015721&language=en_US&ref=ag_home_cont_G200708210)
or in used, damaged, /defective, or materially different condition. Items
returned in original condition and within [ policy
](/gp/help/customer/display.html/?nodeId=15015721&language=en_US&ref=ag_home_cont_G200708210)
cannot be charged a restocking fee. You are not required to accept returns
beyond the return window. However, if you do, you can also charge a restocking
fee.

A restocking fee is a percentage of the item's price; depending on the type of
item and its condition upon return (item price does not include shipping
costs). Only returned items are eligible for a restocking fee. The refund
workflow will help you calculate the restocking fee for eligible items, and
deduct it from the refund you issue to your customer based on the guidelines
outlined in the table below.

**Return Request** |  **Restocking Fee**  
---|---  
The buyer changes their mind* about a purchase and returns an item in the
original condition within the return window.  |  No restocking fee.  
The buyer changes their mind* about a purchase and returns an item in the
original condition outside of the return window  |  Yes. Up to 20% of item’s
price.  
The buyer refuses delivery due to visible damage incurred during shipping or
caused by the carrier.  |  No restocking fee. The seller pays for return
shipping, but can file a claim with the carrier or insurance company, if they
purchased insurance.  
The buyer receives a used or damaged item.  |  No restocking fee. The seller
can file a claim with the carrier or insurance company, if they purchased
insurance.  
The buyer changes their mind* about a purchase and returns a non-media item
within the return window but the seller receives the item damaged or
materially different than how it was originally shipped to the buyer.  |  Yes.
Up to 50% of item's price.  
The buyer returns a book within the return window with obvious signs of use.
|  Yes. Up to 50% of item's price.  
The buyer returns a CD, DVD, VHS tape, , cassette tape, or vinyl record within
the return window that has been opened (taken out of the plastic wrap).  |
Yes. Up to 50% of item's price.  
The buyer changes their mind* and returns open software or video games.  |
Yes. Up to 100% of item’s price  
The buyer returns an item they received materially different from what they
ordered.  |  No restocking fee.  
Any other reason not listed here.  |  See [ About Refunds
](https://www.amazon.com/gp/help/customer/display.html/?nodeId=901926&language=en_US&ref=au_home_cont_G201725780)
.  
  
*The buyer changes their mind and returns the item for one of the following reasons: 

  * Accidental order 
  * Better price available 
  * No longer needed/wanted 

See [ Issue Refunds and Concessions for Seller Fulfilled Orders
](/gp/help/external/GU7K5N5GUP67M4X9) to learn how to charge restocking fees.

To learn about processing returns, see [ Manage seller-fulfilled returns
](/gp/help/external/G200708210) .

Top

