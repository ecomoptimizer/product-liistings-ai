# Customer Service Guidelines.

Source: https://sellercentral.amazon.com/gp/help/external/202073200

This article applies to selling in: **United States**

#  Customer service guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202073200)

Amazon provides an extraordinary experience to customers. Customers have come
to expect this type of service, and that is what keeps them coming back for
more purchases. As a seller, you are now in control of this experience for
your customers. We expect that you will keep this philosophy in mind and
ensure that the customer contacts for which you are responsible are timely,
honest, and respectful.

Seller will handle all customer contacts relating to those customer service
issues for which the seller is responsible, including seller customer service
areas such as:

  * Products, pricing, rebates, item information, availability, technical support, warranty, and public and private recalls 
  * Anything related to third party platform editions of your products (for example, iPad and Android issues) 
  * Order fulfillment 
  * Order cancellation by you or a customer through seller sales channels 
  * Feedback concerning experiences with your personnel, policies, and processes. "Personnel" includes any third party warranting, administering, or otherwise involved in the offer, sale, performance, or fulfillment of your products, including any of your employees, representatives, agents, contractors, or subcontractors. 

Amazon will handle all customer contacts relating to those customer service
issues for which Amazon is responsible, including Amazon customer service
areas such as:

  * Payment 
  * Credit card processing, debiting, or crediting 
  * Use of Amazon sites and their features (including the ordering process, cancellation process, use of customer accounts, help, and subscription management, but excluding seller order fulfillment issues) 
  * Performance of the Amazon sites 

Unless seller and Amazon agree otherwise, with respect to communications sent
to customers:

  * Amazon will handle all transactional communications (such as order confirmations, cancellation confirmations, notices of auto-renewal, and similar communications) related to the purchase or auto-renewal of a product. 
  * Seller will handle all service or content update communications. 

Amazon may implement mechanisms that rate, or allow customers to rate, your
products and your performance as a seller, and Amazon may make these ratings
and feedback publicly available.

When providing customer service for products purchased via Subscribe with
Amazon program, the customer service for your products should be at least as
responsive and available as the most favorable customer service offered
through any seller sales channels and offer at least the same level of
support.

Top

