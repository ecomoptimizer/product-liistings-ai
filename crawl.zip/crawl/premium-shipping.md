# Premium Shipping

Source: https://sellercentral.amazon.com/gp/help/external/G201503640

This article applies to selling in: **United States**

#  Premium Shipping

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201503640)

To be eligible to offer Premium Shipping options, you must be selling on
Amazon for more than 90 days and must meet the following requirements for 30
days for Premium Shipping orders.

  * [ Valid Tracking Rate ](/gp/help/external/G201817070) of 99% 
  * [ On-Time Delivery Score ](/gp/help/external/G200633610) of 97% or greater 
  * Seller-initiated [ cancellation rate ](/gp/help/external/G200285210) of less than 0.5% 

In the United States, Premium Shipping options include [ One-Day Shipping
](/gp/help/external/G202166970) , and/or [ Two-Day Shipping
](/gp/help/external/G201605130) , which you can enable in your shipping
settings.

Amazon will determine your ongoing eligibility by your delivery performance
for orders with Premium Shipping, excluding seller fulfilled orders with a
Prime badge. Review your [ Premium Shipping Eligibility dashboard
](/gp/seller-rating/pages/eligibilities.html) to track eligibility.

**Note:** To deactivate Premium Shipping, you must update the shipping
templates under Shipping Settings and clear the One-Day Delivery and Two-Day
Delivery option.

For more information about perfomance, eligibility, and order cutoff times,
see the following:

  * **Measuring your performance.** There is 10 day lag in getting carrier data. Therefore, we will measure your performance from day 40 to day 10 and exclude Seller Fulfilled Prime orders from the evaluation. Seller Fulfilled Prime orders will be evaluated separately according to the following: [ Seller Fulfilled Prime ](https://sellercentral.amazon.com/gp/help/external/G201812230?language=en_US&ref=ag_G201812230_cont_G201503640)
  * **Revocation of eligibility for Premium Shipping.** If the performance targets falls below the requirements, your eligibility for Premium Shipping may be revoked. Premium Shipping options will be disabled on your offers, and your status will change to not eligible in the Premium Shipping Eligibility dashboard. Your Seller Fulfilled Prime offers will be unaffected by revocation of eligibility for Premium Shipping. 
  * **Restoration of eligibility for Premium Shipping.** You must submit a [ Plan of Action ](https://sellercentral.amazon.com/gp/help/external/G201857560?language=en_US&ref=ag_G201857560_cont_G201503640) to request the restoration of your eligibility to Premium Shipping. 
  * **Order Cutoff Times.** Order cutoff times for your Premium Shipping options must be set to 2:00 P.M. or later local time. Note: The time zone is associated with the warehouse farthest east. 

**Note:** To learn how to set shipping rates for Premium Shipping orders, see
[ Set your shipping rates
](https://sellercentral.amazon.com/gp/help/external/G201841310?language=en_US&ref=ag_G201841310_cont_G201503640)
.

Top

##  Premium Shipping

* [ Order fulfillment settings  ](/help/hub/reference/external/G202096730)
* [ Enroll in One-Day Delivery  ](/help/hub/reference/external/G202166970)
* [ Enroll in Two-Day Shipping  ](/help/hub/reference/external/G201728190)
* [ Premium Shipping Options FAQ  ](/help/hub/reference/external/G201605110)
* [ Submit a Plan of Action for Premium Shipping Options  ](/help/hub/reference/external/G201857560)
* [ Premium Shipping option defect report  ](/help/hub/reference/external/GH7N74XKU6CEEEJC)

