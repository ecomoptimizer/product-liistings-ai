# content requirements

Source: https://sellercentral.amazon.com/gp/help/external/GUHDLPWYZ6FW3N42

This article applies to selling in: **United States**

#  Manage Your Customer Engagement campaign requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGUHDLPWYZ6FW3N42)

On this page

Product acceptability

General image standards

Logo images

Main product images

Lifestyle and supporting images

Prohibited images

[ Manage Your Customer Engagement ](/gp/help/external/GF85G8KLPFJZZV5K) lets
you engage directly with Amazon Customers who Follow or purchase from your
Brand, and helps you build loyal relationships with Amazon Customers and
increase visibility of your new products. The products and images you use in
your Customer Engagement campaigns must comply with the following standards
and guidelines.

##  Product acceptability

If your campaign primary product does not meet the following acceptability
criteria, your campaign may be suspended. If any supporting products of your
campaign do not meet the criteria, the respective products will be removed
from the campaign.

  * Products must be eligible for advertising, as per [ Section 4 of the Sponsored Ads Guidelines and Acceptance Policies. ](https://advertising.amazon.com/resources/ad-policy/sponsored-ads-policies?ref_=a20m_us_p_sp_faq_spcs_spadcap_c#productacceptability)
  * Products must be child ASINs (parent ASINs are not acceptable). 
  * Products cannot be part of a bundle. 
  * Inventory requirements: 
    * ASINs must have 10 or more units of inventory at time of campaign creation and before and during campaign send. 

##  General image standards

  * Images must accurately represent the product. 
  * The product and all of its features must be clearly visible. 
  * Images must match the product title. 
  * We accept JPEG (.jpg) and PNG (.png) file formats, but prefer JPEG. 
  * We do not support animated .gif files. 
  * Images must not contain nudity or be sexually suggestive. 
  * Avoid text in images, as emails may be translated to the preferred language of your customers and image text will not be translated. 

##  Logo images

  * Logos must be in a horizontal layout on black, white, or transparent background. We will accept a different background color only if it is part of your logo branding. 
  * Logos must have a 3:1 aspect ratio. 
  * Logos must be JPEG (.jpg) or PNG (.png) format. 

The following are prohibited in logo images:

  * Call to action buttons or text 
  * Overlapping elements 
  * Claims such as "made in the USA," unless verified with the registered logo on the product packaging or product detail page 
  * Competitive products or services 
  * Profanity 
  * Deals or promotions 
  * Alcohol-related products 
  * Hate or intolerance 
  * Weapons 
  * Solicitations to contact you 
  * References to your other products 
  * Your contact information, such as phone number, email address, or website 
  * Shipping messaging 

##  Main product images

The ASIN image featured in the Manage Your Customer Engagement email campaign
is the main default image on the product detail page.

  * Every product needs one or more product images. The primary image of your product is called the **main** image. The main image is displayed for a product in search results and site pages, and is the first image customers see on the product detail page. 
  * As images are very important to customers, image quality matters. Choose images that are clear, easy to understand, informative, and attractively presented. 

##  Lifestyle and supporting images

You can use a product detail page image as a **supporting** or **lifestyle**
image for your campaign. If you do not use lifestyle imagery on the product
detail page, you can upload a new supporting image. Follow the image standards
listed on this page to maintain quality and consistency across all of your
product images.

  * Lifestyle images may display a setting as context for the product or brand. 
  * Supporting images should meet the following guidelines: 
    * Image should not consist of only text. 
    * Image must not be a duplicate of the primary image. 
    * Product copy may be included in the lifestyle image, as long as it supports the benefits of the product. 
    * Image must not display a contradiction of the product. 
    * Product must occupy at least 85% of the frame. 

If you are creating your own images, you may find our [ imaging products
](https://www.amazon.com/gp/browse.html/?node=14725653011) or [ photography
videos ](https://www.amazon.com/gp/browse.html/?node=17051490011) useful.

##  Prohibited images

The following are prohibited for images:

  * Amazon logos or trademarks, variations, modifications, or anything similar to Amazon's logos and trademarks. This includes, but is not limited to, any words or logos with the terms Amazon, Prime, Alexa, or the Amazon Smile design. 
  * Badges used on Amazon, variations, modifications, or anything similar to such badges. This includes, but is not limited to "Amazon's Choice", "Premium Choice", "Amazon Alexa", "Works with Amazon Alexa", "Best Seller", or "Top Seller". 
  * Images that are blurry, pixelated, or have jagged edges. 
  * Images where product does not fill at least 85% of the frame on the longest side. 
  * Promotion of alcohol, alcohol consumption, or alcohol-related products. 
  * Children’s products shown in an unsafe way, such as product unattended in a pool. 
  * References to shipping or delivery times. 
  * Images containing contact details. 
  * Crowded elements such as text, logos, or too many items. 
  * Images that contain references to another brand, product, or services. 
  * Images that are cropped so that it obscures the product, with the exception of jewelry particularly necklaces. 
  * Promotional content or time-sensitive content. 
  * Warranty or guarantee information that does not have supporting evidence on the product detail page. 
  * Claims that are not substantiated. All claims must be substantiated by a third-party source and cannot be older than 24 months. 
  * Images that include profane terms. 
  * Excessive violence, gore, or scenes that depict torture or abuse to humans or animals. 
  * Images that contain weapons pointed toward individuals or displayed in a gruesome manner. 
  * Content that promotes hate or incites violence or intolerance. 
  * Sexually suggestive content that shows people in poses that emulate a sexual position or draws attention to intimate body parts. 
  * Images that contain sensitive events such as natural disasters, human-caused disasters, health emergencies, incidents of mass drama, or death of a public figure. 
  * Images that undermine, mock, or criticize cultures. 

The following are also prohibited for **main** images:

  * Text, logos, borders, color blocks, watermarks, or other graphics over the top of a product or in the background. 
  * Excessive internal or external propping that covers or surrounds the product or causes confusion about the product. 

Top

