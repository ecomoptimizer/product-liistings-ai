# Listing blocked due to potential pricing error

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> When Amazon detects potential pricing errors in your listings, we will notify you, and we might deactivate the affected listings to avoid a potentially negative customer experience.

---
When Amazon detects potential pricing errors in your listings, we will notify you, and we might deactivate the affected listings to avoid a potentially negative customer experience.

You can identify deactivated listings using the following views:

-   Select **Fix Price Alerts** from the **Pricing** drop-down menu.
-   Use the **Inactive** filter in **Manage Inventory**.

**You can calculate Minimum Price as: \[Item Cost + Amazon Fees + Minimum Profit desired\].**

## Troubleshoot pricing and other listing errors

If you are having difficulty with identifying the cause of your pricing and listing error, use the following tool:

Top

Was this article helpful?
