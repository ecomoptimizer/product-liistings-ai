# Frequently Asked Questions

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69120

This article applies to selling in: **United States**

#  Frequently Asked Questions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69120)

Top

* [ Account health FAQ  ](/help/hub/reference/external/G200285250)
* [ Can Amazon remove buyer feedback?  ](/help/hub/reference/external/G20231)
* [ Why do my numbers seem different across the various seller reports?  ](/help/hub/reference/external/G200989470)

