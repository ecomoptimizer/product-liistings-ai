# List products for Fulfillment by Amazon

Source: https://sellercentral.amazon.com/gp/help/external/200141220

This article applies to selling in: **United States**

#  List products for Fulfillment by Amazon

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200141220)

On this page

Change a listing to Fulfilled by Amazon

List products for multi-channel fulfillment exclusively

Close a listing

Delete a listing

After you create a new listing for a product, you specify it as FBA inventory
by changing the **Fulfilled by** value from **Merchant** to **Amazon** .

When you close or delete an FBA listing, any inventory you have in Amazon
fulfillment centers will not be returned or disposed of until you submit a
removal order. For more information about closing or deleting listings, please
see "Close a listing" and "Delete a listing" later in this topic. For more
information about removal orders, see [ Remove inventory (overview)
](/gp/help/external/200280650) .

**Tip:** You can view your FBA inventory listings on the **Manage Inventory**
page by clicking **Amazon** in the **Fulfilled by** section of the **Filters**
bar.

You can add products to your inventory individually or upload a list of
products to create multiple listings at once. For more information, see one fo
the following:

  * [ Add one product at a time ](/gp/help/external/200220550)
  * [ List products in bulk ](/gp/help/external/200327780)

Make sure that you adhere to the FBA listing requirements when filling out the
details page for your offer. For more information, see [ FBA Listing
Requirements ](/gp/help/external/201051300) .

##  Change a listing to Fulfilled by Amazon

To change a listing to Fulfilled by Amazon:

  

  1. On the [ Manage Inventory ](/hz/inventory) page, select the items that you want to change to FBA. 
  2. On the **Action on Selected** drop-down list, click **Change to Fulfilled by Amazon** . 

**Tip:** To change an FBA listing to a self-fulfilled listing, select **Change
to Fulfilled by Merchant** .

  3. On the **Convert to Fulfilled by Amazon** page, click **Convert** to go to the **Amazon-Fulfilled Inventory** page, or click **Convert & Send Inventory ** to begin creating a shipping plan. For more information, see [ Create an FBA Shipping Plan ](/gp/help/external/201021820) . 

**Important:** If you want to fill orders for these items yourself as well as
offer these items as Fulfilled by Amazon, you must create two listings, one
for each fulfillment type.

##  List products for multi-channel fulfillment exclusively

You can list your Multi-channel Fulfillment inventory without those products
appearing for sale on Amazon by entering a **Start selling** date that is far
in the future when you create your product listing.

**Important:** If you have an Individual selling account, you must list your
products for sale on Amazon in addition to filling orders from other channels.
If you want to use Multi-channel Fulfillment exclusively, and not list your
products for sale on Amazon, you must sign up for a Pro Merchant account.

For more information about using Multi-Channel Fulfillment, see [ Multi-
Channel Fulfillment ](/gp/help/external/200332450) .

##  Close a listing

When you close a listing, the status changes from **Active** to **Inactive** ,
and makes your product unavailable for sale on Amazon. Your inventory of that
product will remain in Amazon fulfillment centers. You can relist your
products, submit removal orders, or fill orders through other channels with
Multi-channel Fulfillment.

  

  1. On the [ Manage Inventory ](/hz/inventory) page, select the listings that you want to close. 
  2. On the **Action on Selected** drop-down list, click **Close listing** . 

##  Delete a listing

When you delete a listing, any offers that are fulfilled by Amazon remain in
your inventory list, but are not available for purchase on Amazon or for
filling Multi-channel Fulfillment orders. Inventory in Amazon fulfillment
centers will remain there until you submit a removal order. For more
information, see [ Remove inventory (overview) ](/gp/help/external/200280650)
.

  

  1. On the [ Manage Inventory ](/hz/inventory) page, select the listings that you want to close. 
  2. On the **Action on Selected** drop-down list, click **Delete products and listings** . 

##

##

Top

