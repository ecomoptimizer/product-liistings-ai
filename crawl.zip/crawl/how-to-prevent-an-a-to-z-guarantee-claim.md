# How to prevent an A-to-z Guarantee claim

Source: https://sellercentral.amazon.com/gp/help/external/GCRVNRBZBVGBK543

This article applies to selling in: **United States**

#  Prevent an A-to-z Guarantee Claim

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGCRVNRBZBVGBK543)

The A-to-z Guarantee policy applies to all buyers, including Amazon Business
Buyers. The A-to-z Guarantee policy is different for Amazon Pay transactions.
You can review the [ Amazon A-to-z Guarantee for merchants
](https://pay.amazon.com/us/help/201212410) on the Amazon Pay website.

To prevent A-to-z Guarantee Claims, we suggest that you follow these best
practices:  

  1. **Shipping**
    * **Include valid tracking for all deliveries** : Tracked shipments allow buyers to see the status of their delivery without needing to contact you. Failure to provide tracking is one basis for granting a claim. For more information, go to [ Valid tracking rate ](/gp/help/external/G201817070) page and [ ODR ](/gp/help/external/200285170) page. You can edit order tracking information: 
      * Go to **Orders** , and then click **Manage Orders** . 
      * Enter the Order ID into the Advanced Search. 
      * Once you find the correct order, click **Edit Shipment** and provide the revised tracking number. 
    * **Require signature confirmation for high value shipments** : Requiring a signature helps Amazon determine if a buyer has received their item(s). If it is unclear if an item has been delivered, a buyer’s claim is more likely to be granted. 
    * **Confirm shipments before expected ship date** : Make sure the courier picking up deliveries first scans the buyer’s package(s) before the ‘ship by’ date. It is important to confirm that you have sent orders on or before the expected ship date so that buyers can see the status of their order and understand when to expect delivery, without needing to contact you. Failure to ship on time negatively impacts your [ Late shipment rate ](/gp/help/external/G200285190) and makes it more likely that a claim will be granted. 
    * **Ensure delivery is completed before the estimated delivery date** : In cases where a delivery is delayed, notify the buyer and verify that they agree to accept late delivery. 
    * **Use supported couriers** : Amazon offers [ Buy Shipping services ](/gp/help/external/G200202220) that enables sellers in certain stores to purchase pre-paid, tracked shipping labels from Amazon and have packages collected directly from their premises. 

**Note:** If sellers ship on time using Amazon's Buy Shipping, sellers are
protected against A-to-z Guarantee Claims if the claim is related to delivery
issues. Under those circumstances, even a granted claim will not impact your
account health, although you may still be responsible for reimbursing the
buyer.

  2. **Products**
    * **Describe products accurately and provide clear images.** This eliminates confusion over what buyers expect to receive. Your products must match the correct ASIN and you must assign the correct condition. For more information, go to [ Condition guidelines ](/gp/help/external/G200339950) . 
    * **Promptly cancel any out-of-stock orders.** Email buyers to let them know why you canceled their orders so they are not waiting for their items to arrive. 
  3. **Buyer service**
    * **Respond to buyers within 48 hours.** If buyers reach out to you, promptly respond to ensure a good buyer experience. If a buyer is requesting a return, direct the buyer to submit a return request. Eligible returns (requested within Amazon’s standard 30 day return window) need to be authorized by you, regardless of the category. [ Out of policy return requests ](/gp/help/external/G201722250) can be denied. Failure to respond within 48 hours increases the chances of a claim being filed. 

**Important:** If you plan to stop selling due to vacation (or for any other
reason) you can update your account settings to receive return request emails
with links to Authorize, Close, or Reply, and you can have Amazon
automatically authorize return requests. You are accountable for processing
return requests and responding to messages from buyers within 48 hours, so it
is important that you update your account settings accordingly. Click the
links to learn more about [ automating returns ](/gp/help/external/201817390)
, about [ the importance of responding to buyer messages
](/gp/help/external/G200389080) , and about [ Listing status for vacations,
holidays, and other absences ](/gp/help/external/200135620) .

    * **Refund buyers proactively.** If buyers contact you for a refund, promptly provide the refund so that buyers do not need to file a claim. 
  4. **Returns**
    * **Respond to** [ **return request** ](/gp/help/external/G9DH343PLXALFTUW) **within 48 hours** . Always approve or close a return request based on order’s return eligibility. If you would like to refund the buyer’s payment, you may choose to request that the buyer return the item before you process the refund. Failure to do so may result in an A-to-z Guarantee Claim and an immediate debit to your account. For more information, go to [ Manage seller-fulfilled returns ](/gp/help/external/G200708210) . 
    * **Communicate clear instructions to buyer on return process.**
      * If you approve a return request and you would like the item to be returned, always provide a local return address or a pre-paid return label and guidelines on how to return the product. 
      * If you approve a return request and you do not want the item to be returned, proactively refund the buyer in full and clarify that the buyer need not return the item(s). 
      * If you close a return request, always clarify the reason for return ineligibility. 

**Note:** For information about A-to-z claims covering property damage or
personal injury caused by a defective product, go to [ A-to-z Claims process
for property damage and personal injury ](/gp/help/external/GTY6NYZDFD5CENYH)
.

Top

