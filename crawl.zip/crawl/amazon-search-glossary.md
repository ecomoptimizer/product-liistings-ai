# Amazon Search Glossary 

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> Adult products are those which are designed for use in sexual activities or which contain explicit images, titles, or other content intended to sexually arouse. For more information, go to Adult products policies and guidelines.

---
## Adult products

Adult products are those which are designed for use in sexual activities or which contain explicit images, titles, or other content intended to sexually arouse. For more information, go to [Adult products policies and guidelines](https://sellercentral.amazon.com/gp/help/G200339940).

## All product search

All Product Search, also known as APS is an "all" search in the Amazon store. It is not category-specific. For example, searching from the home page is an All Product Search.

## ASIN

Amazon Standard Identification Number, also known as ASIN is an item identifier in the Amazon Catalog. Every product that you see on the Amazon website has an ASIN.

## Brand name

Brand name is a required catalog attribute. The brand name of a product appears on the product detail page. For example, jeans "by Levi’s".

## Browse

Customers shop in our stores through browse links, which primarily appear on the left side of the page. Customers browse by categories, such as Electronics, Beauty, and by refinements, such as color, brand, and price.

## Browse Node

The browse structure is made up of browse nodes. For example, shampoo is a leaf node within the Beauty browse structure. Products must be assigned to at least one specific, relevant browse node in order to be searchable.

## Browse node ID

Every browse node has a unique ID. Browse node IDs are used for ASIN assignments and are not visible to customers.

## Browse refinements

Shopping results can be refined using browse refinements, such as color, size, and brand.

## Bullet points

This attribute provides information about a product’s key features and benefits. All bullet points together must be less than 1,000 characters and be written for readability. They are not always indexed by Amazon Search, but always appear in full on product detail pages. For more information, go to [Bullet points](https://sellercentral.amazon.com/gp/help/GX5L8BF8GLMML6CX).

## Catalog attributes

Catalog attributes are the fields that you see when editing listings in Seller Central. Each catalog entry is a collection of attributes. For example, a book has attributes title, author, and publisher, and collectively, this information is known as catalog data.

## Catalog spam

Catalog spam is catalog data that violates the terms of the seller program. For example, it is not allowed to include other brand names or ASINs in an ASIN’s catalog data. Catalog spam is irrelevant data to the product it describes. For instance, including "phone cover" in the catalog data of shoes is catalog spam.

## Description

Product description is a required catalog attribute. Every ASIN must have a product description. It is a paragraph of text that describes the product and appears on a product detail page.

## Generic keywords

Generic keywords is a catalog attribute for terms relevant to customer searches. They must include synonyms, abbreviations, and alternative names for a product. For more information, go to [Use search terms effectively](https://sellercentral.amazon.com/gp/help/G23501) and [Keyword attributes explained](https://sellercentral.amazon.com/gp/help/GF2C2L6RCFZGWBXC) explained.

## Index suppressed

Index suppressed is a catalog attribute. When its value is True, the ASIN is suppressed from search, which means it is not discoverable by customers. To check for supressed listings, go to **Inventory** > **Manage Inventory** > **Search Suppressed**. For the suppressed listing, click **Edit** to fix the issues. Once fixed, the products may become searchable within 72 hours.

## Item type keywords

Item Type Keywords, also known as ITK are primarily used in the U.S. store. They are a means of assigning ASINs to specific browse nodes. For example, U.S. ASINs that have an ITK value of "skin-care-products" are automatically assigned to the Skin care browse nodes.

## Keyword matching

Amazon Search does not do partial matching. This means that results for fitbit charge bands contain all of those words in their catalog data.

## Keywords

Customers search with keywords on Amazon. Sellers include relevant keywords in their product's catalog data.

## Latency

Latency refers to the time between a change being made to an ASIN and when that change goes live on the Amazon store. It can take up to 72 hours for changes to new or existing ASINs to go live. Latency can be slower or faster, depending on the website traffic volumes and other technical factors.

## Launch date

This attribute represents the date that the product launches and must first be shown on the Amazon online store, and has a YYYY-MM-DD format. Products with a future launch date are not searchable.

## Parent ASIN

Products with variations, such as size or color have a parent ASIN and child ASINs. The parent ASIN is the generic product and the child ASIN is the specific variation of the products. For example, Levi’s 501 jeans is the parent ASIN and Levi’s 501 Jeans (large, black) is its child ASIN. The Parent ASIN holds the item relationship together and allows for one detail page for all variations of the product instead of having separate product detail pages for each variation. Parent ASINs are not available for buying. For more information, go to [Variation relationships overview](https://sellercentral.amazon.com/gp/help/G8831).

## Platinum keywords

Platinum keywords are redundant. Previously, platinum keywords were used by platinum sellers for assigning ASINs to their storefront. Storefronts are replaced by Stores and sellers no longer need to populate platinum keywords. For more information, go to [Keyword attributes explained](https://sellercentral.amazon.com/gp/help/GF2C2L6RCFZGWBXC).

## Position

Position refers to what position an ASIN occupies in the featured shopping results. Featured is Amazon’s default sort option.

## Search constraint

Search queries, such as gluten free brownie mix, can have constraints. For example, the shopping results only contain ASINs that have met food restriction verification requirements. The search query, red dresses is constrained to show shopping results that are assigned to a dress browse node and to a red color refinement picker.

## Shopping results

Shopping results are what customers see when they search for products on Amazon. Shopping results can vary in look and feel. The product discovery and shopping landscape is subject to continuous experimentation.

## Search troubleshooting

The goal of search troubleshooting is to ensure that all of your products are discoverable by customers. For information on manual search troubleshooting tips, go to [My ASIN is Unsearchable](https://sellercentral.amazon.com/gp/help/GHGHDMU4X5K9QGCV). You can use a tool called **Determine why a listing is not displaying**:

![](https://m.media-amazon.com/images/G/01//rainer/amazon_search_troubleshooting._CB1198675309_.png)

**Tip:** access this tool by searching for "inactive" within the Seller Central help. Input your ASIN and the tool will diagnose why it may not be discoverable.

For bulk auditing, go to [Search Query Performance Dashboard](https://sellercentral.amazon.com/brand-analytics/dashboard/query-performance). Engage with the listing enhancements and suppressed links on the [Manage Inventory](https://sellercentral.amazon.com/inventory/ref=xx_invmgr_dnav_xx?). To continuously audit your inventory, correct errors, and ensure that it is fully discoverable, go to the [Listing Quality Dashboard](https://sellercentral.amazon.com/quality?ref_=myi_lqd_vl_fba).

## Subject keywords

Subject keywords must only be used for media products, such as books, music and more.

## Title

Title is a required catalog attribute, and every ASIN must have a title. A search result is made up of a title, description, image, price, and other features, such as badges. For more information, go to [Product title requirements](https://sellercentral.amazon.com/gp/help/GYTR6SYGFA5E3EQC).

## Valid values

Valid values refer to the acceptable inputs of catalog attributes that are used in assignment queries on browse nodes. For example, blue is a valid value, as used in the color browse refinement, for the catalog attribute Color name, whereas midnight blue is not a valid value.
