# Opportunity Explorer

Source: https://sellercentral.amazon.com/help/hub/reference/external/GNJ4YRTXWLMBY38U

This article applies to selling in: **United States**

#  Opportunity Explorer

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGNJ4YRTXWLMBY38U)

Opportunity Explorer is a tool to explore customer demand for new product
ideas. To access this tool, go to [ Opportunity Explorer
](https://sellercentral.amazon.com/opportunity-explorer) or navigate in the
Menu to Growth > Product Opportunity Explorer.

**Note:** Opportunity Explorer is currently available to Professional sellers
in US and Germany, and will release more broadly in US and Europe through
2022. If you are a Professional seller and do not see Opportunity Explorer,
refer to the FAQ on this page.

Opportunity Explorer allows you to understand Amazon customer search and
purchasing behavior to evaluate if there is unmet customer demand, and an
opportunity for you to meet that demand through new products. You can explore
up-to-date and accurate data on customer needs and the current selection on
Amazon. Customer needs and selection are bundled together into niches. Each
niche has a unique set of characteristics, which determine the economic
potential for new products in the niche. To find your new niche, you can enter
search terms, or browse the store taxonomy, as a customer would. Summary data
is included in the search results to help you compare related niches of
different sizes. Each niche has a detail page where you can view additional
tabs of data including the top products, top search terms, insights, and
trends.

####  What is a niche?

Customers demonstrate their purchase needs when they enter search terms on the
store. A niche is a collection of customer search terms representing a
customer need, and the top products that cumulatively received 80% of clicks
from those search terms. Search terms and products can meet more than one
customer need, and can be in multiple niches.

####  How is niche data constructed?

Niches include the top related Amazon customer search terms and the top
related clicked or purchased products. Top Products included in the niche
cumulatively received 80% of clicks after customers entered any search term in
the niche. The number of search terms displayed is currently capped based on
which search terms have the greatest search volume. Likewise, products in a
niche are limited to those receiving the majority of the clicks and purchases
from the search terms shown.

Use the following glossary to better understand the data presented to you in
Opportunity Explorer:

**Search Results page:** The resulting page after searching, browsing, or
filtering for niches, the results page shows summary metrics for each of the
returned niches.

Term  |  Definition  |  Example  
---|---|---  
Customer Need  |  Similar products that meet a customer need are called a
"niche". The name of the niche is defined as the top ranked search term, by
search volume.  |  Shark cordless vacuum  
Top Search Terms  |  Additional search terms that customers entered for the
customer need of this niche.  |  Elderberry Gummies, Elderberry for Adults,
Elderberry 1000mg  
Sales Potential Score  |  Sales Potential Score is a number between 1 to 10,
with 10 being the highest score. It indicates the relative potential sales of
a new product in this niche compared to other niches in the same product
category. The score is based on historical data from product sales, customer
search volume, seasonality and other input signals.  |  9/10  
Search Volume (Past 360 days)  |  The total number of times customers entered
any of the search terms in this niche on Amazon in the past 360 days.  |
3,600  
Search Volume Growth (Past 360 days)  |  Across all of the search terms shown
in this niche, the percentage change in search term volume in the past year
(0-360 days), compared to the volume from the previous year (360-720 days).  |
321.98%  
Search Volume (Past 90 days)  |  The total number of times customers entered
any of the search terms in this niche on Amazon in the past 90 days.  |  3,600  
Search Volume Growth (Past 90 days)  |  Across all of the search terms shown
in this niche, the percentage change in search term volume in the past quarter
(0-90 days), compared to the volume from the previous 90 days (90-180 days).
|  321%  
Units Sold (Past 90 days)  |  Units sold when customers purchased products
after entering one of the search terms in this niche.  |  1,500-1,999  
# of Top Clicked Products  |  Niches include the top products that
cumulatively received 80% of clicks after customers entered any search term in
the niche.  |  12  
Average Price  |  The average selling price for all products in this niche in
the past 90 days.  |  $1.23  
  
**Niche Details, Products Tab:** This tab provides ASIN-level details on the
products within the niche. Navigate to this page by clicking on a Customer
Need.

Term  |  Definition  |  Example  
---|---|---  
ASIN Name  |  Product title (of the ASIN). This is a clickable link that takes
you to the ASIN detail page.  |  Women's Gummy Vitamins  
Brand  |  Name of the brand of the product.  |  Amazon  
Category  |  Path to the product within the Amazon browse hierarchy, up to 3
levels deep. Taxonomy depth varies across categories.  |  Vitamins & Dietary
Supplements / Herbal Supplements / Elderberry  
Launch Date  |  Date when ASIN's first buyable offer is available on Amazon.
|  2021-01-01  
Click Count  |  Total number of clicks on this product, after a customer sees
the product as a result from any search term in this niche.  |  249,123  
Click Share (Past 360 days)  |  Number of clicks on this product as a
percentage of the total click count for every product shown in this niche.  |
1.10%  
Average Selling Price (Past 360 days)  |  The average selling price for all
products in this niche in the past 360 days.  |  $1.23  
Total Reviews  |  Total number of reviews for the product, as of the most
current snapshot. Currently this only includes reviews where the customer
provided written product feedback.  |  12  
Average Customer Rating  |  Average star rating customers gave the product in
a review. Currently this only includes reviews where the customer provided
written product feedback.  |  4.3  
Average BSR  |  The best seller rank of this product, within its specific sub
category on Amazon.

**Note:** Products in this niche may be part of different sub categories.

|  12  
Average # of sellers and Vendors (Past 360 days)  |  Average number of buyable
offers on this product, over the past 90 days, from both third-party sellers
and first-party vendors.

**Note:** Offer from Amazon retail counts as a single offer, regardless how
many vendors the product may be sourced from.

|  4.3  
  
**Niche Details, Search Terms Tab:** This tab provides search term-level
details on the search terms within the niche.

Term  |  Definition  |  Example  
---|---|---  
Search Term  |  Name of the search term customers entered when they intended
to purchase products in this niche.  |  Dog leashes  
Search Volume (Past 360 days)  |  The total number of searches customers
entered this particular search term on Amazon in the past 360 days.  |
503,512  
Search Volume Growth (quarter-over-quarter)  |  The percentage change in
search volume in the past quarter (0-90 days), compared to the previous
quarter (90-180 days ago).  |  321.54%  
Search Volume Growth (year-over-year)  |  The percentage change in search
volume in the past quarter (0-90 days), compared to this quarter the previous
year (360-450 days ago).  |  321.54%  
Click Share (Past 360 days)  |  Number of clicks on products from customers
who entered this search term, as a percentage of the total clicks from
customers from every search term in this niche.  |  10.01%  
Search Conversion Rate (Past 360 days)  |  Number of purchases, of any product
in this niche, after a customer entered this search term and clicked on a
product, divided by the total number of times customers entered this search
term.  |  10.01%  
Top 3 Clicked Products  |  The top 3 products, ranked by share of customer
clicks after entering this search term. Each are clickable links that takes
you to the ASIN’s detail page.  |  B07W8KHTGL, B08Y73HJF4, B07MJL8NXR  
  
**Niche Details, Insights Tab:** This tab provides niche-level statistics to
help you assess the launch potential for new products. Per the definition of
Niche, all statistics only include the top products that cumulatively received
80% of clicks after customers entered any search term in the niche.

Term  |  Definition  |  Example  
---|---|---  
Number of Products  |  The number of top products that cumulatively received
80% of clicks after customers entered any search term in the niche.  |  105  
% of Products Using Sponsored Products  |  Products which get the majority of
clicks from Sponsored Products.  |  87.55%  
% of Prime  |  Products which were Prime eligible for at least half of their
page views by customers.  |  93.04%  
Top 5 Products Click Share (past 360 days)  |  The combined clicks shared by
top 20 products in the niche.  |  35.38%  
Top 20 Products Click Share (past 360 days)  |  The combined click share by
top 20 products in the niche.  |  64.39%  
Average Best Seller Rank  |  Average BSR for all products in the niche at the
time of the snapshot.  |  3605.1  
Average Number of Reviews  |  Average number of reviews for all products in
the niche at the time of the snapshot.  |  3684  
# of Brands  |  Number of brands for all products in the niche at the time of
the snapshot.  |  1128  
Top 5 Brands Click Share  |  The combined click share by top 5 brands in the
niche.  |  57.43%  
Top 20 Brands Click Share  |  The combined click share by top 20 brands in the
niche.  |  90.72%  
Average Brand Age in Niche (past 360 days)  |  Brand age in niche is defined
as the product age of the first branded ASIN in a given niche under a given
brand.  |  4.2 years  
# of Selling Partners (past 360 days)  |  Average number of buyable offers on
ASINs in the niche from both third-party sellers and first-party vendors (that
is, an average of a daily snapshot of offer depth) in the past 360 days.

**Note:** Offer from Amazon retail counts as one offer, regardless how many
vendors retail sources the product from.

|  128.9  
Average Selling Partner Age in Niche  |  Merchant’s age in the niche is
defined as the product age of the first ASIN in a given niche under a given
merchant.  |  3.6 years  
# of New Products Launched (past 180 days)  |  Number of ASINs in the niche
(top 80% click share) with product age < 180 days.  |  2  
# of Successful Launches (past 180 days)  |  Number of new launches (in the
past 180 days) with an annualized revenue amount > $50K in the past 30 days.
|  2  
# of New Products Launched (past 360 days)  |  Number of ASINs in the niche
(top 80% click share) with product age < 360 days.  |  15  
# of Successful Launches (past 360 days)  |  Number of new launches (in the
past 360 days) with an annualized revenue amount > $50K in the past 30 days.
|  15  
Average Review Rating  |  Average review rating for all products in the niche
at the time of the snapshot date.  |  4.5  
Average Out of Stock Rate (past 360 days)  |  Average out of stock rate for
all products in niche.  |  8.02%  
Average Product Listing Quality  |  Average listing quality score for all
products in the niche.  |  95 / 100  
  
**Niche Details, Trends Tab:** The trends tab allows sellers to plot time
series data for up to 360 days back for up to 2 KPIs at a time.

Term  |  Definition  |  Example  
---|---|---  
Search Volume  |  The total number of times customers entered any of the
search terms in this niche on Amazon in the past 7 days.  |  3,553  
Product Count  |  The number of top products that cumulatively received 80% of
clicks after customers entered any search term in the niche.  |  44  
Average Price  |  The average selling price for all products in this niche in
the past 7 days.  |  $22.46  
Search Conversion Rate  |  Number of purchases, of any product in this niche,
after a customer entered this search term and clicked on a product, divided by
the total number of times customers entered this search term. Applies to past
7 days.  |  8.47%  
Selling Partner Count  |

Average number of buyable offers on ASINs in the niche from both third-party
sellers and first-party vendors (that is, an average of a daily snapshot of
offer depth) in the past 7 days.

**Note:** Offer from Amazon retail counts as one offer, regardless how many
vendors retail sources the product from.

|  2  
  
The Trends Tab is composed of two parts - Metrics Picker and Chart.

  * The Metrics Picker allows you to select up to 2 metrics to plot in the chart. Your selected metrics will be highlighted blue and orange. You can have up to 5 total metrics present in the picker to quickly toggle between selections. If you have fewer than 5 metrics visible in the Metrics Picker, click “Add Metric”. If you do not see the “Add Metric” icon, you must click the “X” on any metric to remove it from your Picker and select other metrics. 
  * The Chart represents the time series data for each of the metrics selected in the Metrics Picker. The color of the plot lines will correspond with the highlight colors in the Metrics Picker. The chart can be analyzed by hovering your mouse over the plot lines. Each data point in the chart represents the data aggregated in the 7 days before the date reflected in the data point. 

**FAQ:**

####  How often is the data refreshed?

New niches are created at the beginning of every month. Metrics are refreshed
at the beginning of the week.

####  How can I request additional metrics to be added?

On any **Niche Details** page, click **Request a Metric** link on the top
right side of the page. You will be asked to provide some basic details and to
submit the form. You can ask for metrics that may apply to any part of the
Opportunity Explorer experience, and not just limited to the detail page you
are viewing.

####  How do I provide feedback?

On any **Niche Details** page, click the **‘Is this Niche helpful?’** link
next to the niche name. You will be asked to provide feedback about the niche
you are viewing and your overall satisfaction level with the niche. This
feedback is very valuable and will be used by Amazon to improve the overall
usefulness of niches over time.

####  My account seems to have access, but only for the primary user. How do I
grant access to my other users?

By default, Opportunity Explorer is provided to only the primary user on each
account. To grant permissions, navigate to Settings > Manage Global
Permissions, and provide View access for “New Product Opportunities”.

**Note:** If your user is not yet a global user, first navigate to Settings >
User Permissions and select “Add to Global Account”.

####  I am a primary user and I am getting an error that I don’t have
permissions.

Opportunity Explorer is available to Professional sellers in the US, Germany,
UK, France, Italy, and Spain. If you meet the criteria, confirm that you are
the user who registered your account before contacting Selling Partner
Support. If you are not a Professional seller, see [ Selling Plan Comparison
](/help/hub/reference/external/G64491) . If you upgrade to a Professional
account, allow 24 hours to gain access to Opportunity Explorer.

####  I am not getting an error. I am getting a blank page. What now?

Some users who have permissions to view Opportunity Explorer get a blank page
when first attempting to access Opportunity Explorer. We have determined this
is caused by end user browser settings. Clear your cookies or update your
browser to the most recent version.

Top

