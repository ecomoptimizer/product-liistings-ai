# Crafting a Marketplace Entry Strategy

Source: https://sellercentral.amazon.com/gp/help/external/201468360

This article applies to selling in: **United States**

#  Crafting a Marketplace Entry Strategy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201468360)

On this page

Product: Choosing what to sell internationally

Price: Setting and adjusting your pricing

Placement: Optimizing your distribution channels

Promotion: Making your listings more attractive

Deciding where and what to sell in another country's marketplace can be
similar to making these determinations for your home marketplace. However,
there are some added considerations when selling internationally. One way to
evaluate an international marketplace entry strategy is to use the "4Ps"
marketing framework: Product, Price, Placement, and Promotions. Let's review
each through the lens of selling internationally on Amazon.

##  Product: Choosing what to sell internationally

When selling internationally through Amazon for the first time, a natural
approach is to think about your bestselling products in your home marketplace.
From your previous experience and from data in sales reports, what sells well?
It's also important to ask yourself why you think these particular products do
well. Will these same reasons hold true for the marketplace you are entering,
or are there other fundamentals driving customer demand in the new
marketplace, such as culture, climate, and demographics, including average age
and income? Also think about how differences in marketplaces can benefit you.
For instance, do you have seasonal inventory that you don't know what to do
with after the season has passed in one marketplace? You can extend your
selling season by selling abroad where the product may find a new audience.
Learn how [ one seller successfully used international selling on Amazon to
build a business. ](https://services.amazon.com/content/case-studies-sheridyn-
swimwear.htm)

**Tip:** **List broadly across multiple products rather than deeply in one or
two products.**

Why? A broader selection of products means higher customer search exposure to
your listings overall. This breadth can help you quickly gauge what products
can be successful in a particular marketplace.

You can start slow while still maintaining breadth of selection even if you're
not ready to commit a lot of your inventory to another Amazon marketplace. If
your sales spike, you can adjust your price or remove listings to mitigate
stock-out risk, just like in your home Amazon marketplace. For an even smaller
commitment, you can start by fulfilling orders yourself rather than sending
inventory to another country. Remember selling in another marketplace doesn't
mean you lose control over your listings.

In deciding which products to sell in an Amazon marketplace, you of course
have another key source of information available to you: observations of the
marketplace itself. This sort of marketplace research should be very familiar
to you from activities you likely conduct when selling in your primary Amazon
marketplace. For this research, local language proficiency is extremely
helpful. If you are trying to research a marketplace in a language unfamiliar
to you, you may be able get some basic language interpretation from free
online translator tools, but beware of relying too heavily on such tools.

In your target marketplace, review the Best Sellers, New Arrivals, and
Featured Brand selections for your product categories. Read customer reviews
to understand your competition's strengths and weaknesses.

During this product research phase, you may find it helpful to broaden your
search to e-commerce marketplaces beyond Amazon. Use a search engine to find
relevant e-commerce sites by country. Trade publications and online seller
communities in each country can also provide a rich source of information as
you prepare to list products in their locales.

**Tip:** Keep in mind that potential customers of a particular marketplace may
not necessarily reside in target country.

Some customers in each marketplace may reside in a nearby country, prefer to
shop in a particular language, seek products only available in a particular
marketplace, or otherwise choose to purchase out-of-country. For example, an
Amazon.de customer may reside in Austria.

##  Price: Setting and adjusting your pricing

Once you've narrowed down which products you may want to list in a new
marketplace, make observations of prices set by sellers of the same or any
similar products. Do customers appear to be buying based on price or brand? Do
the best selling products ship for free or for reduced rates? Do your
competitors offer specialized delivery? Learn how [ one seller successfully
introduced unique selection to new marketplaces
](https://services.amazon.com/content/case-studies-goatee-saver.htm) .

When you set your prices, build in additional fixed and variable costs
associated with selling internationally. The following are potential new costs
to consider when selling outside your primary marketplace and may change your
profitability calculation:

  * Shipping costs when you are shipping directly to international customers. 
  * International return shipping costs, if you are fulfilling orders yourself. 
  * Shipping costs to send your inventory to fulfillment centers abroad when you are using Fulfillment by Amazon. Learn more about shipping internationally in [ Ship and Fulfill ](/gp/help/external/201468490) . 
  * Customer support costs if you are providing these services yourself in a local language or hiring a third-party provider to manage customer language support. Learn more about customer support in [ Customer Support and Returns ](/gp/help/external/201468530) . 
  * Conversion costs associated with getting paid in your home currency. 
  * Translation costs for listing ASINs in another language. Learn more about listing and translation in [ Register and Launch ](/gp/help/external/201468440) . 
  * Taxes and duties. Learn more about taxes and duties in [ Taxes and Regulations ](/gp/help/external/201468380) . 

As you can see, many of the variable costs change based on whether you decide
to fulfill products yourself or use Fulfillment by Amazon. Review the [
Fulfillment options ](/gp/help/external/201468370) help page for more details.

##  Placement: Optimizing your distribution channels

In addition to growing your international on-Amazon business, you can also
consider growing your international business off-Amazon. The following Amazon
service may be relevant for you to develop this international strategy:

**Multi-Channel Fulfillment**

If you already use Fulfillment by Amazon to fulfill Amazon customer orders,
you can manage online sales from other channels using the same inventory pool.
Use Multi-Channel Fulfillment -a feature within Fulfillment by Amazon- to
fulfill orders that come from sales channels other than Amazon, including your
own website, other third-party channels, and even catalog or in-store sales.
Learn more about [ Multi-Channel Fulfillment
](https://services.amazon.com/fulfillment-by-amazon/multi-channel.htm) .

##  Promotion: Making your listings more attractive

As in your primary Amazon marketplace, Amazon provides tools that enable you
to advertise and run promotions for your products. The promotional tools
available vary by Amazon marketplace and may include Free Delivery, Money Off,
and Buy One Get One (BOGO).

Visit [ Understanding Promotions ](/gp/help/external/60951) for more details
on the type of promotions available ( **Note:** this feature is only available
to sellers with a Professional selling plan). To see the steps to creating a
promotion, visit [ Creating a Promotion ](/gp/help/external/60961) .

Another way to increase exposure to your offers is through [ Amazon Sponsored
Products ](https://services.amazon.com/content/sell-on-amazon/sponsored-
products.htm) , a cost-per-click advertising service that helps you promote
the products you sell on Amazon through keyword-targeted ads.

Top

