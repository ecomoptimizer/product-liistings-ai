# Policies and guidance for Prime Now sellers

Source: https://sellercentral.amazon.com/gp/help/external/G85BNYWWX8R3HYLW

This article applies to selling in: **United States**

#  Additional policies and guidance for Prime Now sellers

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG85BNYWWX8R3HYLW)

The policies and content below apply exclusively to registered Prime Now
sellers.

Top

##  Additional policies and guidance for Prime Now sellers

* [ Standard operating procedures and performance standards for Prime Now sellers  ](/help/hub/reference/external/GXZQ6ZFTRGHBFLQC)
* [ Order fulfillment policy for Prime Now sellers  ](/help/hub/reference/external/G202115900)
* [ Alcohol sales policies for Prime Now sellers  ](/help/hub/reference/external/G201797800)
* [ California Proposition 65 - guidance for Prime Now sellers  ](/help/hub/reference/external/G5KJAZR27FGHEAG9)

