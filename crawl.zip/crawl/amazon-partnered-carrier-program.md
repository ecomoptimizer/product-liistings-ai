# Amazon Partnered Carrier program

Source: https://sellercentral.amazon.com/gp/help/external/G201119120

This article applies to selling in: **United States**

#  Amazon Partnered Carrier options

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201119120)

On this page

Amazon SPD carrier

Amazon partnered LTL and FTL carrier

Amazon Freight LTL shipping service

Send to Amazon: Shipping pallets

Send to Amazon: Shipment cancellation

Send/replenish inventory: Shipment cancellation

Amazon Marketplace Web Service (Amazon MWS)

Amazon Partnered Carrier program options are available for both small parcel
deliveries (SPDs) and less-than-truckload (LTL) and full-truckload (FTL)
shipments within the 48 contiguous states in the US.

  * **SPDs** consist of units that are packed in boxes, with each box individually labeled for delivery. SPDs are typically smaller shipments that are sent via UPS. 
  * **LTL** and **FTL** shipment combines individual boxes on pallets for delivery. 

**Note:** LTL and FTL shipments that don’t use a partnered carrier require a
delivery appointment. For more information, go to [ Carrier requirements for
LTL and FTL deliveries ](/gp/help/external/G200978420) and scroll down to
**Scheduling delivery appointments** .

**Important:** During shipment creation, make sure that you select the correct
**shipping method** and **ship from** address. Shipments that are sent via a
different shipping method or multiple shipping methods or carriers may not get
a delivery appointment or may be refused at pickup. An incorrect **ship from**
address may result in additional fees or missed pickup requests.

Dangerous goods cannot be shipped via partnered carriers. To learn more, go to
[ Dangerous goods identification guide (hazmat)
](/gp/help/external/G201003400) .

For information about loss and damage claims, go to [ FBA inventory
reimbursement policy ](/gp/help/external/200213130) .

##  Amazon SPD carrier

Eligible carriers offer deeply discounted rates, and the cost is billed to
your account as an **inbound transportation charge** . There is a 1kg minimum
fee for carrier shipments. For shipments that weigh less than 1 kg, the
minimum fee applies.

We will provide you a printable shipping label for you to print and use it
with our carrier. Before generating the shipping labels, take a moment to
review the details and check that all is correct. When you accept the charges
and confirm the shipment in Step 2 of Send To Amazon, you will have 24 hours
to complete Step 3 or the shipment will be automatically canceled. After the
24 hours window, all shipping fees will be charged.

After completing your shipment, give your package to the pickup driver. Or
take the package to the carrier drop-off site of your choice.

**Note:** You must reach out to the SPD carrier to schedule a pickup request.
UPS has regularly scheduled web server maintenance every Sunday between 10
a.m. and noon ET. During this period, UPS labels may not be available for
partnered-carrier shipments.

For more information, go to [ Small parcel delivery to Amazon
](/gp/help/external/G200280260) .

**Billable weight and shipping cost calculation**

Billable weight is used to estimate the shipping cost. The billable weight
will be either the dimensional weight or the shipment weight, whichever is
greater.

  * Shipment weight is the actual weight of your shipment based on the weight per box. 
  * Dimensional weight reflects package density based on the box dimensions. 

We estimate shipping cost based on the shipment packing information (box
weights and dimensions) and the billable weight.

**Note:** You are responsible for providing accurate shipment information and
for the actual cost of the shipment. Inaccurate information may result in the
blocking of future shipments or an additional fee for noncompliance.

##  Amazon partnered LTL and FTL carrier

Partnered carriers offer discounted rates to eligible sellers, and the cost is
billed to your account as an **inbound transportation charge** . If your total
shipment weighs more than 150 lb, consider using a partnered LTL or FTL
carrier.

To use a partnered LTL or FTL carrier, you must meet the **shipment
requirements** described below and have the following:

  * A dock or forklift to place pallets on a truck 
  * A dock to place pallets on a truck, see the dock requirements below 
  * The ability to either support a truck coming to your pickup address or use the lift-gate service described below. 

**Note:** LTL shipments using the Amazon Partnered Carrier program must be
placed on pallets. Our partnered carriers will refuse shipments that are not
on pallets, also known as [ floor-loaded ](/gp/help/external/200978440)
shipments.

**Note:** If you cannot accommodate docking a 53 ft trailer for pick-up, open
a support case in Seller Central. For more details, go to [ Amazon Freight LTL
shipping service. ](/gp/help/external/GM9THX2S47XTGJTQ) .

For more information, go to [ Carrier requirements for LTL and FTL deliveries
](/gp/help/external/G200978420) .

**Shipment requirements**

Each shipment requires four-way access wooden pallets that are 40 x 48 inches
and GMA Standard B Grade or higher. Also provide the following information,
ensuring that it’s accurate:

  * A freight-ready date so that pallets are ready for pickup by 8 a.m. local time on that date 
  * A pallet count at the time of estimate acceptance 
  * A weight for each pallet 
  * Freight class 

**Important:** If you anticipate that freight will not be ready before we
attempt to pick it up, either cancel the shipment and create a new one or
contact Selling Partner Support immediately for further assistance. Shipments
that are not ready by the provided freight-ready date may be delayed,
rescheduled, or charged additional carrier fees. If freight is not ready by
the third attempt, we will cancel your pickup request.

**Note:** If you’re unsure of your shipment's freight class, choose the
default **Estimate my freight class** option. If you provide incorrect freight
classes for your shipments, we may disable your ability to enter freight class
and, instead, estimate your freight class for you.

**Freight class**

Freight class is a standardized classification system that determines the
billable weight and risk of a shipment. Freight class is ranked from 50 to
500.

Make sure to provide accurate packaging information when creating a shipment.
This information is used for your freight class estimate. If the freight class
of your shipment appears to be too low, an alert will show an estimated
freight class. If you’re unsure of your shipment’s freight class, choose the
**Estimate my freight class** option during the **Shipping charges** step in
the **Send/replenish inventory** workflow.

You will be asked to accept Amazon's estimated freight class. Shipments with
rejected freight-class estimates are subject to further review. Recurring
issues with packaging information may disable your ability to reject freight-
class estimates.

For more information, go to [ Amazon Partnered Carrier freight class
](/gp/help/external/GUUS7TA8M9Z95P3R) .

**Dock Requirements**

**Important:** Amazon values the safety of our carriers and drivers, reserving
the right to reject pickup in unsafe locations. This can include pickups along
main roads, congested pickup locations, and areas where our drivers may not be
able to dock or park without impacting local traffic or pedestrian safety.

To ensure safety among driver, local traffic, and pedestrian safety, following
requirements must be maintained:

**LTL lift-gate service**

If you don’t have a dock door or a forklift, you can still use the Amazon
partnered LTL service by requesting lift-gate service from the carrier. To
qualify for the service, your shipment must be under 12 pallets and less than
20,000 lb.

**Note:** All partnered LTL carriers support lift gates. When contacting your
partnered carrier, make sure to request a lift gate for pickup.

To use the lift-gate service, do the following:  

  1. After creating a shipment, select **Less than truckload (LTL)** under **Shipping method** and **Amazon Partnered Carrier** under **Shipping carrier** . 
  2. Contact the carrier and request a truck with a lift gate. 
  3. Schedule a pickup time with the carrier. 
  4. Palletize the shipment and be able to move the pallets to the truck when it arrives. Carriers will not have the manpower to move your pallets. 

We will assign a carrier and create a bill of lading, which you will receive
via email and can access in Seller Central.

**Scheduling a pickup**

More than 20 carriers participate in the partnered LTL and FTL service. When
you use this service, we provide an estimated shipping fee and pickup date
based on your shipment information, such as number of pallets, weight, and
freight class. We also include the freight-ready date that you provide.

**Note:** Your actual shipping fees may exceed Amazon’s estimate if the LTL or
FTL carrier determines that your pallets weigh more than you indicated, the
freight class that you provided is incorrect, or both.

Your pickup date will be on either the freight-ready date or two days from
when the estimate is accepted, whichever is later. The carrier assigned to
your shipment will appear in the **Prepare shipment** tab of your shipment as
well as on your bill of lading (BOL).

**Note:** Make sure that you provide the correct shipment to the assigned
carrier. Not doing so may result in additional fees or delays.

Give the carrier the BOL, which will be available in the **Track shipment**
tab of the shipment summary on the morning of your pickup. The BOL will also
be emailed to your contact person for the shipment.

If you discuss your pickup appointment with the carrier, refer to your
shipment by the Amazon reference number (ARN) on your BOL. The ARN is
different from your FBA shipment ID and is required for pickup and delivery
requests. When partnered carriers come for pickup, they won’t have access to
the shipment ID. Partnered carriers can’t accommodate pickup appointments and
will arrive on the provided pickup date.

**Note:** Shipments with more than 12 pallets can be rolled into a FTL
shipment, which may be more cost effective and have better transit times than
an LTL shipment. FTL shipments may require more lead time because carriers
must schedule delivery at the fulfillment center before they can pick up your
shipment.

##  Amazon Freight LTL shipping service

Amazon Freight offers pickup within two days of scheduling in select areas for
shipments sent to local fulfillment centers. For more information, go to [
Amazon Freight LTL shipping service ](/gp/help/external/GM9THX2S47XTGJTQ) .

**Note:** Shipments that are sent using Amazon Freight require Amazon carrier
labels on the outside of your pallets, along with the required FBA shipment
labels. For more information, go to [ Seller requirements for LTL, FTL, and
FCL deliveries ](/gp/help/external/G200978400) .

##  Send to Amazon: Shipping pallets

If you use an Amazon partnered carrier to ship your pallet via **Send to
Amazon** , follow these steps:

  

  1. Under **Step 4: Confirm carrier and pallet information** , confirm your freight-ready date and pickup contact details for all shipments. 
  2. Review the pallet estimates for each of the shipments. If needed, edit the pallet configurations to ensure accurate shipping-cost estimates. 
  3. Confirm each shipment’s pallet configurations to show the shipping-cost estimates. For the freight class, you can enter your own estimate or keep Amazon’s estimate. 
  4. Review all the shipping-cost estimates. 
  5. Click **Confirm all carrier and pallet information** to proceed to **Step 5: Print pallet labels** . 

##  Send to Amazon: Shipment cancellation

You can cancel your Send to Amazon shipment by clicking on **Void shipments
and charges** at the bottom of the page. Voiding will cancel all shipments
that you created and move them into **Canceled** status in your Shipping
Queue.

For more information, go to [ Send to Amazon: Change or cancel a shipment
](/gp/help/external/GP29SYECJZGJ9XMR) .

##  Send/replenish inventory: Shipment cancellation

You can cancel your shipment after approving estimated fees for the following:

  * Up to one hour for LTL or FTL shipments 
  * Up to 24 hours for SPD shipments 

To cancel a **Send/replenish inventory** shipment, go to your Shipping Queue
and follow these steps:

  

  1. Locate the shipment and click **Work on shipment** . 
  2. Click the **Provide details** tab. 
  3. Click **Void charges** . 

**Important:** Your fees will not be canceled even if the shipment is
canceled. Follow the instructions above to ensure that no pickup is made and
that fees will not apply. If the cancellation time expires, you won’t be able
to cancel the fees or receive a refund for them.

##  Amazon Marketplace Web Service (Amazon MWS)

Amazon MWS also includes partnered carrier options. For more information, go
to [ Amazon Marketplace Web Service overview ](/gp/help/external/200389230) .

Top

##  Amazon Partnered Carrier options

* [ Amazon Partnered Carrier program FAQ  ](/help/hub/reference/external/G201530080)
* [ Partnered carrier shipping from India to the US  ](/help/hub/reference/external/G3S78BYFLAJK4YTU)
* [ Cross-Border Partnered Carrier program from the UK to the US  ](/help/hub/reference/external/GHSCW4G88VDKXB9V)
* [ Cross-Border Partnered Carrier program from Germany to the US  ](/help/hub/reference/external/GD2HZGB823TRE9ET)
* [ Ship using cross-border Partnered Carrier Program from Mexico to the US  ](/help/hub/reference/external/GMNHFVSP5QXUC6VN)
* [ Ship using cross-border Partnered Carrier Program from Vietnam to the US  ](/help/hub/reference/external/GHN4W67N7GNKMCMB)
* [ Ship using cross-border Partnered Carrier Program from Thailand to the US  ](/help/hub/reference/external/GW9GM75Y74M9QURJ)
* [ Amazon Partnered Carrier Agreement  ](/help/hub/reference/external/G200296070)

