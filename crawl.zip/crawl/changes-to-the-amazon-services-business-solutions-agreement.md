# Changes to the Amazon Services Business Solutions Agreement

Source: https://sellercentral.amazon.com/help/hub/reference/external/G47071

This article applies to selling in: **United States**

#  Changes to the Amazon Services Business Solutions Agreement

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG47071)

Effective December 9, 2022, we updated Section 18 (Miscellaneous) of the
General Terms of the Amazon Services Business Solutions Agreement to reflect
changes to our terms governing disputes under the agreement. Among other
updates, Amazon will no longer reimburse arbitration fees for claims totaling
less than $10,000, or waive its right to seek attorneys’ fees and costs for
non-frivolous claims. We have also clarified the rules by which an arbitration
award may be appealed.

This update is intended to provide a summary of the most recent changes only.
Please be sure to carefully review [ the terms of the updated agreement here
](https://sellercentral.amazon.com/help/hub/reference/external/G1791) . Your
continued use of Selling Services constitutes your acceptance of these
changes.

Top

