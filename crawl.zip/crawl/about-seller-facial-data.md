# About seller facial data

Source: https://sellercentral.amazon.com/help/hub/reference/external/GVQRRK8ZNHUVNQ6Y

This article applies to selling in: **United States**

#  About seller facial data

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGVQRRK8ZNHUVNQ6Y)

On this page

What data is collected?

How is facial data collected?

How is facial data used?

How long do you keep my facial data?

How is facial data protected?

Is facial data shared with third parties?

How can I request access to my facial data?

When you register to sell in Amazon’s store, we verify your identity to
protect our customers, selling partners, and Amazon’s store. In some cases, we
may offer you the option to complete identity verification using facial
recognition technology in the manner described on this page.

##  What data is collected?

With your consent, we collect images of your face and government-issued
identity documents from your device’s camera, and analyze them using machine
learning models to verify that you are a live person and that your face
matches the picture on your ID. We refer to the unique facial measurements
that we extract from these images as **facial data** . Facial data may be
considered biometric data under the laws of some jurisdictions.

##  How is facial data collected?

Facial data may be collected directly by Amazon or by one of our authorized
third-party service providers, including Persona Identities, Inc. or its
affiliates using their own technology.

##  How is facial data used?

Facial data is used to verify your identity by determining whether you are a
live person and whether your face matches the picture on your government-
issued identification documents. Facial data is only used to verify your
identity, and will not be used for any other purpose.

##  How long do you keep my facial data?

Amazon and its third-party service providers process your facial data in real
time and do not store your facial data. The images used to create your facial
data may be retained for longer periods for audit and compliance purposes.

##  How is facial data protected?

We take your data security very seriously. Amazon and its third-party service
providers employ security measures to protect your facial data that are at
least as protective as the security measures used to protect other
confidential and sensitive data. The images used to create your facial data
are stored securely and only accessed by authorized employees.

##  Is facial data shared with third parties?

Facial data may be collected directly by Amazon or by one of our authorized
third-party service providers, including Persona Identities, Inc. or its
affiliates, using their own technology.  These third-party service providers
are permitted to process and use your facial data only for the purpose of
providing identity verification services to Amazon, and only as described on
this page and in a manner consistent with Amazon's [ Privacy Notice
](https://www.amazon.com/gp/help/customer/display.html?nodeId=201909010) .
Amazon does not share your facial data, or the images used to create your
facial data, with any third party unless required by applicable law.

##  How can I request access to my facial data?

Since neither Amazon nor our third-party service providers retain or store
facial data, we will not be able to provide access to it.

Top

