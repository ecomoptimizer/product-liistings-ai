# FBA Inventory Placement Terms and Conditions

Source: https://sellercentral.amazon.com/gp/help/external/G200943420

This article applies to selling in: **United States**

#  FBA Inventory Placement Service Terms and Conditions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200943420)

On this page

Program overview

Assigning fulfillment centers

Shipping inventory to us

Program fees

Changes to fees or terms

Optional participation

The Inventory Placement Service allows you to request that Amazon assign all
units of a single product/ASIN to the same Amazon fulfillment center for each
shipment. If you participate in this program:

  * You may opt in or out by selecting your desired inventory placement option in your seller account. 
  * The Amazon fulfillment center assigned may be different for each shipment that you create and Amazon does not guarantee that only one fulfillment center will be assigned. 
  * You will be required to pay additional fees, as described below. 

Your participation in this optional service is subject to the terms and
conditions on this page, including additional fees, the Amazon Services
Business Solutions Agreement (the "Agreement") that you have entered into with
Amazon Services LLC, and any other applicable Amazon policies.

##  Program overview

If you use the default FBA Service (Distributed Inventory Placement) and you
create a shipment of inventory to send to Amazon, we may assign units of a
product/ASIN to multiple Amazon fulfillment centers. If you elect to
participate in the Inventory Placement Service and you create a shipment of
inventory to Amazon, we will assign all units of a specific product/ASIN for
that shipment to the same Amazon fulfillment center.

Some product categories and shipment types are not eligible for this service.
See [ FBA Inventory Placement Service ](/gp/help/external/G200735910) for more
information.

**Note:** The FBA Inventory Placement program does not ensure that your
shipments will be routed to one fulfillment center only. This program only
ensures that all units of a specific ASIN are routed to the same fulfillment
center.

##  Assigning fulfillment centers

We will determine in our sole discretion the Amazon fulfillment center to
which each shipment of a product/ASIN is assigned. The Amazon fulfillment
center assigned may be different for each shipment that you create, even when
you participate in the Inventory Placement Service. For example, we will
generally direct different unit types (such as Standard-Size and Oversize) to
different fulfillment centers.

##  Shipping inventory to us

You will ship units of your products/ASINs to the Amazon fulfillment center(s)
we specify in connection with the Inventory Placement Service.

##  Program fees

[ Standard-Size ](/gp/help/external/201105770) per unit (includes all
Standard-Size product size tiers)  
---  
1 lb. or less  |  $0.30  
1 - 2 lb.  |  $0.40  
Over 2 lb.  |  $0.40 + 0.10/lb. above the first 2 lb.  
[ Oversize ](/gp/help/external/201105770) per unit (includes all Oversize
product size tiers)  
5 lb. or less  |  $1.30  
Over 5 lb.  |  $1.30 + $0.20/lb. above the first 5 lb.  
  
##  Changes to fees or terms

We may modify the fees and/or the terms and conditions that apply to the
Inventory Placement Service at any time by providing notice to you as
described in the Agreement or any other applicable Amazon policies.

##  Optional participation

You may discontinue your participation in the Inventory Placement Service by
selecting the **Distributed Inventory Placement** option in your seller
account. See [ FBA Inventory Placement Service ](/gp/help/external/G200735910)
for more information on how to change these settings.

Top

