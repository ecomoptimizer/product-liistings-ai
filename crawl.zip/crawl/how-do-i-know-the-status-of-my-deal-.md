# How do I know the status of my Deal-

Source: https://sellercentral.amazon.com/help/hub/reference/external/G202111570

This article applies to selling in: **United States**

#  How do I know the status of my Deal?

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202111570)

Once you have [ created a Deal ](/gp/help/external/202111550) you can monitor
its status on the **Deals Dashboard** and take the following recommended
actions:

  * **Draft** : One or more values for your Deal contained an error. You have to edit the values you entered and then re-submit for approval. 
  * **Under review** : Your Deal is pending Amazon approval. Deals are usually approved or rejected immediately; however, allow up to 15 minutes for processing. 
  * **Needs edits** : You have to edit the highlighted areas of the Deal and resubmit for approval. 
  * **Pending** : The Deal is eligible; however, the schedule hasn’t been set. Amazon will provide the date and time within one week of the scheduled run. 
  * **Upcoming (Pending date/time scheduling seven days before earliest start date)** : The Deal is eligible; however, the schedule hasn’t been set. The deal schedule will be set within one week of the start date. 
  * **Upcoming** : Your Deal is scheduled to run at the specified date and time. The schedule is automatically generated and cannot be changed.  If you do not want the deal to run at this date and time, you can [ cancel the Deal ](/gp/help/external/202111610) without penalty 25 hours before the scheduled start time. 
  * **Suppressed** : Your Deal does not meet the [ eligibility requirements ](/gp/help/external/202111490) . Click the info to the left of each greyed out ASIN to understand why it was suppressed, then make the necessary changes to price, quantity, or inventory. You must do this at least 25 hours before the scheduled start time to avoid cancellation. 
  * **ASIN greyed out** : Your product does not meet the [ eligibility requirements ](/gp/help/external/202111490) . ASINs that are greyed out cannot be edited; these need to be removed from your deal. However, if too many of your ASINs are greyed out, you may not be able to create or reactivate your deal. 
  * **Running** : The Deal is running according to its start and end date. When a deal is Running, the only edits allowed are to fix deal price related issues or you may cancel your deal. Once your deal sells out or is cancelled, you will no longer be able to submit any edits and your deal cannot be reactivated. 
  * **Canceled** : Deals can be canceled for the following reasons: 
    * The Deal was manually canceled by you. 
    * The Deal was previously suppressed and was not fixed at least 25 hours before its scheduled start time. 
    * The Deal was canceled by Amazon. Amazon is subject to cancel any deals without notification if they violate Amazon’s policy on [ Deal frequency ](/gp/help/external/202111550) . 

After you create a Deal, avoid making the following changes to the ASIN(s) or
parent ASIN participating in the deal:

  * Do not delete or close any of the listings from your **Manage Inventory** page. 
  * Do not change the SKU number for any of the products participating in the Deal. 
  * If your Deal has variations, avoid making changes to the parent ASIN. This includes creating new child ASINs as variations under the parent ASIN, changing the parent SKU, or deleting/closing the parent listing from **Manage Inventory** page. 

For example: After creating a Deal for a product with 3 total size variations
(small, medium, large), avoid creating new variations under the same parent
listing that previously did not exist when the Deal was initially created
(such as x-small, x-large). Any new variation ASIN that was not included in
the initial Deal recommendation will not be eligible to run in the Deal
resulting in the entire Deal becoming suppressed due to no longer meeting all
eligibility criteria.

For information on how to troubleshoot some common errors, go to [
Troubleshooting your Deal ](/gp/help/external/GKN9A84DGTYWYHWY) .

Top

