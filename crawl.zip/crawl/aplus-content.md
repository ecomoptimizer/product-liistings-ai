# A+ content

Source: https://sellercentral.amazon.com/help/hub/reference/external/G202102930

This article applies to selling in: **United States**

#  A+ content

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202102930)

On this page

Who can use A+ content?

Why use A+ content?

What are the types of A+ content?

A+ content placement

Premium A+ FAQ

What is the cost for Premium A+?

What is the eligibility criteria for Premium A+?

What can I do to meet the eligibility criteria for Premium A+?

How will I know if I’m eligible for Premium A+?

What happens at the end of the promotional period?

A+ recommendations

A+ content offers brand owners a way to engage with customers to showcase the
detail page with supplemental marketing content on their branded ASINs.

Using the A+ Content Manager, you can describe your product features in
different ways, whether its highlighting aspects of your brand with the A+
brand story features, or deep diving on product feature information with the
enhanced product description features.

##  Who can use A+ content?

A+ content is meant to be used by brand owners. To add ASINs to your A+
content, you must be a professional Seller and registered as the brand owner
of that ASIN through the [ Amazon Brand Registry Process
](https://brandregistry.amazon.com/register/account?url=/) . A+ content is
also available for emerging brand owners who have been approved for certain
managed selling programs, such as Launchpad and Amazon Exclusives. If you have
registered your brand but still do not have access to A+, contact [ Brand
Registry ](http://www.amazon-brand-registry.com/eng/contact_us) .

We do not charge any fee for adding the Standard Enhanced Product Description
(Basic A+) and A+ Brand Story content features. If we implement a fee for new
types of A+ content in the future, we will make an announcement in the A+
content tool ahead of time so that you know about any change, and your
existing content will not be impacted.

##  Why use A+ content?

Adding A+ content to your product detail pages may result in higher conversion
rates to increase sales, reduce negative reviews by highlighting product
features, and increase discoverability when paired with ads, deals, or
coupons. A+ content provides brand owners the opportunity to answer a
customer’s most common questions by providing relevant brand and product
related details. This information can help drive more rapid purchase decisions
and reduce the likelihood of having products returned.

##  What are the types of A+ content?

Your A+ content can include the following content types, which display in
separate sections on the detail page:  

  1. **Basic A+ content**

Provide more details on product features and uses to complement the bullet
points and images on the main product detail page. These additional details
help customers make purchase decisions by proactively answering their
questions. The Basic A+ content appears in the **Product Description** section
of the detail page, and includes:

    * Access to a diverse set of modules/layouts for content creation 
    * Custom paragraph headers and images 
    * Unique image and text layouts 
    * Product comparison charts 
    * Rich text editor, including bulleted/number feature lists 
    * Comparison charts allow for a minimum of 2 products/2 attributes to compare items in a product line or across your brand 

  2. **Premium A+ content** GHLFBEKJJG9R8NTAs 

Increase engagement with best-in-class detail page experiences available for
supplemental marketing information, using more real estate on the detail page
and richer media content compared to Basic A+ content. This displays in the
**Product Description** of the detail page as well and includes:

    * Interactive hover hotspot modules 
    * Multiple video modules 
    * Enhanced comparison charts 
    * Larger images on the detail page 
    * Carousel modules 
    * Q&A module 

**A+ Content: Basic vs Premium Comparison Guide**

A+ Content Type  |  Text & Images  |  Image Size  |  Comparison Chart  |
Allowable Modules on Detail Page  |  Module Selection  |  Video & Hotspot  |
Navigation Carousel  
---|---|---|---|---|---|---|---  
Basic A+  |

    * |  970 x 300  | 
    * |  5  |  14  | 

|  
  
Premium A+  |

    * |  1464 x 600  | 
    * |  7  |  19  | 
    * | 
    *   3. **A+ Brand Story content**  
  
Educate customers about the history of your brand, the brand's values, and
product lines. Brand Story supports 1 module with up to 19 pre-formatted cards
within a carousel experience and can be used in addition to A+ Content (Basic
or Premium). Brand Story appears in the **From the brand** section on the
detail page, and features include:

    * Carousel display with full screen background on desktop and mobile devices 
    * Image and text cards 
    * Links to other products and your Amazon brand store 

You can publish content to all ASINs that you own as a registered brand owner
in Amazon Brand Registry, and have up to 20 pending submissions in review at
one time.

**Note:**  

  1. If you want to upload and manage product videos, you can use [ Upload and manage your product videos ](/creatorhub/video/library) in Seller Central. 
  2. A+ Content features are not yet formally supported for ASINs sold through Seller Central in the Books, Music, Video, or DVD (BMVD) categories at this time. 
  3. A+ content is not the same as Amazon Business enhanced content, which is a separate tool lets you upload separate file documents to the detail page. 

##  A+ content placement

Basic or Premium A+ content and A+ Brand Story content submitted by sellers
shows in the **Product description** and in the **From the brand** section on
the detail page, respectively. The "From the manufacturer" section of the
detail page is reserved for A+ content from retail vendors. In most cases, A+
content contributed by an Amazon retail vendor that appears in the "From the
manufacturer" section will appear in place of the Seller submitted content
that appears in the "Product description" section. As the manufacturer of the
product, Amazon retail vendor A+ content is prioritized to prevent competing
A+ content submissions on a single ASIN. If an ASIN already has A+ content
contributed by a retail vendor at Amazon, you will not be able to add or edit
A+ content.

When adding A+ content for your ASINs, your A+ content will hide the current
plain-text product description. Ensure that your A+ content includes all the
necessary details from the plain-text product description field. Even though
the plain-text product description is not shown, it is still best practice to
make sure that changes you make to A+ content are also reflected in that field
as well in Manage Your Inventory page.

##  Premium A+ FAQ

##  What is the cost for Premium A+?

Access to Premium A+ features will be available to you at no cost during this
promotional period for all ASINs registered to your brand. During the
promotional period, we encourage you to publish Premium A+ for all ASINs
within your brand. If we announce a fee for Premium A+, you will be given the
opportunity to opt-in for a fee. We will not charge you for any fees without
your consent.

##  What is the eligibility criteria for Premium A+?

The eligibility criteria outlined below is per country that you sell and
publish A+ Content in. You may meet criteria in one country, but not another.
You are eligible if:  

  1. You have already published A+ Brand Story to all ASINs within your catalog that you own. You can confirm this by accessing the A+ Content Manager and searching to see if you have created and published a project. You will also see A+ Brand Story on your ASINs under the “From the Brand” fields on the detail page. 
  2. You have had at least 15 project submissions of A+ content that have been approved within the past 12 months. You can confirm this by accessing the A+ Content Manager and checking the status of your submitted projects and the last modified date. This is to ensure our [ guidelines ](/help/hub/reference/external/GGW8U76SSNTRTBX7) are being adhered to. 

##  What can I do to meet the eligibility criteria for Premium A+?

To meet the criteria, you should:  

  1. Apply A+ brand story to all of your ASINs within the A+ content manager.   

    1. Go to A+ Content Manager 
    2. Start creating A+ content 
    3. Choose brand story 
    4. Add Modules 
    5. Apply ASINs 
    6. Review and Submit. 
  2. To improve your content approval rates, we encourage you to carefully follow our [ A+ Content guidelines ](https://sellercentral.amazon.com/help/hub/reference/external/GGW8U76SSNTRTBX7) as you create new A+ content. Over time, this will help increase your A+ content submission approval rates and improve the time it takes to get content approved and published. 

##  How will I know if I’m eligible for Premium A+?

At the start of each month, we will re-evaluate the eligibility of brand
owners for Premium A+. If you are eligible, we will enable this feature for
you within the A+ content manager and you will see a banner within the A+
content manager notifying you of access with a link to create Premium A+
content. You do not need to contact us for access to Premium A+.

##  What happens at the end of the promotional period?

At the conclusion of the promotional period, we may disable your ability to
add Premium A+ modules to new ASINs. However, any Premium A+ content published
to ASINs during the promotional period will remain on the detail page free of
charge. If we announce a fee for Premium A+, you will not be charged for the
existing content you created. If you would like to replace that content, you
may do so at any time by publishing A+ content using the basic A+ standard
modules.

##  A+ recommendations

Occasionally, A+ recommendations presented on the landing page of the A+
Content Manger are ranked by page views, and are intended to help identify
high traffic ASINs within your catalog that don’t currently make use of A+
content or can help improve existing A+ content.

You can also launch these recommendations as a prioritization workflow from
the content-type selection page after clicking to start creating A+ content.
When you complete, save, or skip any recommendation, the next highest impact
recommendation will be presented to you. If you’re not ready to take action
for a given recommendation, use the dismiss function to hide that item for 30
days.

Top

##  A+ content

* [ A+ content guidelines  ](/help/hub/reference/external/GGW8U76SSNTRTBX7)
* [ Create A+ content  ](/help/hub/reference/external/G202134820)
* [ Content publishing status and content rejection  ](/help/hub/reference/external/GAEAQB7QC4G5Z2LC)
* [ Edit A+ content  ](/help/hub/reference/external/G7DAP8D85ATMUD7Q)
* [ Remove ASINs from an A+ project  ](/help/hub/reference/external/GVED878AAQ2AX2Z3)
* [ A+ content FAQ & troubleshooting  ](/help/hub/reference/external/G202102960)

