# Prepare for the Holiday Season

Source: https://sellercentral.amazon.com/help/hub/reference/external/G8ZDWEJB9Z9YPFQ8

This article applies to selling in: **United States**

#  Prepare for the Holiday Season

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG8ZDWEJB9Z9YPFQ8)

During the peak season, you may experience an increase in sales volume. We
compiled a list of best practices to help you prepare and successfully manage
your seller-fulfilled orders during peak.

**Note:** Even if you do not have a deal planned for peak, assume that you
will receive higher than normal volumes as a result of increased traffic to
Amazon. For more information on peak season readiness, go to [ Seller
University
](/learn/courses?moduleId=33b24db7-f2e2-4be3-b31e-9f3efa5977c2&sid=SU-SEARCH-
ce340ecb-b6c6-4fcc-b85c-dfb71d2747ea&ref_=su_search&modLanguage=English) .

##  Prepare for Peak Sales Volume - Best Practices

**Track your Performance**

You must meet the following requirements to maintain your account eligibility:

  * A Late Shipment Rate under 4% 
  * Pre-fulfillment Cancel Rate of no more than 2.5% 
  * Valid Tracking Rate over 95% 
  * On-time Delivery Rate of at least 97% 
  * Order Defect Rate under 1% 

You can check your [ performance metrics
](/performance/detail/shipping?ref=sp_st_nav_spshp) .

For Premium Shipping orders you must comply with the following metrics:

  * An On-time Delivery Rate above 97% 
  * Pre-fulfillment Cancel Rate less than 0.5% 
  * Valid Tracking Rate over 99% 

You can check your performance metrics on the [ Premium Shipping Options
dashboard ](/performance/eligibilities?ref=sp_st_nav_sphelgb) .

**Manage your orders closely**

Stay on top of orders by updating your notification settings.

Check your Seller app and Seller Central account frequently for orders and
fulfill new orders daily. Do not rely solely on "Sold, ship now" emails to let
you know you have orders. [ Review your notification settings
](/notifications/preferences/ref=xx_notifpref_dnav_xx) .

**Provide accurate product data**

Use unique standard identifiers  (UPC, ,EAN, ISBN)  when creating or matching
to product detail pages. Make sure your product description and condition
notes are clear and helpful to buyers.

**Check your inventory regularly**

Keep an eye on quantity of inventory you have in stock, especially if you sell
in multiple channels. Ensure you have enough inventory to fulfill your sales
and avoid order cancellations due to inventory shortage. For more information
on how to manage your inventory, go to [ Seller University
](/learn/courses?moduleId=497&sid=SU-
SEARCH-75d25549-d515-4645-8886-ccdffb797eb2&ref_=su_search&modLanguage=English&videoPlayer=youtube)
.

**Staffing and handling time**

Review your staffing plans to ensure you have enough capacity to ship during
the holiday season.  Same Day Handling time is only available to sellers who
meet high delivery performance standards. Learn how to to enable and disable [
Same Day handling time ](/gp/help/external/GLL8GJCFS23K333Q) .

Be prepared for an increase in order volume during key sales periods, such as
the run-up to the holiday season. List only those items you will be able to
ship by or before the expected ship date. Learn more about  [ managing orders
](/gp/help/external/G28141) .

**Streamline your shipping and fulfillment**

Review your [ shipping templates ](/sbr#shipping_templates) and ensure that
you can comply with the transit time set on the shipping templates. Weekend
Operations will be optional. When enabled, these days will be considered in
the calculation of the Expected Ship Date.

Ship orders prior to the Expected Ship Date when possible.  Hand over packages
the same day you buy shipping labels and ensure that your carriers provide
first scans the same day.

**Note:** As a reminder, as of September 30, 2020, orders not shipped 7 days
after the Expected Ship Date will automatically be canceled to protect the
customer experience.

**Provide great customer service**

Make an impression on buyers that will last: provide excellent customer
service during the holiday season. Make a point of responding to all of their
inquiries within 24 hours. Add a personal touch to orders - include "thank
you" notes on packing slips. Be courteous in your correspondence with buyers
as per our [ communication guidelines ](/gp/help/external/G1701) , and address
any problems quickly and professionally. Providing world-class service usually
results in buyer appreciation.

**Handle returns, refunds, and A-to-z Guarantee claims**

Address A-to-z Guarantee claims and service chargebacks promptly. Check your
A-to-z Guarantee claim pages daily, and proactively resolve any issues. To
help prevent being held responsible for the reimbursement of a claim, follow
our [ selling policies ](/gp/help/external/G1801) .

Top

