# Amazon Launchpad Program Terms

Source: https://sellercentral.amazon.com/gp/help/external/G202007390

This article applies to selling in: **United States**

#  Amazon Launchpad Program Terms

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202007390)

These Amazon Launchpad ("LP") program terms supplement your seller agreement,
the [ Amazon Services Business Solutions Agreement ](/gp/help/external/G1791)
("BSA").

####  Eligibility

Application is required to participate in LP. To apply, click [ here
](https://sell.amazon.com/programs/launchpad/application) .

As of January 27, 2023, we have paused the enrollment process. For now, we
will not be accepting new applications or recruiting new Selling Partners to
join LP. At this time, we do not have a target date to re-open enrollment. If
you are still interested in joining the program at a future date, check back
to see if enrollment has re-opened.

####  Program benefits

LP is a supplemental program designed to jumpstart and accelerate your Amazon
business. Our mission is to support entrepreneurs and startups that create,
sell, and deliver innovative products to Amazon customers. We offer benefits
such as onboarding guidance, training materials, and product discoverability
support to help your business maximize its success in Amazon’s store.

####  Requirements

To apply to LP, you should:

  * Be a new seller in Amazon’s store, meaning you listed your first product in Amazon’s store less than 4 years ago and your brand’s trailing 12 month gross merchandise sales is less than $5 million. 
  * Be the brand owner of products you list in Amazon’s store. 

At all times during your participation in LP:

  * You must fulfill customer orders for your product(s) using [ Fulfillment by Amazon ](/gp/help/external/G201074400) or [ Seller Fulfilled Prime ](/gp/help/external/G201812230) . 
  * You must maintain a [ Professional selling plan ](https://sell.amazon.com/pricing.html) . 
  * Your account must be in good standing, including maintaining: 
    * Order Defect Rate of 1% or less; 
    * Cancellation Rate of 2.5% or less; and 
    * Late Shipment Rate of 4% or less. 

####  Minimum Commitment and Right to Cancel

By applying to LP, you agree that if accepted you will have to participate in
LP for a minimum of 12 months from the date of acceptance. After 12 months,
you may cancel your participation by providing 30 days’ written notice via an
exit survey.

####  Additional marketing assets

If you include product or brand images on your website or social media
accounts (“Product Images”), they will be deemed part of “Your Materials” and
included in the license granted to us via the BSA. You agree that we can
collect, modify, and display Product Images in connection with the LP program.
You confirm that you are the owner of your Product Images or otherwise have
the right to authorize their use by Amazon. We will comply with your removal
requests as to specific uses of your Product Images.

####  Additional terms

We may in our sole discretion waive the requirements for LP or waive, suspend,
or terminate any feature of LP or terminate your participation in LP in
accordance with your seller agreement. If your participation in LP is
terminated, we will no longer provide you with LP services.

If you are already enrolled in the program, you can get in touch with us in [
Brand Portal ](https://sellercentral.amazon.com/gc/launchpad) .

Top

