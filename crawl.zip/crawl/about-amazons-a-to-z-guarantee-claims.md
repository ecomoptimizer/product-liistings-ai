# About Amazon’s A-to-Z Guarantee claims

Source: https://sellercentral.amazon.com/gp/help/external/G27951

This article applies to selling in: **United States**

#  Amazon’s A-to-z Guarantee Claims

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG27951)

On this page

Common buyer reasons to file a claim under A-to-z Guarantee

Notification of claim submission

Getting product back from buyers

Charging restocking fees

Amazon uses the A-to-z Guarantee for claims, which protects buyers when they
purchase items sold and fulfilled by you directly. The Amazon A-to-z Guarantee
ensures that buyers have a consistent experience across Amazon, regardless of
whether their order is fulfilled by Amazon or by our sellers directly. If a
buyer is not fully satisfied with their order, it is in everyone’s interest if
you are able to resolve the issue directly with the buyer. They end up happier
and your seller account remains healthy and in good standing. The process
involves the following:

  * For A-to-z Guarantee claims covering timely delivery and condition of your items, buyers must first contact you and give you an opportunity to resolve their issue. Depending on buyer issue type, Amazon directs them to use [ Buyer-Seller Messages ](/gp/help/external/200389080) or [ Return Request ](/gp/help/external/G9DH343PLXALFTUW) to alert you to a buyer issue. 
  * You have 48 hours to respond to any issues raised by the buyer. Resolving issues directly with the buyer protects your account health or [ Order defect rate (ODR) ](/gp/help/external/G200285170) . 
  * If you don’t agree on a resolution, buyers are then allowed to file a claim under the A-to-z Guarantee. If the claim is granted in favor of the buyer after Amazon investigates the claim, then claim amount will be debited from your account and reflected in your account health or ODR. For more information on return and claim eligibility policies, go to [ Amazon's return policies ](/gp/help/customer/display.html?nodeId=GKM69DUUYKQWKWX7) and [ A-to-z Guarantee ](/gp/help/customer/display.html?nodeId=201889250) Buyer help page. 

**Note:** For information about A-to-z Guarantee claims covering property
damage or personal injury caused by a defective product, go to [ A-to-z Claims
process for property damage and personal injury
](/gp/help/external/GTY6NYZDFD5CENYH) . For more information about fashion
items-specific return policies, go to [ Free returns of fashion Items for
seller-fulfilled orders ](/gp/help/external/GEKBRFKQE38CQA6V) .

**Important:** The A-to-z Guarantee policy is different for Amazon Pay
transactions. You can review the [ Amazon A-to-z Guarantee for merchants
](https://pay.amazon.com/us/help/201212410) on the Amazon Pay website.

  * If Amazon grants a claim in favor of a buyer, you have 30 days to appeal and request a further investigation. Based on the results of the appeals investigation, Amazon will make a final decision on whether to reverse the initial decision and reimburse you for the claim incurred. 

**Important:** If you do not appeal within 30 days, the claim is closed and
any negative impact to your account health cannot be reversed. Go to our help
page to understand [ how to appeal an A-to-z Guarantee Claim
](/gp/help/external/G202041210) and respond to an A-to-z Guarantee Claim.

  * Once a claim has been granted in favor of a buyer, if the buyer wants to reverse the refund to you for any reason (for example, a delayed order gets delivered and buyer accepts the order), the buyer needs to directly request a retrocharge of their claim amount through their account’s ‘Problem with Order’ page, or they can inform Customer Service to reverse refund claim amount to you. Amazon cannot retroactively charge a buyer unless they specifically tell us to “reverse refund” or perform a retrocharge. To withdraw a claim, the buyer can go to the Orders page or they can call Amazon Customer Service. 

##  Common buyer reasons to file a claim under A-to-z Guarantee

Buyers can file a claim under our A-to-z Guarantee for two basic buyer issues:  

  1. Item has not been received by buyer 

Example: You fail to deliver an item within three calendar days of either the
maximum estimated delivery date ( [ EDD ](/gp/help/external/201714160) ), or
the date of delivery confirmed by a valid tracking link, whichever is sooner.

Buyer eligibility criteria for filing a claim:

    * Buyer has waited until [ EDD ](/gp/help/external/201714160) +3 days and first contacted you through [ Buyer-Seller Messages ](/gp/help/external/200389080) . 
    * You and the buyer do not resolve the issue within 48 hours of the buyer’s first message. 

  2. Item did not meet buyer expectation 

Examples:

    * The item received by the buyer was damaged, defective, materially different from what was ordered, or the buyer changed their mind and returned the item consistent with Amazon’s return policy, but was not refunded or was refunded in the wrong amount. 
    * The buyer wants to return an item internationally but you did not do any of the following:   

      1. Provide a domestic return address 
      2. Provide a pre-paid return label 
      3. Offer a full refund without requesting the item be returned 
    * The buyer has been charged more than the purchase price due to extra charges (for example, Customs charges) not covered by you as the seller. 

Buyer eligibility criteria for filing a claim:

    * Buyer has contacted you through [ return request ](/gp/help/external/G9DH343PLXALFTUW) . 
    * You and the buyer do not resolve the issue within 48 hours of the buyer raising return request. 

Go to [ Prevent an A-to-z Guarantee Claim
](/gp/help/external/GCRVNRBZBVGBK543) to know about the best practices.

##  Notification of claim submission

When a buyer files a claim under Amazon’s A-to-z Guarantee, you will receive
an email notifying you of the claim for your convenience. You can also track
claims filed by your buyers by navigating to the [ A-to-z Guarantee Claims
page ](/gp/guarantee-claims/home.html/ref=xx_azclaims_dnav_xx#/) in [ your
seller account ](/gp/homepage.html/ref=xx_home_logo_xx) under the Performance
tab. You are responsible for monitoring and resolving your claims.

**Note:** You can also use [ this ](/gp/guarantee-
claims/home.html/ref=xx_azclaims_dnav_home#/) quick link to monitor A-to-z
Guarantee Claims status by entering Claims related to an order ID.

##  Getting product back from buyers

If you would like to request for the product back from the buyer who filed a
claim, you can do so using the [ Buyer-Seller Messages
](/gp/help/external/200389080) within Seller Central. Providing a return label
will help the buyer return the item and ensure that you have visibility into
the return. For more information about the return policies, go to [ Guidelines
for handling returns ](/gp/help/external/200364110) .

##  Charging restocking fees

In some circumstances, you can charge a restocking fee when a buyer returns an
item. These circumstances include when an item is returned outside of [
Amazon’s return policy ](/gp/help/customer/display.html/?nodeId=15015721) or
in used, damaged, defective, or materially different condition. Items returned
in original condition and within policy cannot be charged a restocking fee.
You are not required to accept returns beyond the return window. However, if
you do, you can also charge a restocking fee. Go to [ Issue refunds and
concessions for seller-fulfilled orders ](/gp/help/external/GU7K5N5GUP67M4X9)
and [ Guidelines for charging restocking fees ](/gp/help/external/201725780)
to know about charging restocking fees.

Top

