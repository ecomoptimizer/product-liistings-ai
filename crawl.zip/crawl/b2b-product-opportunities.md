# B2B product opportunities

Source: https://sellercentral.amazon.com/help/hub/reference/external/GG6RSFHJVGD653MV

This article applies to selling in: **United States**

#  B2B product opportunities

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGG6RSFHJVGD653MV)

You can find B2B product selection recommendations for your business on the [
B2B product opportunities (BPO) ](/business/opportunities/) page. We use
demand signals like purchasing trends, new product requests and requests for
quantity discounts from our growing Amazon Business customer base coupled with
your selling history to create product selection recommendations for you and
your business. Currently, there are two B2B product opportunity reports
available:

####  Recommended for you

Includes products that are in high demand from categories you are already
selling in.

####  Products not yet on Amazon

Includes products requested by Amazon Business customers that may not be
available on Amazon.

**Note:** APIs are now available to automate your BPO reports. For
documentation on how to build your own API integration, go [ here for SP-API
](https://github.com/amzn/selling-partner-api-
docs/blob/main/references/reports-
api/reportType_string_array_values.md#amazon-business-reports) or [ here for
MWS
](https://docs.developer.amazonservices.com/en_US/reports/Reports_ReportType.html#ReportTypeCategories__AmazonBusinessReports)
.

##  Explore product recommendations with B2B product opportunities

Watch the video below to learn how to access personalized B2B product
recommendations to grow your sales:

Top

##  B2B product opportunities

* [ B2B product opportunities: Recommended for you  ](/help/hub/reference/external/GURRDDL9EK8KH6BL)
* [ B2B product opportunities: Products not yet on Amazon  ](/help/hub/reference/external/GPNBU9M8RSY7ZQKP)

