# Prime Exclusive Discounts

Source: https://sellercentral.amazon.com/gp/help/external/GZG6D3FZA9VSP4XH

This article applies to selling in: **United States**

#  Prime Exclusive Discount

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZG6D3FZA9VSP4XH)

Prime Exclusive Discount is a price discount available to Prime members.
Product offers with a Prime Exclusive Discount will show a discounted price
with the regular price crossed out. Buyers will also see a savings summary in
search results and on product detail pages. Prices adjusted for discounts are
displayed on the Featured Offer detail page for Prime members.

Top

##  Prime Exclusive Discount

* [ Eligibility criteria for Prime Exclusive Discounts  ](/help/hub/reference/external/GNC7446W4QUUSXEU)
* [ Eligibility criteria for Prime Day  ](/help/hub/reference/external/GLREB2WH9JA7R63D)
* [ How do I create a Prime Exclusive Discount?  ](/help/hub/reference/external/GMWCY4U7Q39UP4ZX)
* [ Fixing a file type error while uploading the Prime Exclusive Discount SKUs  ](/help/hub/reference/external/GMJK2KBX3J2XNBQD)
* [ Editing a Prime Exclusive Discount  ](/help/hub/reference/external/GYPA73ZU4JXU4NX7)
* [ Removing or deleting products from a Prime Exclusive Discount  ](/help/hub/reference/external/GWNUAJRK88F5KZ4D)
* [ Why is my product status invalid?  ](/help/hub/reference/external/GCUDVF7L52BWM3SN)
* [ Prime Exclusive Discount FAQ  ](/help/hub/reference/external/GPXVNNG52W63SFGK)
* [ Why is my discount status "Needs Attention?"  ](/help/hub/reference/external/GFXBR898XCK9UGGA)

