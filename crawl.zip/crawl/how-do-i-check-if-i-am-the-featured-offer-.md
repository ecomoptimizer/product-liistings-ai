# How do I check if I am the Featured Offer-

Source: https://sellercentral.amazon.com/help/hub/reference/external/GZA3XB9AA9KH5VXR

This article applies to selling in: **United States**

#  How do I check if I am the Featured Offer?

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZA3XB9AA9KH5VXR)

You can check if you are the Featured Offer by visiting the Product Detail
Page for your ASIN. The Featured Offer is an offer for new products that we
display on a product detail page. It has an **Add to Cart** button that
customers can use to add items to their shopping carts. When one of your items
appears in this way on a product page, you are the Featured Offer. If your
Brand/Seller name shows up in the "Other Sellers" section of the Detail Page,
you are not the Featured Offer.

**Note:** A Featured Offer is at the ASIN level. It is possible that if you
have multiple variations for the same product, you may be the Featured Offer
for some of them and not the others. This is because each variation is a
separate ASIN.

Top

