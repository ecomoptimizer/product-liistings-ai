# Additional Information and Resources for Sellers about our Restricted Products Policy

Source: https://sellercentral.amazon.com/gp/help/external/201567350

This article applies to selling in: **United States**

#  Additional information and resources for selling partners about our
Restricted Products policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201567350)

**Important:** When you sell on Amazon, you must follow federal, state, and
local laws, and Amazon policies that apply to your products and listings.

The sale of illegal products, or other products listed as prohibited for sale
on our [ Restricted Products ](/gp/help/external/200164330) policy page, is
strictly prohibited, and it is each selling partner's responsibility to
carefully review our policies before listing a product.  Selling partners must
also understand that they are responsible for ensuring that their products
comply with all applicable federal and state laws, even if the product is not
specifically described in our policies.  Laws change frequently, so selling
partners should monitor regulatory changes regularly and take appropriate
action.

We are constantly innovating on behalf of our customers to improve the ways we
detect illegal products and products that otherwise violate our policies, and
we continually make adjustments to the systems we use to detect these
products. On occasion, our systems may remove products that are permitted to
be sold on our site. This may occur if there is incomplete or inaccurate
product information provided to us or if our systems incorrectly identify a
product as restricted.  For example, if there is a product with both over-the-
counter and prescription versions, we may restrict the product if we are
unable to determine which version of the product is being offered.  Also note
that some products that are legal are still prohibited by our policies.
Selling partners who believe a product has been removed in error should
contact Selling Partner Support, and we will review the product and make any
appropriate adjustments to our systems as well as to the selling partner's
account status, as applicable. Note that moving a restricted product listing
to Out of Stock (OOS) does not make the listing compliant.  If you think your
product was incorrectly identified as a restricted product on Amazon, close
the listing immediately to ensure compliance while you appeal the restriction
with Selling Partner Support.

Selling partners who violate our policies or applicable law may be subject to
enforcement action, which can vary depending on the type of offense and the
selling partner's account history. We consider a variety of factors in the
selling partner's overall account when determining what action to take,
including the severity and number of violations and other relevant
information. Selling partners who have had their selling privileges removed
may appeal the decision in most cases. In some situations, we may reinstate a
selling partner's account if they have implemented a robust plan of action
that effectively addresses the root causes that led to the violations and will
prevent recurrence of those and other violations.

Below are some best practices selling partners can follow to aid in compliance
with our policies:

  * Do not assume that a product is permitted because it is not listed in our "Examples of Prohibited Listings" or has an existing ASIN. 
  * Assign one or more employees to be responsible for reviewing each product you plan to sell. This employee must have deep and up-to-date knowledge of the products as well as the industry, including laws applicable to those products. 
  * Carefully review our Restricted Products policy, including the "Examples of Prohibited Listings," and your product catalog on a regular basis. This includes any products that are included in inventory feeds or uploaded using an automated system. 
  * If buying inventory from a source other than the manufacturer, apply extra diligence to understand the provenance of the products and the legal framework in which they may be sold. 
  * When in doubt about whether a product may be sold, do not list it. 
  * If selling drugs or supplements, understand the ingredients in these products and research whether they are permitted. In addition to our [ Restricted Products policy ](/gp/help/external/200164330) , there are some resources available online that can help sellers with this research  , including those listed below  . 

  * FDA Recalls and Alerts: [ http://www.fda.gov/Safety/Recalls/default.htm ](https://www.fda.gov/Safety/Recalls/default.htm) (note: includes a sign up to receive automatic email alerts from the FDA) 
  * Drugs@FDA: [ http://www.accessdata.fda.gov/scripts/cder/drugsatfda/index.cfm ](https://www.accessdata.fda.gov/scripts/cder/drugsatfda/index.cfm)
  * FDA National Drug Code Directory: [ http://www.accessdata.fda.gov/scripts/cder/ndc/dsp_searchresult.cfm ](https://www.accessdata.fda.gov/scripts/cder/ndc/dsp_searchresult.cfm)
  * FDA Orange Book (prescription and OTC drugs): [ http://www.accessdata.fda.gov/scripts/cder/ob/default.cfm ](https://www.accessdata.fda.gov/scripts/cder/ob/default.cfm)
  * FDA Green Book (animal drugs): [ http://www.fda.gov/animalveterinary/products/approvedanimaldrugproducts/default.htm ](https://www.fda.gov/animalveterinary/products/approvedanimaldrugproducts/default.htm)
  * FDA's tips for buying drugs online: [ http://www.fda.gov/ForConsumers/ProtectYourself/default.htm ](https://www.fda.gov/ForConsumers/ProtectYourself/default.htm)
  * Legit Script product search: [ http://www.legitscript.com/ ](https://www.legitscript.com/)

##  Create, implement, and submit a plan of action for restricted product
violations

**What is a plan of action?**

A plan of action is an explanation of the issues that led to your product or
account deactivation, steps to resolve the violation, and preventative actions
that you have implemented to ensure the issue does not happen again.

A viable plan of action must answer the following four questions:

  * What was the restricted product violation or which policy was violated by what product? 
  * What caused the violation? 
  * What reactive steps have you taken to resolve the violation? 
  * What proactive steps have you taken to prevent future violation? 

Your plan of action should be factual and direct. Focus on the facts and
events that led to the issue rather than providing an introduction of your
product, business or customers. Avoid attempting to explain every recent
policy or performance issue on your account, unless they specifically relate
to the current Restricted Products violation you have to address.

Complete the following steps to create, implement, and submit your plan of
action.

**Step 1: Identify your restricted product violation**

Identify and describe your violation in your plan of action. Include the ASIN
or specific product type, and the policy that was violated.

To learn more about Amazon’s restricted products policies, refer to [
Restricted Products ](/gp/help/external/G200164330) .

Avoid oversimplification, which can deny your appeal:

  * Generic plans: Apologizing for the violation without providing a specific explanation or identifying the product in any way, and promising to do better. 
  * Invalid root cause: “I did not create the ASIN, I just listed against a product already on the website.” or “I have listed a restricted product”. 

**Step 2: Identify the cause of your restricted product violation**

Identify and describe the cause of your violation in your plan of action. Be
as specific as possible about why the violation occurred.

**Step 3: Take reactive steps to resolve your restricted product violation**

Take the reactive steps necessary to resolve your violation and describe those
steps in your plan of action. These steps might include, (but not be limited
to):

  * deleting a prohibited listing 
  * updating the detail page for your listing to remove prohibited claims 
  * providing information required to demonstrate compliance 
  * fixing a technical issue 

**Step 4: Take proactive steps to prevent future restricted product
violation**

Take proactive steps to prevent future violation and describe the steps in
your plan of action. These steps might include, (but not be limited to):

  * educating yourself and your employees on one or more Amazon restricted product policies 
  * revising an internal process or policy to ensure that one or more types of prohibited product are not listed in the future 
  * completing a comprehensive review of your Amazon listings and deleting any listings that do not comply with applicable laws, and Amazon policies 
  * consulting a legal expert for advice on laws, regulations, and Amazon policies 

Ensure that the steps you take will effectively prevent a future restricted
product violation and avoid listing invalid proactive steps. For example:

  * “If I am unsure whether a product is permitted, I will contact Selling Partner Support for approval before I list it.” Amazon will not pre-screen listings for compliance, or provide legal advice. Contacting Selling Partner Support to ask if a product is permitted is not an effective mechanism to ensure compliance. 
  * “I will set questionable listings to Inactive (Out of Stock) to avoid getting additional violations.” Moving a listing to Closed or Inactive (Out of Stock) will not prevent the potential deactivation of your selling account if those products are found to be prohibited. 

**Step 5: Submit your plan of action**

To submit your plan of action, refer to the instructions at the top of your [
Account Health dashboard ](/performance/dashboard?reftag=ah_em_rp) in Seller
Central.

**Note:** Amazon will assume that all reactive and proactive steps described
in your plan of action have been implemented at the time of submission. If you
commit new violations that are identical or very similar to prior violations,
you must provide a new plan of action for those violations. You cannot re-use
or recycle an old plan of action.

Top

