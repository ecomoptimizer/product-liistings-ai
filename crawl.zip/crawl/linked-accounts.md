# linked accounts

Source: https://sellercentral.amazon.com/gp/help/external/202095190

This article applies to selling in: **United States**

#  Single sign-on

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202095190)

If you have cross-regional accounts, use single sign-on (SSO) to reach all of
your marketplaces from a single sign-in and browser. SSO lets you access any
of your accounts with any set of account credentials. Then you can use the
marketplace switcher to alternate between your marketplaces.

Single sign-on is already in effect if you have linked your accounts. If they
are not yet linked, visit [ Linking accounts ](/gp/help/external/G201841950)
and follow the instructions there.

**Note:** If you don’t see a region or marketplace on the Sell Globally page,
SSO is not yet available for it.

To learn more about single sign-on, watch our video.

[ English ](https://youtu.be/vfS8F68CGr8) | [ 中文
](/learn/courses?ref_=su_home_c112_m441&courseId=112&moduleId=441&modLanguage=Chinese&videoPlayer=youtube)
| [ 日本語 ](https://youtu.be/M-g0l3rDke0) | [ Italiano
](https://youtu.be/dR7H-w64Tjw) | [ Deutsch ](https://youtu.be/52N9SfZGt7U) |
[ Español ](https://youtu.be/1f1ZwndEZiA) | [ Français
](https://youtu.be/UORqiu5zJbk)

Top

