# Browsers and operating systems supported forSeller Central

Source: https://sellercentral.amazon.com/gp/help/external/G21361

This article applies to selling in: **United States**

#  Supported browsers and operating systems

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG21361)

####  Supported browsers:

To ensure you are using a supported browser, install the latest version from
the browser's website listed below:

  * [ Google Chrome ](https://www.google.com/chrome/)
  * [ Mozilla Firefox ](https://www.getfirefox.com/)
  * [ Apple Safari ](https://support.apple.com/downloads/#safari)
  * [ Microsoft Edge ](https://www.microsoft.com/en-us/windows/microsoft-edge)

####  Supported desktop browsers:

  * Mozilla Firefox: Latest version 
  * Google Chrome: Latest version 
  * Apple Safari: Latest version 
  * Edge: Latest version 

####  Supported mobile device browsers:

  * Chrome Mobile: Latest version 
  * Safari Mobile: Latest version 

####  Supported operating systems:

  * Windows: Latest 2 versions 
  * Mac OS X: Latest 2 versions 

Top

