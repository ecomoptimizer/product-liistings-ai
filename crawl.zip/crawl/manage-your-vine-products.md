# Manage your Vine products

Source: https://sellercentral.amazon.com/gp/help/external/GFPUL8XZS2XJLJFL

This article applies to selling in: **United States**

#  Manage your Vine products

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGFPUL8XZS2XJLJFL)

The Vine dashboard will give you access to all the products you have enrolled
in Vine. Your most recent enrollments are easily accessible on the first page
of this dashboard, while older enrollments can be accessed by entering the
ASIN or SKU in the dashboard search field. The dashboard is also the place for
you to see if your enrollments encounter any blockers. You can also see
whether your Vine products have been ordered and reviewed, or cancel your
enrollments.

Enrollments can be classified as concluded, reviews in progress, awaiting
reviews, cancelled by seller, or action required.

  * **Concluded:** Refers to enrollments that either received all the expected reviews or were enrolled over 90 days ago. At this point we do not expect additional reviews to be published. 
  * **Reviews in progress:** Refers to the state of enrollments for which some of the expected reviews have been posted. 
  * **Awaiting reviews:** Refers to enrollments that are yet to receive any review. 
  * **Cancelled by seller:** Refers to enrollments you have cancelled. 
  * **Action required:** Refers to blocked enrollments. You will either need to correct the offer/SKU you enrolled in Vine, update some of your product’s catalog attributes, or send more inventory to resolve the block. For some listing errors, such as the enrolled product’s set parent/child relationship not existing anymore, you would need to cancel and re-enroll your product. For more information on the action required status, refer to the [ Vine errors ](/gp/help/external/GFW53X4JYHRCU9YH) page. 

####  In the dashboard:

You will be able to see the date you enrolled the product in Vine, the number
of units that are still available for Vine Voices to request, the number of
units you enrolled, the number of units Vine Voices claimed, and the number of
Vine reviews that were published.

####  After clicking Details:

You will be able to edit specific aspects of your enrollment (for example,
cancel the enrollment). To access the Vine reviews, you can go to the product
detail page on the Amazon website.

####  Timeline for enrollments:

  * Enrolling an item in Vine is immediate if your ASIN is eligible for the program. 
  * In most cases, Vine Voices can start ordering units within 24 hours of the enrollment being completed. 
  * Vine Voices can start leaving reviews immediately after receiving units. 
  * 25% of reviews received occur within 5 days of the order, while 99% of reviews received occur within 35 days of the order (based on Vine's worldwide reviewer population as of April 2018). 
  * Vine Voices are not required to leave a review on the product, but we update our pool of reviewers often in order to ensure only the most active, helpful reviewers are part of Vine. 
  * If an item arrives defective, damaged, or the reviewer receives the incorrect product due to labeling issues, we will cancel the Vine Voices order if they contact us, and they won't leave a review. 

Top

