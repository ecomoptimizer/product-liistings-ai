# Customer Support for International Sales

Source: https://sellercentral.amazon.com/gp/help/external/201468540

This article applies to selling in: **United States**

#  Customer Support for International Sales

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201468540)

When you sell in an Amazon marketplace, you are required to provide customer
support in the local language of the marketplace. For instance, if you are
selling on Amazon.jp or Amazon.es, you are required to provide customer
support in Japanese or Spanish, respectively. You can choose to do it on your
own or you can have Amazon do it when you join FBA.

##  Fulfilling orders on your own

**Local language customer support**

When you choose to fulfill customer orders yourself, it's not just the
picking, packing, and shipping to customers that you'll need to handle; Amazon
also requires that you handle customer support. This can be challenging if you
are selling in an Amazon marketplace where you don't know the language.

You may be tempted to use automated computer translators to respond to email
inquiries from international customers. However, a risk to this approach is
that machine translation may lead to less-than-optimal translations, which in
turn could lead to a poor customer experience, ultimately affecting your
seller performance ratings. A better option, if you do not have in-house
customer service capabilities in the local language, is to use third-party
service providers to handle your customer support.

**Timely responses**

Customers expect prompt, helpful service when they have questions or concerns
about your products. To maintain a healthy seller scorecard, you should have
customer service specialists who understand your products, that know where the
customer's product is and when it will be delivered, and who will be able to
respond quickly (within 24 hours) to customer e-mail contacts in the local
language. This may be challenging when selling in marketplaces that are in
different time zones from your place of business, as the time differences will
shorten the time frame in which you can respond to customers during your
regular business hours.

There are many online resources that can help sellers with customer support.
Here are a few links other sellers have found useful organized by region.

**Customer support services in** |  **Company**  
---|---  
North America  |  [ Seller Engine ](https://sellerengine.com/services/)  
Europe  |  [ InterCultural Elements ](https://www.intercultural-elements.eu/)  
Japan  |  [ Jumbo ](https://www.jmb.co.jp/english/contents/a_japan.html)  
  
##  Fulfilling orders through FBA

When you use FBA, Amazon will provide 24-hour customer support on your behalf
in the local language of the relevant marketplace. For many sellers, this
feature of FBA is critical to selling on international marketplaces
successfully. With local language customer support already included in FBA,
you can provide your customers with Amazon's world-class customer service, and
you can focus on growing and managing your business.

Top

