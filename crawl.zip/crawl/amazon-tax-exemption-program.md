# Amazon Tax Exemption program

Source: https://sellercentral.amazon.com/gp/help/external/201641810

This article applies to selling in: **United States**

#  Amazon Tax-Exemption Program

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201641810)

Top

* [ How Amazon Tax Exemption Program (ATEP) Works  ](/help/hub/reference/external/G201707880)
* [ Customers With Tax-Exempt Status  ](/help/hub/reference/external/G201707890)
* [ Get Tax-Exemption Certificates  ](/help/hub/reference/external/G201707900)

