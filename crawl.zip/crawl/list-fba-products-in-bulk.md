# List FBA products in bulk

Source: https://sellercentral.amazon.com/gp/help/external/200327780

This article applies to selling in: **United States**

#  List FBA products in bulk

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200327780)

Learn how you can upload product listings in bulk using a flat file instead of
listing each product individually.

You can create listings for Fulfillment by Amazon products in bulk by
uploading a tab-delimited list. There are inventory file templates for
specific Amazon categories that you can download and use to create your
listing files.

For more information about listing products in bulk, see [ Inventory File
Templates ](/gp/help/external/1641) .

After you have successfully uploaded the list, you can use the FBA Fulfillment
Attributes template to update FBA-specific product information not included in
the inventory file templates.

When you use these inventory file templates to create your FBA listings, make
sure you include the following information:

  * In the **Fulfillment Center ID** column ( **fulfillment_center_id** ), type AMAZON_NA for products that you will be selling through FBA. If you plan to fulfill this product yourself (Fulfilled by Merchant), leave the field blank, or type DEFAULT. If you want to sell these products through FBA and fulfill them yourself, you need two listings, one for each fulfillment type. 
  * In the **Quantity** column ( **quantity** ), leave this field blank for FBA products. If you provide a value in the ‘quantity’ column for SKU’s that are fulfilled by Amazon, they will convert to seller-fulfilled. You will use the tools in your seller account to update the quantity when you create your shipping plan. If you are fulfilling the items yourself (Fulfilled by Merchant), type the number of items you currently have in stock. 

##  Update FBA product information

In addition to the inventory file template, use the FBA Fulfilment Attributes
template to update FBA-specific product information not included in the
inventory file template. This is information is uploaded once for each listing
that you have already created.

[ Download the FBA Fulfillment Attributes template ](https://images-na.ssl-
images-
amazon.com/images/G/01/rainier/help/ff/release_4_1/Flat.File.FBA._TTH_.xls) to
begin updating your existing FBA listings.

The workbook includes four tabs:

  * **Instructions** provides directions for using the template. 
  * **Data Definitions** provides an explanation for each column in the template. 
  * **Template** provides a blank spreadsheet for shipping individual products. 
  * **Example** provides an example of how to list your products. 
  * **Valid Values** provides a list of valid entries for the columns in the template. 

To create and upload your attributes list:  

  1. Review the instructions and data definitions. 
  2. Fill out the spreadsheet, adding all of the appropriate information for your products with values from the **Valid Values** tab.  Field name  |  Definition   
---|---  
sku  |  Unique blocks of letters and numbers that are assigned by you to the
product you are selling  
is-expiration-dated-product  |  Identifies perishable products  
maturity-rating  |  Identifies the suitable age range for product  
identity-package-type  |  Identifies the product packaging type  
package-length  |  The length of the product package  
package-width  |  The width of the product package  
package-height  |  The height of the product package  
unit-of-measure  |  The unit of measure  (e.g. inches, feet, centimeters)  
can-ship-in-original-container  |  Whether or not the product can ship in its
original container or if it requires additional packing at the fulfillment
center  
serial-num-scan  |  Whether or not the product serial number can be scanned  
serial-number-format  |  The format of the serial number  
  3. Click **File** and then click **Save As** . Browse to the location where you want to save your file. In the **File name** text box, type a name for your file. In the **Save as type** drop-down list, select **Text (Tab delimited) (*.txt)** . Click **Save** . 
  4. On the [ Add Products via Upload ](/hz/inventory/addproducts) tool page, follow the instructions to complete the upload. 

##

##

Top

