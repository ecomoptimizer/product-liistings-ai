# Examples of products that may be regulated as dangerous goods

Source: https://sellercentral.amazon.com/gp/help/external/G200525640

This article applies to selling in: **United States**

#  Examples of products that might be regulated as dangerous goods

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200525640)

On this page

Apparel

Automotive

Baby

Beauty and personal care

Books

Consumer electronics

Food and beverages

Health and household

Home improvement

Office

Pet products

Shoes

Sports and outdoor

Toys

Video games

Dangerous goods (also called Hazmat) are substances or materials that might
pose a risk while storing, handling, or transporting because they contain
flammable, pressurized, corrosive, or otherwise harmful substances. The list
of products below does not contain every potential dangerous good in each
category, but represent the types of dangerous goods that you might encounter
among your listings, and can therefore serve as good examples to increase your
ability to identify dangerous goods.

To learn more about dangerous goods, see the [ Dangerous goods identification
guide ](/gp/help/external/201003400) . You can also watch the following videos
in Seller University:

[ Introduction to Dangerous Goods ](/learn/courses?moduleId=401)

[ Dangerous Goods Awareness ](/learn/courses?moduleId=402)

When products might be regulated as dangerous goods, you must provide Amazon
with specific product information and documentation (for example, a Safety
Data Sheet) via the [ Upload dangerous goods documents ](/gp/fba/material-
safety-data-sheet/index.html) tool. For more information, see [ Required
dangerous goods information and documentation ](/gp/help/external/201371860) .

Use the **Look up an ASIN** tool to check the classification status of your
FBA ASIN.

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200525640)

##  Apparel

  * Hats and vests with rechargeable batteries 
  * Hat stiffener 
  * Apparel stain remover 

##  Automotive

  * Engine and tire care 
  * Interior and paint care 
  * Oils and fluids 
  * Lead-acid batteries 
  * Spillable and non-spillable batteries 
  * Airbags 

##  Baby

  * Baby grooming and skincare 
  * Antibacterial products 

##  Beauty and personal care

  * Spray deodorants 
  * Hairspray 
  * Hair colors 
  * Hair dyes 
  * Perfume 
  * Essential oils 
  * Self-tanning lotions and sprays 
  * Antiseptics and disinfectants 
  * Verruca and wart treatments 
  * Insect repellents 
  * Aftershave treatments 
  * Cleaning cartridges (electric shavers) 
  * Hair removal solutions and treatments 
  * Shaving creams or foams 
  * Nail polish 

##  Books

  * Songbooks 
  * Magazines with beauty product samples 
  * E-books devices, e-readers 

##  Consumer electronics

  * Powerbanks 
  * Cell phones 
  * Chargers and batteries 
  * Darkroom supplies 
  * Speakers 

##  Food and beverages

  * Aromatic essential oils 
  * Products with high alcohol content 
  * Foods in pressurized container / aerosol format (e.g., whipped cream) 
  * Spirits 

##  Health and household

  * Cleansers and cleaners 
  * Dishwashing liquids and powders 
  * Laundry liquids and powders 

##  Home improvement

  * Grills 
  * Pest and insect control 

##  Office

  * Cartridges and toners 
  * Equipment cleansers 
  * Tape, adhesives and glue 
  * Markers, highlighters, pens and refills 

##  Pet products

  * Ear and eye care 
  * Flea, fly, mosquito, lice and tick control 
  * Itch remedies 
  * Deodorizers 
  * Aquarium glass cleaners 
  * Aquarium water treatments and test kits 

##  Shoes

  * Light-up shoes 
  * Sole and shoe stain remover 
  * Shoe polish 

##  Sports and outdoor

  * Airsoft supplies 
  * Camp stoves 
  * Hand warmers 
  * E-bikes and e-scooters 
  * Bike tools and equipment 
  * Spillable and non-spillable batteries 
  * Life-saving vests 

##  Toys

  * Battery-operated toys 
  * Arts and crafts 
  * Building kits 
  * Chemistry sets 
  * Painting and repair kits 
  * Kits with sprays 
  * Crackers 

##  Video games

  * Controllers 
  * Wireless and Bluetooth headset 
  * Gamepads 

Top

