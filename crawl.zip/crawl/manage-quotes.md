# Manage quotes

Source: https://sellercentral.amazon.com/gp/help/external/G202173820

This article applies to selling in: **United States**

#  Manage Quotes

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202173820)

**Note:** These features are only available to sellers in the [ Amazon
Business Seller Program ](/hz/b2bregistration) .

Amazon Business customers can request a quantity discount on a specific ASIN
by clicking the **Buying in bulk?** link on the product detail page. Customers
then submit the number of units that they would like to purchase. All Amazon
Business sellers can respond to these requests through the **Requests for
items that you sell** tab on the **Manage Quotes** page. Once a discount has
been set, it is available to all Amazon Business customers.  To increase your
chances of making a sale and growing your business on Amazon, set a discount
by the **Respond by** date.

You can also choose to download a list of up to 1000 customer requests by
clicking **Generate downloadable report** . The report can take up to five
minutes to process, and includes several columns for every request. After
downloading this file, complete the steps in Add business prices and quantity
discounts to your [ Manage Quotes feed file
](/gp/help/external/GKU8F3E92RG6HEJM) below.

For a definition of the columns, go to [ Manage Quotes downloadable report
](/gp/help/external/GXPS4MNVWD5Q7WUN) .

To learn more, go to [ Quantity discount requests
](/gp/help/external/202173840) .

To learn more, go to [ Set quantity discounts ](/gp/help/external/202173860)
on the **Manage Quotes** page.

##  Frequently Asked Questions

####  How can I be notified when a business customer requests a quantity
discount on an ASIN that I sell?

All Amazon Business sellers are automatically signed up for email
notifications for requests. You will receive an email whenever a business
customer requests a quantity discount on an ASIN that you sell.

If you would like to unsubscribe from these email notifications, click the
**unsubscribe** link at the bottom of the email.

####  How can I update the email address where I receive notifications?

You can update your email address through the **Change email preference** link
on the top right corner of the **Requests for items you sell** tab. The
**Change email preference** link takes you to the notifications page where you
can edit the email settings for manage quotes email notifications.

####  Why do I see duplicate customer requests on the Manage Quotes page?

You might see multiple requests from the same customer if you have multiple
SKUs on the same ASIN.

####  Are my existing quantity discounts already available to customers who
send me a new request?

Yes, your existing discounts are already available to all Amazon Business
customers. However, you can update your discounts via the **Manage Quotes**
page if you want to better accommodate the customer request.

####  Can I add more quantity discount tiers to an SKU that already has five?

You can only add five quantity discount tiers on a single SKU. If you would
like to offer a new quantity discount, you can edit one of the existing tiers.

####  Can I respond to customer requests on a mobile device?

Yes, you can respond to customer requests using the mobile app. However,
requests responded to using the app will still show as **Response needed**
when viewing them on a desktop device.

Top

##  Manage Quotes

* [ Quantity discount request  ](/help/hub/reference/external/G202173840)
* [ Set quantity discounts requested by buyer  ](/help/hub/reference/external/G202173860)
* [ Manage Quotes downloadable report  ](/help/hub/reference/external/GXPS4MNVWD5Q7WUN)
* [ Custom Quote FAQ  ](/help/hub/reference/external/GEPUV45QETRB3WVV)

