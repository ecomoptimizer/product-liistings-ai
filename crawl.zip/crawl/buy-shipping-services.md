# Buy Shipping services

Source: https://sellercentral.amazon.com/gp/help/external/G200202220

This article applies to selling in: **United States**

#  Use Buy Shipping services

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200202220)

With Amazon's Buy Shipping, you can buy shipping labels individually or in
bulk, ship and confirm your orders, and track your shipments. Buy Shipping
ensures that your products are delivered to your customers using a trusted
network of shipping carriers.

To start taking advantage of Amazon’s Buy Shipping services, see:

  * [ Buy shipping through Seller Central ](/gp/help/external/G200202280)
  * [ Buy shipping in bulk ](/gp/help/external/G202168950)

**Note:** Bulk shipping is currently not available for international shipping.

  * [ Merchant Fulfillment API ](/gp/help/external/G201950090)

Top

##  Use Buy Shipping services

* [ Buy shipping in bulk  ](/help/hub/reference/external/G202168950)
* [ How does Buy Shipping work?  ](/help/hub/reference/external/GLXKP5E6P6QTSSU8)
* [ Missing carrier or ship method in Buy Shipping  ](/help/hub/reference/external/GTQMVHPB94LP2355)
* [ Buy Shipping preferences  ](/help/hub/reference/external/G202086070)
* [ Buy shipping using the Merchant Fulfillment API  ](/help/hub/reference/external/G201950090)
* [ Buy shipping through Seller Central  ](/help/hub/reference/external/G200202280)
* [ Shipping integrators  ](/help/hub/reference/external/GZZPMC9QLNBX48RP)
* [ Veeqo  ](/help/hub/reference/external/GPW2UV7N2KW2GZHD)
* [ Buy Shipping Services - Terms and Conditions  ](/help/hub/reference/external/G200672320)
* [ QZ Tray  ](/help/hub/reference/external/GKULTMACW6HHP7AD)
* [ Amazon Print Connect  ](/help/hub/reference/external/GQ8WSSALNXZJEW3S)
* [ Amazon Print Connect Software License Agreement  ](/help/hub/reference/external/GLJU3HEJGJBT8WVE)
* [ USPS SCAN forms  ](/help/hub/reference/external/GRCGPC8WMSELHC2Q)
* [ Ship from China with Buy Shipping  ](/help/hub/reference/external/GSL4PTYW5Y6Q6ACK)
* [ Amazon Sponsored Discount for Buy Shipping services  ](/help/hub/reference/external/G7X4G8VWJS9B8UUN)

