# Getting Started

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69031

This article applies to selling in: **United States**

#  Getting Started

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69031)

Top

* [ Best practices to maintain positive feedback and rating  ](/help/hub/reference/external/G12051)
* [ Migrating to the Customer Experience Metrics tool  ](/help/hub/reference/external/GEWCZCEXMKYT5KBU)
* [ Customer Reviews  ](/help/hub/reference/external/GXATYDG72KXPG7EM)
* [ Popular Brand Indicator  ](/help/hub/reference/external/G9WV5LPV2LX4CYHK)
* [ About Customer Experience Metrics  ](/help/hub/reference/external/GZE455GHZ4QBEL8W)
* [ Customer Experience Metrics  ](/help/hub/reference/external/GWWTABHFJ3DMY7ZR)

