# Learn more about business pricing

Source: https://sellercentral.amazon.com/gp/help/external/201740300

This article applies to selling in: **United States**

#  Business prices and quantity discounts

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201740300)

**Note:** These features are available to sellers in the Amazon Business
Seller Program only. [ Learn more ](/gp/help/external/201542150)

Offering business prices and quantity discounts can help you capture
customers' attention, gain their trust, and earn their business.

As an Amazon Business Seller, you can offer two types of discounts:

  * **Business price:** A discounted price available exclusively to Amazon Business customers regardless of the quantity purchased. 
  * **Quantity discount:** Tiered discounts available exclusively to Amazon Business customers for higher-volume purchases. Each seller in the Amazon Business Seller program specifies tiers for quantity pricing. 

##  Add, edit, or delete business prices and quantity discounts

You can add, edit, and delete business prices and quantity discounts in your
listings by using [ Manage Inventory ](/inventory/ref=ag_invmgr_dnav_xx_) ,
feeds, or XML files. To learn more, see:

  * [ Use feeds to add business prices and quantity discounts ](/gp/help/external/201995470)
  * [ Edit business prices and quantity discounts ](/gp/help/external/201958240)
  * [ Delete business prices and quantity discounts ](/gp/help/external/201958320)

You can also use the [ Automate Pricing tool ](/automatepricing/home) to set
and automatically update your business prices and quantity discounts in
response to changes in your standard price. For more information, see [ Create
a business pricing rule ](/gp/help/external/GD29LN5JBS94EL4L) .

For more information about the Amazon Business Seller program, including links
to frequently asked questions and troubleshooting information, see [ Amazon
Business overview ](/gp/help/external/201542150) . For more frequently asked
questions on business pricing, see [ Business pricing and quantity discounts
FAQs ](https://sellercentral.amazon.com/gp/help/external/201824530) .

Watch our video on Seller University to [ learn more about business prices and
quantity discounts ](/learn/courses?moduleId=91) .

Top

##  Business prices and quantity discounts

* [ Edit business prices and quantity discounts  ](/help/hub/reference/external/G201958240)
* [ Use Feeds to Add Business Prices and Quantity Discounts  ](/help/hub/reference/external/G201995470)
* [ Business discount insights  ](/help/hub/reference/external/G6ADCY95R5HWLD84)

