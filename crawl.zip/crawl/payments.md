# Payments

Source: https://sellercentral.amazon.com/help/hub/reference/external/G211

This article applies to selling in: **United States**

#  Payments

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG211)

####  How can I find out how much I will be paid?

You can find out how much and when you will be paid from the [ Payments
](/payments/reports/statement/details) report.

Learn more by visiting [ Payments summary ](/gp/help/external/G200913190) .

|

####  What fees will I be charged for Selling on Amazon

The fees charged to your account will depend on whether you have an Individual
or Professional selling plan, which can be found under [ My Services
](/gp/express-boarding/mys-wizard-mode/components/manage-your-services.html) .

Learn more by visiting [ Selling on Amazon Fee Schedule
](/gp/help/external/G200336920)

|

####  What is unavailable balance?

The unavailable balance is the amount of money that is reserved to ensure that
you have enough funds to fulfill any claims or chargebacks.

[ See the full article ](/gp/help/external/G200136810)  
  
---|---|---  
  
####  Why am I being charged a subscription fee?

If you have a Professional selling plan, you will be charged a monthly
subscription fee.

[ See the full article ](/gp/help/external/G16251)

|

####  What is the Individual selling plan?

The Individual selling plan is a pay-as-you-go plan that provides access to a
basic set of listing and order management tools

[ See the full article ](/gp/help/external/G200399460)

|

####  What's the difference between an Individual and a Professional selling
plan?

The Individual selling plan offers foundational selling features, while the
Professional selling plan provides a robust set of tools and features for
Selling on Amazon.

Learn more by visiting [ Selling plan comparison ](/gp/help/external/G64491) .  
  
Top

##  Payments

* [ Payments FAQ  ](/help/hub/reference/external/G69122)
* [ Payments tasks and tools  ](/help/hub/reference/external/G69038)
* [ Payments reference  ](/help/hub/reference/external/G69039)
* [ Seller Lending program  ](/help/hub/reference/external/GZN5DX64LP2QYZ69)
* [ Funds withholding policy  ](/help/hub/reference/external/G9RA9LYBJ3QP27M6)
* [ Acceptable bank accounts and payment service providers  ](/help/hub/reference/external/GKLETRP8MLF7CVFX)
* [ Payment Service Provider FAQ  ](/help/hub/reference/external/GY8JTVAWBPQT2XFC)
* [ Payment Service Provider updates  ](/help/hub/reference/external/GHP8M87Z5W6XTSTL)
* [ Seller Wallet FAQ  ](/help/hub/reference/external/GW57DZACAZGNREVQ)
* [ Express Payout frequently asked questions  ](/help/hub/reference/external/GA24UN79VBPKXZXX)
* [ Express Payout Bank Account and Visa Debit Card Policies  ](/help/hub/reference/external/GHRCBB7RE3HSLGHC)
* [ Buy with Prime lending program  ](/help/hub/reference/external/GY28S6RDW7Z4N5NS)

