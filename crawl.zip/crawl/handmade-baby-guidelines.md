# Handmade Baby guidelines

Source: https://sellercentral.amazon.com/gp/help/external/GDLH7JE6U8WXKCFH

This article applies to selling in: **United States**

#  Handmade Baby guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGDLH7JE6U8WXKCFH)

As a Maker, your handmade Baby products must adhere to the following
guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must meet the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * Baby apparel designs must be your own, produced in your studio or workspace. 
  * [ Amber teething jewelry ](/gp/help/external/GTKJJAREFYF2CTA5) is prohibited. 
  * If you supply products for sale on Amazon, you must comply with all federal, state, and local laws and Amazon policies applicable to those products and product listings.  For [ Children’s Products ](/gp/help/external/G5SB2HLMUYFK4MXC) , review the policy for more details, including [ Children’s Jewelry ](/gp/help/external/GT3XLUHYCWPM3THX) policy. 

Top

