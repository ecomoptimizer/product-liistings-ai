# Offer placement

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201687530

This article applies to selling in: **United States**

#  Offer placement

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201687530)

When you list eligible products on Amazon, all customers browsing the site can
find and purchase them (as long as the items can be shipped to the customer's
shipping address). Customers can add products to their shopping carts using
one of the following three methods:

  * By using the **Add to Cart** button (below the Featured Offer). 
  * By browsing offerings in the **Other Sellers on Amazon** box. Customers can then click **Add to Cart** next to the offer the customer wants to purchase. 
  * By clicking the **used & new ** link and browsing all offers for an item. Customers can then click **Add to Cart** next to the seller from whom the customer wants to purchase the product. 

**Note:** If there are no used listings, the link will only mention **new.**

Amazon selects the Featured Offer from the pool of eligible offers based on,
among other things, price, availability, and the customer's shipping address.
Buyers see the Featured Offer as the first choice while using the **Add to
Cart** button on the product detail page. The product detail page also
features additional offers.

In addition to the Featured Offer, up to three additional eligible offers will
display in the **Other Sellers on Amazon** box on the product detail page. Any
remaining offers are available via the **new & used ** link (or **new** link)
to go to the offer listing page.

####  See also

[ How the Other Sellers on Amazon Box Works ](/gp/help/external/200418110)

Top

