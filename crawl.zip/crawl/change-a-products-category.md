# Change           a product’s category

Source: https://sellercentral.amazon.com/gp/help/external/201950630

This article applies to selling in: **United States**

#  Change a product’s category

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201950630)

##  How is a browse node different from a product category?

Every product on Amazon has one browse node to help customers that are either
searching or browsing for a type of product. For example, a pair of sneakers
could have the browse path:

Clothing, Shoes & Jewelry > Men > Shoes > Athletic

A product category determines what restrictions may be placed on selling
products in that category as well as fees.

##  Changing multiple products' browse node

You can save time when you need to change the category of multiple products by
uploading an Inventory File.

  1. Go to [ Add Products via Upload ](/listing/download) and generate the appropriate inventory file template. 

  2. Enter your product information and include the new category in the Item Type Keyword column.    

  3. Upload the file on the [ Check and Upload your Inventory File ](/listing/upload) tab of the Add Products via Upload page. 

Top

