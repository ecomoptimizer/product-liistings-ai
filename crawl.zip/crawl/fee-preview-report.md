# Fee Preview report

Source: https://sellercentral.amazon.com/gp/help/external/201115050

This article applies to selling in: **United States**

#  Fee Preview report

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201115050)

This report shows the estimated Amazon selling and fulfillment fees for your
current FBA inventory, as well as upcoming fee changes, if any, on your
seller-fulfilled and FBA offers.

FBA fee estimates for seller-fulfilled offers are for your information only
and are not charged to your account. The data in the report may be up to 72
hours old.

For more information, go to [ FBA features, services, and fees
](/gp/help/external/201074400) .

##  Field definitions

Field name  |  Description  |  Example  
---|---|---  
sku  |  Stock Keeping Units (SKUs) are unique blocks of letters or numbers
that identify your products. SKUs are assigned by you as the seller.  |
AB-8675309  
fnsku  |  Unique identifier assigned by Amazon to products stored in and
fulfilled from an Amazon fulfillment center  |  X00000E5TX  
asin  |  Amazon Standard Identification Numbers (ASINs) are unique blocks of
10 letters or numbers that identify products. ASINs are assigned by Amazon.
You can find the ASIN on the product detail page.  |  B003ZYF3LOv  
product-name  |  The title of your product  |  Toysmith Nonstick or Bakeware
Set  
product-group  |  The Amazon department or category  |  Kitchen  
brand  |  The brand of your product  |  Casio  
fulfilled-by  |  The entity that fulfilled the item  |  MFN or AFN  
your-price  |  Your current selling price  |  10.25  
sales-price  |  Your current promotional price  |  4.00  
longest-side  |  Measurement of the longest side of your product including its
packaging  |  20  
median-side  |  Measurement of the side that is neither the longest nor the
shortest side of your product including its packaging  |  10  
shortest-side  |  Measurement of the shortest side of your product including
its packaging  |  4  
length-and-girth  |  The longest side of your product, including its
packaging, plus the girth, a unit measure, equivalent to 2 x (median side +
shortest side)  |  48  
unit-of -dimension  |  The unit of dimension used in measurement  |  inches  
item-weight  |  The weight of the product  |  10  
unit-of-weight  |  The unit of weight used in weight measurement  |  pounds  
product-size-tier  |  The size tier assigned to your product by FBA based on
its dimensions and weight  |  Lg-Oversize  
currency  |  The currency in which the fee is calculated  |  USD  
estimated-fee-total  |  The estimated fulfillment and selling on Amazon fee  |
25  
estimated-referral-fee-per-unit  |  The estimated selling on Amazon referral
fee  |  2  
estimated-variable-closing-fee  |  The estimated variable closing fee for your
product  |  5  
estimated-order-handling-fee-per-order  |  The estimated order handling fee
per order  |  6  
estimated-fba-fulfillment-fee-per-unit  |  The estimated FBA fulfillment fee
for your product per unit  |  2  
estimated-weight-handling-fee-per-unit  |  The estimated weight handling fee
for your product based on the outbound shipping weight  |  1  
estimated-future-referral-fee-per-unit  |  The estimated referral fee per unit
based on the future fee category that will be charged by the future fee
category effective date  |  3.54  
current-fee-category  |  The current fee category that is mapped to your
listing  |  Books  
future-fee-category  |  A fee category that will be mapped to your listing by
the future fee category effective date  |  DVD  
future-fee-category-effective-date  |  The date when the future fee category
will take into effect  |  2022/3/15  
  
Top

