# Featured Offer eligibility

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200418100

This article applies to selling in: **United States**

#  Featured Offer eligibility

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200418100)

On this page

What is the Featured Offer?

How can I become eligible?

How do I check if my items are eligible?

##  What is the Featured Offer?

The Featured Offer is an offer for new products that we display on a product
detail page with an **Add to Cart** button that customers can use to add items
to their shopping carts. When one of your items appears in this way on a
product page, we call it the Featured Offer.

There are two steps to selecting offers to feature. First, we determine which
items are eligible to be featured based on criteria that are designed to give
customers a great shopping experience. Second, we select compelling offers to
feature from among this pool of eligible offers.

This Help topic deals with that first step, eligibility. Becoming eligible for
the Featured Offer doesn't guarantee that you will get featured. However,
there are a few things that you can do to increase your chances. To learn
more, see [ Becoming the Featured Offer ](/gp/help/external/201687550) .

##  How can I become eligible?

Your offers are eligible for the Featured Offer if you have a Professional
selling account. [ Check your current account type
](/gp/help/external/201747610) if you’re not sure and upgrade if required. To
ensure that customers have a great shopping experience and to guard against
abuse, we remove eligibility based on account performance and other risk
factors.

  

##  How do I check if my items are eligible?

You can find out if any of your items are eligible for the Featured Offer:

  

  1. First, ensure seller eligibility (see above). 
  2. In Seller Central, go to your [ Manage Inventory ](/hz/inventory) page and then click **Preferences** . 
  3. Select **Featured Offer (Buy Box) Eligible** , and at the bottom of the page, click **Save Changes** . 

The **Featured Offer (Buy Box) Eligible** column will display the status for
each of your ASINs.

Top

