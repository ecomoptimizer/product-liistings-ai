# New Seller Incentives

Source: https://sellercentral.amazon.com/help/hub/reference/external/GXMJ38VA95GUN5XU

This article applies to selling in: **United States**

#  New Seller Incentives

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGXMJ38VA95GUN5XU)

On this page

Program overview

Seller eligibility

Benefit disbursement

Frequently asked questions

New Seller Incentives program terms and conditions

**Note:** This page and terms and conditions apply only to sellers who list
their first buyable ASIN on or after March 1, 2023. If you listed your first
buyable ASIN between January 1, 2022, and February 28, 2023, go to the [ 2022
program terms and conditions ](/gp/help/external/GFAKX5SD6RJG4FRS) .

##  Program overview

Through New Seller Incentives, new sellers on Amazon’s Professional selling
plan can qualify for a suite of benefits designed to help them launch and grow
on Amazon.

For new sellers who are identified as brand owners with [ Amazon Brand
Registry ](https://brandservices.amazon.com/) , benefits include the
following:

  * A 5% bonus on up to $1 million in eligible branded sales (up to $50,000 in bonus value) or for one year after eligibility is determined, whichever comes first. 
  * $200 in credits for [ Amazon Vine ](/gp/help/external/G92T8UV339NZ98TN) .  Vine invites the most trusted reviewers in the Amazon store to post opinions about new products to help their fellow customers make informed buying decisions. Participating sellers can provide free units of their products to these reviewers. 

For new sellers who use [ Fulfillment by Amazon (FBA)
](https://sell.amazon.com/fulfillment-by-amazon) , benefits include the
following:

  * $100 in credits in inventory shipping fees for using the [ Amazon Partnered Carrier program ](/gp/help/external/G201119120) or $200 in credits in fulfillment fees for using [ Amazon Global Logistics ](/gp/help/external/G202187670) . 
  * Automatic enrollment in [ FBA New Selection ](/gp/help/external/GWHQRT98SAZC29VQ) , which provides free monthly storage, liquidations, and return processing for your eligible new-to-FBA ASINs. 

For new sellers who use [ Sponsored Products
](https://advertising.amazon.com/solutions/products/sponsored-
products?ref_=a20m_us_hnav_p_sp) , benefits include the following:

  * $50 in promotional clicks for using Sponsored Products. Help customers find your products by quickly creating ads that appear in related search results and product pages. 

For new sellers who use [ Amazon coupons ](/gp/help/external/G202189350) ,
benefits include the following:

  * $50 in coupon credits. Coupons help you create compelling promotions for your customers in the Amazon store. 

##  Seller eligibility

New sellers on the [ Professional selling plan
](https://sell.amazon.com/pricing?ref_=sdus_soa_sell_pricing_plans#selling-
plans) whose first buyable ASIN was listed in the US on or after January 1,
2022, and who take specific actions as described below are eligible to receive
New Seller Incentives benefits.

This page and terms and conditions apply only to sellers who list their first
buyable ASIN on or after March 1, 2023. If you listed your first buyable ASIN
between January 1, 2022, and February 28, 2023, go to the [ 2022 program terms
and conditions ](/gp/help/external/GFAKX5SD6RJG4FRS) .

**Eligibility for new brand-owner benefits**

We define brand-owner benefits as the 5% bonus on branded sales and credits
for Vine. To become eligible for brand-owner benefits, you must complete
Amazon Brand Registry and be identified as brand owner no later than six
months after you list your first buyable ASIN, and you must be the first
seller to complete brand registry for the given brand.  For more information,
go to [ Amazon Brand Registry ](https://brandservices.amazon.com/) . Another
recommended resource is the [ Amazon IP Accelerator
](https://brandservices.amazon.com/ipaccelerator) , which provides support to
sellers who are pursuing trademarking.

  * You're eligible to earn the 5% bonus on multiple brands, as long as you have been identified as the first brand owner to complete brand registry for the brands in question, sold via your seller account. Only sales that are associated with brands for which you’re the first to complete brand registry are eligible to earn the 5% bonus. 
    * To view the brands for which you’re the brand owner, go to [ Brand benefit eligibility ](/ap/signin?clientContext=133-4052452-5077640&openid.return_to=https%3A%2F%2Fsellercentral.amazon.com%2Fbrands%2Fbrand-relationships%3Fref%3Dbrnd_vine_bssi_help&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=sc_na_amazon_v2&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&mons_redirect=sign_in&ssoResponse=eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.4DjCknSlN9gliV4A8QzX3Rjv8AZ3rNiNvDrhMqHPmcqrFn3IaF8RkA.lQi-pJdMI1JTofj3.fkK70hcxWYvNKeyazNIPCndY4OKlWZr83UedWCUamiYJ5iGweUtdHTU824L-0T_sVhTpLRbFNHZNQBajrLZbstfqvVs_nI7cPi_c7hI4RVBTMaCxUytJX1IAV5l6TG1OmZ9b4NTU1iE1lzhzR9J1vLaBNG0885O64WdwMhdEoWco3U6swHV6J4JpBsfAzhvobKyHfEPBs47rP3SbTLOk11dtOBn1UJfc_nlYG5ZT2VXUZBXowcTrj787nRnNV6FcwOGntYVeGgn8kgaqV8nnpL5eeH-5f3uQeQIJ.FWgUGCdHUT45v59GlCDSjA) . If you’re missing the brand-owner designation, contact Selling Partner Support. 
    * To track which ASINs are eligible to earn the bonus and to track the total bonus that you’ve accumulated to date, go to the [ New Seller Incentives dashboard ](/new-seller-incentives/dashboard) . 
  * In addition, to become eligible for Vine credits, you must also [ enroll in Vine ](/gp/help/external/GSTY2Q2TD5E84RXJ) within 90 days of becoming eligible for brand benefits (the latter of when you completed Brand Registry enrollment and listed your first ASIN). The Vine credits will start applying to ASINs that are enrolled five days or more after you become eligible for brand benefits. 

**Eligibility for new FBA seller benefits**

To receive the inventory shipping discount or fulfillment fee discount, and to
be eligible for automatic enrollment in [ FBA New Selection
](/gp/help/external/GWHQRT98SAZC29VQ) , you must create your first FBA
shipment within 90 days of listing your first buyable ASIN.

**Eligibility for Sponsored Products benefits**

To be eligible for Sponsored Products credits, you must launch a campaign
within 90 days of listing your first buyable ASIN.

**Eligibility for Amazon coupons benefits**

To receive the credits for Amazon coupons, you must create a coupon within 90
days of listing your first buyable ASIN.

##  Benefit disbursement

**Brand owners’ 5% bonus:** Each month, you’ll earn a bonus amount equivalent
to 5% of eligible branded sales sold the month before. The amount will be
applied as a credit to the referral fees on next month’s referral fees at the
order level.

When payments cover the entire referral fee on a given order, the bonus will
be applied in the background, and the referral fee section will not be shown
as a separate line item in the transaction. You can track the total bonus
accumulated to date on the [ New Seller Incentives dashboard ](/new-seller-
incentives/dashboard) .

**Vine credits:** If you complete the eligibility steps of becoming a brand
owner and listing your first buyable ASIN, you'll get a waiver on the first
$200 charged for enrolling ASINs into Vine.  The credits will start applying
to ASINs that are enrolled in Vine five days or more after you become eligible
for the benefits. Unused credits will expire 90 days after you become eligible
for brand benefits.

**Inventory shipping and fulfillment fee credits:** You can get either credits
for inventory shipping fees or fulfillment fees, depending on whether you
create your first shipment with the Amazon Partnered Carrier program or Amazon
Global Logistics.

  * If you create your first shipment using a partnered carrier, you’ll get $100 in credits to waive future inventory shipping fees.  Credits will be provided after the shipment is received at the fulfillment center and will be used to waive future fees. 
  * If you create your first shipment using Amazon Global Logistics, you’ll get $200 in credits to waive future fulfillment fees.  Credits will be provided after the shipment is received at the fulfillment center and will be used to waive future fees. 

To be eligible for either benefit, you must create your first shipment within
90 days of listing your first buyable ASIN.

**Note:** It can take at least 10 days for the credits to be applied to your
account before they can be used to waive future fees. You can check your
credits on the [ New seller Incentives dashboard ](/new-seller-
incentives/dashboard) . Credits expire after one year if unused.

**Sponsored Products promotional clicks:** Credits are provided if you launch
a Sponsored Products campaign within 90 days of listing your first buyable
ASIN. Any unused promotional click credits will expire 30 days after they’ve
been applied to your account. You’ll see the promotional click credits via the
Campaign Manager. It can take up to two weeks for the credits to be applied
after you complete the required eligibility steps.

**Amazon coupons credits:** To get credits for coupons, you must sign up for [
Amazon Coupons ](/gp/help/external/G202189350) within 90 days of listing your
first buyable ASIN.  These credits will be applied to your first $50 in fees
charged for creating coupons. The credits expire after one year if unused.

##  Frequently asked questions

####  I’m an existing Amazon seller who wants to launch in another region. Am
I eligible for New Seller Incentives?

Yes. The New Seller Incentives program is available to the following:

  * Sellers who launch in the US 
  * Sellers who launch in the UK, Germany, France, Italy, and Spain, and who are not yet selling in any one of those stores 
  * Sellers who launch in Japan 

For example, a current US seller who launches in Japan will be eligible for
New Seller Incentives in Japan if all other eligibility requirements are met.
Sellers who launch in the UK, Germany, France, Italy, and Spain will be
eligible for New Seller Incentives only once for the region.

####  I’m an existing Amazon seller already selling in the UK, Germany,
France, Italy, or Spain. I want to expand to other stores in the region. Am I
eligible for New Seller Incentives benefits?

No. If you launched your first buyable ASIN in the UK, Germany, France, Italy,
or Spain before January 1, 2022, you won’t be eligible for New Seller
Incentives benefits in any of other stores in the region. This page and terms
and conditions apply only to sellers who list their first buyable ASIN on or
after March 1, 2023. If you listed your first buyable ASIN between January 1,
2022, and February 28, 2023, go to the [ 2022 program terms and conditions
](/gp/help/external/GFAKX5SD6RJG4FRS) .

####  I’m a new seller on the Individual selling plan. Am I eligible for New
Seller Incentives benefits?

No. New Seller Incentives are available only for sellers on the Professional
selling plan.  For more information about Amazon’s selling plans, go to our [
pricing page ](https://sell.amazon.com/pricing) .

##  New Seller Incentives program terms and conditions

These New Seller Incentives Program Terms and Conditions (“ **Terms and
Conditions** ”) apply to your participation in the New Seller Incentives
Program (“ **New Seller Incentives** ”), which is described more fully on the
New Seller Incentives page.  These Terms and Conditions supplement the [
Amazon Services Business Solutions Agreement ](/gp/help/external/G1791) (the “
**Agreement** ”).  Capitalized terms used and not defined in these Terms and
Conditions have the meanings ascribed to them in the Agreement.

**1\. New Seller Incentives Overview and Eligibility**

New Seller Incentives is a suite of benefits focused on assisting new Amazon
Professional sellers with their selling. For purposes of New Seller
Incentives, “ **New Sellers** ” are sellers with [ Professional selling
accounts
](https://sell.amazon.com/pricing?ref_=sdus_soa_sell_pricing_plans#selling-
plans) who list their first buyable ASIN on or after January 1, 2022, in
Amazon.com in order to sell in the US. New Sellers may be eligible to receive
some or all of the available New Seller Incentives benefits, based on the
eligibility criteria for each benefit. The New Seller Incentives suite of
benefits is only available once per selling account and per brand in the US.
Only brands that have not already been sold on Amazon.com are eligible for
benefit.

**Note:** This page and terms and conditions apply only to sellers who list
their first buyable ASIN on or after March 1, 2023. If you listed your first
buyable ASIN between January 1, 2022, and February 28, 2023, go to the [ 2022
program terms and conditions ](/gp/help/external/GFAKX5SD6RJG4FRS) .

**New Seller Incentives Benefits**

2.1 _Brand Registry Benefits_ . New Seller brand owners who complete [ Brand
Registry ](https://brandservices.amazon.com/) within six months of listing
their first buyable ASIN and are identified by Amazon as a brand owner in the
US will be eligible to receive the following benefits:

**Note:** These benefits are available only to sellers who own a brand. Only
the first seller for a registered brand in Brand Registry is eligible.  This
seller must be responsible for selling the brand on Amazon.com.  If you do not
have access to these benefits, you have not been identified as a brand owner.
Visit the  [ Brand Benefit Eligibility ](/brands/brand-
relationships?ref=brnd_aba_bssi_help) page to identify as brand owner and gain
access to these and other brand-exclusive benefits. If you believe that you do
fit these criteria but still don't have access, contact Selling Partner
Support.

  * _Bonuses on Eligible Branded ASINs_ . A monthly bonus equivalent to 5% of your sales of ASINs where you are identified by Amazon as the brand owner in the US. The bonus will be paid in the calendar month after it is earned. The bonus will stop accumulating after the earlier of the first $1 million in eligible branded sales or one year. The one-year eligibility timeline begins at the latter of either the listing of your first buyable ASIN, or your completion of Brand Registry and identification as a brand owner by Amazon in the US. While this bonus may not stack with other bonuses offered by Amazon, including rebate from the FBA New Selection program, we will always award you the more favorable bonus to you. 
  * _Amazon Vine Credits_ .  A $200 credit applied to the first $200 in fees charged for enrolling ASINs in the [ Vine program ](/gp/help/external/G92T8UV339NZ98TN?ld=SDUSSOADirect) . Unused credits will expire 90 days after becoming eligible for Brand Registry benefits. Note that the credits will start applying to ASINs enrolled five days after becoming eligible for the Brand Registry benefits. 

2.2 _Fulfillment by Amazon Benefits_ . New Sellers who create their first
shipment to an Amazon fulfillment center within 90 days of listing their first
buyable ASIN will be eligible to receive the following benefits:

  * _Domestic Inbound Discount_ .  New Sellers who create their first shipment to an Amazon fulfillment center using the [ Amazon Partnered Carrier program ](/gp/help/external/G201119120) will earn $100 in shipping credits. The discount is applied to future partnered-carrier shipments after the first partnered-carrier shipment is received at a fulfillment center and is used until the full $100 amount is consumed. Unused credits expire one year after the receiving of your first partnered-carrier shipment. This discount will not be provided to sellers who already received the non-domestic inbound discount mentioned below. Note that it can take up to 10 days to obtain the $100 credits that can be used to waive future fees after the first shipment is received at an Amazon fulfillment center. 
  * _Non-domestic Inbound Discount_ .  New Sellers who create their first shipment to an Amazon fulfillment center using [ Amazon Global Logistics ](/gp/help/external/202187670) or [ SEND ](/gp/help/external/201119120) will receive $200 in fulfillment fee credits.  .  This credit will be applied to future fulfillment fees after the seller’s first Amazon Global Logistics or SEND shipment is received at an Amazon fulfillment center and expires one year after the first shipment is received at an Amazon fulfillment center.  This discount will not be provided to sellers who already received the domestic inbound discount mentioned above. Note that it can take up to 10 days to obtain the credits that can be used to waive future fulfillment fees after the first shipment is received at an Amazon fulfillment center. 
  * _Enrollment in FBA New Selection_ . Automatic enrollment in the [ FBA New Selection program ](/gp/help/external/GWHQRT98SAZC29VQ) after the first shipment is received at an Amazon fulfillment center, giving you access to the FBA New Selection program benefits. Additional terms and conditions specific to FBA New Selection will apply. 

2.3 _Advertising Benefits_ .

  * _Sponsored Products Credits_ . To be eligible for the $50 benefit, sign up for [ Sponsored Products ](https://advertising.amazon.com/solutions/products/sponsored-products?ref_=a20m_us_hnav_p_sp) and launch a campaign within 90 days of listing your first buyable ASIN. [ Additional terms and conditions apply. ](https://advertising.amazon.com/legal/terms-conditions/sponsored-products-new-seller-incentives-promotion-2023)
  * _Coupon Credits_ .  For sellers who sign up for [ Amazon Coupons ](/gp/help/external/G202189350) and create their first coupon campaign within 90 days of listing their first buyable ASIN, we will provide $50 in credits applied to fees charged for creating coupons. Unused credits will expire one year after you create your first coupon campaign. 

You may choose to stop receiving your benefits at any time. We may stop any of
the benefits if we determine you have violated the Agreement or these Terms
and Conditions, or you have committed fraud. We may also change or cease to
offer the New Seller Incentives or any of its benefits in accordance with the
Agreement, including the relevant notice provision.

Top

##  New Seller Incentives

* [ 2022 New Seller Incentives  ](/help/hub/reference/external/GFAKX5SD6RJG4FRS)

