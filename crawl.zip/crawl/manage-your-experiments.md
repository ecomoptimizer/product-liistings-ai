# Manage Your Experiments

Source: https://sellercentral.amazon.com/help/hub/reference/external/GVP453K5XRBJS7Y9

This article applies to selling in: **United States**

#  Manage Your Experiments

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGVP453K5XRBJS7Y9)

Manage Your Experiments lets you run A/B tests (also known as split tests) on
your brand’s listings content. Experiments let you compare two versions of
content against each other so you can see which performs better. At the end of
an experiment, you can review which version performed the best and then
publish the winning content. By running experiments, you can learn how to
build better content that appeals to your customers and helps to drive more
sales.

During the experiment, customers that view your ASIN’s content are randomly
split into two groups. One group sees Version A of content, while the other
sees Version B, for the entire experiment. This means that experiments are
**not** rotating content over time. Instead, both versions of content are
always showing during the experiment, but to different groups of customers.
Customers in the experimental group will see your content everywhere it is
available. For example, an experimental product title will show in search
results, on the ASIN’s product detail page and in cart/checkout. (Note:
Experiments **do not** impact search rankings.)

##  Content types available for experimentation

There are  five  types of content available for experimentation:  product
images, product titles, product bullet points, product description and A+
Content (Brand authored detail page content which describes the unique brand
story and contains enhanced images and text placements.)

Customers use product titles and images when reviewing search results to
determine which product detail pages to visit. Thus, product title experiments
and image experiments can be used to optimize your content and help drive
traffic to your listings.  When on a detail page, customers use the main
product image and the associated A+ content to make a purchase decision. Thus,
image and A+ content experiments can help you determine which content may
improve conversion.  Bullet points and description help you to up sell
features and benefits of your product. Thus, Bullet points and Title
experiments can help you determine which content helps customers make informed
purchase decisions.

##  Eligibility

Brand Eligibility: To run experiments, you must  own a brand  . That means
that you are internal to the brand and responsible for selling the brand in
the Amazon store. Additionally, in order to experiment, you must have at least
one eligible ASIN based on traffic (see next section).

ASIN Eligibility: An ASIN is eligible if it belongs to your brand and has
received enough traffic in recent weeks to be eligible for experimentation. We
only let you experiment with high-traffic ASINs to increase the likelihood
that you can confidently determine a winner at the end of the experiment.
Depending on the category, high-traffic ASINs may get several dozen orders per
week, or more. When selecting an ASIN to experiment on, MYE will show the
eligibility status of most candidate ASINs, but note that ASINs with very low
traffic may not appear at all.

If an ASIN isn’t eligible because it isn’t high-traffic, consider driving more
traffic to it using advertising or other means.  A+ experiments must have
published A+ content to be eligible. Only one experiment can be run on any
particular ASIN at a time.

Top

##  Manage Your Experiments

* [ Creating Experiments  ](/help/hub/reference/external/GYZYA77YZTWTF7YZ)
* [ Experiment Results  ](/help/hub/reference/external/GY6DCFA53HYDH79H)
* [ Tips for Experiments  ](/help/hub/reference/external/G2BNMJ8NFCGZQVFH)
* [ Experiments FAQ  ](/help/hub/reference/external/G9FCELUZGHBD9C7H)

