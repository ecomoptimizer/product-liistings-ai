# How to create coupons in bulk

Source: https://sellercentral.amazon.com/gp/help/external/G363YLQW4NB5L38V

This article applies to selling in: **United States**

#  Create coupons in bulk

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG363YLQW4NB5L38V)

To use spreadsheets to create coupons, follow the steps below:  

  1. Go to **Advertising** , and then select **Coupons** . 
  2. Click **Create a new coupon** on the dashboard. 
  3. In the **Create in bulk section** on the right, click **Download template file** . 
  4. Open the file and fill in the spreadsheet according to the instructions listed below. 

**Note:** Each row in the spreadsheet is a separate coupon. If you want to add
multiple ASINs to the same coupon, add them in the same cell in column A,
separated by a semi-colon.

Spreadsheet column  |  Column title  |  Details  
---|---|---  
A  |  ASIN list  |  Enter up to 200 parent ASINs or 8,000 child ASINs that you
want to run a coupon on. The ASIN list should be semi-colon separated. If you
add a parent ASIN, all child ASINs will be automatically added to the coupon.  
B  |  Discount type (  USD  off or **Percentage Off** )  |  Choose either
**Money Off** or **Percentage Off** .  
C  |  Coupon discount **Percentage Off** value  |

Fill this section only if you selected **Percentage Off** in column B. Leave
blank if you selected  USD  off.

Enter the discount percentage that you want to offer on the coupon. The
discount percentage should be between  5% - 80%  .  
  
D  |  Coupon discount "  USD  Off" value  |

Fill this section if you selected  USD  Off in column B. Leave blank if you
selected **Percentage Off** .

Enter the discount percentage that you want to offer on the coupon. The
discount value must be greater than zero.  
  
E  |  Coupon title  |  Amazon automatically generates the beginning of your
coupon title with the discount that you selected, for example, "Save 10% on").
Input the rest of the title that will be displayed to customers. Using the
brand and product name is recommended. The limit is 80 characters. Note that
entering offensive words, discount amounts or percentages, referring to
events, such as Prime Day or Black Friday, or using languages that are not
supported in the given store in coupon titles are prohibited and can result in
your coupon being deactivated.  
F  |  Coupon budget  |  Enter the budget amount that you want to add to the
coupon. Minimum is  USD 100  . Note that coupon budgets are not hard limits.
For more information, go to [ Why is my spending higher than my budget?
](/gp/help/external/GRTVWTKPM8NLQQT2) .  
G  |  Coupon start date  |  Choose a start date within the next 60 days. Use
the  MM/DD/YYYY  date format. Your coupon will start at midnight on the start
date. Note that coupons may take up to 4-6 hours to show on website after they
go live.  
H  |  Coupon end date  |  Choose an end date within 3 months from the coupon
start date. Use  MM/DD/YYYY  date format. Coupons end at 11:59 p.m. on the end
date.  
I  |  Limit redemption to one per customer  |  Select **Yes** to limit the
redemption of your coupon to one per customer. Select **No** to allow your
coupon to be redeemed multiple times per customer.  
J  |  Targeted segment  |  Specify the customer segment that your coupon
should be visible to. For example, if you choose **All customers** , your
coupon will be seen by all customers. If you choose **Amazon Prime** , your
coupon will only be visible to Amazon Prime customers.  
  5. Save your file as XLS. 
  6. Click **Choose file** , select the XLS file you saved in the previous step, and then click **Upload** . 
  7. Our system will start processing your spreadsheet. Refer to **Recent uploads** to review the status of your coupon spreadsheet. The status could be one of the following: 
    * **Processing** : The spreadsheet is going through basic validations. Status will change to **Success** or **Error** . 
    * **Success** : The spreadsheet was processed successfully, and coupons were created. Note that this does not mean that your coupon will run. After a spreadsheet has been processed successfully, our systems will run a number of validations on the coupon. Monitor the status of the coupon on the **Coupons** dashboard. 
    * **Error** : There were errors in creating coupons. Download the status file to review the errors and take the required actions to correct them.  For more information, go to [ Fix spreadsheet errors in coupon uploads ](/gp/help/external/GXRK7QW9Y7WZJ4MM) . 

**Note:** The earliest a coupon can go live is six hours after creation.
Coupons created with a same-day start date require at least six hours for our
systems to run a number of validation rules on them to ensure they offer a
good value to our customers.

Top

