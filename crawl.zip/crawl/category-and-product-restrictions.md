# Category and Product Restrictions

Source: https://sellercentral.amazon.com/gp/help/external/G200301050

This article applies to selling in: **United States**

#  Category, product, and listing restrictions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200301050)

On this page

Product compliance requirements

Safety and labeling requirements

Content and listing requirements

**Important:** When you sell on Amazon, you must follow federal, state, and
local laws, and Amazon policies that apply to your products and listings.

To maintain a safe and trustworthy shopping experience, certain products
cannot be listed or sold on Amazon or may be subject to additional
requirements because they have legal or regulatory restrictions (for example,
illegal drugs) or violate other Amazon policies (for example, crime scene
photos). Please review these pages in detail to understand what policies or
approval requirements may apply to your products before listing them for sale.

##  Product compliance requirements

  * [ Restricted products ](/gp/help/external/200164330)
  * [ Restricted Products FAQ ](/gp/help/external/CYAVS22E6CQKV2B)
  * [ Additional Information and Resources for Sellers about our Restricted Products Policy ](/gp/help/external/201567350)
  * [ Categories and products requiring approval ](/gp/help/external/G200333160)
  * [ Trade Control Laws ](/gp/help/external/201575280)
  * [ Amazon Debarred Seller Policy ](/gp/help/external/KVVXRYWTEMD6UWV)
  * [ Expiration dates on seller-fulfilled products ](/gp/help/external/GD646NUBNNJLQADP)

##  Safety and labeling requirements

  * [ Product compliance ](/gp/help/external/XMGGPL6LC4CVXHT)
  * [ CPSIA Choking Hazard Warnings and Material Content Limits ](/gp/200292910)
  * [ Energy Labeling Rule ](/gp/201814570)
  * [ Food Safety and Compliance ](/gp/help/external/UCMGZBFXQ97P2SU)
  * [ Food products: USDA Country of Origin Labeling ](/gp/help/external/202064660)
  * [ NIOSH-Approved Filtering Facepiece Respirators ](/gp/help/external/93NM4S8RDEDNPAA)
  * [ Marking and labeling requirements for children's products ](/gp/help/external/GN9YK5Y7TYGRGNRG)

##  Content and listing requirements

  * [ Adult products policies & guidelines ](/gp/200339940)
  * [ Condition guidelines ](/gp/200339950)
  * [ Listing restrictions ](/gp/help/external/200832300)
  * [ Product Bundling Policy ](/gp/help/external/200442350)
  * [ Prohibited Product Claims ](/gp/help/external/202024200)
  * [ Selling Ink or Toner Cartridges ](/gp/help/external/200511820)
  * [ Selling International Media Products ](/gp/help/external/201215040)
  * [ Sell software ](/gp/help/external/200386270)
  * [ Selling Textbooks ](/gp/help/external/200386280)

Top

##  Category, product, and listing restrictions

* [ Product safety and compliance  ](/help/hub/reference/external/GUH6FA4XSJ2LZFLY)
* [ Additional information and resources for selling partners about our Restricted Products policy  ](/help/hub/reference/external/G201567350)
* [ Listing restrictions  ](/help/hub/reference/external/G200832300)
* [ Trade control laws  ](/help/hub/reference/external/G201575280)
* [ Prohibited product claims  ](/help/hub/reference/external/G202024200)
* [ Product compliance  ](/help/hub/reference/external/GXMGGPL6LC4CVXHT)
* [ Restricted products  ](/help/hub/reference/external/G200164330)
* [ Selling restrictions on safety risk products  ](/help/hub/reference/external/GKKYJ3C25DG334PW)
* [ Amazon Debarred Seller Policy  ](/help/hub/reference/external/GKVVXRYWTEMD6UWV)
* [ Food Safety and Compliance  ](/help/hub/reference/external/GUCMGZBFXQ97P2SU)
* [ Marking and labeling requirements for children’s products  ](/help/hub/reference/external/GN9YK5Y7TYGRGNRG)

