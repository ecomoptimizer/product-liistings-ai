# How the Other Sellers on Amazon box works

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> The Other Sellers on Amazon box on a product detail page displays listings from eligible sellers who have consistently provided customers with a great buying experience on Amazon. Up to three listings from eligible sellers are selected based on, among other things, price, availability, and the customer's shipping address. The Other Sellers on Amazon box also provides a link to the All Offers page. All listings that match the product appear on the All Offers page.

---
The **Other Sellers on Amazon** box on a product detail page displays listings from eligible sellers who have consistently provided customers with a great buying experience on Amazon. Up to three listings from eligible sellers are selected based on, among other things, price, availability, and the customer's shipping address. The **Other Sellers on Amazon** box also provides a link to the All Offers page. All listings that match the product appear on the **All Offers** page.

A key feature seen on Amazon is that the same product can be sold by multiple sellers. If several sellers offer the same product in New condition, they may compete for the **Featured Offer** and the **Other Sellers on Amazon** box for that product.

Sellers must be [Featured Offer eligible](https://sellercentral.amazon.com/gp/help/200418100) to have their listings qualify for the **Other Sellers on Amazon** box.

Since seller performance metric targets can vary by category and are subject to change, we do not disclose specific targets needed to qualify for Featured Offer eligibility. Qualification requires meeting very high standards, and excelling in the qualifying criteria is the best way to work toward being featured in the **Other Sellers on Amazon** box.

**Note:** Seller offers for Books, Music, Video and DVD products (BMVD Products) will not appear in the **Other Sellers on Amazon** box on the product detail page.

Top

Was this article helpful?
