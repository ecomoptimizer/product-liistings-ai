# FBA New Selection program

Source: https://sellercentral.amazon.com/gp/help/external/GWHQRT98SAZC29VQ

This article applies to selling in: **United States**

#  FBA New Selection

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGWHQRT98SAZC29VQ)

On this page

Program details

Seller eligibility

ASIN eligibility

Frequently asked questions

Program terms and conditions

By participating in FBA New Selection, you can qualify for free monthly
storage, free liquidations of unproductive inventory, a rebate on branded new
selection, and free return processing for all eligible parent ASINs that are
new to FBA for a limited time.

If you are an existing FBA seller, to participate, you must enroll in the
program.  After you enroll, we will determine whether you qualify for the fee
waivers based on the eligibility criteria below.

If you’re a new seller, you’ll be enrolled in the program automatically if you
create your first shipment within 90 days of listing your first buyable ASIN.
For more information, go to [ New Seller Incentives
](/gp/help/external/GXMJ38VA95GUN5XU) .

By participating in New Selection, you agree to the terms and conditions
below.

**Important:** [ Enroll now
](/fba/programs/subscribeMerchant/default?programId=FBA_NEW_SELECTION)

After enrollment, you'll have access to the [ FBA New Selection dashboard
](/fulfillment-by-amazon/new-selection/dashboard) , which shows your
engagement with the program

##  Program details

  * **10% rebate on average for sales for brand-registered sellers** : Brand owners who complete [ Brand Registry ](https://brandservices.amazon.com?ref_=sc_starterpack_bs_br) receive a monthly average rebate of 10% for sales of eligible parent ASINs that are new to FBA. We calculate the rebate based on the product category, and account for the referral fees that are charged, to provide you with a rebate between 0% and 12%. The rebate is applied to your fulfillment fees the following month that it’s earned. For eligible parent ASINs that are new to FBA, the rebate applies to up to 30 units for eligible oversize items for 90 days, and up to 100 units for eligible standard-size items for 120 days. 
  * **Limited to new-to-FBA parent ASINs:** After you enroll in the program, you can use the fee waiver benefits for an unlimited number of new-to-FBA [ parent ASINs ](/gp/help/external/8831) that you create. 
  * **Free monthly storage and free liquidations for standard-size ASINs:** No monthly storage fees will be charged for the first 100 units of each new parent ASIN for 120 days after the first unit is received at a fulfillment center. You can liquidate any of those first 100 units within 180 days after the first inventory-received date with no liquidation fees. 
  * **Free monthly storage and free liquidations for oversize ASINs:** No monthly storage fees will be charged for the first 30 units of each new parent ASIN for 90 days after the first unit is received at a fulfillment center. You can liquidate any of those first 30 units within 180 days after the first inventory-received date with no liquidation fees. 
  * **Additional benefits for apparel and shoes:** We'll waive return processing fees for up to 20 units of each standard-size parent ASIN. Returned items must be received at a fulfillment center within 180 days of the first inventory-received date. 
  * **Global enrollment:** You only need to enroll once and New Selection benefits will be applied in each Amazon store automatically where you have an active account, determined based on your MCID and email, and have sent eligible new selection to fulfillment centers. 

These benefits apply to parent ASINs that are sent to fulfillment centers on
or after March 1, 2023.

##  Seller eligibility

Professional sellers are eligible to enroll in the FBA New Selection program.
If you've been assigned an [ Inventory Performance Index
](/gp/help/external/G202174810) (IPI) score, you must have a score of 400 or
higher to qualify for the program. If you have yet to be assigned an IPI
score, you can also enroll in the program and receive the program's benefits.

To get the benefits, you must maintain eligibility after enrollment. Your
eligibility status will be updated daily, based on your IPI score.

You'll remain eligible until the next yearly assessment on April 1, even if
your IPI score changes before that date. If your IPI score is below 400 on the
next assessment date, you will be removed from the program.

If you have enrolled but aren't eligible for the program benefits because your
IPI score is below 400, you'll become eligible if your IPI score is 400 or
higher on the next daily IPI assessment date, even if it comes before the
yearly eligibility assessment on April 1.

You must be eligible for the program on the date that your first new-to-FBA
ASIN is received at a fulfillment center in order for that ASIN to qualify for
the program’s free monthly storage, free liquidations, free return processing
benefits, and rebate for branded product sales

To be eligible to receive the sales rebate, you must complete Brand Registry
and be identified as a brand owner on the [ Brand Benefit Eligibility
](/brands/brand-relationships) page.  The rebate will be applied only to
branded new selection where you are the brand owner.  While this bonus may not
stack with other bonuses offered by Amazon, including the New Seller
Incentives bonus, we will always award you the more favorable bonus to you.
You can learn more by going to [ New Seller Incentives
](/gp/help/external/GXMJ38VA95GUN5XU) .

##  ASIN eligibility

[ Standard-size and oversize ](/gp/help/external/G201105770) (including small,
medium and large oversize, but not special oversize) items are eligible for
the program.

[ Parent ASINs ](/gp/help/external/8831) must be new to FBA.

ASINs in Media categories and used items are not eligible.  Media categories
are Books, DVDs, Music, Software & Computer/Video Games, Video, Video Game
Consoles, and Video Game Accessories.

Only apparel and shoes ASINs are eligible for free return processing.

**Tip:** To see if your ASIN is new to FBA across Amazon's stores, go to [ FBA
New Selection ](/gc/fulfillment-by-amazon/new-selection) or use our [ product
search tool ](/gc/fulfillment-by-amazon/new-to-fbaproductsearch) .

For more details, see the program terms and conditions section below.

##  Frequently asked questions

####  How is my rebate calculated?

Brand owners can earn a 10% rebate on average from their qualifying sales.  To
estimate your rebate, multiply your qualifying sales by the minimum rebate
rate in the corresponding product category.

The rebate benefit is calculated based on the referral fees for each product
category. To determine the rebate, we calculate the referral fee percentage
per category that applies to each sale minus 5%. This results in a referral
fee of 5% for most product categories.

Based on this calculation, a rebate between 0% and 12% is applied to your
fulfillment fees the following month that it’s earned. The maximum rebate that
you can earn is 12%.

The rebate amount will be applied as a credit to your fulfillment fees on next
month’s fulfillment fees at the order level. When payments cover the entire
fulfillment fee on a given order, the rebate will be applied in the
background, and the fulfillment fee section will not be shown as a separate
line item in the transaction.

Your actual rebate rate may vary based on factors such as additional shipping
and gift-wrapping fees, which can vary between sellers.

####  Where can I track my benefits for the program?

After enrollment, you'll have access to the [ FBA New Selection dashboard
](/fulfillment-by-amazon/new-selection/dashboard) . The dashboard shows your
engagement with the program, including the benefits that you receive and the
ASINs that qualify.

####  How do liquidations work?

We send your inventory to wholesale liquidators, allowing you to recover
typically 5% to 10% of an item’s average selling price. New Selection offers
an alternative to having your inventory disposed of or returned to you.

Free liquidations will be available for the following:

  * Standard-size ASINs: For first 100 units of each new parent ASINs within 180 days after the first inventory received date 
  * Oversize ASINs: For first 30 units of each new parent ASINs within 180 days after the first inventory received date 

While this benefit is the only free, value-recovery option available through
this program in the US, you can still remove inventory through other removal
channels, if preferred.

For eligible parent ASINs that fail to sell a single unit in the first 180
days, we’ll automatically liquidate this inventory for free.

For more information, or to opt out of automatic liquidation, go to [ FBA
Liquidations ](/gp/help/external/GYVCG5Q3BEJ6MLMF) .

####  Am I limited to sending 100 or fewer units to fulfillment centers?

No, you can send in as many units as you like. However, only the first 100
units of each eligible standard-size ASIN, and the first 30 units of each
eligible oversize ASIN that are received at fulfillment centers will qualify
for the fee waivers.

####  What is Brand Registry, and how can I enroll?

Enrolling in Amazon Brand Registry unlocks a suite of tools designed to help
you build and protect your brand, creating a better experience for customers.
Go to [ Brand Registry ](https://brandservices.amazon.com/eligibility) to
learn more about their eligibility requirements and application process.

####  Can I receive both the New Selection rebate and the New Seller
Incentives bonus?

For new brand owners, the New Seller Incentives bonus will apply first. You
can receive the New Seller Incentives bonus for one year after eligibility is
determined, or for your first  $1 million  in branded sales, whichever comes
first. Afterwards, you will qualify for the New Selection rebate.

##  Program terms and conditions

The following terms and conditions govern your participation in the FBA New
Selection Program.

  1. The Program started on April 1, 2020.    

  2. Only Professional sellers are eligible for the Program. Your participation in the Program is subject to Amazon’s approval. 

  3. To be an eligible seller for the FBA New Selection program, Professional sellers who have been assigned an IPI score must have a score of 400 or higher. Eligible new Professional sellers who will get auto-enrolled in the program, or sellers yet to be assigned an IPI score, are also eligible to enroll in the program and receive benefits.  To get the benefits, existing sellers must enroll in the program and both new and existing sellers must maintain eligibility status. 

  4. To be eligible to receive the sales rebate you must complete Brand Registry and be identified as a Brand Owner.  The rebate will be applied to the sales of items where you are listed as the Brand Owner on the [ Brand Benefit Eligibility ](/brands/brand-relationships) page.  The rebate will be paid the following month it is earned.  This rebate may not stack with other bonuses offered by Amazon, including the New Seller Incentives bonus, we will always award you the more favorable bonus to you. 

  5. The rebate on eligible branded new-to-FBA parent ASINs is calculated based on the final sales price of the product. If the product price is reduced by the application of a discount, the rebate will be calculated based on the product price after the discount. 

  6. "Eligible ASIN" means one of the ASINs you create for FBA after you are enrolled in the Program that is:    
  

    1. New to FBA;    

    2. A parent ASIN not previously enrolled in FBA; 
    3. Not a Media or used item;    

    4. Standard-size or oversize (including small, medium, and large oversize, but not special oversize); and    

    5. Received at an Amazon fulfillment center after March 1, 2023.    

  7. To be eligible for free return processing, an ASIN must be in the Apparel (Clothing & Accessories) or Shoes category and meet the Eligible ASIN criteria specified above. 

  8. Eligible ASINs exclude:    

    1. [ New child ASINs ](/gp/help/external/G8831) created under a parent ASIN that already exists on FBA; 
    2. New ASINs created by " [ bundle (Product bundle) ](/gp/help/external/G8831) " the same or different existing FBA ASINs; and    

    3. Media and used items.    

  9. Seller must be enrolled in the program before an ASIN’s first inventory-received date at an Amazon fulfillment center for the ASIN to qualify for monthly storage, liquidations, and return processing fee waivers.    

  10. For each Eligible standard-size ASIN, FBA will waive monthly storage fees for the first 100 units received at Amazon fulfillment centers, for up to 120 days after the first inventory-received date. Sellers can liquidate of any of those first 100 units within 180 days after the first inventory-received date, with no FBA liquidation fees.    

  11. For each Eligible oversize ASIN, FBA will waive monthly storage fees for the first 30 units received at Amazon fulfillment centers, for up to 90 days after the first inventory-received date.  Sellers can liquidate any of those first 30 units within 180 days after the first inventory-received date, with no FBA liquidation fees. Sellers can remove of any of those first 30 units within 180 days after the first inventory-received date, with no FBA liquidations fees.    

  12. For each Eligible Apparel and Shoe ASIN, FBA will waive return processing fees for up to 20 units of each eligible parent ASIN. Returned items must be received at a fulfillment center within 180 days of the first inventory-received date. 

  13. A parent ASIN and variations of it (child ASINs) are considered one ASIN for determining the first 30 or 100 units of each eligible ASIN.    

  14. Amazon may change or cancel the Program at any time by giving you 30 days' prior written notice.    

Top

##  FBA New Selection

* [ FBA New Selection dashboard  ](/help/hub/reference/external/G5KCMZFVXE5DF3QE)

