# Payments FAQ

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69122

This article applies to selling in: **United States**

#  Payments FAQ

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69122)

On this page

Getting paid

Payments reports

Fees

##  Getting paid

Follow the links below to learn more about how and when we'll pay you the
proceeds of your sales.

  * [ When will I be paid? ](/gp/help/external/14911)
  * [ Why didn't I get paid? ](/gp/help/external/19301)
  * [ How Amazon transfers payments ](/gp/help/external/19321)

##  Payments reports

Follow the links below for additional information related to payments reports.

  * [ What is account level reserve? ](/gp/help/external/G200136810)
  * [ What is a deferred transaction? ](/gp/help/external/GLRNLZDAKHDBBVBY)
  * [ How do I read my Payments report? ](/gp/help/external/14921)
  * [ Why do I have a negative balance? ](/gp/help/external/16261)
  * [ Why are you charging my credit card for a negative balance? ](/gp/help/external/16331)
  * [ What are "Other" transactions in my Payments report? ](/gp/help/external/16091)

##  Fees

Follow the links below for additional information related to fees.

  * [ What is the referral fee for each product line? ](/gp/help/external/19281)
  * [ Selling on Amazon Fee Schedule ](/gp/help/external/200336920)
  * [ Why am I being charged a subscription fee? ](/gp/help/external/16251)
  * [ Why is my referral fee category different from my retail site category? ](/gp/help/external/UMAYEVLKPU8LMBN)

Top

##  Payments FAQ

* [ When will I be paid?  ](/help/hub/reference/external/G14911)
* [ Why didn't I get paid?  ](/help/hub/reference/external/G19301)
* [ How Amazon transfers payments  ](/help/hub/reference/external/G19321)
* [ How do I read my Payments report?  ](/help/hub/reference/external/G14921)
* [ Why do I have a negative balance?  ](/help/hub/reference/external/G16261)
* [ Available repayment options  ](/help/hub/reference/external/G16331)
* [ What is the referral fee for each product line?  ](/help/hub/reference/external/G19281)
* [ Why is my referral fee category different from my retail site category?  ](/help/hub/reference/external/GUMAYEVLKPU8LMBN)
* [ What is a deferred transaction?  ](/help/hub/reference/external/GLRNLZDAKHDBBVBY)

