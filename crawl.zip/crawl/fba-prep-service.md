# FBA Prep Service

Source: https://sellercentral.amazon.com/gp/help/external/201023020

This article applies to selling in: **United States**

#  FBA Prep Service

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201023020)

On this page

Minimum qualifications

If you sign up for FBA Prep Service

Enable FBA Prep Service

Choose who preps the products

Select who labels the products

FBA Prep Service fees

Use the FBA Prep Service to ensure that your products are properly packaged
and prepared for fulfillment. Correct [ packaging and prep
](/gp/help/external/200141500) helps to reduce delays in receiving time,
protect your products while in Amazon fulfillment centers, and create a better
customer experience.

**Important:** Planned prep or labeling, as part of the FBA Prep Service or
FBA Label Service, may delay full receipt of your shipment. However, unplanned
prep or prep that is not part of the FBA Prep or Label Service may further
delay complete receipt of your shipments by up to 48 hours.

If you use the FBA Prep Service, Amazon will prepare your eligible products
for a per-unit fee. After you enable the service, you can choose whether you
or Amazon will prep the products that you send to fulfillment centers. When
you build your shipping plan, we will provide an estimate of the prep fees
based on the expected services for the selected products.

**Note:** If your products are classified as fragile, glass, or sharp, they
must be packaged to withstand transit and be safely handled by our associates.

##  Minimum qualifications

  * Condition: Any (new, used, collectible, refurbished) 
  * Product type: Any (media and non-media) 
  * ASIN: Each unit must have a scannable barcode (ISBN, UPC, EAN, or JAN). The unit's barcode must not be punched out, marked over, covered, or otherwise obstructed. 
  * 

##  If you sign up for FBA Prep Service

  * For products that Amazon preps, you will be charged the applicable FBA Prep Service fees based on the services provided (see the table below). The prep services that we perform for your products are determined at Amazon’s sole discretion. 
  * There are separate fees for standard-size and oversize products. 
  * Your qualifying units may be divided into multiple shipments. 
  * If Amazon preps your products, the [ FBA Label Service ](/gp/help/external/200483750) may be included automatically for select products. You would then be charged the applicable per-item fee. 

##  Enable FBA Prep Service

To enable the FBA Prep Service, follow these steps when creating your shipping
plan:  

  1. Select a product that you want Amazon to prep. 
  2. Select **Amazon** in the **Who Preps?** field. 

##  Choose who preps the products

**Note:** If you use **Send to Amazon** for shipments, go to [ Create
shipments with Send to Amazon ](/gp/help/external/G6925SDD66GDLXJW) for prep
and labeling information.

If you use **Send/replenish inventory** for shipments, after you enable the
FBA Prep Service, you can choose whether Amazon or you will prep each eligible
product by following the steps below on the **Prepare products** tab.

You can also choose who preps your products by default on your FBA settings
page. Changing the default does not affect previously created shipments or any
prep preferences you have defined for specific items.

####  For products with prep guidance

For each eligible product listed on the **Prepare products** tab of
**Send/replenish inventory** , select one of the following in the **Who
preps?** field:

  * **Amazon** if you want Amazon to prep the product 
  * **Merchant** if you want to prep the product yourself 

**Amazon** will be the default selection for products with prep guidance.

####  For products without prep guidance

Products without prep guidance may still have packaging and prep requirements.
For these products, **Choose category** will appear in the **Prep guidance**
column on the **Prepare products** tab. If you want Amazon to prep these
products, follow these steps:

  

  1. Click **Choose category** from the **Prep guidance** column. 
  2. In the pop-up window, select the category that best fits your product from the **Prep category** drop-down list. Or select **No prep** if you believe that no prep is required.  1 
  3. Select **Amazon** in the **Who preps?** column. 

If you don’t follow these steps or if you select **Merchant** in the **Who
preps?** column, you are responsible for preparing these products.

1  For more information, download [ How to Prep Products ](https://m.media-
amazon.com/images/G/01/fba-help/QRG/FBA_Prep_Products_en-US.pdf) and go to [
Packaging and prep requirements ](/gp/help/external/200141500) .

##  Select who labels the products

After determining who will prep the products, you can choose on the **Label
product** tab whether Amazon or you will apply labels to each unit.

You can also choose who labels your products by default in your FBA settings.
Changing the default does not affect previously created shipments or any label
preferences you have defined for specific items.

For more information, go to [ FBA Label Service ](/gp/help/external/200483750)
.

##  FBA Prep Service fees

Per-unit fee  |  Standard-size  |  Oversize  
---|---|---  
Prep category*  |  Prep  |  Labeling  |  Total  |  Prep  |  Labeling  |  Total  
**Fragile/glass**

  * Bubble wrap 
  * Labeling 

|  $0.80  |  $0.55  |  **$1.35** |  $1.60  |  $0.55  |  **$2.15**  
**Liquids**

  * Bagging 
  * Labeling (optional) 

|  $0.70  |  $0.55**  |  **$0.70 to $1.25** |  $1.40  |  $0.55**  |  **$1.40
to $1.95**  
**Apparel, fabric, plush, and textiles**

  * Bagging 
  * Labeling (optional) 

|  $0.70  |  $0.55**  |  **$0.70 to $1.25** |  $1.40  |  $0.55**  |  **$1.40
to $1.95**  
**Baby products**

  * Bagging 
  * Labeling (optional) 

|  $0.70  |  $0.55**  |  **$0.70 to $1.25** |  $1.40  |  $0.55**  |  **$1.40
to $1.95**  
**Sharp**

  * Bubble wrap 
  * Labeling 

|  $0.80  |  $0.55  |  **$1.35** |  $1.60  |  $0.55  |  **$2.15**  
**Small**

  * Bagging 
  * Labeling 

|  $0.70  |  $0.55  |  **$1.25** |  n/a  |  n/a  |  **n/a**  
**Adult**

  * Bagging (black or opaque) 
  * Labeling 

|  $1.00  |  $0.55  |  **$1.55** |  $2.00  |  $0.55  |  **$2.55**  
****Powders, pellets, and granular** **

  * Bagging 
  * Labeling (optional) 

|  $0.70  |  $0.55**  |  **$0.70 to $1.25** |  $1.40  |  $0.55**  |  **$1.40
to $1.95**  
**Perforated packaging**

  * Bagging 
  * Labeling (optional) 

|  $0.70  |  $0.55**  |  **$0.70 to $1.25** |  $1.40  |  $0.55**  |  **$1.40
to $1.95**  
  
**Sold as set**

  * Bagging 
  * Labeling 

|  $0.70  |  $0.55  |  **$1.25** |  $1.40  |  $0.55  |  **$1.95**  
  
*Amazon will eventually charge for these additional prep services: boxing, hanger removal, set creation, suffocation stickering, and set stickering. 

**The FBA Label Service is optional. All products must have a scannable label
that is visible after prep is complete. Amazon may verify the weight and
dimensions of a product by using representative samples. Our information about
a product’s weight and dimensions will be used to calculate fees if this
information differs from your information.

We may change our information about a product’s weight and dimensions from
time to time to reflect updated measurements. Fees based on the weight and
dimensions of a product are calculated using our information about the weight
and dimensions of that product when the fee is calculated.

Top

