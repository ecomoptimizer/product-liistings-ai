# Error code explanations

Source: https://sellercentral.amazon.com/help/hub/reference/G17781

Errors result when you submit a product that does not meet the [requirements for a properly formatted entry](https://sellercentral.amazon.com/gp/help/G200390640). For example, if you submit a product with a description that exceeds 1000 characters, this will result in an error in the [processing report](https://sellercentral.amazon.com/gp/help/G200194300), and your product will not be included in the catalog. These error messages are safeguards that prevent incorrect information in your product from being displayed on the website.

---
We encourage you to review the [processing report](https://sellercentral.amazon.com/gp/help/201576740) after each upload. If you are submitting an inventory file, this report shows up at the bottom of the [Add Products via Upload](https://sellercentral.amazon.com/gp/item-manager/ezdpc/uploadInventory.html/) page.

To see error messages, their definitions and suggested solutions, select an error from the list on the left side of the navigation.

Top

Was this article helpful?