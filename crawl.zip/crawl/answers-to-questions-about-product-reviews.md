# Answers to Questions about Product Reviews

Source: https://sellercentral.amazon.com/gp/help/external/201972160

This article applies to selling in: **United States**

#  Answers to Questions about Product Reviews

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201972160)

####  How can I encourage buyers to review a product?

Amazon automatically sends emails asking buyers to leave reviews. You do not
have to do anything in this regard. Go to [ Early Reviewer Program
](https://www.amazon.com/gp/help/customer/display.html/ref=hp_left_v4_sib?ie=UTF8&nodeId=202094910)
to learn more.

If you decide to ask a buyer to leave a review, you may not ask for a positive
review or ask for reviews only from buyers who had a positive experience, nor
may you ask customers to change or remove their review, or attempt to
influence the review. For example, you may not offer any compensation for a
review, including money or gift cards, free or discounted products, refunds or
reimbursements, or any other future benefits.

####  Can I offer a voucher or a free gift?

We do not permit reviews or votes on the helpfulness of reviews that are
posted in exchange for compensation of any kind, including any of the
following:

  * Payment (including money or gift cards) 
  * Refund or reimbursement, including through non-Amazon payment methods 
  * Free product 
  * Entry to a prize drawing or competition 
  * Discounts on future purchases 
  * Other gifts 

####  Can I use a good review for my product description?

No. The reviewer owns the copyright of the review.

####  Can I write a product review about products I sell?

No. You may not write reviews about products you or your competitors sell. You
should also ensure that your family members and employees comply with this
requirement.

####  Can a buyer review a product not purchased on Amazon or from me?

Yes, provided that the buyer meets the eligibility criteria in our [ Community
Guidelines
](https://www.amazon.com/gp/help/customer/display.html?nodeId=201929730&language=en_US&ref=ag_home_cont_G201972160)
. They can review any product on Amazon, regardless of where they purchased
that product.

####  Why are there reviews on a product that has not been released yet?

We only allow buyers to submit reviews for products that have already been
released for sale. We make an exception for the following product releases:

  * DVDs and Blu-ray movies. Reviews can be submitted before movies are released based on their run in theaters. Music and video games cannot be reviewed before they are released. 
  * Books. Reviews can be submitted before the release if the book is already available in a different version. For example, a pre-release of a paperback can be reviewed if a hardbound book is already released. 
  * Vine pre-release copies. Vine reviewers may review products before they are released. Learn more [ About Amazon Vine ](/gp/help/external/G92T8UV339NZ98TN) . 

**Note:** If you see reviews appear on a product before it is released and
none of the above apply, use the **Report abuse** link next to the review to
report it.

####  Can you link reviews across Amazon's international stores?

Amazon shares reviews written by verified purchasers of the same product in
other countries. Reviews for certain products are shown in the section “Top
reviews from other countries” below the local reviews section on the detail
page. To benefit from this feature, your brand must be enrolled in Brand
Registry and your products must have the same brand across all stores.

For information on how to enroll in Brand Registry, click [ here
](https://brandservices.amazon.com/) .

####  Can you link reviews across a variation?

Yes. Amazon shares Product Reviews across Parent and Child ASINs in a
Variation to make it easier for customers to make informed purchasing
decisions. We only share reviews when products are materially same and listed
in the same category. Reviews of each product should be relevant and
applicable to the entire set.

For more information about variation relationships, go to [ variation
relationships FAQ ](/gp/help/external/G201951410) .

####  What is the difference between a customer review and seller feedback?

Customer reviews are about the product, and seller feedback is about the
seller and the purchase experience. Customer reviews do not affect your seller
performance metrics, but seller feedback can have an impact on your seller
performance metrics.

####  What should I do if the seller feedback I received is about the product?

If you receive feedback that is about the product and not your service or the
shopping experience, Request Remove Feedback from [ Feedback Manager
](/feedback-manager/index.html) .

####  Do I get a notification when my product gets a new review?

No. Amazon does not notify sellers when new reviews are posted for the
products they sell.

####  Will Amazon delete reviews after a certain time?

No. As long as a product is listed on Amazon, its reviews will continue to
appear. We do, however, remove reviews that violate our guidelines. Buyers can
also remove their own reviews.

####  Will reviews be deleted when an upgraded product comes out, such as a
new model, fixed issues, or software upgrades?

No. Any information a buyer provides could be helpful to other buyers.

####  Why do some reviews disappear?

Reviews are removed from the Amazon website for these reasons only:

  * The review conflicted with our [ Community Guidelines ](https://www.amazon.com/gp/help/customer/display.html?nodeId=201929730&language=en_US&ref=ag_home_cont_G201972160) . 
  * The review was removed by the reviewer. 
  * We discovered that multiple products were incorrectly listed as the same product. Reviews that were posted for those products are separated when the products are separated. 
  * We detected unusual review behavior and are not accepting or displaying reviews for this item at this time, or we are only accepting or displaying Amazon Verified Purchase reviews. 

####  What action can I take against an unjustified negative review, which may
even be a fake review?

If you see reviews that you think violate our [ Community Guidelines
](https://www.amazon.com/gp/help/customer/display.html?nodeId=201929730&language=en_US&ref=ag_home_cont_G201972160)
, use the **Report abuse** link next to the review to report it. Go to [
Customer product reviews ](/gp/help/external/G201972140) for more information.

####  Can you remove a review that compares my product with a competitor's
product and makes my product look bad?

No. We encourage our buyers to give their honest opinions on our products. As
long as the review is within our guidelines, we will not remove it. For more
information, go to [ Can Amazon remove buyer feedback
](/gp/help/external/G20231) help page.

####  Can I block buyers that leave bad reviews on my products?

No. You cannot block a buyer from writing reviews on your products. If you
think a review violates our guidelines, use the **Report abuse** link next to
the review to report it. Go to [ Customer product reviews
](/gp/help/external/G201972140) for more information.

####  Can you edit a review for me?

No. We check reviews for violations of our guidelines, but we do not edit
reviews.

####  Do buyers have to change or remove a bad review after an issue with a
product is resolved?

No. That is entirely up to the buyer to decide. You are not allowed to ask
buyers to change or remove reviews. For additional information, Go to [ this
](/gp/help/external/G202125690) topic.

####  Can you give me the email address of reviewers so I can contact them
directly ?

No. Amazon never shares private buyer information.

Top

