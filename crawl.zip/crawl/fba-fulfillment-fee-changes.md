# FBA fulfillment fee changes

Source: https://sellercentral.amazon.com/gp/help/external/GABBX6GZPA8MSZGW

This article applies to selling in: **United States**

#  2023 US FBA fulfillment fee changes

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGABBX6GZPA8MSZGW)

On this page

FBA fulfillment fee changes (excluding apparel)

FBA fulfillment fees changes for apparel

Product size examples

Fulfillment fee changes for dangerous goods

Calculate the shipping weight

Frequently asked questions

Glossary

This page details upcoming changes to Fulfillment by Amazon (FBA) fulfillment
fees.

**Note:** For an overview of all 2023 US selling fee changes, go to [ 2023 US
referral and FBA fee changes summary ](/gp/help/external/G201411300) .

##  FBA fulfillment fee changes (excluding apparel)

2023 US FBA fulfillment fees (excluding apparel) will take effect on January
17, 2023. The greater of unit weight or dimensional weight will be used to
calculate the shipping weight for all large standard-size and oversize units,
except for special oversize. For more information, go to the **Calculate the
shipping weight** section of this page.

2022 fulfillment fee  1  |

|  2023 fulfillment fee  2  
---|---|---  
Size tier  |  Shipping weight  |  Peak fulfillment fee per unit  |  Non-peak
fulfillment fee per unit  |

|  Size tier  |  Shipping weight  |  Fulfillment fee per unit  
**Small standard** |  6 oz or less  |  $3.28  |  $3.07  |  |  **Small
standard** |  4 oz or less  |  $3.22  
|  4+ to 8 oz  |  $3.40  
6+ to 12 oz  |  $3.43  |  $3.22  |  |  8+ to 12 oz  |  $3.58  
12+ to 16 oz  |  $3.98  |  $3.77  |  |  12+ to 16 oz  |  $3.77  
**Large standard** |  6 oz or less  |  $4.03  |  $3.72  |  |  **Large
standard** |  4 oz or less  |  $3.86  
|  4+ to 8 oz  |  $4.08  
6+ to 12 oz  |  $4.27  |  $3.96  |  |  8+ to 12 oz  |  $4.24  
12+ to 16 oz  |  $5.06  |  $4.75  |  |  12+ to 16 oz  |  $4.75  
1+ to 2 lb  |  $5.71  |  $5.40  |  |  1+ to 1.5 lb  |  $5.40  
|  1.5+ to 2 lb  |  $5.69  
2+ to 3 lb  |  $6.60  |  $6.08  |  |  2+ to 2.5 lb  |  $6.10  
|  2.5+ to 3 lb  |  $6.39  
3+ lb to 20 lb  |  $6.96 + $0.32/lb above first 3 lb  |  $6.44 + $0.32/lb
above first 3 lb  |  |  3+ lb to 20 lb  |  $7.17 + $0.16/half-lb above first 3
lb  
**Small oversize** |  70 lb or less  |  $10.44 + $0.40/lb above first lb  |
$9.39 + $0.40/lb above first lb  |  |  **Small oversize 3  ** |  70 lb or less
|  $9.73 + $0.42/lb above first lb  
**Medium oversize** |  150 lb or less  |  $15.99 + $0.46/lb above first lb  |
$13.37 + $0.46/lb above first lb  |  |  **Medium oversize 3  ** |  150 lb or
less  |  $19.05 + $0.42/lb above first lb  
**Large oversize** |  150 lb or less  |  $89.33 + $0.83/lb above first 90 lb
|  $86.71 + $0.83/lb above first 90 lb  |  |  **Large oversize 3  ** |  150 lb
or less  |  $89.98 + $0.83/lb above first 90 lb  
**Special oversize** |  Over 150 lb  |  $161.11 + $0.83/lb above first 90 lb
|  $158.49 + $0.83/lb above first 90 lb  |  |  **Special oversize 3  ** |
Over 150 lb  |  $158.49 + $0.83/lb above first 90 lb  
  
1  _ Peak fulfillment fee will apply from October 15, 2022, to January 14,
2023. Non-peak fulfillment fee will apply from January 15 to 16, 2023. Fees
include a 5% fuel and inflation surcharge.  _

2  _ Starting January 17, 2023, fees without a separate 5% fuel and inflation
surcharge will apply.  _

3  _ For detailed definitions of oversize size tiers, go to [ product size
tiers ](/gp/help/external/GG5KW835AHDJCH8W) .  _

##  FBA fulfillment fees changes for apparel

The 2023 US FBA fees for apparel items will take effect on January 17, 2023.
The greater of unit weight or dimensional weight will be used to calculate the
shipping weight for standard items more than 0.75 pounds and oversize, except
for special oversize. Starting on February 16, 2023, the greater of unit
weight or dimensional weight will be used to calculate the shipping weight for
all large standard-size and oversize units, except for special oversize. For
more information, go to the **Calculate the shipping weight** section of this
page.

2022 fulfillment fee  1  |

|  2023 fulfillment fee  2  
---|---|---  
Size tier  |  Shipping weight  |  Peak fulfillment fee per unit  |  Non-peak
fulfillment fee per unit  |

|  Size tier  |  Shipping weight  |  Fulfillment fee per unit  
**Small standard** |  6 oz or less  |  $3.64  |  $3.43  |  |  **Small
standard** |  4 oz or less  |  $3.43  
|  4+ to 8 oz  |  $3.58  
6+ to 12 oz  |  $3.81  |  $3.60  |  |  8+ to 12 oz  |  $3.87  
12+ to 16 oz  |  $4.36  |  $4.15  |  |  12+ to 16 oz  |  $4.15  
**Large standard** |  6 oz or less  |  $4.75  |  $4.43  |  |  **Large
standard** |  4 oz or less  |  $4.43  
|  4+ to 8 oz  |  $4.63  
6+ to 12 oz  |  $4.94  |  $4.62  |  |  8+ to 12 oz  |  $4.84  
12+ to 16 oz  |  $5.64  |  $5.32  |  |  12+ to 16 oz  |  $5.32  
1+ to 2 lb  |  $6.42  |  $6.10  |  |  1+ to 1.5 lb  |  $6.10  
|  1.5+ to 2 lb  |  $6.37  
2+ to 3 lb  |  $7.35  |  $6.83  |  |  2+ to 2.5 lb  |  $6.83  
|  2.5+ to 3 lb  |  $7.05  
3+ lb to 20 lb  |  $7.54 + $0.32/lb above first 3 lb  |  $7.01 + $0.32/lb
above first 3 lb  |  |  3+ lb to 20 lb  |  $7.17 + $0.16/half-lb above first 3
lb  
**Small oversize** |  70 lb or less  |  $10.44 + $0.40/lb above first lb  |
$9.39 + $0.40/lb above first lb  |  |  **Small oversize 3  ** |  70 lb or less
|  $9.73 + $0.42/lb above first lb  
**Medium oversize** |  150 lb or less  |  $15.99 + $0.46/lb above first lb  |
$13.37 + $0.46/lb above first lb  |  |  **Medium oversize 3  ** |  150 lb or
less  |  $19.05 + $0.42/lb above first lb  
**Large oversize** |  150 lb or less  |  $89.33 + $0.83/lb above first 90 lb
|  $86.71 + $0.83/lb above first 90 lb  |  |  **Large oversize 3  ** |  150 lb
or less  |  $89.98 + $0.83/lb above first 90 lb  
**Special oversize** |  Over 150 lb  |  $161.11 + $0.83/lb above first 90 lb
|  $158.49 + $0.83/lb above first 90 lb  |  |  **Special oversize 3  ** |
Over 150 lb  |  $158.49 + $0.83/lb above first 90 lb  
  
1  _ Peak fulfillment fee will apply from October 15, 2022, to January 14,
2023. Non-peak fulfillment fee will apply from January 15 to 16, 2023. Fees
include a 5% fuel and inflation surcharge.  _

2  _ Starting January 17, 2023, fees without a separate 5% fuel and inflation
surcharge will apply.  _

3  _ For detailed definitions of oversize size tiers, go to [ product size
tiers ](/gp/help/external/GG5KW835AHDJCH8W) .  _

##  Product size examples

The following product examples help illustrate the new 2023 US Fulfillment by
Amazon fees.

**Small standard-size**  
---  
|

**Mobile device case**

Dimensions: 13.8 x 9 x 0.7 inches

Unit weight: 2.88 oz

Shipping weight range: 4 oz or less  
  
2023 fulfillment fee per unit  |  $3.22  
  
**Small standard-size**  
---  
|

**Plates**

Dimensions: 13.9 x 11.1 x 0.7 inches

Unit weight: 12.80 oz

Shipping weight range: 12+ to 16 oz  
  
2023 fulfillment fee per unit  |  $3.77  
  
**Large standard-size**  
---  
|

**T-shirt**

Dimensions: 13 x 9 x 0.85 inches

Dimensional weight: 11.45 oz

Unit weight: 5.40 oz

Shipping weight range: 4+ to 8 oz

_(From January 17 to February 15, 2023)_

Shipping weight range: 8+ to 12 oz

_(Starting February 16, 2023)*_  
  
2023 fulfillment fee per unit

_(From January 17 to February 15, 2023)_

|  $4.63  
  
2023 fulfillment fee per unit

_(Starting February 16, 2023)_

|  $4.84  
  
|  _ * The greater of unit weight or dimensional weight will be applied.  _  
  
**Large standard-size**  
---  
|

**Iron**

Dimensions: 12.6 x 6.6 x 5.5 inches

Dimensional weight: 3.29 lb

Unit weight: 3.35 lb

Shipping weight range: 3+ to 3.5 lb  
  
2023 fulfillment fee per unit  |  $7.33 ($7.17 for first 3 lb plus $0.16 for
each additional 0.5 lb interval)  
  
**Small oversize**  
---  
|

**Baby cot**

Dimensions: 24 x 7.5 x 6 inches

Dimensional weight: 7.77 lb

Unit weight: 7.90 lb

Shipping weight range: 7+ to 8 lb  
  
2023 fulfillment fee per unit  |  $12.67 ($9.73 for first 1 lb plus $0.42 for
each additional 1 lb interval)  
  
**Large oversize**  
---  
|

**Monitor**

Dimensions: 54 x 35 x 3.5 inches

Dimensional weight: 47.59 lb

Unit weight: 41 lb

Shipping weight range: 47+ to 48 lb*  
  
2023 fulfillment fee per unit  |  $89.98 ($89.98 for first 90 lb)  
|  *  _ Based on a dimensional weight of 47.59 lb, which is greater than the
unit weight.  _  
  
##  Fulfillment fee changes for dangerous goods

The 2023 US Fulfillment by Amazon fees for dangerous goods will take effect on
January 17, 2023. FBA has separate fulfillment fees for dangerous goods (also
known as hazardous materials or hazmat) that require special handling and
storage. For more information, go to [ FBA Dangerous Goods program
](/gp/help/external/GZLZBQ7W6QZRKWWK) and [ Dangerous goods identification
guide ](/gp/help/external/G201003400) .

2022 Fulfillment Fee  1  |

|  2023 Fulfillment Fee  2  
---|---|---  
Size tier  |  Shipping weight  |  Peak Fulfillment fee per unit  |  Non-Peak
Fulfillment Fee per unit  |

|  Size tier  |  Shipping weight  |  Fulfillment fee per unit  
**Small standard** |  6 oz or less  |  $4.25  |  $4.04  |  |  **Small
standard** |  4 oz or less  |  $4.19  
|  4+ to 8 oz  |  $4.48  
6+ to 12 oz  |  $4.49  |  $4.28  |  |  8+ to 12 oz  |  $4.64  
12+ to 16 oz  |  $4.58  |  $4.37  |  |  12+ to 16 oz  |  $4.37  
**Large standard** |  6 oz or less  |  $4.82  |  $4.50  |  |  **Large
standard** |  4 oz or less  |  $4.64  
|  4+ to 8 oz  |  $4.89  
6+ to 12 oz  |  $5.06  |  $4.75  |  |  8+ to 12 oz  |  $5.03  
12+ to 16 oz  |  $5.66  |  $5.34  |  |  12+ to 16 oz  |  $5.34  
1+ to 2 lb  |  $6.31  |  $6.00  |  |  1+ to 1.5 lb  |  $6.00  
|  1.5+ to 2 lb  |  $6.29  
2+ to 3 lb  |  $7.07  |  $6.54  |  |  2+ to 2.5 lb  |  $6.56  
|  2.5+ to 3 lb  |  $6.85  
3+ lb to 20 lb  |  $7.42 + $0.32/lb above first 3 lb  |  $6.90 + $0.32/lb
above first 3 lb  |  |  3+ lb to 20 lb  |  $7.63 + $0.16/half-lb above first 3
lb  
**Small oversize** |  70 lb or less  |  $11.19 + $0.40/lb above first lb  |
$10.14 + $0.40/lb above first lb  |  |  **Small oversize 3  ** |  70 lb or
less  |  $10.48 + $0.42/lb above first lb  
**Medium oversize** |  150 lb or less  |  $16.86 + $0.46/lb above first lb  |
$14.24 + $0.46/lb above first lb  |  |  **Medium oversize 3  ** |  150 lb or
less  |  $19.92 + $0.42/lb above first lb  
**Large oversize** |  150 lb or less  |  $101.26 + $0.83/lb above first 90 lb
|

$98.64 + $0.83/lb above first 90 lb

|  |  **Large oversize 3  ** |  150 lb or less  |  $101.91 + $0.83/lb above
first 90 lb  
**Special oversize** |  Over 150 lb  |  $181.90 + $0.83/lb above first 90 lb
|  $179.28 + $0.83/lb above first 90 lb  |  |  **Special oversize 3  ** |
Over 150 lb  |  $179.28 + $0.83/lb above first 90 lb  
  
1  _ Peak fulfillment fee will apply from October 15, 2022, to January 14,
2023. Non-peak fulfillment fee will apply from January 15 to 16, 2023. Fees
include a 5% fuel and inflation surcharge.  _

2  _ Starting January 17, 2023, fees without a separate 5% fuel and inflation
surcharge will apply  _

3  _ For detailed definitions of oversize size tiers, go to [ product size
tiers ](/gp/help/external/GG5KW835AHDJCH8W) .  _

##  Calculate the shipping weight

For core FBA excluding apparel, apparel (starting on February 16, 2023), and
dangerous goods products, we use the greater of unit weight or dimensional
weight to calculate the shipping weight for all large standard-size units and
all small oversize, medium oversize, and large oversize units. Dimensional
weight is equal to the unit volume (length x width x height) divided by 139.
The dimensional weight for oversize items assumes a minimum width and height
of 2 inches. Small standard-size units and special oversize units will use
unit weight. This also applies to units fulfilled through [ Small and Light
](/gp/help/external/G201706140) .

Core FBA excluding apparel, apparel (starting on February 16, 2023), dangerous
goods, and Small and Light  
---  
Size tier  |  Shipping weight  
**Small standard size** |  **Unit weight**  
**Large standard size** |  The greater of the **unit weight** or **dimensional
weight**  
**Oversize** |  The greater of the **unit weight** or **dimensional weight**  
**Special oversize** |  **Unit weight**  
  
##  Frequently asked questions

####  When will the 2023 US FBA fulfillment fee changes take effect?

The 2023 FBA fulfillment fees for core FBA excluding apparel, apparel, and
dangerous goods will take effect on January 17, 2023.

####  Will 2023 US FBA fulfillment fee changes apply to products ordered
before January 17, 2023?

FBA fulfillment fees are calculated and charged when shipments leave
fulfillment centers. If a product is ordered before the date of a fee change,
but is shipped on or after that date, the new rates will apply.

####  How is dimensional weight calculated?

Dimensional weight is equal to the unit volume (length x width x height)
divided by 139. For oversize items, we assume a minimum width and height of 2
inches. Amazon will use dimensional weight when it is greater than unit weight
for all large standard-size units and oversize units (except special
oversize). Small standard-size units will use unit weight. This calculation
will apply to apparel items starting on February 16, 2023.

####  How do I determine what product size tier my product belongs to?

Use the [ size tiers table ](/gp/help/external/G201105770) to determine your
product's size tier.

####  I have questions not addressed here. How can I get help?

If you have more questions, contact [ Selling Partner Support ](/gp/contact-
us/contact-amazon-form.html?ref=xx_toolPage_xxxx_helphub) .

##  Glossary

####  Small standard size

Any packaged item that is 16 oz or less with its longest side 15 inches or
less, its shortest side 0.75 inch or less, and its median side 12 inches or
less.

####  Large standard size

Any packaged item that is 20 lb or less with its longest side 18 inches or
less, its shortest side 8 inches or less, and its median side 14 inches or
less.

####  Small oversize

Any packaged unit that is 70 lb or less with its longest side 60 inches or
less, its median side 30 inches or less, and its longest side plus girth 130
inches or less.

####  Medium oversize

Any packaged unit that is 150 lb or less with its longest side 108 inches or
less and its longest side plus girth 130 inches or less.

####  Large oversize

Any packaged unit that is 150 lb or less with its longest side 108 inches or
less and its longest side plus girth 165 inches or less.

####  Special oversize

Any packaged unit that exceeds one or more of the following: over 150 lb (unit
weight or dimensional weight), over 108 inches on its longest side, or over
165 inches when the longest side is added to the girth. In addition, products
that we determine require special handling or delivery will be designated as
special oversize.

####  Median side

The dimension of a product that is neither the longest nor the shortest side.

####  Girth

A unit measure equivalent to 2 x (median side + shortest side).

####  Unit weight

The physical weight of a packaged individual unit.

Top

