# Long-Term Storage Fee Charges report

Source: https://sellercentral.amazon.com/gp/help/external/200725880

This article applies to selling in: **United States**

#  Long-Term Storage Fee report

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200725880)

This report provides itemized details of your most recent long-term storage
fee charges to allow you to identify which of your products in Amazon
fulfillment centers were charged the long-term storage fee and review the
amounts charged.

This report includes product details, quantity, per-unit volume and the total
amount for each SKU to which the long-term storage fee was applied. See the [
Long-Term Storage Charges
](/gp/ssof/reports/search.html/?recordType=LONGTERM_STORAGE_FEE_CHARGES)
report.

The Long-Term Storage Fee is assessed based on the total volume in cubic feet
of units that have been stored in Amazon fulfillment centers for at least 365
days. Per SKU amounts are calculated as: (12-mo-long-term-storage-fee) =
(12-mo-qty-charged-long-term-storage-fee) x (per-unit-volume) x $6.90 (charge
applicable beginning with August 15, 2015, fee assessment).

To calculate total long-term storage fee charged across all inventory,
download the report and add up the charges in the **12-mo-long-term-storage-
fee** column.

##  Field names

Online Header  |  Download Header  |  Description  |  Example Value  
---|---|---|---  
Date  |  snapshot-date  |  Date the Long-Term Storage Fee was assessed.  |
2019-08-15  
Merchant SKU  |  sku  |  Stock Keeping Units (SKUs) are unique blocks of
letters or numbers that identify your products. SKUs are assigned by you as
the seller.  |  AB-8675309  
FNSKU  |  fnsku  |  Unique identifier assigned by Amazon to products stored in
and fulfilled from an Amazon fulfillment center.  |  X00000E5TX  
ASIN  |  asin  |  Amazon Standard Identification Numbers (ASINs) are unique
blocks of 10 letters or numbers that identify products. ASINs are assigned by
Amazon. You can find the ASIN on the product detail page.  |  B003ZYF3LO  
Title  |  product-name  |  The title of your product.  |  Toysmith Non-stick
Bakeware Set  
Condition  |  condition  |  The condition of your product.  |  New or Used  
12+ Month Charged Quantity  |  qty-charged-12-mo-long-term-storage-fee  |  The
number of sellable Units in fulfillment centers for 12 months or more for
which the Long-Term Storage Fee was assessed.  |  2  
Per-Unit Volume  (in cubic feet)  |  per-unit-volume  |  The volume in cubic
feet  of each inventory unit assessed the Long-Term Storage Fee .  |  1.5  
12+ Month Charged Amount  |  12-mo-long-term-storage-fee  |  The Long-Term
Storage Fee that was charged for units that have been in fulfillment centers
for  12 months or more  .  |  67.50  
Volume unit  |  volume-unit  |  Unit name of the volume value  |  CUBIC METERS  
Country  |  country  |  Country in which your products are stored  |  US  
Enrolled in Small and Light  |  enrolled-in-small-and-light  |  Whether or not
the item is enrolled in FBA Small and Light  |  N  
  
Top

