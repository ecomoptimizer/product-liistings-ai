# Amazon Handmade- List your products

Source: https://sellercentral.amazon.com/gp/help/external/G201817280

This article applies to selling in: **United States**

#  Amazon Handmade: List your products

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201817280)

On this page

List products manually

Product identity

Vital Info tab

Variations tab

Offer tab

Images tab

Description tab

Keywords tab

More Details tab

Customizations

Frequently asked questions

Additional resources to list your Handmade products

Once approved to sell on Amazon Handmade, you can list your products. If you
are new to Amazon, go to the **List products manually** section of this help
page or to learn more go to [ Amazon Handmade: Use inventory templates to
upload products ](/gp/help/external/GMU4YRNPVSDUGJZX) . Alternately, you can
use the [ Amazon Seller mobile app ](/sellermobileapp) to add new listings or
edit existing ones.

If you have products listed on Etsy and want to transfer them to Amazon
Handmade, go to [ Transfer product details from Etsy to Amazon Handmade
](/gp/help/external/GRDU4XCFF6GFRFE8) .

If you are already selling products on Amazon that meet the criteria for
Amazon Handmade, you can relist them in the Handmade store. Products can only
be listed in a single category, so you must delete the original listings and
relist them in Amazon Handmade.

When you relist items in Amazon Handmade, you can choose to use a new seller
SKU for your products, or delete your existing SKU from your inventory and
wait up to 24 hours to reuse that SKU. For instructions to delete existing
listings, go to [ Stop selling a product ](/gp/help/external/G200216110) .

If you must pause the sale of your items due to a family emergency or going on
a vacation, you can change your listing status to **Inactive** in your
**Vacation Settings** . This removes your self-fulfilled listings from Amazon
and the search results within an hour. For more information, go to [ Listing
status for vacations, holidays, and other absences
](/gp/help/external/G200135620) .

**Note:** We encourage you to set up your [ Maker Profile ](/handmade/profile-
edit/ref=xx_gldprf_dnav_home) page so customers can learn more about you, how
you make your products, and details about your listings in one place.

##  List products manually

To list products manually, follow these steps:  

  1. In Seller Central, select **Catalog** , and click **Add Products** . 
  2. From the list of Handmade products, select one that is closest to the product you are listing; clicking through the sub-categories to refine your selection. For listing quality purposes, it is good to select an actual sub-category, rather than any one of the “Other” options. 
  3. Create your listing by clicking each tab and provide all required information. You can also select the **All attributes** option in the left-hand navigation to reveal additional fields. This lets you provide additional details to customers on your detail page. 
  4. Click **Save and finish** to complete the listing process. You can edit the information for your listing at any time. 

**Note:** It can take up to 24 hours for your listing to appear. If you are
still unable to find your products after that, go to [ Common reasons you
cannot find your Handmade listings ](/gp/help/external/GRCWJ4KHBNQ3SNTB) .

##  Product identity

Following are the required fields on this tab:

  * Product Title 
  * Brand Name 

The **Brand Name** attribute is reserved for sellers whose brand name is
approved by Amazon Brand Registry. Sellers whose brand name isn't approved are
required to select **This product does not have a brand name** . This will
automatically populate the attribute as **Generic** .

##  Vital Info tab

Depending on the product type or category that you are listing in, there may
or may not be any required fields on this tab.

The Beauty & Grooming and Pet Supplies categories require filling the **Unit
Count** , **Unit Count Type** , and **Is Product Expirable?** fields.

**Unit Count** and **Unit Count Type** , along with **Your Price** (designated
in the **Offer** tab), work together to display a price per unit (PPU) on the
detail page. For example:

  * 4.5 lb of cat litter priced at $50, displays as $50 ($11.11/lb) 
  * 2 fluid oz of perfume priced at $200, displays as $200 ($100/fluid oz) 
  * 3-pack of combs priced at $6, displays as $6 ($2/count) 

  * 4.5 kg of cat litter priced at €50, displays as, €50 (€11.02/kg) 
  * 100 ml of perfume priced at €200, displays as, €200 (€2/ml) 
  * 3-pack of combs priced at €6, displays as, €6 (€2.00/count) 

For more details on the proper configuration of PPU, go to [ Price per unit
requirements ](/gp/help/external/G201618190) .

Click **Advanced View** to view additional fields associated with size, color,
and bullet points. For more information, go to [ Bullet Points
](/gp/help/external/GX5L8BF8GLMML6CX) .

**Note:** For sellers using A+ Content, when you add A+ content to your
listings, it replaces the product description on the Handmade detail pages.
This leaves the section below your product title blank and it displays further
down on the detail page. Therefore, we recommend you to add bullet point
content to all your listings.

##  Variations tab

Variations or variation families, also known as parent-child relationships,
are sets of products that are related to one another in terms of size, color,
or scent. For more information, go to [ Variation relationships overview
](/gp/help/external/G8831) .

**Note:** When you add existing ASINs to a variation family, you must edit any
information in the **Keywords** and **More Details** tabs of the parent ASIN.
This is because they will not carry over from the existing child ASINs when
you create your parent-child relationship. After successfully creating your
variation parent ASIN, make sure to confirm your child ASINs have retained
their information under **Keywords** and **More Details** .

For more information on creating a listing with variations, go to the
following videos in Seller University:

  * [ Create product variations one at a time ](/learn/courses?ref_=selleru_athena&courseId=a119406f-32ff-498c-8be0-5cc4d3d904af&moduleId=9287b780-d339-4f5c-ba86-b0952e64ef8d)

  *     * [ How to create product variations in bulk ](/learn/courses?ref_=su_course_accordion&moduleId=bdd0c374-edc8-4e1b-b216-464ceb14d2c8&courseId=d7325144-5a7d-4042-ba0b-ea3627f82351)

The [ Variation Wizard ](/listing/varwiz) is a tool used to create a new
variation family or update an existing one by combining existing stand-alone
listings within your catalog. Although we do not recommend using this tool
because the UI requires entering a UPC, which isn't a requirement for
Handmade. If you are comfortable with it, you can enter 13 zeros in this
field. For more information, go to [ Add a variation using Variation Wizard
](/gp/help/external/G202034620) .

####  When to use variations

For more information on variations, go to [ When to use parent-child
relationship in variations ](/gp/help/external/GADRGERG8NLZ3HLV) .

If you already have variation options set up as custom options such as size,
scent, or color, you are not required to convert them to a variation family,
but there are a few benefits to do so:

  * Each variation is assigned its own SKU and ASIN making it easier to fulfill orders. 
  * Customers can quickly see the different variants of a product on your product page. 
  * The reviews for your child ASINs will be consolidated under the parent ASIN which improves visibility to newer or less popular child ASINs. 
  * The specific variant will show in search results based on the search term used. For example, if you offer a gold and silver ring in a variation family, and a customer searches for “gold ring” your gold ring will show in the search results. 

####  Create a variation family

It is not necessary to create a new listing to create a variation family.
Using an existing ASIN preserves sales history and reviews, and helps with
your search relevancy.

From your inventory list, find the ASINs you would like to add to the new
variation family and note the SKUs. You will require this information later.  

  1. In Seller Central, select **Catalog** , click **Add Products** , and then select the category that best describes your chosen product. 
  2. In the **Product Identity** tab, find the **Variations** field and select **Yes** indicating that your product will have variations, and then choose the attributes of your variations from the options given. 
  3. In the **Vital Info** tab, enter any required information that may be requested. 
  4. In the **Variations** tab, identify all the available variation options for your products. Doing this will populate a matrix of all the available options. Fill out any requested information in the matrix. 
    * If you have existing ASINs that you want to add to your variation family or child ASINs, enter the SKUs you have already assigned to your ASINs. You can find the SKU on the _Manage Inventory_ page of Seller Central. 
    * If you want to create new child ASINs, enter new SKUs for each child ASIN or you can leave the SKU field blank, and the system will generate one automatically. 
  5. Click **Apply changes** . 
  6. Click through each tab and provide all required information. Selecting the **All attributes** option in the left-hand navigation allows you to provide additional details to customers on your detail page. 
  7. Click **Save and finish** . 

It can take several hours to complete the new family setup.

####  Convert an existing ASIN with customizations to a variation family

If you are currently using the customization feature to offer customers
different options for your product for example, size, color, scent, converting
the custom fields into a variation family can improve the customer shopping
experience and make it easier for you to fulfill orders. From your inventory
list, find the customizable ASINs you would like to add to the new variation
family and note the SKUs. You will require this information later.

To convert your ASIN with customizations to a variation family:  

  1. Follow the steps above to create a variation family in Seller Central.   

    1. In the Variations tab, enter the SKU for your existing ASIN with customizations for the first variation in the matrix. 
    2. Enter either a new SKU for each of the remaining child ASINs or leave the SKU field blank for them, and the system will generate one automatically. 
  2. Once created, find the SKU you want to remove the custom offering from on the **Manage Inventory** page, click **Edit** , and then click **Remove customization information** . 

It can take several hours complete the new family setup.

##  Offer tab

Following are the required fields on this tab:

  * Your Price 
  * Quantity 

When **All Attributes** is selected, you will find the option to designate
your **Fulfillment Channel** and other options to designate a SKU, shipping
template, identify the maximum number a single customer can buy, production
time, sale dates and prices, gift options, and a restocking date for
backorders.

**Note:** The default setting for fulfillment channel is **I will ship this
item myself** and this will be your selection when creating all new listings.
Once your listing is published, you can convert your listing to Fulfilled by
Amazon (FBA).

**Note:** The List Price field on the Offer tab is not required as handcrafted
items will not have one; however, if you want to [ Create a deal
](/gp/help/external/G202111550) to promote your listings, you must enter a
price in this field.

To learn more about setting accurate quantities and production times, go to [
Amazon Handmade: Best practices for fulfilling orders
](/gp/help/external/G201835090) .

##  Images tab

For more information, go to [ Amazon Handmade: Image requirements best
practices ](/gp/help/external/GNRP6DDJV79DUHRD) .

##  Description tab

Following are the required fields on this tab:

  * Product description 
  * Bullet points 

Due to their critical nature in search relevancy and the customer experience,
Amazon Handmade requires all listings have bullet points. We recommend 4-5
bullet points on all listings.

####  Good bullet point practices

  * Order your bullets by importance. 
  * Keep your bullet points clear and concise. Avoid over-stuffing your bullet points with keywords and other content. 
  * Bullet points should be quick facts about your product, such as materials, dimensions, appropriate age ranges, benefits, or even warnings. 
  * Don’t exceed 15 words or 500 characters for each bullet point or 1,000 characters total. 

####  What to avoid when creating bullet points

Avoid the following:

  * Pricing information, shipping details, or information about you or your company 
  * Marketing- or advertising-like content 
  * HTML or fancy code 
  * Run-on sentences 

Bullet points can be removed from your detail page when they violate any of
these standards, so be sure to review your detail pages frequently.

##  Keywords tab

There is one required field on this tab for all listings: Search terms. Other
fields may be required, depending on the category and sub-category of your
listing.

Identify the right set of search terms, the ones that customers would use to
search for your products, this will guide customers to your listings.

For more information on identifying keywords, go to [ Using Search Terms
effectively ](/gp/help/external/G23501) .

##  More Details tab

If you identify a product as expirable on the **Vital Info** tab, you will be
required to identify the **Product Expiry Type** and **Fulfillment Center
Shelf Life** fields in this tab.

We strongly recommend that you add as much detail as possible in this tab.
Customers will feel more confident when they know exactly what they are
purchasing, and it will also make your products easier to discover.

Here you have the opportunity to add details that will make it easier to find
your products. Following are some of the available fields:

  * **Shipping Weight** and the corresponding unit of measurement: Complete these fields if you choose weight-based delivery for your products. 
  * **How are your products made?** : Highlight the materials and process used in crafting your products. 
  * **Occasion** : You can select up to four occasion types for your product as a way to display your listing to customers who search by event type; for example, birthday, or wedding. 

##  Customizations

Customized product listings are similar to regular product listings, but offer
customers with an opportunity to configure or personalize their product, for
example, engraving a name on jewelry, or embroidering a monogram on a shirt,
or towel.

For detailed information on how to enable customizations on your listing, go
to [ Amazon Handmade: Customizable products ](/gp/help/external/G201817850) .

##  Frequently asked questions

####  Can I copy listings that are already created?

Once you have listed a product, you can copy that listing to create a new,
similar product in the same category. Doing so will transfer the product
information so that you can easily list more products. To copy a listing,
follow these steps:  

  1. In Seller Central, select **Inventory** , and then click [ Manage All Inventory ](/inventory/ref=xx_invmgr_dnav_xx) . 
  2. Scroll through your products or use the search box to find the listing you want to copy. 
  3. On the right side of the page, for the product you want to copy, select **Copy listing** from the dropdown menu. This opens the **Add a Product** tool, where most of the information from the original product, including customizations, is copied for you. 
  4. To complete your new listing, upload a main image under **Images** , and update the **Product Name** on the **Vital Info** page. 
  5. Click **Save and finish** . 

**Note:** Cloning a listing with customizations is not currently supported.
You can clone your listing, the customizations will not carry over and once
created, select **Edit** , and then **Add/Edit Customization Information** to
add your customizations.

####  Can I transfer information from other online channels I sell on?

Yes. You can transfer product details from Etsy onto Amazon using inventory
file template, go to [ Transfer product details from Etsy to Amazon Handmade
](/gp/help/external/GRDU4XCFF6GFRFE8) .

####  Is there a limit to the number of variations that can be created in a
variation family?

Variation families with more than 2,000 child ASINs will not be displayed on
the detail page.

####  I created a variation family, but child ASINs or reviews are not merged
onto one detail page. What must I do?

In most cases, variation families and reviews will merge onto a single detail
page in 15 minutes. However, we recommend waiting a full 24 hours to give the
process time to populate before contacting Selling Partner Support.

####  Can I change the order of the variation on my detail page?

No. The order of the variations is populated automatically and cannot be
changed.

####  I have noticed some variation families contain a preview picture along
with the variation options on the detail page and others do not. How do I
enable this feature?

A "Swatch" preview of a color variation is available on child ASINs,
associated with a variation family that contain a **color** option as part of
the variation theme. If your existing child ASIN has a **color** option as
part of its variation theme, edit each child and go to the **Image** tab where
you will find an option for **Swatch** .

####  Are sales rank and history merged under the Parent ASIN when a listing
is added to a variation family?

No. Both sales rank and history are specific to the individual SKUs which do
not change.

####  Is there a way to pause my listings?

If you require more time as you are caught up, have a family emergency, or
you’re going on vacation, you can change the status of your listings to
**Inactive** using vacation settings. This will remove your self-fulfilled
listings from Amazon and search results within an hour. For more information,
go to [ Listing status for vacations, holidays, and other absences
](/gp/help/external/G200135620) .

####  Does the Build International Listings tool work with Amazon Handmade
listings?

Yes. You can use the Build International Listings tool to create and update
offers across all Amazon Handmade stores. For more information, go to [ Build
International Listings ](/gp/help/external/G202121570) .

####  Are Handmade listings eligible for Business Pricing (B2B)?

Yes. Go to [ Amazon business overview ](/gp/help/external/G201542150) for
details on this program.

**Can I use the Amazon Seller mobile app to create Handmade listings?**

Yes. You can add new listings or edit existing listings via the Amazon Seller
mobile app. [ Download the Seller mobile app. ](/sellermobileapp)

##  Additional resources to list your Handmade products

  * [ Amazon Handmade: Using inventory templates to upload products ](/gp/help/external/GMU4YRNPVSDUGJZX)

Top

##  Amazon Handmade: List your products

* [ Amazon Handmade: Use inventory templates to upload products  ](/help/hub/reference/external/GMU4YRNPVSDUGJZX)
* [ Transfer product details from Etsy to Amazon Handmade  ](/help/hub/reference/external/GRDU4XCFF6GFRFE8)
* [ Amazon Handmade: Product title best practices  ](/help/hub/reference/external/GRLUNACJV3JB23G2)
* [ Amazon Handmade: Customizable products  ](/help/hub/reference/external/G201817850)
* [ Amazon Handmade: Expand your Handmade business to other regions  ](/help/hub/reference/external/G7TEMLUGAH27UDS9)
* [ Amazon Handmade: Image requirements best practices  ](/help/hub/reference/external/GNRP6DDJV79DUHRD)
* [ Storefront dedicated to Made in Italy products  ](/help/hub/reference/external/G201952630)
* [ Amazon Handmade: Edit product listings  ](/help/hub/reference/external/GACPFCRX6CH32JST)

