# Carrier requirements for LTL and FTL deliveries

Source: https://sellercentral.amazon.com/gp/help/external/G200978420

This article applies to selling in: **United States**

#  Carrier requirements for LTL and FTL deliveries

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200978420)

On this page

Related guidelines

Scheduling delivery appointments

Floor loaded shipments

Vehicle condition

On this page, you will learn what is required of your carriers for less than
truckload (LTL) and full truckload (FTL) deliveries to Amazon fulfillment
centers. We recommend that you, as well as your carrier, become familiar with
these requirements.

##  Related guidelines

  * For additional requirements for LTL and FTL deliveries, see [ Seller requirements for LTL, FTL, and FCL deliveries ](/gp/help/external/200978400) and [ Floor loading policy ](/gp/help/external/200978440) . 
  * For weight, dimension, and shipment packing requirements, review the [ Shipping and routing requirements ](/gp/help/external/200141510) . 
  * For smaller shipments that are individually labeled for delivery, see [ Small parcel delivery to Amazon ](/gp/help/external/200280260) . 

When you select a carrier, you are responsible for making sure it complies
with the requirements below. The failure of a carrier to comply with these
terms may cause the delivery to be refused.

  * The carrier must have a complete list of Amazon reference IDs (PO lists), shipment IDs, and tracking (PRO) numbers included on or with the bill of lading (BOL). Amazon will require this information when scheduling a dock appointment. Reference and shipment IDs are found on the **Summary** page of the shipping workflow. PRO numbers are obtained from your carrier. 
  * The carrier must communicate box and pallet counts before an appointment will be scheduled. The fulfillment center may request unit counts if they are provided to the carrier. Floor-loaded trailers should be indicated on the carrier freight bill and when requesting an appointment. 
  * Upon arriving at the fulfillment center, the carrier must provide a physical BOL that meets Amazon requirements. Alternatively, the carrier may use an electronic BOL if a soft copy is provided to the fulfillment center prior to the scheduled shipment arrival. 

If shipping through the [ Amazon Partnered Carrier program
](/gp/help/external/201119120) , you must provide the carrier with an Amazon
BOL. An Amazon-generated BOL is available on the **Tracking events** tab in
the shipment summary page on the morning of your scheduled pickup. The carrier
will need this BOL to schedule a delivery appointment for your shipment. You
can alternatively download a blank BOL to fill in for your partnered carrier
shipment [ here (PDF) ](https://m.media-amazon.com/images/G/01/fba-
files/FBA_PARTNERED_LTL_BOL_TEMPLATE.pdf) . For more information, see [ Seller
requirements for LTL, FTL, and FCL deliveries ](/gp/help/external/200978400) .

##  Scheduling delivery appointments

The carrier you select to deliver your shipment will need to schedule an
advanced delivery appointment. Please ensure that both you and your carrier
complete any required steps prior to requesting a delivery appointment.

**Important:** All units on a shipment must be delivered within 7 days of when
the shipment first begins to receive units. Any delivery requests submitted
after 7 days may be rejected.

  * Amazon does not allow general public deliveries. Only professional carriers are allowed to make delivery appointments at Amazon fulfillment centers. 
  * All carriers must register with Amazon before appointments will be granted. 
  * No LTL/FTL or SPD shipments will be accepted at an Amazon fulfillment center without a scheduled appointment. If the carrier misses the scheduled appointment by 30 minutes or more, the freight will be refused at no cost to Amazon. A new appointment request will need to be submitted and approved by the carrier for attempted re-delivery. 
  * Carriers must adhere to Amazon's delivery requirements and safety standards. 
  * Carriers are required to schedule a delivery appointment no less than 24 hours ahead of delivery. 
  * Carriers should schedule a single appointment per physical delivery once the final number of shipments expected is determined. 
  * If a shipment is delayed because of weather, the carrier must notify Amazon. Appropriate schedule changes will be made based on availability. 

**Note:** Carriers should only request advance appointments once all shipments
that will be physically delivered have been determined. Carriers can only
request up to 3 appointments for a single shipment.

**Important:** Scheduling multiple appointments for the same physical
delivery, or providing incorrect shipment information, may cause appointments
to be deleted, delay your shipment, and can result in a suspension of shipping
privileges. For more information, see the “Dos & Don'ts” section on the [
Carrier Central user manual ](https://images-na.ssl-images-
amazon.com/images/G/01/magicarp/common/Carrier_Central_Manual_USAmazon.pdf) .

To schedule a delivery appointment, follow these steps:

  

  1. Ensure your carrier has an accurate BOL for your shipment. For more information, see [ Seller requirements for LTL, FTL, and FCL deliveries ](/gp/help/external/200978400) . 
  2. Provide your carrier the [ Carrier Central user manual ](https://images-na.ssl-images-amazon.com/images/G/01/magicarp/common/Carrier_Central_Manual_USAmazon.pdf) . 
  3. Have your carrier create an account (if it doesn’t already have one) and sign in to [ Carrier Central ](https://carriercentral.amazon.com/) to request an appointment. 

Amazon will respond to your carrier's request within 24 hours, at which time
it will schedule a delivery appointment date and time based on availability.
This time may differ from the time that was originally requested.

**Important:** When scheduling appointments, carriers need to explicitly
mention the shipments are for Fulfillment by Amazon and provide the FBA
Shipment ID (found in the **Summary** page of the shipping workflow). This
will help expedite appointment scheduling and help ensure accurate receipt of
your inventory.

##  Floor loaded shipments

**Note:** If you are using Amazon's Partnered Carrier Program for LTL/FTL
deliveries, place your shipment on pallets. Our partnered carriers do not
accept floor loaded shipments (shipments not on pallets).

For all LTL/FTL shipments, Amazon fulfillment centers prefer shipments on
pallets. If you cannot place your shipment on pallets for any reason, your
carrier must select Floor Loaded as the load type when booking an appointment
at the fulfillment center. For more information about floor loading, see the [
Floor loading policy ](/gp/help/external/200978440) .

##  Vehicle condition

Vehicles delivering goods to Amazon fulfillment centers must meet the
following standards:

  * The vehicle floor must be able to withstand a pallet jack fully laden. 
  * The vehicle floor must be well-maintained, safe, and free from any obstructions and damage such as holes. 
  * The vehicle must be watertight, clean, and free of strong odors, especially when delivering food and health-care products. 
  * Straps, unless actually securing a load, must be firmly fixed to the vehicle, so they present no danger to fulfillment center associates and ensure accessibility to the goods being unloaded. 
  * Due to safety concerns, the use of trailers with uneven or corrugated floors (such as in refrigerated trailers) is not permitted. 
  * Any trailer, truck, shipment, or portion of a shipment is subject to refusal at the fulfillment center if the fulfillment center associates are unable to safely unload the product with no additional cost to Amazon. Notification of such events will be sent to the e-mail address associated with your seller account. 

Top

