# Amazon

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Add your favorite pages here by clicking this icon in the navigation menu.

---
Add your favorite pages here by clicking this icon in the navigation menu.

Hide

[Account settings](https://sellercentral.amazon.com/help/hub/reference/G181)

[Manage inventory](https://sellercentral.amazon.com/help/hub/reference/G41)

[Featured Offer](https://sellercentral.amazon.com/help/hub/reference/G37911)

[Create and manage offers](https://sellercentral.amazon.com/help/hub/reference/GFQ8J5JPKERTHQPP)

[Qualify to Made in France / Fabriqué en France](https://sellercentral.amazon.com/help/hub/reference/G4C9SLZZ2EG4AR8B)

[Lost Sales Dashboard](https://sellercentral.amazon.com/help/hub/reference/GVBF5JR9AJCU65FF)

[About Product Documents](https://sellercentral.amazon.com/help/hub/reference/GZJNHR2M4GDNM3Q3)

[Compare and Choose Listing Methods](https://sellercentral.amazon.com/help/hub/reference/G201576400)

[Start Listing Your Products Now](https://sellercentral.amazon.com/help/hub/reference/G201474070)

[Create listings one at a time](https://sellercentral.amazon.com/help/hub/reference/G39EFY66ZLSJQ7PM)

[Create listings in bulk](https://sellercentral.amazon.com/help/hub/reference/GZ4ZQ4HZQM2R4B2X)

[About products and listings](https://sellercentral.amazon.com/help/hub/reference/G200182950)

[Amazon Search](https://sellercentral.amazon.com/help/hub/reference/GS6TQLG64JYD4LSY)

[Product page style guide](https://sellercentral.amazon.com/help/hub/reference/G200270100)

[Assign category and browse terms to your listings](https://sellercentral.amazon.com/help/hub/reference/G200986940)

[Product detail pages and offers](https://sellercentral.amazon.com/help/hub/reference/G51)

[Novelty SKU Limits](https://sellercentral.amazon.com/help/hub/reference/G201440840)

[Image manager](https://sellercentral.amazon.com/help/hub/reference/GUGPCYWV2P8KVFUT)

[Product 3D models](https://sellercentral.amazon.com/help/hub/reference/G7RGSNQFZ2BAG7K3)

[Product images](https://sellercentral.amazon.com/help/hub/reference/G200986900)

[Image variants](https://sellercentral.amazon.com/help/hub/reference/G8HQAHPDXA9ANPH4)

[Multipack imaging standards](https://sellercentral.amazon.com/help/hub/reference/G94GSFMC79RSLDBY)

[Image Troubleshooting](https://sellercentral.amazon.com/help/hub/reference/G17771)

[Product image requirements](https://sellercentral.amazon.com/help/hub/reference/G1881)

[Missing product images](https://sellercentral.amazon.com/help/hub/reference/G17811)

[Rotate a product image](https://sellercentral.amazon.com/help/hub/reference/G202131150)

[Image Issues](https://sellercentral.amazon.com/help/hub/reference/GT8RSE9S9NK4LP6Z)

[Text/Logo/Graphics/Watermarks](https://sellercentral.amazon.com/help/hub/reference/GB6V3RU3M5XG24GC)

[Non-white background](https://sellercentral.amazon.com/help/hub/reference/G75PWC4THA8J269P)

[Cropped Product](https://sellercentral.amazon.com/help/hub/reference/GMPJ3FNUF4LZV8GR)

[Product not outside of packaging/has packaging tags](https://sellercentral.amazon.com/help/hub/reference/GJ7NW9R96FAUEK3D)

[Propping](https://sellercentral.amazon.com/help/hub/reference/G5SD576VXDFLCR32)

[Blurriness or Pixelation](https://sellercentral.amazon.com/help/hub/reference/GN9G8EM6GUAX4ZY6)

[Product Too Small](https://sellercentral.amazon.com/help/hub/reference/GKPLUEFR7TJ9EDAN)

[Prurient](https://sellercentral.amazon.com/help/hub/reference/G98ZNV6HDKK5NZ8C)

[Multiple Product Views](https://sellercentral.amazon.com/help/hub/reference/G4VZLFFU7KJP7PBH)

[Human Model](https://sellercentral.amazon.com/help/hub/reference/GBESJNTVU5XPKVVU)

[Mannequin or hanger](https://sellercentral.amazon.com/help/hub/reference/G684P2ZPKPTDLSQW)

[Model in non-standing position](https://sellercentral.amazon.com/help/hub/reference/GLBZSXRFB5VX32HC)

[Bad ASIN or Variant](https://sellercentral.amazon.com/help/hub/reference/GP8W3L6D7G2ZFVME)

[Unsupported File Suffix](https://sellercentral.amazon.com/help/hub/reference/G2AHG9AAHGG2DPVH)

[Image File was Corrupted or of an Unexpected Format](https://sellercentral.amazon.com/help/hub/reference/G7HVPM8H8YTKXTAW)

[Image Dimensions Too Small](https://sellercentral.amazon.com/help/hub/reference/GLZCW6ZLJBDYS922)

[Authoritative Image Already Exists](https://sellercentral.amazon.com/help/hub/reference/G864APBMA4HCKXGS)

[Unknown Internal Error](https://sellercentral.amazon.com/help/hub/reference/G74GGME6P8ELPLGU)

[Image with Identical ASIN and Variant Submitted](https://sellercentral.amazon.com/help/hub/reference/GXP59A6ZVJUFJTFN)

[Resubmission of Previously Accepted/Rejected Images](https://sellercentral.amazon.com/help/hub/reference/GD4EQJXHH6RNTDGA)

[Technical Image File Requirements](https://sellercentral.amazon.com/help/hub/reference/G9FUUH87RBNXGKB7)

[Name your image files](https://sellercentral.amazon.com/help/hub/reference/GJV4FNMT7563SF5F)

[Listing photos](https://sellercentral.amazon.com/help/hub/reference/G201270290)

[Amazon Merchant Transport Utility](https://sellercentral.amazon.com/help/hub/reference/G16481)

[Software License Agreement](https://sellercentral.amazon.com/help/hub/reference/G200569620)

[Potential Duplicates and Split Variations](https://sellercentral.amazon.com/help/hub/reference/G202105450)

[Suppressed listings](https://sellercentral.amazon.com/help/hub/reference/G200898440)

[Listing blocked due to potential pricing error](https://sellercentral.amazon.com/help/hub/reference/G201141430)

[Use Amazon Selling Coach to help increase your selling success](https://sellercentral.amazon.com/help/hub/reference/G200966670)

[How the Other Sellers on Amazon box works](https://sellercentral.amazon.com/help/hub/reference/G200418110)

[Error code explanations](https://sellercentral.amazon.com/help/hub/reference/G17781)

[Error 15](https://sellercentral.amazon.com/help/hub/reference/G30601)

[Error 5461](https://sellercentral.amazon.com/help/hub/reference/G7BA3K25ZRY56U6Z)

[Errors 5661, 5664, 5665](https://sellercentral.amazon.com/help/hub/reference/GHG54ZV2MQGHKJZC)

[15000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G202171800)

[Error 3015](https://sellercentral.amazon.com/help/hub/reference/G22951)

[Error 4000](https://sellercentral.amazon.com/help/hub/reference/G200557810)

[Error 4400](https://sellercentral.amazon.com/help/hub/reference/GGU2CYVZ5HVXEU4W)

[5000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712450)

[6000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G202023420)

[8000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G201440690)

[Error 10018](https://sellercentral.amazon.com/help/hub/reference/G31601)

[Error 11003](https://sellercentral.amazon.com/help/hub/reference/G24761)

[13000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712510)

[18000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712520)

[20000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712530)

[30000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712500)

[40000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G202023430)

[90000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G200712050)

[300000 Series Error Codes](https://sellercentral.amazon.com/help/hub/reference/G202152330)

[Common Inventory Template Errors - Chinese Translations](https://sellercentral.amazon.com/help/hub/reference/G201809710)

[Error 990003](https://sellercentral.amazon.com/help/hub/reference/GJBM8ZUVXP7J2DVP)

[Error 8105](https://sellercentral.amazon.com/help/hub/reference/GUX5Q82QLU6TTPBE)

[Error 90057](https://sellercentral.amazon.com/help/hub/reference/GJ6RWQCLKQGY2HT3)

[Error 99010](https://sellercentral.amazon.com/help/hub/reference/GKWM4E4QWN663FXX)

[Error 99036](https://sellercentral.amazon.com/help/hub/reference/GN7XGFX6LT5FMSTL)

[Create and manage inventory FAQ](https://sellercentral.amazon.com/help/hub/reference/GSXJTLLHYLVQCWQZ)

[Newer version widget](https://sellercentral.amazon.com/help/hub/reference/GAEG57678UHDZ3EP)

[Enroll products in our Climate Pledge Friendly program](https://sellercentral.amazon.com/help/hub/reference/GE94565V5PDYL5MZ)

[Enroll textile products in Climate Pledge Friendly (CPF)](https://sellercentral.amazon.com/help/hub/reference/GKQ2X9KZ9EU7AK53)

[Qualify for Compact by Design](https://sellercentral.amazon.com/help/hub/reference/G8K5K99JHR3ACAXM)

[Updated dimension attributes for product types](https://sellercentral.amazon.com/help/hub/reference/GMYRLMMPMNR7UQSE)

[Size Normalization FAQ](https://sellercentral.amazon.com/help/hub/reference/GZJRCRLWW7WKKDAH)

[Conditional Unit Count based on Item Form, Normalized Value of Size, Item Form, Number of Items and Net Content details](https://sellercentral.amazon.com/help/hub/reference/G2RCDMZR4SKGQFAY)

[Warning code 18367: Product type modified by Amazon](https://sellercentral.amazon.com/help/hub/reference/GXMA2QU3JZTG8JNL)

[Manage your offers one at a time](https://sellercentral.amazon.com/help/hub/reference/G201186860)

[Manage your offers in bulk](https://sellercentral.amazon.com/help/hub/reference/G9DZLGS87GVDT94B)

[Price your item](https://sellercentral.amazon.com/help/hub/reference/G62551)

[Catalog and drafts](https://sellercentral.amazon.com/help/hub/reference/G202078860)

[Custom Report Builder](https://sellercentral.amazon.com/help/hub/reference/GEQ8JEWH5KJC5QCG)

[Policies, agreements, and guidelines](https://sellercentral.amazon.com/help/hub/reference/GSNV3657R94YP9DZ)

[Amazon Services Business Solutions Agreement](https://sellercentral.amazon.com/help/hub/reference/G1791)

[Changes to the Amazon Services Business Solutions Agreement](https://sellercentral.amazon.com/help/hub/reference/G47071)

[Program Policies](https://sellercentral.amazon.com/help/hub/reference/G521)

[Account Health Rating program policy](https://sellercentral.amazon.com/help/hub/reference/G200205250)

[FBA inventory reimbursement policy](https://sellercentral.amazon.com/help/hub/reference/G200213130)

[Unsuitable inventory investigations policy](https://sellercentral.amazon.com/help/hub/reference/GH4YYXNDRW9BSZEN)

[Amazon Business invoicing policy](https://sellercentral.amazon.com/help/hub/reference/GHTQ5U9J25GBF5YB)

[U.S. Income Reporting & Tax Identity Collection FAQ](https://sellercentral.amazon.com/help/hub/reference/G200663290)

[ASIN creation policy](https://sellercentral.amazon.com/help/hub/reference/G201844590)

[Selling on Amazon fee schedule](https://sellercentral.amazon.com/help/hub/reference/G200336920)

[Product guidelines](https://sellercentral.amazon.com/help/hub/reference/G11621)

[Convenience Store Payment Service Terms of Use](https://sellercentral.amazon.com/help/hub/reference/G200371490)

[Product safety alerts, recalls, stop sales, and market withdrawal policy for sellers](https://sellercentral.amazon.com/help/hub/reference/GRD4EMBNNW3P47GH)

[Customization Program Terms for Sellers](https://sellercentral.amazon.com/help/hub/reference/G201823150)

[Important information for international sellers](https://sellercentral.amazon.com/help/hub/reference/G200404870)

[Countries accepted for seller registration](https://sellercentral.amazon.com/help/hub/reference/G200405020)

[Guidelines for use of the Available at Amazon Badge by Sellers](https://sellercentral.amazon.com/help/hub/reference/G200573210)

[Intellectual Property Policy for Sellers](https://sellercentral.amazon.com/help/hub/reference/G201361070)

[Amazon Brand Name Policy](https://sellercentral.amazon.com/help/hub/reference/G2N3GKE5SGSHWYRZ)

[Intellectual Property Policy for Sellers - FAQ about Copyrights](https://sellercentral.amazon.com/help/hub/reference/GJLSFCSEA8C9EZYZ)

[Intellectual Property Policy for Sellers - FAQ about Trademarks](https://sellercentral.amazon.com/help/hub/reference/GZUQ6GBBXQVHQKF2)

[Intellectual Property Policy for Sellers - FAQ about Patents](https://sellercentral.amazon.com/help/hub/reference/GQ53DXVX2D2TPCPQ)

[Letter of Authorization](https://sellercentral.amazon.com/help/hub/reference/GUF78PCXAMHDY2A6)

[Report a Violation](https://sellercentral.amazon.com/help/hub/reference/G200444420)

[Parallel Imported Products](https://sellercentral.amazon.com/help/hub/reference/G200936440)

[Amazon Anti-Counterfeiting Policy](https://sellercentral.amazon.com/help/hub/reference/G201165970)

[Communication Guidelines](https://sellercentral.amazon.com/help/hub/reference/G1701)

[Amazon Currency Converter for Sellers Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/G200371640)

[Tax policies](https://sellercentral.amazon.com/help/hub/reference/G200405820)

[Supply Chain Standards](https://sellercentral.amazon.com/help/hub/reference/G202111990)

[Consumption Tax Indication](https://sellercentral.amazon.com/help/hub/reference/G201440180)

[Standards for Brands Selling in the Amazon Store](https://sellercentral.amazon.com/help/hub/reference/G201797950)

[Amazon Imaging Services Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/GLB92H2ZXTHU95HH)

[Amazon Points Services Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/G201647680)

[Tax Registration Agreement (VAT or GST)](https://sellercentral.amazon.com/help/hub/reference/G30394)

[E.U. Value Added Tax (EU VAT) Registration Agreement](https://sellercentral.amazon.com/help/hub/reference/G201190460)

[Fulfillment by Amazon Policies and Requirements](https://sellercentral.amazon.com/help/hub/reference/G53911)

[Cash On Delivery terms of use](https://sellercentral.amazon.com/help/hub/reference/G200796940)

[Pay by Invoice Policies](https://sellercentral.amazon.com/help/hub/reference/G202105160)

[Amazon Launchpad Program Terms](https://sellercentral.amazon.com/help/hub/reference/G202007390)

[Selling Services Terms](https://sellercentral.amazon.com/help/hub/reference/G201484410)

[Textbook Rental Policy](https://sellercentral.amazon.com/help/hub/reference/G201962800)

[Fine Jewelry Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/G201622250)

[FBA Inventory Placement Service Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/G200943420)

[Commercial Liability Insurance Policy](https://sellercentral.amazon.com/help/hub/reference/G200386300)

[Selling Services on Amazon Policies](https://sellercentral.amazon.com/help/hub/reference/G201840340)

[Subscribe With Amazon Program Agreement](https://sellercentral.amazon.com/help/hub/reference/G202072540)

[Tax Calculation Services Terms](https://sellercentral.amazon.com/help/hub/reference/G200787220)

[Amazon Renewed Quality policy](https://sellercentral.amazon.com/help/hub/reference/G202190320)

[Amazon Renewed Program Policies](https://sellercentral.amazon.com/help/hub/reference/GZZVY5QX4DZHWHSW)

[Seller Fee Tax Invoice](https://sellercentral.amazon.com/help/hub/reference/G202162720)

[Important information for international sellers](https://sellercentral.amazon.com/help/hub/reference/G202168490)

[Get Paid Faster Service Terms for Invoiced Orders](https://sellercentral.amazon.com/help/hub/reference/G202192350)

[FBA Dangerous Goods Program Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/GYS2KBEE7MYVCGE3)

[Prime Launches program terms](https://sellercentral.amazon.com/help/hub/reference/GBJGLGMYML2BRNGV)

[Get Paid Faster service terms for invoiced orders](https://sellercentral.amazon.com/help/hub/reference/G5DA4FB5YD6PD5PX)

[Ship-to-Store Terms](https://sellercentral.amazon.com/help/hub/reference/GHV3AEGYL9VHKGUQ)

[Ship-to-Store Policies](https://sellercentral.amazon.com/help/hub/reference/GGUZWLQKEGJW4QCK)

[Customer product reviews policies](https://sellercentral.amazon.com/help/hub/reference/GYRKB5RU3FS5TURN)

[EU Geo-blocking regulation](https://sellercentral.amazon.com/help/hub/reference/G4QVDR2M6RV4NP5W)

[Amazon Brand Analytics Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/GM3JKB2JPVWPVUZC)

[Additional policies and guidance for Prime Now sellers](https://sellercentral.amazon.com/help/hub/reference/G85BNYWWX8R3HYLW)

[Amazon Vine Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/G3MB5C56WDZZXHBG)

[Referral fees reimbursement policy](https://sellercentral.amazon.com/help/hub/reference/GRRJCFXD6474GRLY)

[Customer Service by Amazon Terms & Conditions](https://sellercentral.amazon.com/help/hub/reference/G65T4N3XGC3MJB38)

[Amazon Services Provider – Program Policies](https://sellercentral.amazon.com/help/hub/reference/G9GPDWV663AD4USD)

[Selling on Amazon fees guide](https://sellercentral.amazon.com/help/hub/reference/G6F7CN3EQS7MEGCN)

[Amazon Accelerator](https://sellercentral.amazon.com/help/hub/reference/G52NQJE353XZGWN7)

[Amazon Brand Referral Bonus Terms and Conditions](https://sellercentral.amazon.com/help/hub/reference/GKPK6UXEUARLBX9Z)

[A-to-z Claims Process for Property Damage and Personal Injury](https://sellercentral.amazon.com/help/hub/reference/GTY6NYZDFD5CENYH)

[Amazon Services Provider – program policies](https://sellercentral.amazon.com/help/hub/reference/GFJV7WJSANEJ6MJ4)

[Local Selling Program Policies](https://sellercentral.amazon.com/help/hub/reference/GALGRJ45NC438BPK)

[Local Selling Terms](https://sellercentral.amazon.com/help/hub/reference/GUGFQ9HS2JBLN7XZ)

[Amazon Generic Product Policy](https://sellercentral.amazon.com/help/hub/reference/G84H3T69ZX762NWT)

[Lab Central Program Policy](https://sellercentral.amazon.com/help/hub/reference/GFUQMPCZZCJ5S34E)

[Black-Owned Business badge](https://sellercentral.amazon.com/help/hub/reference/GBYJYA8MG6FV4XYC)

[Amazon Warehousing and Distribution terms and conditions](https://sellercentral.amazon.com/help/hub/reference/GHV89YC29VWN6SBM)

[Dangerous Goods policy for seller-fulfilled products](https://sellercentral.amazon.com/help/hub/reference/GN4SW35Y4KXHX8BT)

[Changes to program policies](https://sellercentral.amazon.com/help/hub/reference/GQHQGBTD7XB7EECN)

[Intellectual Property for Rights Owners](https://sellercentral.amazon.com/help/hub/reference/GU5SQCEKADDAQRLZ)

[International selling agreements](https://sellercentral.amazon.com/help/hub/reference/GEENGDB2JGLEK3PZ)

[Additional Guidelines](https://sellercentral.amazon.com/help/hub/reference/G69G3YF8A6VG7C2Y)

[About seller facial data](https://sellercentral.amazon.com/help/hub/reference/GVQRRK8ZNHUVNQ6Y)

[Use of business credit reports](https://sellercentral.amazon.com/help/hub/reference/G6TS99MYVGUEAKJW)

[Manage Orders](https://sellercentral.amazon.com/help/hub/reference/G28141)

[Payments](https://sellercentral.amazon.com/help/hub/reference/G211)

[Returns, refunds, cancellations, and claims](https://sellercentral.amazon.com/help/hub/reference/G69126)

[Monitor feedback and performance](https://sellercentral.amazon.com/help/hub/reference/G171)

[Get started with Fulfillment by Amazon (FBA)](https://sellercentral.amazon.com/help/hub/reference/G53921)

[Amazon Lending](https://sellercentral.amazon.com/help/hub/reference/G5FQ5KR6FTQ4DGG2)

[Increase sales](https://sellercentral.amazon.com/help/hub/reference/G43381)

[Amazon Global Selling](https://sellercentral.amazon.com/help/hub/reference/G201062890)

[Amazon Handmade](https://sellercentral.amazon.com/help/hub/reference/G201817090)

[Private Brands safety and compliance](https://sellercentral.amazon.com/help/hub/reference/GFZ4GKGVGPHP5XL6)

[Amazon Custom](https://sellercentral.amazon.com/help/hub/reference/G201757520)

[Data exchange through XML, API, and third-party apps](https://sellercentral.amazon.com/help/hub/reference/G221)

[Amazon Business](https://sellercentral.amazon.com/help/hub/reference/G201542150)

[Amazon Pay help](https://sellercentral.amazon.com/help/hub/reference/G201064080)

[Manage service orders](https://sellercentral.amazon.com/help/hub/reference/G201484490)

[Delivery with Services](https://sellercentral.amazon.com/help/hub/reference/G202159960)

[Amazon Services Provider program](https://sellercentral.amazon.com/help/hub/reference/G201955140)

[Amazon Brand Registry](https://sellercentral.amazon.com/help/hub/reference/G202130410)

[Merch Collab](https://sellercentral.amazon.com/help/hub/reference/GE9SDJX2QH6ZSLSV)

All articlesRecently viewed

## Need more help?

[Visit Seller Forums](https://sellercentral.amazon.com/forums/index.jspa)[Get Support](https://sellercentral.amazon.com/help/hub/support)

## Authoritative Image Already Exists

An image will fail to upload if we prefer to use an image that already exists for this product.

Top

Was this article helpful?

-   [Help](https://sellercentral.amazon.com/gp/contact-us/contact-amazon-form.html?ref=xx_contactus_foot_xx)
-   [Program Policies](https://sellercentral.amazon.com/gp/help/help.html/ref=xx_help_foot_xx?itemID=521)

-   © 1999-2023, Amazon.com, Inc. or its affiliates
