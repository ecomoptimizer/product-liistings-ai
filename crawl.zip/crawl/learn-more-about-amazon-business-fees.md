# Learn more about Amazon Business fees

Source: https://sellercentral.amazon.com/gp/help/external/G201762480

This article applies to selling in: **United States**

#  Selling on Amazon Business fee schedule

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201762480)

On this page

Monthly subscription fee

Fulfillment by Amazon fees

Referral fees

How to identify business transactions

##  Monthly subscription fee

Sellers are required to have a Professional selling plan to participate in the
[ Amazon Business Seller program ](/gp/help/external/201542150) , and the
associated monthly subscription fee and other selling fees apply. For a
limited time, sellers participating in the Amazon Business Seller program pay
no additional monthly program fee. For more information on fees, see the [
Selling on Amazon Fee Schedule ](/gp/help/external/200336920) .

##  Fulfillment by Amazon fees

The FBA fee schedule applies to business orders fulfilled by Amazon. [ Learn
more about FBA fees ](/gp/help/external/201074400) .

##  Referral fees

Referral fees for business orders on Amazon follow the [ Selling on Amazon Fee
Schedule ](/gp/help/external/G200336920) .

##  How to identify business transactions

Business transactions are identified by the **Business Buyer** label in Order
Details and the is-business-order flag in **Order Reports** .

Top

##  Selling on Amazon Business fee schedule

* [ Custom Quote Fees  ](/help/hub/reference/external/GV6BNSTMAEXJC7UW)

