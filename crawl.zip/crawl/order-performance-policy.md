# Order Performance policy

Source: https://sellercentral.amazon.com/gp/help/external/GGJVNFDXQT8C3RA8

This article applies to selling in: **United States**

#  Order Performance program policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGGJVNFDXQT8C3RA8)

On this page

Order Defect Rate

Cancellation Rate

Late Shipment Rate

Valid Tracking Rate

On-Time Delivery Rate

Address customer feedback

The below Order Performance policies require that sellers meet minimum
performance standards on fulfillment, delivery, and customer service. These
policies are intended to ensure that customers will continue to have a
positive experience shopping in Amazon’s store after their order has been
placed.

You can see how you are performing against these metrics by reviewing the
Customer Service Performance and Shipping Performance sections on your [
Account Health ](/performance/dashboard) page.

##  Order Defect Rate

The Order Defect Rate (ODR) is a key measure of your ability to provide a good
customer experience. It includes all orders with one or more defects (defined
below) represented as a percentage of total orders during a given 60-day
period.

The following are the types of order defects:

  * Negative feedback 
  * An A-to-z Guarantee claim that is not denied 
  * Credit card chargeback 

Our policy is that sellers maintain an Order Defect Rate under 1% in order to
sell on Amazon. An Order Defect Rate above 1% may result in loss or
restriction of selling privileges.

##  Cancellation Rate

The Cancellation Rate (CR, or Pre-Fulfillment Cancellation Rate as it is
referred to on the Account Health page) includes all seller-canceled orders
represented as a percentage of total orders during a given 7-day period. CR
only applies to seller-fulfilled orders.

This metric includes all order cancellations initiated by the seller, with the
exception of those requested by the customer using the order-cancellation
options in their Amazon account. Pending orders that are canceled by the
customer directly on Amazon are not included.

Our policy is that sellers maintain a CR that is under 2.5% in order to sell
on Amazon. A CR above 2.5% may result in loss or restriction of selling
privileges.

##  Late Shipment Rate

The Late Shipment Rate (LSR) includes all orders with a shipping confirmation
that is completed after the expected ship date. LSR is represented as a
percentage of total orders over both a 10-day or 30-day period. LSR only
applies to seller-fulfilled orders.

It is important to confirm the shipment of orders by the expected ship date so
that customers can see the status of their shipped orders online.

The following results can occur due to an order with a confirmed late shipment
date:

  * Increased A-to-z Guarantee claims 
  * Negative feedback 
  * Customer contacts 
  * Negative customer experience 

Our policy is that sellers maintain an LSR under 4% in order to sell on
Amazon. An LSR above 4% can result in loss or restriction of selling
privileges.

##  Valid Tracking Rate

The Valid Tracking Rate (VTR) includes all shipments with a valid tracking
number represented as a percentage of total shipments during a given 30-day
period. Valid Tracking Rate only applies to seller-fulfilled orders.

Amazon customers depend on tracking numbers to find out where their orders are
and when they can expect to receive them. The Valid Tracking Rate is a
performance metric that reflects those expectations. All major carriers,
including USPS, FedEx, UPS, and DHL now offer free tracking.

Our policy is that sellers maintain a Valid Tracking Rate greater than 95% for
their shipments. A Valid Tracking Rate below 95% in a product category may
result in restrictions on your ability to sell non-FBA items within that
category. This may also affect your eligibility to participate in [ Premium
shipping ](/gp/help/external/G201503640) .

##  On-Time Delivery Rate

The On-Time Delivery Rate (OTDR) includes all shipments delivered by their
estimated delivery date (EDD) represented as a percentage of total tracked
shipments. OTDR only applies to seller-fulfilled orders.

We consider OTDR performance when determining which transit times you are
eligible to set, which may enable you to promise faster delivery times and
improve your conversion.

We recommend that sellers maintain an OTDR greater than 97% in order to
provide a good customer experience. However, there is no consequence for not
meeting the OTDR target.

##  Address customer feedback

Certain negative performance metrics are caused by a customer’s feedback based
on their experience. Sellers should try to determine the cause of the problem
and work with the customer using one of the following options:

**Use the Feedback Manager**

  1. Go to Seller Central home page. 

  2. Under **Performance** , click [ Feedback ](/feedback-manager/index.html#/) . 

  3. In the **Recent feedback** table, select **Contact customer** under the **Actions** column next to the designated Order ID. 

Note that this action will only be available for neutral or negative feedback.

**Use the[ Buyer-Seller Messaging Service templates ](/messaging/templates) **

For more information, go to [ Email templates for Buyer-Seller Messaging
Service ](/gp/help/external/G201109160) .

**Note:** You can only use the Buyer-Seller Messaging Service templates to
contact a customer with regards to an order or a customer service question.

Top

