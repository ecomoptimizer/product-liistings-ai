# China

Source: https://sellercentral.amazon.com/gp/help/external/GSTQGS38CC9867UF

This article applies to selling in: **United States**

#  If your business location is China

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGSTQGS38CC9867UF)

**Identity document** : We accept ID documents such as passport and national
ID card.

Make sure your document also meets the following criteria:

  

  1. We do not accept electronic IDs. 
  2. ID holder must be above 18 years of age. 

**Proof of address document:**

We accept government-issued Business License (BL).

Make sure your document also meets the following criteria:

  

  1. Must not be electronic Business Licenses. 
  2. Must not be a branch office or a rural credit cooperative. 
  3. Must be valid for at least 45 days from the date of your submission. 
  4. Must be in color (black and white not accepted). 
  5. Must be with information that matches with the information on the national chinese company register website. 
  6. Must be with “normal/live/active” status, without being listed to any abnormal business status. 

For more information on Global Seller Identity Verification, go to [
Frequently asked questions about Global SIV
](/gp/help/external/G2MJXHQCR62DZSSM) .

Top

