# ASIN Creation Policy

Source: https://sellercentral.amazon.com/gp/help/external/201844590

This article applies to selling in: **United States**

#  ASIN creation policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201844590)

On this page

ASIN creation by non-brand owners

ASIN creation limit

Variation policy

Duplicate ASIN creation policy

How are duplicates created?

Tips to avoid creating duplicate ASINs

To create an ASIN, go through the process as outlined in our [ Add a Product
](/productsearch) tool. To sell a product available in the Amazon catalog,
match it to the existing ASIN by creating an offer. If your product is not in
the Amazon catalog, you will have to create a single new ASIN for the product.

##  ASIN creation by non-brand owners

To protect the customer shopping experience, we limit the creation of new
ASINs for a brand enrolled in Brand Registry by sellers who are not associated
with the brand owner.

If you encounter the following error message, it is because you are not
associated with the brand owner and therefore restricted from creating new
ASINs for the brand. You may still seek approval to create the new ASIN if you
can show that it is an authentic product of the brand, for which no ASIN
exists yet. Providing all the necessary information on the first contact will
reduce the time it will take for your request to be reviewed.

Error code  |  Error message  |  Requested information  
---|---|---  
5461  |

You may not create new ASINs for this brand. However, you are free to add
offers to any existing ASIN for this brand ( [ listing limitations may apply
](/gp/help/external/G200333160) ). Please review our [ ASIN creation policy
](/gp/help/external/201844590) for more information.

If you believe the product you want to sell is not already listed in the
Amazon catalog and should be listed as a new ASIN, contact [ Selling Partner
Support ](/hz/contact-us) and mention error code 5461. Before contacting
Selling Partner Support, review the ASIN Creation Policy and confirm your
product is not already listed on the catalog.

When contacting Selling Partner Support, provide the following information:

  * Product title (including any variations in color, size, measurements, model/part number, etc.) 
  * Brand 
  * Manufacturer 
  * Category 
  * Description 
  * SKU 
  * UPC/EAN/JAN if available 
  * If using inventory file templates, please provide the Batch ID of the inventory file process report 
  * Real-world images of the product (front and back images of the product including bar code, along with UPC and brand name, packaged and unpackaged, and unfolded if the item is apparel) 

|

  * Product name 
  * Brand 
  * Manufacturer 
  * Category 
  * Description 
  * SKU 
  * UPC/EAN/JAN 
  * Product title including any variations in color, size, measurements, model/part number, etc. 
  * Batch ID of inventory file process report 
  * Screen shot of the error code you received 
  * Images of the product (front and back images of the product including bar code along with UPC and brand name; packaged and unpackaged; unfolded if the item is apparel) 

  
  
####  Where do I find product information?

Brand name, UPC or EAN/JAN, and part number (or model/style number) can be
found on a purchase order or invoice from the manufacturer or distributor from
which your product was purchased. Some information may be available directly
from the product packaging or through the manufacturer’s catalog or website.

##  ASIN creation limit

To protect the onsite shopping experience for our customers, we limit the
number of listings (offers and ASINs) you can create in a given week until you
establish a sales history with Amazon. As you increase your sales, your
capacity will increase. We encourage you to prioritize the products you are
listing to increase your sales quickly.

Additionally, if you are an established seller and have created a high number
of new listings, we reserve the right to temporarily remove your ability to
create new listings. We will re-evaluate your status on a weekly basis.

If you think your listing creation privileges have been removed in error,
contact [ Selling Partner Support ](/cu/contact-us) .

##  Variation policy

Variations are sets of products that are related to one another. Good
variation relationship listings allow buyers to compare and choose products
based on different attributes such as size, color, or other characteristics
from the available options on a single product detail page. For more
information, go to [ Variation Relationship Overview ](/gp/help/external/8831)
.

The following prohibited practices are misuses of variations, either of the
parent ASIN or in parent-child relationships. These practices create a
negative customer experience and can result in your ASIN creation or selling
privileges being temporarily or permanently removed:

  * Changing the product’s detail page (parent or child) to become fundamentally different from the original product listed 
  * Changing the parent product's detail page so it does not match the children 
  * Adding incorrect child variations that are not true variations of the parent product. This includes but is not limited to: 
    * Adding products that are fundamentally different from the parent ASIN 
    * Adding products images and/or names that are that are fundamentally different from the parent ASIN 
    * Adding products that are newer versions or models of the parent ASIN 
  * Adding multi-pack variations that aren’t manufacturer-created to an already existing parent 
    * If you’ve created a multi-pack listing that is not directly sold by the manufacturer, you must match your listing to an identical multi-pack product detail page. If an identical multi-pack detail page doesn’t exist, you must create a new product detail page with its own unique UPC 
    * Adding multi-pack children by bundling two or more of the same manufacturer products, that is, bundling two three-packs to create a package quantity of six. Multi-pack children must be packaged by the manufacturer. If a customer wants to buy two or more of the same product, they can select that quantity for purchase 

##  Duplicate ASIN creation policy

Creating a new ASIN when the product already exists in Amazon's catalog is
prohibited and can result in your ASIN creation or selling privileges being
temporarily suspended or permanently removed.

Matching your products to existing products in Amazon’s catalog helps drive a
high-quality customer experience. Matching to an existing product instead of
creating a duplicate listing allows you to more fully benefit from buyer
interest and traffic for that product.

##  How are duplicates created?

Duplicates are most commonly created when one or more of the following
happens:

  * You incorrectly use the UPC, EAN, ISBN, ASIN, or JAN not belonging to the product (such as from another product) to identify the product you are selling. 
  * You introduce distinct UPCs, EANs, ISBNs, or JANs for identical products. For example: 
    * You assign a product a new UPC or EAN in each Amazon marketplace where you sell the product. 
    * You assign a new UPC or EAN for compatible products such as a laptop charger that is compatible with multiple laptops. 
  * You are an Amazon Brand Registry seller using an alternative key attribute to list your products. If you use multiple key attribute values to list the same product, a new ASIN will be created for each key attribute value. 
  * You have received a product identifier exemption for a product that actually has a product identifier. Listing it without an identifier will create a duplicate. 

##  Tips to avoid creating duplicate ASINs

Ensure that you always use the appropriate UPC, EAN, ISBN, ASIN, or JAN code
when listing a product. The codes are reliable data that can be used to match
your products to existing products in the catalog. Using incorrect UPC, EAN,
ISBN, ASIN, or JAN codes to list a product is prohibited and can result in
your ASIN creation privileges being suspended or permanently removed.  For
more information, go to [ Potential duplicates ](/gp/help/external/G202105450)
, [ Amazon brand name policy ](/gp/help/external/G2N3GKE5SGSHWYRZ) , and [ How
to list products that do not have a GTIN (UPC, EAN, JAN, or ISBN)
](/gp/help/external/G200426310) .

####  Register your brand with Amazon

If you are the brand owner or manufacturer of your own products and if you can
uniquely identify each product with other attributes such as model number or
style number, you might be eligible to register your brand with the Amazon
Brand Registry, which allows you to use an alternative product identifier.

For more information, go to [ Amazon Brand Registry
](/gp/help/external/G202130410) .

####  Request a brand or SKU-level UPC exemption

If the product you are listing has been confirmed to have no known UPC, EAN,
ISBN, ASIN, or JAN code and if you are listing a unique selection, you can
request a brand or SKU-level UPC exemption. For information on eligibility, go
to [ How to List Products That Do Not Have a GTIN (UPC, EAN, JAN or ISBN)
](/gp/help/external/200426310) .

Top

