# FBA inventory reimbursement policy

Source: https://sellercentral.amazon.com/gp/help/external/200213130

This article applies to selling in: **United States**

#  FBA inventory reimbursement policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200213130)

On this page

Eligibility

Claims

Reimbursements

How we calculate reimbursement value

If an item you send to us as part of the Fulfillment by Amazon (FBA) service
is lost or damaged at a facility or by a carrier operated by Amazon or on
behalf of Amazon, we will replace that item with a new item of the same FNSKU
or we will reimburse you for it.

##  Eligibility

For an item to be eligible under this policy, all of the following must be
true:

  * The item is registered in FBA at the time it is lost or damaged. 
  * The item complies with [ FBA product requirements and restrictions ](/gp/help/external/200140860) and with [ FBA inventory requirements ](/gp/help/external/201100890) . 
  * You have sent us the exact items and quantities stated in your shipping plan. 
  * The shipment for the item is not in canceled or deleted status. 
  * The item is not pending disposal or was not disposed of at your request or because we have exercised a right to do so. 
  * The item is not defective and was not damaged by a customer. 
  * When a lost or damaged item claim is filed, under review, and during any appeals, the seller’s account must be in normal status. 

##  Claims

If your item is eligible under this policy and we haven't already reimbursed
you, you can file a reimbursement claim. The process to a file a claim varies
depending on where the fulfillment process your item is lost or damaged.

  * [ Shipment to Amazon ](/gp/help/external/GEYPWTSQRTXXXMVB)
  * [ Fulfillment center operations ](/gp/help/external/GGEV4254LJJ9BAEG)
  * [ FBA customer returns ](/gp/help/external/G9N934L7Y4SFWPJ4)
  * [ Removals ](/gp/help/external/G9ZB3H4DP4H72U6R)

**Important:** You must follow the applicable process described on the pages
linked above and provide all requested information when you file a claim.
Amazon may decline your claim if you do not.

##  Reimbursements

If we determine that your reimbursement claim is valid, we will replace the
lost or damaged item with a new item of the same FNSKU or we will reimburse
you for it.

If a reimbursement was made in error, or if a reimbursed item is later found
and returned to your inventory, Amazon reserves the right to reverse the
reimbursement credit that was applied to your account.

We may dispose of any item for which we reimburse you under this policy,
including by selling it. As a result, such items — including lost items that
are found after reimbursement — may be listed for sale on  [ Amazon Warehouse
](https://www.amazon.com/Warehouse-Deals/b?ie=UTF8&node=10158976011) or other
channels.

**Important:** Our policies prohibit any activity that would interfere with
our capacity to help other sellers. Examples of such activities include
submitting insufficiently researched or premature requests, or submitting a
large number of requests in a short time. Sellers who repeatedly engage in
these activities may receive delayed support on their cases or be subject to
monitoring, investigation, and account action.

##  How we calculate reimbursement value

**Important:** The maximum reimbursement amount for a single unit of any FBA
eligible item is $5,000. For items valued at more than $5,000, we recommend
that you consider buying third-party insurance.

Because item prices tend to fluctuate over time and may vary widely from
seller to seller, we compare several price indicators to determine an
estimated sale price for the item when calculating the reimbursement amount.
The price indicators we compare are:

  * The median price at which you have sold the item on Amazon over the past 18 months 
  * The median price at which other sellers have sold the same item on Amazon over the past 18 months 
  * The current list price you have set for the same item on Amazon or the mean list price if you have multiple listings for the same item 
  * The current list price for the same item from other sellers on Amazon 

If we don't have enough information to calculate the estimated sale price of a
unit using the price indicators described above, we will assign an estimated
sale price based on the price of a comparable product. We may ask you for
additional information or documentation to help us determine that value.

If we elect to reimburse you for a [ shipment to Amazon claim
](/gp/help/external/GEYPWTSQRTXXXMVB) , we will reimburse you for the
estimated proceeds of a sale of that item.

**Note:** "Estimated proceeds" means the estimated sale price of the item for
which you are being reimbursed minus referral fees and fulfillment fees.

If we elect to reimburse you for a [ fulfillment center operations claim
](gp/help/GGEV4254LJJ9BAEG) or a [ removal claim
](/gp/help/external/G9ZB3H4DP4H72U6R) , we will reimburse you for the
estimated proceeds of the sale of that item, unless the item was in an
unsellable condition when lost or damaged or when removed from the Amazon
fulfillment network.  For unsellable items, Amazon will reimburse you at a
valuation consistent with the estimated proceeds of the discounted sale of the
unit.  We may ask you for additional information or documentation to help us
determine that discounted value.

If we elect to reimburse you for a [ customer return claim
](/gp/help/external/G9N934L7Y4SFWPJ4) , the value of the reimbursement is
based on the refund or replacement given to the customer on your FBA order.
If Amazon refunded or replaced an item on your FBA order, we calculate the
reimbursement value as the refund amount or the price of the replacement item
on the original order minus applicable fees.

If you don't agree with the Amazon valuation of a unit, you can file a claim
using the [ Contact Us ](/help/hub/support) page in Seller Central within 90
days after we issued the reimbursement.

Top

##  FBA inventory reimbursement policy

* [ FBA inventory reimbursement policy: Shipment to Amazon claims  ](/help/hub/reference/external/GEYPWTSQRTXXXMVB)
* [ FBA inventory reimbursement policy: Fulfillment center operations claim  ](/help/hub/reference/external/GGEV4254LJJ9BAEG)
* [ FBA inventory reimbursement policy: Removals claims  ](/help/hub/reference/external/G9ZB3H4DP4H72U6R)
* [ FBA inventory reimbursement policy: Customer return claims  ](/help/hub/reference/external/G9N934L7Y4SFWPJ4)
* [ FBA shipping label reimbursement policy  ](/help/hub/reference/external/GL862UFSVUR6TM2P)

