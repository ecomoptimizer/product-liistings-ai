# My ASIN is unsearchable

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> Four common reasons for an ASIN being unsearchable are:

---
I can't find my Asin: Four common reasons for an ASIN being unsearchable are:  

1.  Parent ASIN
2.  No Browse Node
3.  No Offer
4.  Future Launch Date

## 1\. Parent ASIN

To enable Variation Elimination to work, parent ASINs are not searchable or buyable. A parent ASIN forces customers to select a color or/and size:

![](https://m.media-amazon.com/images/G/01/ASIN_Unsearchable/Shoes._CB463952415_.png)

**Note:**

-   **Check**: If your ASIN is unsearchable, check if it is a parent ASIN.
-   **Diagnosis**: Parent ASINs are not indexed by Amazon Search.
-   **Fix**: No fix needed. It is normal for parent ASINs to not be searchable.

## 2\. No Browse Node

In order to be searchable, ASINs need to be assigned to a browse node. A browse node is like a shelf in a supermarket. Your product needs to be on a “shelf” in order to be found.

Unassigned ASINs are not indexed by Amazon Search.

You can use the [Product Classifier](https://sellercentral.amazon.com/gp/help/G200956770) or a [Browse Tree Guide (BTG)](https://sellercentral.amazon.com/gp/help/G1661) to help you identify the correct categories for your products.

**Example**

This ASIN is nicely-assigned to the specific browse node called “Bubble Bath”:

![](https://m.media-amazon.com/images/G/01/ASIN_Unsearchable/GB._CB463947101_.png)

ASIN browse assignments “roll up”. In this example, the ASIN will appear in Bubble Bath and in Bath and in Bath & Bathing Accessories and in Personal Care and in the overall Beauty & Personal Care category on Amazon.

**Note:**

-   **Check**: If your ASIN is unsearchable, check if it is assigned to a product category.
-   **Diagnosis**: Unassigned ASINs are not indexed by Amazon Search.
-   **Fix**: Assign your ASIN to a specific, relevant browse node.

**Tip**: Some ASINs are searchable in All Product Search (APS), but not within Departments on Amazon. This is because they were not assigned to a browse node, so were automatically assigned to a category called **Everything Else**. Assigning your ASIN to a specific, relevant browse node will ensure that your product doesn't end up in Everything Else.

## 3\. No Offer

In order to be searchable, an ASIN needs an offer. If an ASIN's offer expires, this would cause it to become unsearchable.

To add an offer to a product, you need to supply data such as Item Price, Quantity, and Launch Date.

You can add offers one at a time via [Add a Product](https://sellercentral.amazon.com/gp/help/G200220550) or in bulk via [inventory templates](https://sellercentral.amazon.com/gp/help/G202094740).

![](https://m.media-amazon.com/images/G/01/ASIN_Unsearchable/zh_AU._CB463947181_.png)

**Note:**

-   **Check**: If your ASIN is unsearchable, check that it has an active offer.
-   **Diagnosis**: ASINs without offer are unsearchable.
-   **Fix**: Give your ASIN an offer.

## 4\. Future Launch Date

A common reason for an ASIN being unsearchable is because it has a future launch date. In other words, it is not yet possible to buy the product.

To be searchable, an ASIN's launch date must be in the past.

<table><tbody><tr><td><img src="https://m.media-amazon.com/images/G/01/ASIN_Unsearchable/ROOTASIN_Unsearchable_77848._CB463668344_.png"></td><td><p><strong>In templates: </strong>launch-date</p><p><strong>In feeds</strong><strong>(<u><a href="https://sellercentral.amazon.com/gp/help/G1611" target="_self">Product.xsd</a></u>): </strong>LaunchDate</p></td></tr></tbody></table>

**Note:**

-   **Check**: If your ASIN is unsearchable, check if it has a future launch date.
-   **Diagnosis**: ASINs with future launch dates are not searchable.
-   **Fix**: To make it searchable now, update your ASIN's launch date to a date in the past.
