# Payments tasks and tools

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69038

This article applies to selling in: **United States**

#  Payments tasks and tools

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69038)

All proceeds from your sales will be transferred directly to your bank account
using an Automated Clearing House (ACH) deposit.

To view detailed information related to your payments account and details on
all order and other transactions, go to the **Reports** tab and select
**Payments** .

Top

##  Payments tasks and tools

* [ Get payments reports  ](/help/hub/reference/external/G60511)
* [ Amazon Currency Converter for Sellers (ACCS): FAQ  ](/help/hub/reference/external/G200381250)
* [ Making a payment  ](/help/hub/reference/external/G201058620)
* [ [Beta] Disburse Funds to your Gift Card to shop on Amazon.com  ](/help/hub/reference/external/GCH5XL78M62CU8TL)

