# Guidelines for contacting Selling PartnerSupport

Source: https://sellercentral.amazon.com/gp/help/external/GK3V2JYCN2P28BFX

This article applies to selling in: **United States**

#  Guidelines for contacting Selling Partner Support

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGK3V2JYCN2P28BFX)

We strive to provide quick and accurate support to resolve questions about
selling on Amazon. You can get support within Seller Central through [ Contact
Us ](/cu/contact-us?_encoding=UTF8&ref_=ag_contactus_nmhb_521) . To help us
better serve you, follow these guidelines:

  * Review your case log to check case status instead of opening a new case to ask. If your issue is time sensitive, flag the case as urgent. 
  * Create one case per issue. We have multiple teams and they'll resolve your issue more efficiently if each team receives their own contact on a specific issue. 
  * Don’t open a new case if one is already under review for the same issue. 
  * If you need more time to respond to a case, you may ask us to keep the case open. 
  * If you have questions about a closed case or think it was handled incorrectly, reopen it instead of opening a new case. 
  * To protect sellers and customers, we decline requests that are not consistent with our policies. If we’ve informed you that no further action will be taken on an issue, don’t seek to obtain a different outcome by reopening the case or raising it again in other cases. 

Amazon may close cases or limit support if you don’t follow these guidelines.

Top

