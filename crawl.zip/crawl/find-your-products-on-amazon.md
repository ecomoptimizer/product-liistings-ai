# Find your products on Amazon

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> The first step in the Add a Product feature is searching the Amazon catalog. This saves you time by locating existing product detail pages that match your product.

---
The first step in the **Add a Product** feature is searching the Amazon catalog. This saves you time by locating existing product detail pages that match your product.

Type the product name, keyword, product identifier (UPC, EAN, ISBN or JAN), or ASIN and then click **Search**. (Unless your product is unique to you as a manufacturer, we recommend searching the catalog first.)

The search returns a list of possible matches. Using the results of your search, take one of the following steps:

-   If you see a match for your product, click **Sell Yours**. You don't need to type in the product details since our catalog provides them. Instead, just enter your price, quantity, and other details relevant to your specific listing. See [List your inventory](https://sellercentral.amazon.com/gp/help/G200220550) for more information.
-   If you get too many results, you can narrow your results using the category filters on the left side of the page.
-   If the product you want to list has variations, click **Show Variations** to select the exact version (size, color, etc.) of the product that corresponds to your item.
-   If you aren't sure you have a match, click **See all product details** to see more information.

If you do not find a match for your product or cannot find the correct version of your product, click **Create a new product** to add the product to the Amazon catalog.
