# Eligible ASINs

Source: https://sellercentral.amazon.com/gp/help/external/G202111490

This article applies to selling in: **United States**

#  Make your products eligible for Deals

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202111490)

On this page

How can I become eligible?

Which products are eligible for deals?

Useful tips

A Lightning Deal is a time-bound, promotional offer where an item is featured
for a limited number of hours, usually 4 to 12 hours (as determined by
Amazon), on the [ Amazon Deals ](https://www.amazon.com/deals) page. Featuring
an item as a Lightning Deal may help increase sales and reduce your inventory.
Learn how to use Lightning Deals to help improve your [ brand awareness and
sales
](/learn/courses?ref_=su_home_c3_m346&courseId=3&moduleId=346&modLanguage=English)
.

A Best Deal is a time-bound, promotional offer where an item is featured for a
limited number of days on the [ Amazon Deals ](https://www.amazon.com/deals)
page.

To be eligible for deals, you must be a professional seller an overall rating
of at least 3.5-stars. Additionally, products must meet these criteria:

  * Have a sales history in Amazon stores and at least a 3-star rating. 
  * Include as many variations as possible. 
  * Not be a restricted product or offensive, embarrassing or inappropriate product. 
  * Be Prime eligible in all regions. 
  * New condition. 
  * Be compliant with customer product reviews policies.  To learn more, go to [ Customer product reviews policies ](/gp/help/external/YRKB5RU3FS5TURN) . 
  * Compliant with pricing policies  and have a valid reference price  .  For more information, go to  [ Show a reference price on your products ](/gp/help/external/G27XM55CQM3SBMD2) and  [ Amazon Policy on Reference Prices ](/gp/help/external/G202170370) . 
  * Compliant with deal frequency requirement. To learn more, go to [ Create a Deal ](/gp/help/external/202111550) . 

**Note:** If your product is approved for a deal and then it violates the
above criteria, your deal will be canceled immediately and you might not be
eligible for a refund of your deal fees and all future deal eligibility may be
removed indefinitely.

You can create two types of deals: Lightning Deal and Best Deal.

If you meet the criteria for a deal:

  1. In the **Deals** dashboard, click [ Create a new deal ](/merchandising-new/create) . 

  2. Select a product in your inventory and click **Select** . 

  3. Enter the **Schedule** , and click **Continue to next step** . 

  4. Click **Continue to next step** . 

  5. Click **Submit Deal** . 

##  How can I become eligible?

Currently, only professional sellers are eligible to run deals. Here's how you
can [ upgrade ](/gp/help/external/201747610) .

##  Which products are eligible for deals?

Eligible products are automatically displayed in the **Eligible ASINs**
section of the **Deals Dashboard** when they meet the following criteria
(subject to change based on country and time of year):

**Note:** Because of other criteria that Amazon is unable to disclose, it is
possible that certain ASINs may not receive a recommendation although they
meet the criteria listed above.

You can choose to [ Create a Deal ](/gp/help/external/202111550) from the list
of eligible ASINs in the **Select Products** tab of the **Deals Dashboard** .
Eligible ASINs are refreshed every week, so an eligible ASIN you see this week
may not necessarily be there next week.

You can choose to [ Create a deal
](https://sellercentral.amazon.com.au/gp/help/external/202111550) from the
list of eligible ASINs in the **Select Products** tab of the **Deals
Dashboard** . If you do not see a particular ASIN on the Deals Dashboard, this
means it may not currently eligible to be a Deal. Eligible ASINs are refreshed
every week, so a Deal you see this week may not necessarily be there next
week. You can also consider other options, such as [ Coupons
](/gp/help/external/G202189350) and [ Promotions ](/gp/help/external/G60951) ,
if your product is not currently eligible for Deals.

##  Useful tips

  * Convert your products to [ FBA ](https://sellercentral.amazon.com/learn/courses?ref_=su_courses_c8_m38&courseId=8&moduleId=38&modLanguage=English&videoPlayer=youtube) or enroll in [ Seller Fulfilled Prime ](/learn/courses?ref_=su_courses_c110_m321&courseId=110&moduleId=321&modLanguage=English&videoPlayer=youtube) . 
  * Leverage the [ Account Health Dashboard ](/performance/dashboard?_encoding=UTF8&ref_=ag_srsumprf_anav_srnavbar) and [ Customer Feedback Manager ](/gp/seller-rating/pages/feedback-manager.html?ref=sp_st_nav_sphcfdbk) to ensure your account is in good standing and is maintaining a high feedback rating. 

Top

