# Fulfillment fees for Multi-Channel Fulfillment orders

Source: https://sellercentral.amazon.com/gp/help/external/201112650

This article applies to selling in: **United States**

#  Fulfillment fees for Multi-Channel Fulfillment orders

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201112650)

On this page

Calculate fees

Single-unit order examples

Multi-unit order examples

Fulfillment fees (per unit)

**Note:** From October 15, 2022, to January 14, 2023, a holiday peak
fulfillment fee will be applied to all Multi-Channel Fulfillment (MCF) orders
in the US. On January 15, 2023, FBA fulfillment fees will revert back to the
non-peak period rates. You can view the non-peak period rates below. To view
our peak period rates, go to [ 2022 MCF holiday peak fulfillment fee
](/gp/help/external/GU9APCGF6KETA8WC) .

**Note:** Starting January 19, 2023, MCF fulfillment fees will change. For
more information, go to [ 2023 US Multi-Channel Fulfillment fee changes
](/gp/help/external/GJBDKUZXFX2VCVGG) .

**Note:** Effective August 1, 2022, orders going to Hawaii, Puerto Rico, the
Virgin Islands, and Alaska will include a surcharge of 100% for standard-sized
items, and 200% for oversized items.

On this page, you will learn how to calculate fulfillment fees for orders
placed on websites other than Amazon. You will also learn how to determine
your product’s size tier and shipping weight. Learn more about our ship speeds
by going to [ Multi-Channel Fulfillment: Fulfill orders for your sales
channels ](/gp/help/external/G200332450) .

**Note:** You can preview your per-unit MCF fees with our fee calculator. To
download the calculator template, go to [ Multi-Channel Fulfillment
](/mcf?#fees) and click the **Fee Calculator** tab. You can also preview your
MCF fees by integrating your website with our [ preview API
](https://github.com/amzn/selling-partner-api-
docs/blob/main/references/fulfillment-outbound-
api/fulfillmentOutbound_2020-07-01.md#getfulfillmentpreview) .

##  Calculate fees

  1. Determine the [ product volume and dimensions ](/gp/help/external/G37G73BJXHF75ACH) of the item. 

  2. Determine the [ product size tier ](/gp/help/external/G5KW835AHDJCH8W) of the item. 

  3. Determine the unit weight of the item. 

  4. Determine the [ dimensional weight ](/gp/help/external/G53Z9EKF8VVZVH29) and if it is used to calculate the fees for the item. 

  5. Determine the [ shipping weight ](/gp/help/external/GEVWP48HPBLEFJEY) of the item. 

##  Single-unit order examples

The following product examples illustrate the MCF fee structure for single-
unit orders.

Small standard size (2 to 6 oz)  
---  
|

**Mobile device case**

Dimensions: 13.8 x 9 x 0.7 inches

Unit weight: 2.88 oz

Rounded shipping weight: 3 oz  
  
**Standard** |  $5.35  
**Expedited** |  $8.15  
**Priority** |  $16.64  
  
Large standard-size apparel (6 to 12 oz)  
---  
|

**T-shirt**

Dimensions: 14 x 10 x 0.76 inches

Dimensional weight: 12.24 oz

Unit weight:12.32 oz

Rounded shipping weight: 13 oz  
  
**Standard** |  $7.45  
**Expedited** |  $10.00  
**Priority** |  $17.95  
  
Large standard size (over 3 lb)  
---  
|

**Iron**

Dimensions: 12.6 x 6.6 x 5.5 inches

Dimensional weight: 3.3 lb

Unit weight: 3.35 lb

Rounded shipping weight: 4 lb  
  
**Standard** |  $8.57  
**Expedited** |  $10.98  
**Priority** |  $19.00  
  
Small oversize  
---  
|

**Baby cot**

Dimensions: 24 x 7.5 x 6 inches

Dimensional weight: 7.8 lb

Unit weight: 7.90 lb

Rounded shipping weight: 8 lb  
  
**Standard** |  $15.26  
**Expedited** |  $17.43  
**Priority** |  $30.05  
  
Large oversize  
---  
|

**Monitor**

Dimensions: 54 x 35 x 3.5 inches  1

Dimensional weight: 47.6 lb

Unit weight: 41 lb

Rounded shipping weight: 48 lb  2  
  
**Standard** |  $103.39  
**Expedited** |  $122.99  
**Priority** |  $167.00  
1  This product’s length plus girth is 131 inches, which puts it in the large
oversize tier.

2  This weight is calculated based on the product’s dimensional weight, which
is 47.6 lb and greater than the unit weight.

##  Multi-unit order examples

The following product examples illustrate the MCF fee structure for multi-unit
orders.

Two-unit order for different products  
---  
|

**Mobile device case: Small standard-size (2 to 6 oz)**

**T-shirt: Large standard-size (12 to 16 oz)**  
  
**Shipping speed** |  **Mobile device case fee** |  **T-shirt fee** |
**Total**  
**Standard** |  $3.80  |  $5.15  |  $8.95  
**Expedited** |  $5.35  |  $6.35  |  $11.70  
**Priority** |  $9.10  |  $10.00  |  $19.10  
  
Two-unit order for the same product  
---  
|  **T-shirt: Large standard-size (12 to 16 oz)**  
**Shipping speed** |  **T-shirt fee** |  **T-shirt fee** |  **Total**  
**Standard** |  $5.15  |  $5.15  |  $10.30  
**Expedited** |  $6.35  |  $6.35  |  $12.70  
**Priority** |  $10.00  |  $10.00  |  $20.00  
  
##  Fulfillment fees (per unit)

The below fees apply to MCF orders shipped within the US. Go to [ FBA Export
](/gp/help/external/G200804980) for pricing to ship internationally.

**Note:** All non-fulfillment fees, like storage and labeling, will continue
to be the same for MCF as for Fulfillment by Amazon (FBA). For more
information on FBA fees, go to [ FBA features and fees
](/gp/help/external/G201074400) .

Standard 3- to 5-day shipping  
---  
Size tier  |  1-unit order  |  2-unit order  |  3-unit order  |  4-unit order
|  5+ unit order  
**Small standard: 2 oz or less** |  $4.75  |  $3.00  |  $2.65  |  $2.08  |
$1.97  
**Small standard: 2 to 6 oz** |  $5.35  |  $3.80  |  $3.29  |  $2.50  |  $2.30  
**Small standard: 6 to 12 oz** |  $6.20  |  $4.50  |  $3.90  |  $3.30  |
$2.60  
**Small standard: 12 to 16 oz** |  $7.45  |  $5.15  |  $4.45  |  $3.80  |
$2.70  
**Large standard: 2 oz or less** |  $4.75  |  $3.00  |  $2.65  |  $2.08  |
$1.97  
**Large standard: 2 to 6 oz** |  $5.35  |  $3.80  |  $3.29  |  $2.65  |  $2.30  
**Large standard: 6 to 12 oz** |  $6.20  |  $4.50  |  $3.90  |  $3.30  |
$2.60  
**Large standard: 12 to 16 oz** |  $7.45  |  $5.15  |  $4.45  |  $3.80  |
$2.70  
**Large standard: 1 to 2 lb** |  $7.65  |  $5.22  |  $4.55  |  $4.00  |  $3.10  
**Large standard: Above 2 lb** |  $7.65 + $0.46/lb  |  $5.22 + $0.46/lb  |
$4.55 + $0.46/lb  |  $4.00 + $0.46/lb  |  $3.10 + $0.46/lb  
**Small oversize: 2 to 30 lb** |  $12.50 + $0.46/lb  |  $8.99 + $0.46/lb  |
$7.65 + $0.46/lb  |  $6.35 + $0.46/lb  |  $5.00 + $0.46/lb  
**Small oversize: Above 30 lb** |  $24.70 + $0.46/lb  
**Medium oversize: Above first 2 lb** |  $20.20 + $0.51/lb  
**Large oversize: Above first 90 lb** |  $103.39 + $1.05/lb  
**Special oversize: Above first 90 lb** |  $171.99 + $1.10/lb  
  
Expedited 2-day shipping  
---  
Size tier  |  1-unit order  |  2-unit order  |  3-unit order  |  4-unit order
|  5+ unit order  
**Small standard: 2 oz or less** |  $8.10  |  $4.65  |  $4.00  |  $2.80  |
$2.30  
**Small standard: 2 to 6 oz** |  $8.15  |  $5.35  |  $4.00  |  $3.35  |  $2.35  
**Small standard: 6 to 12 oz** |  $8.40  |  $5.85  |  $4.49  |  $3.60  |
$2.79  
**Small standard: 12 to 16 oz** |  $10.00  |  $6.35  |  $5.10  |  $4.20  |
$3.15  
**Large standard: 2 oz or less** |  $8.29  |  $4.65  |  $4.10  |  $2.89  |
$2.30  
**Large standard: 2 to 6 oz** |  $8.29  |  $5.35  |  $4.15  |  $3.39  |  $2.35  
**Large standard: 6 to 12 oz** |  $9.00  |  $5.85  |  $4.65  |  $3.60  |
$2.79  
**Large standard: 12 to 16 oz** |  $10.00  |  $6.35  |  $5.10  |  $4.20  |
$3.15  
**Large standard: 1 to 2 lb** |  $10.00  |  $6.95  |  $5.25  |  $4.30  |
$3.70  
**Large standard: Above 2 lb** |  $10.00 + $0.49/lb  |  $6.95 + $0.49/lb  |
$5.25 + $0.49/lb  |  $4.30 + $0.49/lb  |  $3.70 + $0.49/lb  
**Small oversize: 2 to 30 lb** |  $14.49 + $0.49/lb  |  $10.29 + $0.49/lb  |
$9.65 + $0.49/lb  |  $9.35 + $0.49/lb  |  $9.05 + $0.49/lb  
**Small oversize: Above 30 lb** |  $30.69 + $0.49/lb  
**Medium oversize: Above first 2 lb** |  $24.05 + $0.51/lb  
**Large oversize: Above first 90 lb** |  $122.99 + $1.14/lb  
**Special oversize: Above first 90 lb** |  $204.77+ $1.20/lb  
  
Priority 1-day shipping  
---  
Size tier  |  1-unit order  |  2-unit order  |  3-unit order  |  4-unit order
|  5+ unit order  
**Small standard: 16 oz or less** |  $16.64  |  $9.10  |  $6.85  |  $6.35  |
$5.10  
**Large standard: 16 oz or less** |  $17.95  |  $10.00  |  $8.15  |  $7.50  |
$5.20  
**Large standard: 1 to 2 lb** |  $18.00  |  $10.20  |  $8.90  |  $7.75  |
$6.25  
**Large standard: Above 2 lb** |  $18.00 + $0.50/lb  |  $10.20 + $0.50/lb  |
$8.90 + $0.50/lb  |  $7.75 + $0.50/lb  |  $6.25 + $0.50/lb  
**Small oversize: Above first 2 lb** |  $27.05 + $0.50/lb  |  $14.69 +
$0.50/lb  |  $11.30 + $0.50/lb  |  $10.70 + $0.50/lb  |  $10.25 + $0.50/lb  
**Small oversize: Above 30 lb** |  $41.70 + $0.50/lb  
**Medium oversize: Above first 2 lb** |  $32.68 + $0.51/lb  
**Large oversize: Above first 90 lb** |  $167.00 + $1.14/lb  
**Special oversize: Above first 90 lb** |  $278.15 + $1.20/lb  
  
Top

