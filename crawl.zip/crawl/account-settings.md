# Account settings

Source: https://sellercentral.amazon.com/help/hub/reference/external/G181

This article applies to selling in: **United States**

#  Account settings

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG181)

You can manage all of your account information like payment information,
business information, shipping and return information, and tax information
using Account Settings. If you are new to Selling on Amazon, see [ What you
need to know to sell on Amazon ](/gp/help/external/G200421970) .

  * To access your account settings: Go to Seller Central and click **Settings** . Click [ Account Info ](https://sellercentral.amazon.com/hz/sc/account-information/ref=xx_acctinfo_dnav_xx) . See [ Add, view, and update your bank account information ](/gp/help/external/GWHNLFB8G85QAZ5W) for more information. 
  * If you want to temporarily deactivate your listings, see [ Listing status for vacations, holidays, or other absences ](/gp/help/external/G200135620) . 
  * If you want to permanently close your account, see [ Close your seller account ](/gp/help/external/G200399470) . 

To learn about Seller Central first steps, watch this Seller University video:

Top

##  Account settings

* [ Selling on Amazon  ](/help/hub/reference/external/G200421970)
* [ Get Started with Selling Services  ](/help/hub/reference/external/G201484560)
* [ Global seller identity verification  ](/help/hub/reference/external/GQRP483PDN88Q3M9)
* [ Two-Step Verification  ](/help/hub/reference/external/G202110760)
* [ Manage account settings  ](/help/hub/reference/external/G69035)
* [ Seller-fulfilled shipping  ](/help/hub/reference/external/G200342080)
* [ Selling on Amazon video tutorials  ](/help/hub/reference/external/G201813650)
* [ Bank account and credit card information for your seller account  ](/help/hub/reference/external/G19791)
* [ Selling on Amazon reference  ](/help/hub/reference/external/G69036)

