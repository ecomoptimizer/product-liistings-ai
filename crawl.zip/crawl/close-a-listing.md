# Close a listing

Source: https://sellercentral.amazon.com/gp/help/external/DJZDBNYUAS8C7QB

This article applies to selling in: **United States**

#  Close a listing

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FDJZDBNYUAS8C7QB)

You can close a listing at any time, up until the time of purchase. This
action does not remove the record from your inventory. The SKU and all listing
information for the item are retained. Additionally, a listing can be re-
listed (or reactivated) at any time. There is no fee associated with closing a
listing.

To manage product listings, do the following:

  1. On the **Inventory** menu, select **Manage All Inventory** . 

  2. On the Manage Inventory page, select the **Active** status filter above the product list. 

  3. Find the listing you want to close and select **Close listing** from the drop-down menu in the same row. 

Your listing should appear as Inactive within 24 hours.

**Note:** This will close your listing automatically, without confirmation.
You can re-list or reactivate your listing at any time.

Top

