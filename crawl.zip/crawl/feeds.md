# Feeds

Source: https://sellercentral.amazon.com/gp/help/external/201951010

This article applies to selling in: **United States**

#  Feeds

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201951010)

##  You are registered with Release Package 4.1

Use the following template versions.

File templates  |  Style guides  |  Browse Tree Guide (BTG)  |  [ Approval
required ](/gp/help/external/200333160)  
---|---|---|---  
[ Automotive & Powersports (Parts & Accessories)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.AutoAccessory.xlsm)

[ Automotive & Powersports (Tires & Wheels)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.TiresAndWheels.xlsm)

|  [ Automotive & Powersports (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/Style_guide_Automotive_Powersports_Final.pdf)

[ Motorcycles & ATVs (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/Motorcycle_ATV_Style_Guide.pdf)

|  [ Automotive and Powersports BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/automotive_browse_tree_guide.xls) |  [
View requirements ](/gp/help/external/G200164410)  
[ Baby ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Baby.xlsm) |  [ Baby (PDF) ](https://m.media-
amazon.com/images/G/01/01/help/images/Baby.pdf) |  [ Baby BTG
](https://images-na.ssl-images-amazon.com/images/G/01/rainier/help/btg/baby-
products_browse_tree_guide.xls) |  No  
[ Beauty ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Beauty.xlsm) |  [ Beauty (PDF) ](https://m.media-
amazon.com/images/G/01/01/help/images/Beauty.pdf) |  [ Beauty BTG
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/beauty_browse_tree_guide.xls) |  No  
[ Books ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.BookLoader.xlsm) |  [ Use Book Loader
](/help/hub/reference/external/G200390640)

[ Use UIEE Format to List Books ](/gp/help/external/201576610)

|  [ Books BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/books_browse_tree_guide.xls) |  For
Books, approval is required only for listing in "Collectible" condition. Learn
more about [ Collectible Books ](/gp/help/external/200386320) .  
[ Camera & Photo ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.CameraAndPhoto.xlsm) |  See Consumer Electronics.
|  See Consumer Electronics.  |  No  
[ Cell Phones & Accessories (Wireless) ](https://s3.amazonaws.com/category-
custom-templates/ff/na/us/Flat.File.Wireless.xlsm) |  See Consumer
Electronics.  |  [ Cell Phone & Accessories BTG ](https://images-na.ssl-
images-amazon.com/images/G/01/rainier/help/btg/cell-
phones_browse_tree_guide.xls) |  No  
[ Clothing & Accessories ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Clothing.xlsm) |  [ Clothing & Accessories (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01//rainier/help/style//ClothingStyleGuide._CB1198675309_.pdf)
|  [ Clothing & Accessories BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/fashion_browse_tree_guide.xls) |  No  
[ Collectible Coins ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Coins.xlsm) |  [ Collectible Coins (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/CoinsStyleGuide._V336345069_.pdf) |  There is
no separate BTG available for this category.  |  [ View requirements
](/gp/help/external/201526800)  
[ Computers ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Computers.xlsm) |  See Consumer Electronics.  |
See Consumer Electronics.  |  No  
[ Consumer Electronics ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.ConsumerElectronics.xlsm) |  [ Consumer
Electronics (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/CEStyleGuide.pdf)

[ Consumer Electronics Store Style Guide ](/gp/help/external/200288470)

|  [ Consumer Electronics BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/electronics_browse_tree_guide.xls) |
No  
[ Entertainment Collectibles ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.EntertainmentCollectibles.xlsm) |  [
Entertainment Collectibles (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/EntertainmentCollectiblesStyleGuide.pdf) |
BTG available upon approval to sell in this category.  |  [ View requirements
](/gp/help/external/200944120)  
Eyewear (See [ Clothing & Accessories ](https://s3.amazonaws.com/category-
custom-templates/ff/na/us/Flat.File.Clothing.xlsm) )  |  [ Eyewear
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/Eyewear_Style_Guide.pdf) |  [ Clothing &
Accessories BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/fashion_browse_tree_guide.xls) |  No  
Fine Art - Inventory File Template available upon approval to sell in this
category.  |  [ Fine Art (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/FineArtStyleGuide.pdf) |  BTG available
upon approval to sell in this category.  |  [ View requirements
](/gp/help/external/201257400)  
[ Furniture ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Home.xlsm) \- For product type, select Furniture
|  See Home & Garden.  |  [ Home & Kitchen BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/home-
kitchen_browse_tree_guide._TTH_.xls) |  No  
[ Gift Cards ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.GiftCards.xlsm) |  [ Gift Cards (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/GiftCardStyleGuide512.pdf) |  BTG available
upon approval to sell in this category.  |  No  
[ Grocery & Gourmet Food ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.FoodAndBeverages.xlsm) |  [ Grocery & Gourmet
Food (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/SellerCentral/GroceryStyleGuide.pdf) |  [ Grocery &
Gourmet Food BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/grocery_browse_tree_guide._TTH_.xls) |
[ View requirements ](/gp/help/external/201511970)  
[ Health & Personal Care ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Health.xlsm ) |  [ Health & Personal Care (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01/SellerCentral/HPCStyleGuide.pdf) |  [ Health & Personal
Care BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/health_browse_tree_guide.xls) |  No  
[ Home, Home Decor, Kitchen & Garden ](https://s3.amazonaws.com/category-
custom-templates/ff/na/us/Flat.File.Home.xlsm) |  [ Home & Garden (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/Home_Garden_and_Pets-Style_Guide.pdf) |  [
Home & Kitchen BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/home-
kitchen_browse_tree_guide._TTH_.xls)

[ Patio, Lawn & Garden BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/garden_browse_tree_guide.xls)

[ Arts, Crafts & Sewing BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/arts-and-
crafts_browse_tree_guide._TTH_.xls)

|  No  
[ Industrial & Scientific (Fasteners) ](https://s3.amazonaws.com/category-
custom-templates/ff/na/us/Flat.File.MechanicalFasteners.xlsm)

[ Industrial & Scientific (Food Service and Janitorial, Sanitation, & Safety)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.FoodServiceAndJanSan.xlsm)

[ Industrial & Scientific (Lab & Scientific Supplies)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.LabSupplies.xlsm)

[ Industrial & Scientific (Power Transmission)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.PowerTransmission.xlsm)

[ Industrial & Scientific (Raw Materials) ](https://s3.amazonaws.com/category-
custom-templates/ff/na/us/Flat.File.RawMaterials.xlsm)

[ Industrial & Scientific (Industrial and Other)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Industrial.xlsm)

|  [ Industrial & Scientific (PDF) ](https://m.media-
amazon.com/images/G/01/01/help/images/Industrial__Scientific.pdf) |  [
Industrial & Scientific BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/industrial_browse_tree_guide._TTH_.xls)
|  [ Selling Guidelines ](/gp/help/external/201847780)  
[ Jewelry ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Jewelry.xlsm) |  [ Jewelry (PDF)
](https://m.media-amazon.com/images/G/01/01/help/images/Jewelry.pdf) |  [
Jewelry BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/fashion_browse_tree_guide.xls) |  [
View requirements ](/gp/help/external/200332590)  
[ Lighting ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Lighting.xlsm) |  [ Lighting (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/LightingStyleGuide.pdf) |  See Tools &
Home Improvement.  |  No  
[ Luggage & Travel Accessories ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Clothing.xlsm) |  [ Luggage & Travel Accessories
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/Luggage_Style_Guide.pdf) |  There is no
separate BTG available for this category.  |  No  
Motorcycles & ATVs (See Automotive Parts & Accessories)  |

|

|  [ View requirements ](/help/hub/reference/external/G200584550)  
[ Music ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Music.xlsm) |  [ Music Loader Instructions
](/help/hub/reference/external/G201576580) |  There is no separate BTG
available for this category.  |  [ View requirements
](/help/hub/reference/external/202188990)  
[ Musical Instruments ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.MusicalInstruments.xlsm) |  See Consumer
Electronics.  |  [ Musical Instruments BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/musical-
instruments_browse_tree_guide._TTH_.xls) |  [ Selling Guidelines
](/gp/help/external/201638040)  
[ Office Products ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Office.xlsm) |  See Consumer Electronics.  |  [
Office Products BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/office-products_browse_tree_guide.xls)
|  No  
[ Outdoors (Outdoor Gear, Outdoor Sports Apparel, Cycling, and Action Sports)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Outdoors.xlsm) |  [ Outdoors (PDF)
](https://images-na.ssl-images-
amazon.com/images/G/01//rainier/help/style//SportsOutdoors._CB1198675309_.pdf)
|  [ Outdoors BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/sporting-
goods_browse_tree_guide._TTH_.xls) |  No  
[ Pet Supplies ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.PetSupplies.xlsm) |  See Home & Garden.  |  [ Pet
Supplies BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/pet-supplies_browse_tree_guide.xls) |
No  
[ Shoes, Handbags & Sunglasses ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Shoes.xlsm) |  [ Handbags ](https://images-
na.ssl-images-amazon.com/images/G/01/rainier/help/Handbags_Style_Guide.pdf)

[ Shoes & Accessories (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01//rainier/help/style//ShoesStyleGuide._CB1198675309_.pdf)

|  [ Clothing & Accessories BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/fashion_browse_tree_guide.xls) |  No  
[ Software & Video Games ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.SoftwareVideoGames.xlsm) |  [ Software & Video
Games ](/help/hub/reference/external/G200390640) |  [ Software BTG
](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/software_browse_tree_guide.xls)

[ Video Games BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/videogames_browse_tree_guide.xls)

|  [ View requirements ](/help/hub/reference/external/GP9BGQD68HQ5V4YF)  
[ Sports (Exercise & Fitness, Hunting Accessories, Team Sports, Licensed Fan
Shop, Athletic Apparel, Boating & Fishing, and Game Room)
](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Sports.xlsm) |  [ Sports (PDF) ](https://images-
na.ssl-images-
amazon.com/images/G/01/rainer/help/sportinggoods_style_guide.pdf)

[ Selling Sports Apparel ](/gp/help/external/200626260)

|  [ Sports BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/sporting-
goods_browse_tree_guide._TTH_.xls) |  No  
[ Sports Collectibles ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.SportsMemorabilia.xlsm)

[ Trading Cards ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.TradingCards.xlsm)

|  [ Sports Collectibles ](/gp/help/external/200800780) |  BTG available upon
approval to sell in this category.  |  [ View requirements
](/gp/help/external/200800780)  
[ Tools & Home Improvement ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.HomeImprovement.xlsm) |  [ Tools & Home
Improvement (PDF) ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/ToolsAndHomeImprovement_StyleGuide.pdf) |
[ Tools & Home Improvement BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/home-
improvement_browse_tree_guide.xls) |  No  
[ Toys & Games ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Toys.xlsm) |  [ Toys (PDF) ](https://m.media-
amazon.com/images/G/01/01/help/images/Toys__Games.pdf) |  [ Toys & Games BTG
](https://images-na.ssl-images-amazon.com/images/G/01/rainier/help/btg/toys-
and-games_browse_tree_guide.xls) |  No  
[ Video & DVD ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Video.xlsm) |  [ Video Loader Instructions
](/help/hub/reference/external/G200482410) |  There is no separate BTG
available for this category.  |  [ View requirements
](/help/hub/reference/external/202188990)  
[ Watches ](https://s3.amazonaws.com/category-custom-
templates/ff/na/us/Flat.File.Watches.xlsm) |  [ Watches (PDF)
](https://m.media-amazon.com/images/G/01/01/help/images/Watches.pdf) |  [
Watches BTG ](https://images-na.ssl-images-
amazon.com/images/G/01/rainier/help/btg/watches_browse_tree_guide.xls) |  [
Apply to sell ](/hz/approvalrequest/approve?input-
value=gl_watch&workflow=98ca856e-95ee-407c-acf9-2d1394f6fafb&input-
type=gl&application-id=b6b33d17-eb78-e30a-2489-6689fe278526)  
  
Top

