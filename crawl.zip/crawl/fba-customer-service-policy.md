# FBA customer service policy

Source: https://sellercentral.amazon.com/gp/help/external/G200298130

This article applies to selling in: **United States**

#  FBA customer service

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200298130)

Your Fulfillment by Amazon listings are displayed with the FBA logo, so
customers know that Amazon will handle fulfillment and customer service for
their orders.

Our world-class customer service team saves you time by managing customer
inquiries, refunds, and returns for FBA items bought on the Amazon store.
There is no extra charge for this service, except for certain product
categories including apparel and jewelry.  For more information, go to [
Returns processing fee ](/gp/help/external/G64LS955WNFT6EDP) .

**Note:** [ Multi-Channel Fulfillment ](/gp/help/external/G200332450) orders
are not eligible for Amazon customer service.

FBA’s online Returns Center provides customers with help pages and details
about how to contact us for refunds and returns.  See the [ FBA customer
returns policy ](/gp/help/external/G200379860) for more information about how
Amazon handles returns, refunds, and reimbursements.

**Note:** For FBA orders, the [ Buyer-Seller Messages
](/gp/help/external/G200389080) service is for product inquiries only. Any
customer service inquiries should be directed to Amazon customer service.

Top

##  FBA customer service

* [ Customer Experience for Products Fulfilled by Amazon  ](/help/hub/reference/external/G201229050)

