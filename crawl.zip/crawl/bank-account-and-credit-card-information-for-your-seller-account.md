# Bank account and credit card information for your seller account

Source: https://sellercentral.amazon.com/help/hub/reference/external/G19791

This article applies to selling in: **United States**

#  Bank account and credit card information for your seller account

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG19791)

When you register as a seller, you must enter a credit card that will accept
international charges and that has a valid billing address located in an [
eligible country ](/gp/help/external/G200405020) . Your credit card will be
billed the monthly fee (if applicable) or USD 1 (excl. VAT) for purposes of
validating the card. For more information, go to [ Registration requirements
by country ](/gp/help/external/G201468460) .

Use the tool below to find out why your credit card information might be
invalid and to update your credit card:

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG19791)

You may be redirected to a financial institution to verify your card with a
security question to verify your identity, before being redirected back to
Amazon. You may need to address a separate security question to verify that
you are the card holder for each card that you provide to Amazon, and for each
market you would like to sell in.

**Note:** We may periodically run a validation check on your credit card.

##  Accepted credit cards

We accept the following credit cards:

  * American Express 
  * Diners Club 
  * Discover 
  * JCB 
  * MasterCard 
  * Visa 

**Note:** We do not accept alternative charge methods, such as prepaid credit
cards, gift certificates, checks, or online payment systems like PayPal.

You cannot delete the credit card that you designated as your primary payment
method, but you can add a new card or select a different card from the list of
cards you have entered in your seller account. You can also designate another
card as your primary payment method, in order to delete your former primary
payment method.

If you have a positive settlement balance, Amazon will deposit the money into
your bank account. We cannot transfer funds to your credit card. We may charge
this credit card if you have a negative settlement balance. For verification
related issues or to know how to add and delete your credit card in an Amazon
store, go to [ Add, delete, and verify your credit card information
](/gp/help/external/GUQLF3C3HXXXERLC) .

##  Bank account information

Amazon uses electronic transfers to pay out your sales proceeds. Before you
can receive payments, you have to enter bank account information into your
seller account. We cannot transfer funds to a credit card or online payment
system such as PayPal.

To avoid payment delays:

  * Your seller account must have a [ business address ](/gp/help/external/841) associated with it. 
  * Your bank account must be located in a country supported by the [ Amazon Currency Converter ](/gp/help/external/G200497780) . 
  * Your bank account information must be up to date. 

You can use the Amazon Currency Converter service to register a bank account
that is located in a different country from the store where you are selling.
For more information, go to [ Amazon Currency Converter for Sellers (ACCS)
](/gp/help/external/G200381250) .

Top

##  Bank account and credit card information for your seller account

* [ Add, view, and update your bank account information  ](/help/hub/reference/external/GWHNLFB8G85QAZ5W)
* [ Adding more than one bank account  ](/help/hub/reference/external/GW2QZPWB284AMMSM)
* [ Update credit card information  ](/help/hub/reference/external/G202131360)
* [ Add, delete, and verify your credit card information  ](/help/hub/reference/external/GUQLF3C3HXXXERLC)

