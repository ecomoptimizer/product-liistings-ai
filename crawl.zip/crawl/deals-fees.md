# Deals fees

Source: https://sellercentral.amazon.com/gp/help/external/202111590

This article applies to selling in: **United States**

#  Deal Fees

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202111590)

On this page

What is the fee and where can I see it?

Fee ranges

When will I be charged?

Will Amazon charge me if my deal does not perform well?

Will Amazon charge me for a canceled Deal?

Deals are flash sales where a product is featured for several hours on the [
Amazon Deals ](https://www.amazon.com/gp/goldbox) page, one of the most
visited pages on Amazon.  Best Deals are also featured on the Amazon Deals
page for up to seven days at a time.  Featuring a product as a Deal or a Best
Deal might help increase sales, and it can also be an effective way to reduce
your inventory. There is a fee required to run a Deal or a Best Deal.

##  What is the fee and where can I see it?

You will be charged for each Lightning Deal or a Best Deal that is submitted
and has successfully run. The fee is displayed as part of the deal creation
work flow when you select the schedule for the deal.

**What doesn't affect the fee:** Changes to the number of variations,
quantity, and price.

**What affects the fee:** The country in which you run the deal and the week
you choose to run the deal.

**Note:** If applicable, you might be taxed based on the tax rules of the
respective country.

##  Fee ranges

The fee for your Lightning Deal or Best Deal might change depending on the
date on which your deal runs. The weeks with higher fees are a time period
during which customer traffic to Amazon is significantly higher, leading to
greater exposure and potential sales for your deal.

If your deal is scheduled during this higher traffic time period, you will be
charged a higher fee, which will be displayed on the **Deal** page. If you are
unsatisfied with the resulting fee, you can [ cancel the Deal
](/gp/help/external/G202111610) .

##  When will I be charged?

You will be charged after a deal runs on its scheduled date and time. When the
fee is processed, it will show up as a [ Deal Fee transaction ](/gp/payments-
account/view-transactions.html) on your Seller Central statement ( **Seller
Central** > **Reports** > **Payments** > **Transaction View** > **Service
Fees** ). The fee will be deducted from your account, similar to [ FBA fees
](/gp/help/external/G201074400) . You can view additional details, such as
which deal is associated with the fee, by clicking on the amount in the
**Total** column.

##  Will Amazon charge me if my deal does not perform well?

Amazon does not guarantee sales from running a deal, nor provides refunds if
your deal does not perform well. Additionally, running a deal does not
guarantee that you'll be the Featured Offer.

If you were incorrectly charged a deal fee for a deal that did not run,
contact Selling Partner Support within 30 days of the scheduled run time for
possible refund consideration.

##  Will Amazon charge me for a canceled Deal?

Amazon will not charge you if:

  * You cancel the deal before the scheduled start time. 
  * Amazon cancels the deal before the scheduled start time. 

You will be charged the full fee if you cancel a deal while it is running.

Top

