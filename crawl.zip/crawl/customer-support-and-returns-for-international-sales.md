# Customer support and returns for international sales

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201468530

This article applies to selling in: **United States**

#  Customer support and returns for international sales

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201468530)

Amazon has set high standards for itself and sellers when it comes to customer
focus. A great shopping experience for customers includes finding and ordering
products with ease, getting fast and free shipping, and providing excellent
customer support on orders and returns.

In this section we will cover customer support and customer returns.  As
presented in previous sections, you have two options to fulfill your
international orders: you can do it on your own or you can use Fulfillment by
Amazon (FBA).  Your fulfillment method will determine how you provide customer
support and handle returns. Let's look at how you can provide excellent
customer support based on the fulfillment options you use.

Top

##  Customer support and returns for international sales

* [ Customer Support for International Sales  ](/help/hub/reference/external/G201468540)
* [ Customer returns for international sales  ](/help/hub/reference/external/G201468550)

