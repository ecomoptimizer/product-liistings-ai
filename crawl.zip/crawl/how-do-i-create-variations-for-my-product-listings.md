# How do I create variations for my product listings

Source:https://sellercentral.amazon.com/help/hub/reference/G202009940



---
How do I create variations for my product listings

1.  On the Inventory tab, select **Add Products via Upload.**
2.  Download the appropriate inventory file template.
3.  Refer to the **Valid Values** tab in the template to see what variation themes are available.  
    Note: If no variation theme is listed, you cannot create a product with variations in that category.
4.  In the inventory template, create parent and child SKUs.
5.  On the parent item:
    1.  Enter values for required fields, including **SKU**.
    2.  Leave **Parent SKU** blank.
    3.  Enter a value for "parent" in **Parentage** and enter a valid value in **Variation Theme**.
    4.  Leave **Relationship Type** blank.
    5.  Leave all other non-required fields blank.
6.  For each child item:
    1.  Enter values for required fields.
    2.  Fill in the **Parent SKU** field using the value from the parent's SKU (value will be the same for all child items).
    3.  Enter "child" in **Parentage**, and enter "variation" in **Relationship Type**.
    4.  In the **Variation Theme** field, enter the same value that you entered for Variation Theme on the parent (value will be the same for all child items).
    5.  Enter values in attribute column(s) related to the variation theme (for example, if the variation theme is flavor-size, you must enter valid values in the "flavor" and "size" fields for each child item).
    6.  Enter values in other optional fields.
7.  Upload the completed inventory file:
    1.  Save your inventory template as a Text (tab-delimited) (\*.txt) file.
    2.  On the Inventory tab, click Add Products via Upload.
    3.  Validate the listings in your template using the [Check My File](https://sellercentral.amazon.com/gp/help/201576680)  feature and make corrections as necessary.
    4.  From the drop-down menu, select the type of file to upload (e.g., "Inventory Files for non-Media Categories").
    5.  Browse to locate the tab-delimited file you want to upload, then click **Upload now**.

Top

Was this article helpful?