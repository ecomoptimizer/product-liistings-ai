# Fee Explainer

Source: https://sellercentral.amazon.com/gp/help/external/201822160

This article applies to selling in: **United States**

#  View a breakdown of selling fees

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201822160)

You can find detailed explanation on your selling fees for each transaction in
your [ Payments Dashboard
](/payments/dashboard/index.html/ref=xx_payments_dnav_xx) .

**Note:** Sellers who participate in certain selling programs might have
limited permission to view a breakdown.

To see a breakdown of selling fees, follow the instructions below:

  1. Select **Payments** under **Reports** in Seller Central. 

  2. Select [ Transaction view ](/gp/payments-account/view-transactions.html) . 

  3. Click the amount in the **Total** column to view your transaction details. 

  4. Click any of the clickable amounts under **Amazon fees** . 

For more information on selling fees, go to [ Selling on Amazon Fee Schedule
](/gp/help/external/200336920) .

To check Amazon fees for all your transactions, you can also download a report
of the transactions from the [ Transaction View
](/payments/event/view?resultsPerPage=10&pageNumber=1) tab.

For a complete list of transactions and other columns not displayed under
Transaction View tab, go to the [ Disbursements
](/payments/allstatements/index.html?ref_=xx_disbmt_ttab_trans) or [ Date
Range Reports ](/payments/reports/custom/request) tabs.

Top

