# Payment Service Provider updates

Source: https://sellercentral.amazon.com/help/hub/reference/external/GHP8M87Z5W6XTSTL

This article applies to selling in: **United States**

#  Payment Service Provider updates

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGHP8M87Z5W6XTSTL)

As part of our continued effort to make Amazon the safest and most trusted
store in the world for customers and sellers, Amazon announced the Payment
Service Provider Program (PSPP, or “Program”) on February 1, 2021. For more
information, see the [ New Payment Service Provider policy
](/gp/headlines.html?id=GMKVUNE2NUJVULZE) announcement. Sellers that choose to
use a payment service provider (PSP) to receive their Amazon store sales
proceeds must use a PSP participating in the Program.

As of **July 15, 2021** , we have stopped making disbursements to sellers
using non-participating PSPs. To avoid impact, sellers using non-participating
PSPs need to switch to a participating PSP or switch to a deposit-taking bank
(that is a traditional bank account) in order to receive their disbursements.

##  Participating PSPs

If you are currently using a PSP from the list of participating PSPs below or
a deposit-taking bank in order to receive your disbursements, no action is
required.

**Note:** You can view the participating PSPs on the [ disbursement solutions
list
](/apps/store/search?category=f00228ab-f2c8-4e3d-ac20-d4c159e5e482&pageNumber=1)
.

  * Airwallex 
  * Allinpay 
  * Baofu 
  * China CITIC Bank 
  * CoGoLinks 
  * Currencies Direct Ltd. 
  * Currenxie 
  * Eaching 
  * Ebury 
  * Fortunetech 
  * Glofortune Company Limited 
  * GoAllPay 
  * GPS Capital Markets 
  * KJPay 
  * Huifu 
  * iPaylinks 
  * Lakala Payment 
  * LianLian Global 
  * Linklogis 
  * Netease Global Pay 
  * OFX 
  * Onerway 
  * OTT PAY HK 
  * Panpay 
  * Payability 
  * PayEco 
  * Payoneer 
  * Photon Dance 
  * PingPong 
  * PingAn Pay 
  * SellersFunding 
  * Skyee 
  * Sunrate 
  * TransferEasy 
  * Umpay 
  * Whalet 
  * Windpayer 
  * WorldFirst 
  * Zhejiang Chouzhou Commercial Bank 

##  What's new? More PSPs are joining the program!

We are working diligently to enroll more PSPs into the Program. The following
PSPs have met our requirements for provisional enrollment and are currently
working towards becoming full participants. If you are using any of these
PSPs, no action is required at this time. You can continue to use your PSP to
receive your Amazon store disbursements without being impacted. Once these
PSPs have fulfilled the requirements for full enrollment, they will be added
to the participating PSP list and to our [ disbursement solutions list
](/apps/store/search?category=f00228ab-f2c8-4e3d-ac20-d4c159e5e482&pageNumber=1)
.

  * Bank of Hangzhou 
  * Bank of Ningbo 
  * Bank of Wenzho 
  * CBiMoney 
  * China Industrial Bank 
  * Hyperwallet 
  * Revolut Ltd 
  * Shanghai Pudong Development Bank 
  * Tenpay Global 
  * Vcan FinTech 
  * Zhejiang Tailong Commercial Bank 
  * Zhejiang Rural Credit Cooperative Union 

If you are using a PSP that is neither on the lists above nor on the [
disbursement solutions list
](/apps/store/search?category=f00228ab-f2c8-4e3d-ac20-d4c159e5e482&pageNumber=1)
, contact your PSP to find out about their participation plan and current
status. If your PSP does not plan to enroll, you should switch to a
participating PSP or use a deposit-taking bank as soon as possible to avoid
impact to your disbursements.

We will update the list above on a weekly basis.

Top

