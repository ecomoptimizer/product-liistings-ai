# Global selling

Source: https://sellercentral.amazon.com/gp/help/external/201101640

This article applies to selling in: **United States**

#  FBA Global Selling

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201101640)

On this page, you will learn how Fulfillment by Amazon can enable you to
expand your business globally.

There are two methods of selling globally:

  * [ FBA Export ](/gp/help/external/200149570) enables you to list your FBA products on Amazon or your own website and have Amazon export orders to customers in countries around the world. 
  * [ Amazon Global Selling ](https://sell.amazon.com/global-selling.html) enables you to list and sell your products on any one of our websites in the United States, Germany, United Kingdom, France, Italy, Spain, Canada, Australia, Singapore, Japan, and the Middle East.  You ship your products to the countries you want to list in and the products are fulfilled out of Amazon fulfillment centers in those countries. You can access various tools and services, including product listing tools and the Amazon Unified Account. 

[ Learn how to setup your Amazon global account
](/gp/help/external/G201468450)

Top

##  FBA Global Selling

* [ FBA Export  ](/help/hub/reference/external/G200149570)

