# Manage account settings

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69035

This article applies to selling in: **United States**

#  Manage account settings

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69035)

The following topics can help you with logging in, listing vacation status,
updating account information, and more.

  * [ Change login settings ](/gp/help/external/G831) : Change your email address or set up security questions. 
  * [ Update account information ](/gp/help/external/G191) : Manage your seller profile, including display name, Storefront links, shipping address, and tax or VAT information. 
  * [ Financial information ](/gp/help/external/G19791) : Review or change bank account and credit card information. 
  * [ Listing status for vacations, holidays, and other absences ](/gp/help/external/G200135620) : Set your listings to "Inactive" during vacations, inclement weather, or emergencies. 
  * [ Set and edit user permissions ](/gp/help/external/G901) : Provide account access to others, such as employees or co-owners. 
  * [ Notification preferences ](/gp/help/external/G871) : Choose how you want to receive notifications and alerts about your account. 
  * [ Close your seller account ](/gp/help/external/G200399470) : Downgrade your account, request account closure, or temporarily suspend your listings. 
  * [ Account settings FAQ ](/gp/help/external/G19781) : Get answers to common questions about permissions, where to find help topics, the store selector, and other topics. 

Top

##  Manage account settings

* [ Change login settings  ](/help/hub/reference/external/G831)
* [ Update account information  ](/help/hub/reference/external/G191)
* [ Set and edit User Permissions  ](/help/hub/reference/external/G901)
* [ Notification preferences  ](/help/hub/reference/external/G871)
* [ Close your seller account  ](/help/hub/reference/external/G200399470)
* [ Account settings FAQ  ](/help/hub/reference/external/G19781)

