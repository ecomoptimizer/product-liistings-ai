# FBA prohibited  products

Source: https://sellercentral.amazon.com/gp/help/external/G201730840

This article applies to selling in: **United States**

#  FBA prohibited products

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201730840)

Substances regulated by the Narcotics Act

It is your responsibility to know whether the products you are shipping are
regulated as hazardous materials. Hazardous materials that are shipped to
Amazon fulfillment centers may be subject to disposal without reimbursement,
even if they have not been previously identified by Amazon as hazardous
materials. To learn more, see the [ Dangerous goods identification guide
](/gp/help/external/G201003400) .

Sellers participating in Fulfillment by Amazon (FBA) must comply with Amazon’s
[ restricted products policy ](/gp/help/external/200164330) and FBA-specific
product restrictions. The following products are prohibited from FBA:

  * Alcoholic beverages (including non-alcoholic beer) 
  * Vehicle tires 
  * Gift cards, gift certificates, and other stored-value instruments 
  * Products with unauthorized marketing materials, such as pamphlets, price tags, or other non-Amazon stickers 

**Note:** Amazon will not accept pre-priced labels or products.

  * Products that require preparation but that have not been prepped according to FBA [ packaging and prep requirements ](/gp/help/external/G200141500)
  * Loose packaged batteries 
  * Damaged or defective units 

**Note:** Used condition products may have damage as long as the product is
labeled with the appropriate condition.

  * Products with labels that were not properly registered with Amazon before shipment or that do not match the product that was registered 
  * Products that do not comply with any agreement between Amazon and the seller 
  * Products that have been illegally replicated, reproduced, or manufactured 

**Note:** We reserve the right to deny removal requests for and to destroy any
inventory identified as counterfeit.

  * Products that Amazon otherwise determines are unsuitable 

To learn more about Amazon’s product policies, requirements, and restrictions,
see:

  * [ Categories and products requiring approval ](/gp/help/external/G200333160)
  * [ Restricted products ](/gp/help/external/200164330)
  * [ Expiration-dated FBA inventory ](/gp/help/external/201003420)

##

##

##

Top

