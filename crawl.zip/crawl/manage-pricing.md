# Manage pricing

Source: https://sellercentral.amazon.com/gp/help/external/PTFQ566449VXXCP

This article applies to selling in: **United States**

#  Manage pricing

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FPTFQ566449VXXCP)

The Manage Pricing page allows you to update prices on any active listings,
either one by one or in batches. It includes columns most commonly used for
making price updates, but you can change the columns you want to see by
clicking **Preferences** . See [ Set your Manage Inventory page preferences
](/gp/help/external/GE7UVMSSJREL55WA) to customize the page view of Manage
Inventory.

The **Price** column on the [ Manage Inventory
](https://sellercentral.amazon.com/inventory/ref=xx_invmgr_dnav_xx) page
indicates product prices. The shipping charge is displayed in **Price** for
active listings only.

**Note:** **Shipping** indicates the lowest shipping charge available for a
product, based on your shipping settings. When you sort by the Price column,
the shipping charge is not taken into account.

##  Set minimum and maximum price limits

If you have listings that are deactivated because of potential pricing errors,
you can confirm and update your prices by clicking [ Price Alerts
](https://sellercentral.amazon.com/inventory?viewId=PRICEALERTS) tab and
entering limits in Your Maximum Price and Your Minimum Price fields for each
deactivated listing.

To set price limits, you can add minimum and maximum price columns to your
**Manage Pricing** or **Manage Inventory** view.  

  1. Click [ Manage Pricing ](https://sellercentral.amazon.com/inventory?viewId=PRICING) at the **Manage Inventory** page. 
  2. Click **Preferences** . 
  3. Select the check boxes next to **Your Minimum Price** and/or **Your Maximum Price** , and click **Save changes** . These columns will now appear on the page. 
  4. Enter the values you want in the columns, and click **Save** . 

##  Update the price of your product

  

  1. Click [ Manage Pricing ](https://sellercentral.amazon.com/inventory?viewId=PRICING) at the **Manage Inventory** page. 
  2. Locate the product you want to update. 
  3. Click **Match low price** . The item price in the **Low Price + Shipping** column will automatically update to match the low price. 
  4. Click **Save** to save your new price. 

Top

