# How to List Products That Do Not Have a GTIN UPC EAN JAN or ISBN

Source: https://sellercentral.amazon.com/gp/help/external/200426310

This article applies to selling in: **United States**

#  How to list products that do not have a Product ID (UPC, EAN, JAN or ISBN)

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200426310)

On this page

Before you request a GTIN exemption

How to request a GTIN exemption

How to add a product after you receive a GTIN exemption

Additional resources

If your product does not have a product ID, also called a [ GTIN (Global Trade
Item Number) ](/gp/help/external/G200211450) , you might be eligible to
request a GTIN exemption.

First, check the Amazon catalog to see if your product already exists. If your
product matches an existing product, you can add your offer on the existing
product detail page without a GTIN. However, if your product does not match an
existing product, you have to request a GTIN exemption and then add your
product.

This page will help explain what you must know **before you request a GTIN
exemption** , detailed steps on **how to request a GTIN exemption** , and
information to help you **add your product after you receive a GTIN
exemption** .

##  Before you request a GTIN exemption

GTIN exemptions are not available for brands that already provide a
GS1-approved barcode on their products. Even if you have a GTIN exemption for
a certain category, you will not be able to list certain branded items without
a product ID.

Here are some scenarios when you can apply for a GTIN exemption:

  * You want to sell products for which the brand, manufacturer, or publisher does not provide a GTIN. For example, private-label products or handmade products. 
  * You want to sell products for which you are the manufacturer, brand, or publisher and you do not have barcodes on your products. For example, private-label products or handmade products. 
  * You want to sell product parts that do not have a GTIN. For example, automotive parts or mobile accessories. 
  * You want to sell  a bundled pack of more than one product  . For example, a pack containing a leather belt and wallet or a pack of two shirts. 
    * **Note:** 1\. Learn more about the [ overview of category requirements and UPC exemptions ](/gp/help/external/G200317520) to understand about categories that do not require product IDs for listing. 

    * **Note:** 2\. If the categories you are planning to list in are restricted, you will also need category-level approval in addition to a GTIN exemption to start listing products. If you do not have this approval already, go to [ Overview of Categories ](/gp/help/external/G200332540) for more information on category-level approvals and apply accordingly. 

##  How to request a GTIN exemption

You can apply for GTIN exemption [ here ](/gtinx) .  Before you apply, make
sure you have the following:

  * Product name and a minimum of two (and maximum of nine) images showing all sides of your product and the packaging of the product. Ensure the guidelines below are met: 
    * The brand name entered during the application process should be an exact match to the brand name available on the product or packaging. 
    * Images should be real-world photos of the products and packaging, meaning the product and packaging need to be held or placed on a table while taking the photo. 
    * Branding is permanently affixed on the packaging or product. 
    * Products should not have a GS1-approved barcode available on the product or packaging of the product. If a GS1-approved barcode is available, you can use it to list products instead of applying for a GTIN exemption. 

Once you have your product images, follow the steps below to apply for a GTIN
exemption.

  1. On the [ Apply for a GTIN exemption ](/gtinx) page, click the **Select** button and then select the relevant **Product category** from the pop-up list. 

  2. Type the brand or publisher name in the **Brand/Publisher** field. For unbranded items and bundles, type **Generic** (case sensitive).  You can apply for multiple exemptions (up to 10) by clicking **\+ Add more brands/publishers** to add brands or publishers under the same category and click **\+ Add more categories** to add new categories. 

  3. Click **Check for eligibility** .  An **Eligibility summary** will appear. A check mark will appear in the **Status** column if you are eligible for an exemption. If your product is not eligible for a GTIN exemption, you will not be able to continue. 

  4. If your product is eligible for exemption, click the **Continue to submit proof** . 

  5. On the **Provide proof** page, upload your images: 
    * Provide the **Product name** and upload photos showing all sides of the product. 
Repeat step 5 for all products in your exemption request.

  6. Click **Submit request** . 

You will receive an email within 48 hours regarding the approval status of
your request. Alternatively, you can check the status of your request in your
[ case log ](/cu/case-lobby?ref=xx_caselog_cont_home) .

During the application process you may encounter the following errors. Go to
each of the following for more information on the error and how to resolve it:

  * [ Error 5665 ](/gp/help/external/G2N3GKE5SGSHWYRZ)
  * [ Error 5461 ](/gp/help/external/G201844590)
  * [ Match Only Error ](/gp/help/external/G1471)

##  How to add a product after you receive a GTIN exemption

Watch this video to learn more about adding listings after you get your GTIN
exemption:

####  Things to remember:

  * After you have applied for a GTIN exemption, check the status of your request in your case log. 
  * Once you receive a GTIN exemption, wait 30 minutes before adding your product in the same way you would while listing with a GTIN. Our system will identify the GTIN exemption and allow you to proceed without a GTIN (product ID). 
  * In certain cases, category-level approvals may be required in addition to GTIN exemption approvals to start listing products on Seller Central. In case you are unable to list products using an approved GTIN exemption, we recommend that you check if you are already approved to list in that particular category. If you do not have this approval already, go to [ Overview of Categories ](/gp/help/external/G200332540) for more information on category-level approvals and apply accordingly. 
  * For the exemption to work, be sure to enter the **Category** and **Brand/Publisher** name exactly as they appear in your exemption approval notice. If you use a different case or insert additional characters or spaces, the system will not recognize your exemption. 
  * After approval, you can leave **Product ID** and **Product ID Type** columns blank. 

  * You can re-apply for an exemption in case you have taken a GTIN exemption under an incorrect brand name or category. 
  * A GTIN exemption is only given to list products without a product ID. You may be required to obtain additional brand approval to list your products. 
  * You will have to apply for the GTIN exemption each time you want to list under a different brand or a category, . 
  * You can apply for a GTIN exemption for up to 10 different brand names-category combinations in a single form. 

**There are two ways to add your products in Seller Central:**

####  [ Add a Product ](/productsearch/ref=xx_addlisting_dnav_xx) (one by
one): For Individual and Professional sellers

Go to [ Add one product at a time ](/gp/help/external/G200220550) for detailed
instructions on how to use this tool. With your GTIN exemption, you do not
need to enter anything in the **Product ID** and **Product ID Type** fields in
the **Vital Info** section.

**Note:** Ensure that the category under which you are listing is non-
restricted or you have already taken the required approval. For more
information on categories that require approval, go to [ Overview of
Categories ](/gp/help/external/G200332540) .

  

  1. Go to **Catalog** > **Add a Product** > click **'I am adding a product not sold on Amazon'** and enter the product details. 
  2. If there is no product ID (bar code, UPC, EAN, JAN, or ISBN) on your product or the packaging, you can apply for a GTIN exemption and add your products without the product ID. 
  3. After you receive a GTIN exemption, wait 30 minutes before listing your products. 
  4. When you are ready to add listings, click **'I am adding a product not sold on Amazon'** and enter the product details. Select the exact product type in which a GTIN exemption has been approved. 
  5. Select the exact product type in which a GTIN exemption has been approved. 
  6. Begin adding the brand name for which you have the exemption. After you add a valid brand name, the Product ID field will not be highlighted in red, which means that it is **optional** . 
  7. Fill in the product-related information. Fields highlighted in red are required. If needed, select the **Advanced View** option at the top right to add other required details. After the mandatory attributes are filled in, **Save and Finish** at the bottom will change from gray to teal. 

**Note:** If your product is unbranded, such as a bundle, enter “Generic”
(case sensitive) in the **Brand Name** field.

####  [ Add Products via Upload ](/listing/download) (bulk upload): For
Professional sellers only

Go to [ Add your products using inventory files ](/gp/help/external/201576410)
for detailed instructions on how to use this tool. With your GTIN exemption,
you can leave the **Product ID** and **Product ID Type** columns blank in the
template.

**Note:** Ensure that the category under which you are listing is non-
restricted or you have already taken the required approval. For more
information on categories that require approval, go to [ Overview of
Categories ](/gp/help/external/200332540) .

  

  1. Go to **Catalog** > **Add products Via Upload** > Click the **Download an Inventory File** tab. 
  2. Go to the **Search tool** section and type the product type that you want to list. 

If the category of your choice does not need approval, the **Select** button
will be available. If the product requires category approval, click **Request
Approval** .  For more information on selling restricted products, go to [
Categories and products that require approval ](/gp/help/external/G200333160)
.

  3. If the search tool is not returning the category you are looking for, try using the **Product Classifier** categories below the search bar. 
  4. As of now, only fashion jewelry does not require a UPC exemption. 
  5. After you have selected all your relevant nodes, click the type of template you want to generate and click **Generate Template** . 
  6. Alternatively, if you want to fill in category-specific flat file, download the required category file by clicking this [ link ](/gp/help/external/1641) . Remember to fill in the product feed type and leave the Product ID and Product ID Type column blank in the flat file. The brand name entered should be the same as the brand name used to get a GTIN exemption. 

**Note:** GTIN exemptions granted after August 24, 2018, will not expire. If
your exemption was approved before this date, please re-apply using the [ GTIN
exemption ](/gtinx) page. Check for existing GTIN exemptions in your [ case
log ](/cu/case-lobby?ref=xx_caselog_cont_home) .

##  Additional resources

  * [ Potential Duplicates and Split Variations ](/gp/help/external/G202105450)
  * [ Amazon Brand Name Policy ](/gp/help/external/G2N3GKE5SGSHWYRZ)
  * [ Match your products ](/gp/help/external/G1471)

Top

##  How to list products that do not have a Product ID (UPC, EAN, JAN or ISBN)

* [ Product ID (GTIN) requirements for Books  ](/help/hub/reference/external/G200786200)

