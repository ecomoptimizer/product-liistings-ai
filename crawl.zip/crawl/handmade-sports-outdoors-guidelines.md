# Handmade Sports & Outdoors guidelines

Source: https://sellercentral.amazon.com/gp/help/external/GNBPK6NFHKZJ66U3

This article applies to selling in: **United States**

#  Handmade Sports & Outdoors guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGNBPK6NFHKZJ66U3)

As a Maker, your handmade Sports and Outdoor products must adhere to the
following guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must meet the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * For [ Explosives, Weapons, and Related Items ](/gp/help/external/G200164950) , review the policy for more details. 
  * Unauthorized copies or reproductions of artwork that violate any copyright or trademark are not allowed.  Read more about [ Intellectual Property for Rights Owners ](/gp/help/external/GU5SQCEKADDAQRLZ) . 

Top

