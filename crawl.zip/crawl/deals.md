# Deals

Source: https://sellercentral.amazon.com/gp/help/external/G202043110

This article applies to selling in: **United States**

#  Amazon deals

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202043110)

Creating deals is an efficient way of driving your sales up. You can create
two types of deals: Best deals and Lightning deals. To learn more about each
type, use the left navigation pane.

Top

##  Amazon deals

* [ Make your products eligible for Deals  ](/help/hub/reference/external/G202111490)
* [ Create a Deal  ](/help/hub/reference/external/G202111550)
* [ How do I know the status of my Deal?  ](/help/hub/reference/external/G202111570)
* [ Deal Fees  ](/help/hub/reference/external/G202111590)
* [ Cancel a Deal  ](/help/hub/reference/external/G202111610)
* [ Deals for Events  ](/help/hub/reference/external/G202183600)
* [ Troubleshooting Suppressed and Active Deals  ](/help/hub/reference/external/GKN9A84DGTYWYHWY)
* [ Getting the most out of your Deals  ](/help/hub/reference/external/GSY3EMGXT9UCKB4F)
* [ Best Deal & Lightning Deal Performance Results  ](/help/hub/reference/external/GTXD25GEG7Z6XZHC)

