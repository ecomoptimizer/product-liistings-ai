# Error code explanations

Source: https://sellercentral.amazon.com/help/hub/reference/G202171800



---

#### Error Code 15001

There was an unexpected failure in processing the row. Please try again later.

#### Error code 15002

The file size exceeds the maximum allowed 5000 rows. Upload a file with less than 5000 rows.

#### Error code 15003

You currently do not have any Automate Pricing rules. Create at least one rule using the [Automate Pricing tool](https://sellercentral.amazon.com/automatepricing/home) before using the Automate Pricing file. Learn more about how to [Create a pricing rule](https://sellercentral.amazon.com/gp/help/201995750).

#### Error code 15004

We were unable to process the file that you have uploaded. Please try again later.

#### Error code 15005

The value is invalid. See the "Instructions" and "Data Definitions" tabs in the file and enter a valid input.

#### Error code 15006

There was no pricing rule found for the given rule name. Note that rule names are case sensitive and symbols in the rule name are not allowed. Review your rules at the [Automate Pricing Rules](https://sellercentral.amazon.com/automatepricing/home) page and if applicable, remove symbols from the rule name using the Automate Pricing tool.

#### Error code 15007

There are missing required column values for 'rule-action'. See the "Instructions" and "Data Definitions" tab in the file and enter all required values.

#### Error code 15008

This row was skipped because it is for a duplicate SKU from a previous row.

#### Error code 15009

The 'minimum-seller-allowed-price' is equal to or greater than the 'maximum-seller-allowed-price'. Please enter valid minimum and maximum prices.

#### Error code 15010

The 'minimum-seller-allowed-price' is greater than the selling price for the listing. See the “Instructions” and “Data Definitions” tab in the file and enter a valid minimum price.

#### Error code 15011

The 'maximum-seller-allowed-price' is less than the selling price for the listing. See the “Instructions” and “Data Definitions” tab in the file and enter a valid maximum price.

#### Error code 15012

The 'minimum-seller-allowed-price' is too low. See the “Instructions” and “Data Definitions” tab in the file and enter a valid minimum price. Refer to the [help content](https://sellercentral.amazon.com/gp/help/202024630) to learn more about minimum and maximum price validation.

#### Error code 15013

The 'maximum-seller-allowed-price' is greater than the allowable value. See the “Instructions” and “Data Definitions” tab in the file and enter a valid maximum price. Refer to the [help content](https://sellercentral.amazon.com/gp/help/202024630) to learn more about minimum and maximum price validation.

#### Error code 15014

The inputs are invalid. See the "Instructions" and "Data Definitions" tabs in the file and enter valid inputs.

#### Error code 15015

The offer is not active or does not exist. Enter a valid SKU.

#### Error code 15016

The maximum number of associations allowed have been reached.

#### Error code 15017

The currency value is invalid. See the "Instructions" and "Data Definitions" tabs in the file and enter a valid input.

#### Error code 15018

The file uploaded does not follow our guidelines. See the "Instructions" and "Data Definitions" tabs in the file to create a valid file.

#### Error code 15023

The currency code is not valid for the specified country code. The value ‘!{currencyCode}’ was expected. See the "Instructions" and "Data Definitions" tabs in the file and enter a valid currency code.

#### Error code 15024

The specified country code does not match to the marketplaces for which Automate Pricing is enabled. See the “Instructions" and "Data Definitions" tabs in the file and enter a valid country code.

#### Error code 15025

There are no countries for which Automate Pricing is enabled. To use Automate Pricing, go to Pricing > Automate Pricing to start by creating a rule.