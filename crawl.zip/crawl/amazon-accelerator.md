# Amazon Accelerator

Source: https://sellercentral.amazon.com/gp/help/external/G52NQJE353XZGWN7

This article applies to selling in: **United States**

#  Amazon Accelerator

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG52NQJE353XZGWN7)

On this page

Overview

Benefits

Additional Terms

Program policies

How to apply

##  Overview

**Program vision**

Amazon Accelerator enables manufacturers to launch brands and innovative
products exclusively on Amazon and provides a path to become an Amazon Private
Brands supplier.

**Brand Exclusivity**

Suppliers will create and trademark their own Amazon-exclusive brand. The
brand will remain exclusive to Amazon.

**Supplier-Driven Selection**

You determine what products to launch based on your category expertise. We
encourage you to take advantage of this opportunity to recommend proven high-
quality and high-rated products.

**Testing & Learning **

You can easily test new innovative products and get quick customer feedback.

##  Benefits

####  Path to Amazon Private Brands

The Amazon Accelerator program is a potential entry into Amazon Private
Brands. Successful Amazon Accelerator participants may be selected to become
suppliers for our Amazon Private Brands, and certain Amazon Accelerator brands
may be purchased by Amazon. If we opt to purchase your brand, the price and/or
calculation of it will be contained in your Amazon Accelerator agreement.

####  Brand Protection

Amazon will maintain exclusivity over your brand. No other sellers can add
offers to your ASINs.

####  Marketing Services

Brands will receive a suite of marketing and promotions support, including
site merchandising and free access to our Vine program. Products with high
ratings and reviews may also receive additional placements across Amazon.

####  Onboarding Support

Suppliers will receive guided support, a toolset to tell the brand story, and
analytics to track brand performance.

####  Reporting and selection insights:

Brands can leverage Amazon analytics tools to get customer feedback on their
products. Some categories are eligible for category insights to help you
understand recent trends.

**Note:** Amazon Accelerator features and benefits are subject to change.

##  Additional Terms

Participation in the Amazon Accelerator program is subject to additional terms
and conditions. You will be provided with, and required to accept, the program
terms in order to complete the application process.

##  Program policies

The following policies apply to Accelerator participants. Violation of these
policies will result in the brand being exited from the program.

Program fees  |

If we approve your Selling on Amazon account for participation in the Amazon
Accelerator, you will be charged in accordance with the program fees. Fees
will be applied at the account level and will apply to all sales associated
with your account. No refunds will be issued for services already provided.
The program fee is an additional 7% premium to the Referral Fees described on
the Selling on Amazon Fee Schedule.

When selling products under Fashion categories (Clothing & Accessories, Shoes
& Bags, Jewelry, Watches, Luggage), the fee for the program is an additional
7% premium to the Referral Fees described on the Selling on Amazon Fee
Schedule for Clothing & Accessories regardless of which Fashion category
product you sell.

Fees are subject to change.

All brands under the Seller Central account used for Accelerator will be
charged a program fee  
  
---|---  
Brand exclusivity  |  Brands enrolled in the Accelerator program will be sold
exclusively through Amazon worldwide.  
Trademark  |  Selling Partners should apply for trademark and register to
Brand Registry in the stores they sell in.  
Social Responsibility  |  We require selling partners to disclose all
facilities used in the production of brands participating in the Accelerator
program. At a minimum, these facilities must meet and maintain a basic set of
requirements in order to qualify for the program and its premium marketing
placements. Please review [ Accelerator Supplier Manual ](https://m.media-
amazon.com/images/G/01/Accelerator_SR/Accelerator_Supplier_Manual_27Oct2020.pdf)
for more information.  
Product restrictions  |  Products offered for sale on Amazon must comply with
all laws and regulations and with Amazon's policies. The sale of illegal,
unsafe, or other restricted products listed on [ Amazon policies
](https://sellercentral.amazon.com/gp/help/external/help-
page.html?itemID=521&language=en_US&ref=efph_521_bred_G200164330) , including
products available only by prescription, is strictly prohibited. The Amazon
Accelerator program has chosen to restrict select product types in addition to
those restricted or prohibited by law or broader Amazon policies. Please
review [ Accelerator Product Restrictions Policy ](https://m.media-
amazon.com/images/G/01/Accelerator_Product_Restrictions/Amazon_Accelerator_Product_Restrictions_Policy.pdf)
to learn more on categories that are not eligible for the Accelerator program
before joining the program and launching your selection.  
Fulfilment channel  |  Accelerator holds to highly convenient delivery
experience for Amazon customers. 3P selling partners must adopt FBA
fulfillment for 100% of their buyable ASINs. They are temporarily allowed to
use merchant fulfilled models (Seller Fulfilled Prime; Merchant Fulfilled
Network) when FBA inventory has sold out. In this case, sellers are
responsible to maintain order performance (e.g. cancel rate, defect rate,
customer service).  
Brand name and detail page content  |

Selling Partners should select brand names that do not infringe the rights of
third parties.

Selling Partners may not use brand names that may create the impression that
the brands are associated with Amazon in any way. This includes brands that
directly or indirectly refer to Amazon, brands owned by Amazon or its
affiliates, or specific Amazon employees. For example, brands may not include
any of the following words: Prime, Day 1, Day One, Alexa, Echo, Kindle, Fresh,
Wholefoods, 365, Eero, Ring. The list of Amazon trademarks is available [ here
](https://www.amazon.com/gp/help/customer/display.html?nodeId=GCX77V9988LUPMB2)
. Brand names that incorporate profanity or culturally insensitive terminology
or references are also prohibited.

Selling Partners also may not use detail page content that suggests any
affiliation to Amazon, including "Amazon Brand", "Private Brand", "Amazon
Accelerator". Selling Partners may mention their brand is "Exclusively sold on
Amazon".  
  
##  How to apply

Go to the [ Amazon Accelerator landing page
](https://www.amazon.com/l/?node=17882322011&https://accelerator.amazon.com/)
and click on sign up to complete our questionnaire. Our teams will get back to
you to confirm next steps.

Top

