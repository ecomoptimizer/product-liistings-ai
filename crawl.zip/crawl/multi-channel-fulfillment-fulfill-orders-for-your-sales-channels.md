# Multi-Channel Fulfillment- Fulfill orders for your sales channels

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200332450

This article applies to selling in: **United States**

#  Multi-Channel Fulfillment: Fulfill orders for your sales channels

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200332450)

On this page

Shipping and delivery speed

Create orders

Track orders

Cancel orders

Fees

Blank Box (Unbranded packaging)

Carrier preference

Reimbursements

Lost orders

Damaged, wrong, or missing items

Returns

Settings

Amazon Multi-Channel Fulfillment (MCF) fulfills orders for your sales channels
at the same delivery speed as Fulfillment by Amazon (FBA).  For more
information, go to our [ program page ](/mcf) .

##  Shipping and delivery speed

Shipping times are calculated from the time that an order is placed to when it
is shipped from our fulfillment center. Delivery times are calculated from the
time that an order is shipped from our fulfillment center to when it is
delivered to the buyer. **Tracking information is available as soon as an
order is shipped.**

The shipping and delivery times in the table below apply to inventory received
and stored in a fulfillment center and orders shipped within the 48 contiguous
states of the US. Delivery times may be longer for the following:

  * Inventory shipped from your location but not yet received and added to your inventory 
  * Inventory that’s transferred from one fulfillment center to another, which is shown in the **Reserved** column on [ FBA Inventory ](/inventoryplanning/manageinventoryhealth)
  * Orders shipped to non-contiguous US states and territories, including Alaska, Hawaii, and Puerto Rico 

Shipping speed  |  Shipping  |  Delivery  
---|---|---  
Priority  |  1 business day  |  1 business day  
Expedited  |  1 business day  |  2 business days  
Standard  |  2 business days  |  3–5 business days  
  
MCF also offers exports, cross-border shipments to a buyer in another country,
for books, music, videos, and DVDs.

##  Create orders

MCF fulfills orders from outside of Amazon, including your own website. You
can create MCF orders through our [ quick order form ](/mcf/orders/create-
order) , [ bulk order upload ](/mcf/orders/bulk-orders) , or [ API
integrations ](https://supplychain.amazon.com/integrations) with providers
such as Shopify, ChannelAdvisor, ShipStation, and WooCommerce.

A [ quick order form ](/mcf/orders/create-order) allows you to place a single
ship order or hold order against available FBA inventory by entering your
customer's shipping address, items, and shipping speed.  [ Multi-Channel
Fulfillment bulk orders ](/mcf/orders/bulk-orders) allow you to create and
cancel multiple orders at once by uploading a completed template.

In the quick order form, if you select **Place order** , you'll create a ship
order that will plan and ship within 2 business days for Standard speed and
next business day for Expedited and Priority speeds.

If you select **Create hold order** , an order will be planned and placed on
hold, reserving your inventory. These hold orders must be activated on the MCF
order details page to initiate the shipment. The order will only meet the
expected delivery date if activated before the expected ship date. If not, the
expected delivery date will not update and the order will deliver at a later
date. If the hold order isn't activated within 14 days, the order will be
canceled automatically.

To activate a hold order, follow these steps:

  1. Go to [ Manage Orders ](/orders-v3/search?q=&qt=orderid&page=1) . 

  2. In the search box, enter the MCF order ID and click **Search** . 

  3. Click the order ID link in the **Order details** column. 

  4. On the MCF order details page, click **Ship this order** . 

##  Track orders

Follow these steps to track MCF orders on the MCF order details page:

  1. Go to [ Manage Orders ](/orders-v3/search?q=&qt=orderid&page=1) . 

  2. In the search box, enter the MCF order ID and click **Search** . 

  3. Click the order ID link in the **Order details** column. 

  4. On the MCF order details page, click the **Shipment** tab to view the shipment details for the order. 

For each shipment, the ship date, delivery estimate, tracking number, and
carrier information will be available, along with the package contents.

Click the tracking number to view tracking details on [ Swiship
](https://www.swiship.com/track/) , our tracking website. Swiship provides
real-time status updates of shipped packages, which can be shared with
customers. Alternatively, to view the tracking details on your selling
account, click **Shipping event details** on the **Shipment** tab of the MCF
order details page. For more information, go to [ How to track your Multi-
Channel Fulfillment orders ](https://supplychain.amazon.com/learn/how-to-
track-your-mcf-orders) .

The tracking number generated by our system expires after 90 days. If a
tracking number has expired, the tracking details may not be available on
Swiship.

##  Cancel orders

To request an order cancellation, follow these steps:

  1. Go to [ Manage Orders ](/orders-v3/search?q=&qt=orderid&page=1) . 

  2. In the search box, enter the MCF order ID and click **Search** . 

  3. Click the order ID link in the **Order details** column. 

  4. On the MCF order details page, click **Cancel this order** , if available. 

**Note:** Clicking **Cancel this order** only submits a request and does not
guarantee a cancellation. Cancellations depend on the planning and processing
status of the order shipments at the fulfillment center. If there are multiple
shipments in an order, the cancellation request for each shipment will be
treated independently.

**Cancel this order** may not appear in certain cases. For example, it may not
appear if the order was already packed, or if a tracking number was generated
and the order was shipped. In these cases, the order cannot be canceled.

You aren't charged for MCF orders that are successfully canceled before
shipping. If some items in an order have shipped, or have returned to Amazon
before reaching customers, fees for the shipped items will apply. MCF doesn’t
offer the option to intercept an order after it’s been shipped.

Once an MCF order has been submitted, the order details cannot be changed,
including the products, quantity, recipient name, and delivery address. Before
you place an order, make sure that you confirm with the customer that the
address provided is accurate. Amazon is not responsible for any delivery
failures that result from incorrect information submitted during order
creation, and such orders are ineligible for reimbursement.

##  Fees

MCF charges [ fulfillment fees for domestic orders
](/gp/help/external/201112650) and [ export orders
](/gp/help/external/200804980) . To preview your MCF fees, use our [ fee
calculator ](/mcf/#fees) .

##  Blank Box (Unbranded packaging)

All MCF sellers are automatically enrolled in unbranded packaging at no
additional cost. Unbranded packing is the default ship option for MCF orders,
except in cases when it may result in longer shipping and delivery times.

To ensure that your orders are shipped in unbranded packaging, select **Only
ship with blank boxes** under the Add items section of the [ quick order form
](https://sellercentral.amazon.com/mcf/orders/create-order) . When you select
this option, our fulfillment logic checks and verifies whether the inventory
is in a blank box fulfillment center. If the inventory isn’t in a blank box
fulfillment center, the option to only ship with blank boxes isn’t available.
Unbranded packaging is available for eligible sortable items. Non-sortable
inventory, apparel, footwear, and any items larger than 56" and/or 49.9lbs are
not eligible and cannot be shipped via this program.

Replenishment alerts for unbranded-packaging inventory are currently not
available.

To view how many items are enabled for unbranded packaging for a specific
ASIN, go to the [ Multi-Channel Fulfillment Inventory report
](/reportcentral/MCF_INVENTORY_REPORT/1) .

##  Carrier preference

You can block your MCF orders from being shipped by Amazon Logistics, which
will result in a 5% surcharge on your MCF orders. For more information, go to
[ Fulfillment fees for Multi-Channel Fulfillment orders
](/gp/help/external/201112650) .

You can block Amazon Logistics at the account level in your [ Multi-Channel
Fulfillment settings ](/gp/ssof/configuration/multi-channel-fulfillment-
settings.html) . For individual orders, you can block this shipping method
through [ MCF API ](https://developer-docs.amazon.com/sp-api/docs/fulfillment-
outbound-api-v2020-07-01-reference) or by selecting **Block Amazon Logistics
as a carrier for this order** on the [ order creation ](/mcf/orders/create-
order/) page.

If you block this shipping method through your MCF settings, by default none
of your MCF orders will ship with Amazon Logistics. Changing your Amazon
Logistics preference for individual orders will override your MCF settings
preference for those orders only.

##  Reimbursements

You're eligible for reimbursements on your MCF orders if we determine that
they have been lost or damaged.  You have **up to 90 days after the promised
delivery date** to submit your claim for any lost or damaged items on your MCF
orders.  Check the status of your existing reimbursements on the [ Amazon
Fulfilled Inventory report ](/reportcentral/AFNInventoryReport/1?) or the [
Payments dashboard ](/payments/dashboard/index.html/ref=xx_payments_dnav_xx) .

**You are ineligible for reimbursements if you use MCF in either of the
following ways:**

  * You use MCF as a way to remove items from a fulfillment center. Instead, create a removal order. For more information, go to [ Remove inventory (overview) ](/gp/help/external/G200280650) . 
  * You use MCF as a way to fulfill any order placed on the Amazon website, including self-fulfilled orders, FBA orders, or any related shipments.  Instead, use FBA. For more information, go to [ Get started with Fulfillment by Amazon (FBA) ](/gp/help/external/53921) . 

Also ineligible for reimbursements are MCF fulfillment fees and orders that
are marked as delivered by the carrier.

**How we calculate reimbursement value**

If we determine that your reimbursement claim is valid, we’ll reimburse your
account with a corresponding number of units of the same FNSKU, added into
your inventory, or credit your account with a cash reimbursement for the
units.

For any cash reimbursements, we will determine an estimated proceeds of sale.
This amount is the estimated sale price of the item for which you’re being
reimbursed minus referral fees and FBA fulfillment fees, as explained in the
next section.

We compare several price indicators to determine an estimated sale price for
the item:

  * The median price at which you’ve sold the item on Amazon over the past 18 months 
  * The median price at which other sellers have sold the same item on Amazon over the past 18 months 
  * The current list price that you’ve set for the same item on Amazon or the mean list price if you have multiple listings for the same item 
  * The current list price for the same item from other sellers on Amazon 

If we don't have enough information to calculate the estimated sale price of a
unit using these price indicators, we’ll base the estimate on the price of a
comparable product. We may ask you for additional information or documentation
to help us determine that value.

**Why we use referral and FBA fulfillment fees to calculate MCF
reimbursements**

Referral fees are not charged for MCF orders. When we estimate the proceeds of
a sale, we start with an estimated sale price. Because MCF orders occur
outside of the Amazon website, we don’t have a record of the sale price.
Therefore, we determine the estimated sale price based on your FBA sales, and
we use the fees that are applicable to FBA sales to determine a fair
estimation of the proceeds of sale.

##  Lost orders

If your order isn’t delivered within 7 days after the promised delivery date
or estimated delivery date, you can claim a lost reimbursement with [ Selling
Partner Support ](/help/hub/support/INTENT_DA_MultiChannelOrderIssues?) .
Orders that are marked as delivered by the carrier aren’t eligible for
reimbursement.

Your claim must include **all of the following** :

  * Order ID 
  * Proof of the original non-Amazon order, such as a screenshot of your Shopify order, including all affected ASINs and corresponding quantities, as well as the buyer’s name and address 
  * Proof of refund or replacement provided to the buyer, including the buyer’s name and address 
  * Tracking IDs for the affected shipments, if the order contained multiple shipments 

##  Damaged, wrong, or missing items

If any items in your order are wrong, missing, or damaged in transit to the
buyer, you can file for reimbursement by contacting [ Selling Partner Support
](/gp/help/support/INTENT_DA_MultiChannelOrderIssues?) . To receive a
reimbursement, you must provide photographic proof of the damaged item, wrong
item, or missing items in the package.

When you submit a reimbursement claim for an order that contains damaged,
wrong, or missing items, you must provide **all five of the following** :

  * Order IDs, ASINs, or FNSKUs of the damaged, wrong, or missing items, and quantities of each affected item 
  * Proof of the original non-Amazon order, such as a screenshot of your Shopify order. The order must include all ASINs and corresponding quantities, as well as the buyer's name and address. 
  * Proof of refund or replacement provided to the buyer, including the buyer's name and address 
  * Images of the shipping box or envelope and all shipping labels 
  * The following information, depending on the issue: 
    * **For damaged items**
      * A description of the damage 
      * Images of the whole item, including clear images of the UPC, ASIN, or FNSKU barcode label 
      * Images of the damage described 
      * For electronics, such as TVs and printers, images of the serial and model numbers 
    * **For wrong items**
      * A description of the difference 
      * Images of the incorrectly received item showing the UPC, ASIN, or FNSKU barcode label, or the LPN sticker, or both, and the described difference 
      * Images of the model number and serial number, if available 
    * **For missing items**
      * Images of the inside of the shipping box or envelope showing the received items, if one unit of multiple units that were shipped in the package is missing 
      * Images of the empty shipping box, if only one item was shipped in the box 
      * Images of empty product packaging, if a product box was received without one or more of the internal contents 

##  Returns

Items fulfilled through MCF can be returned to Amazon fulfillment centers. You
can choose to return items to fulfillment centers, or follow your existing
returns process.

When a customer contacts you to initiate a return, you can ask the customer to
ship the return to Amazon. By electing to ship products back to Amazon, the
return can be incorporated into your Amazon inventory.

To initiate a return to Amazon, follow these steps:

  1. Go to [ Manage Orders ](/orders-v3/search?q=&qt=orderid&page=1) . 

  2. In the search box, enter the MCF order ID and click **Search** . 

  3. Click the order ID link in the **Order details** column. 

  4. On the MCF order details page, click the **Return** tab. 

  5. Select the return quantity for the item or items that the customer wants to return. 

  6. Indicate the return reason for the item or items. 

The return merchandise authorization form will then be generated. The form
contains the following two sections:

  * **Return mailing label:** A label that contains the address of the fulfillment center that will be receiving and processing the return. Ask the customer to affix the label on their return package. **Note:** Postage is not provided on the return mailing letter. You or the customer are responsible for purchasing and producing the return label. 
  * **Return authorization slip:** A form that contains a barcode and item description for the products being returned. The slip must be included inside the return package alongside the items. 

When a return is received at a fulfillment center, our associates validate the
state of the product. If it’s deemed to be in a sellable condition, we add the
unit back to your Amazon inventory. If the unit is unsellable, you must follow
our removal procedure to receive the defective product. For more information,
go to [ Required removals ](/gp/help/external/G202000820) .

It may take up to 7 days to process the return and add the unit to your
inventory once the unit is delivered to a fulfillment center.

After you initiate a return, click the **Return status** tab on the MCF order
details page for information on the return. You can also view this information
on the [ FBA Customer Returns report ](/reportcentral/CUSTOMER_RETURNS/0) . On
this page, enter the MCF order ID in the **Amazon order ID** field and select
**Last 365 days** in the **Event date** drop-down menu. The report will show
if the return has been received by Amazon and the disposition of the item.

In some cases, a unit may be returned to a fulfillment center by the carrier.
This may occur due to various reasons, including when an item was damaged
during transit, an item was undeliverable due to an incorrect address, or the
buyer refused delivery. In these cases, it may take up to 7 days from the last
tracking update to add the returned units back to your inventory.

##  Settings

You can change the name and text on your packing slip in [ Multi-Channel
Fulfillment settings ](/gp/ssof/configuration/multi-channel-fulfillment-
settings.html?language=en_US&ref=ag_xx_cont_G200332450) .

Top

##  Multi-Channel Fulfillment: Fulfill orders for your sales channels

* [ Multi-Channel Fulfillment settings  ](/help/hub/reference/external/G56JCGRSP2NKQZ5A)
* [ New beta features for Multi-Channel Fulfillment  ](/help/hub/reference/external/G47ZF4V7HNRY3JWD)

