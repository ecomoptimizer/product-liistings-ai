# Image File was Corrupted or of an Unexpected Format

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> An image will fail to upload if the file is incomplete, corrupted, in the wrong format, or too large.

---
An image will fail to upload if the file is incomplete, corrupted, in the wrong format, or too large.

Common reasons for receiving this error may be that the file type extension was incorrectly attached or it was an unflattened .tif or .psd file that was saved as a .jpg. We accept JPEG (.jpg), TIFF (.tif), .PNG, or .GIF files with either RGB or CMYK color models.

You may also get this error if there are color tonal variations in the image (this may occur when CMYK images are used on the website). RGB images are preferred. Images with more than 10,000 pixels in either height or width may also cause this error.

Verify the image file format if you get this error:

-   If you cannot view the file, it may be corrupt. You can try using an image editing program to change the file extension to a known file type, as it may have been assigned the wrong extension. If the file appears to be have the extension other than the current named extension, flatten and re-save it as a JPEG using an image editing program.
-   If you can view the file, it may be incomplete. In this case, try using an image editing program to re-save the file as a JPEG.

Before uploading a corrected file, verify that it can be viewed on your computer using a preview or image editing program.
