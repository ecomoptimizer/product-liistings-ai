# FBA Small and Light Terms and Conditions

Source: https://sellercentral.amazon.com/gp/help/external/GZKHKFS7YLKWR5CC

This article applies to selling in: **United States**

#  FBA Small and Light Terms and Conditions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGZKHKFS7YLKWR5CC)

These terms and conditions supplement the [ Amazon Services Business Solutions
Agreement ](/gp/help/external/G1791) and govern your participation in the FBA
Small and Light program (the "Program").  

  1. **Program enrollment**

Your participation in the Program is subject to Amazon’s approval. Amazon may
change Program eligibility criteria from time to time. You may withdraw from
the Program at any time.

  2. **Product enrollment**   

    1. You will enroll in the Program only products that meet the eligibility requirements described in the "Product eligibility" section of the [ Program Help page ](/gp/help/external/G201706140) . 
    2. Amazon may decline or cancel the enrollment of any product in the Program at any time, for any reason. 
    3. You may withdraw your Products from the Program at any time. 

  3. **Preparation, packing, and shipping requirements**

FBA Small and Light has the same [ packaging and prep requirements
](/gp/help/external/G200141500) as standard FBA. Review our [ Small and Light
prep and packaging guide ](/gp/help/external/GCFL9GA7ZXSRS6RL) and ship your
products to the fulfillment center specified by Amazon.

  4. **Fees**

In lieu of standard FBA fulfillment fees, you will pay the fulfillment fees
for the Program described on the [ Program Help page
](/gp/help/external/G201706140) for the fulfillment of Small and Light
eligible products. Your obligation to pay all other applicable Selling on
Amazon and FBA fees is not changed by the Program.

  5. **Products not eligible for Small and Light**

We will fulfill only Small and Light eligible products through the Program. If
you send us products that are not Small and Light eligible products or if your
products become non-Small and Light eligible products after you enroll them in
the Program, non-eligible ASIN inventory will be charged the standard FBA
fees.

Top

