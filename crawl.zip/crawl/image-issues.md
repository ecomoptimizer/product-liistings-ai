# Image Issues

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> When you upload your image files, they are checked to confirm that they meet technical file requirements. Files that don't meet these requirements are not uploaded to your listings.

---
When you upload your image files, they are checked to confirm that they meet technical file requirements. Files that don't meet these requirements are not uploaded to your listings.

Additionally, if the images on your Amazon product listings are found to be non-compliant with Amazon's image content requirements, the product listings are removed from search until you provide a compliant image. For more information on possible image issues and how to fix them, go to the following pages:

-   To view products removed from search due to image issues, go to [Fix your products](https://sellercentral.amazon.com/fixyourproducts/suppressed?).
-   To view technical file requirement failures, go to [Submission status](https://sellercentral.amazon.com/imaging/upload/status).
-   To learn more about image requirements, go to [Image troubleshooting](https://sellercentral.amazon.com/gp/help/G17771).
-   If you are creating your own images, you may find our [self-service imaging products](https://www.amazon.com/pstudioipv) and [photography videos](https://www.youtube.com/c/AmazonImaging) useful.

| Reason of suppression | Required action | Affected image |
| --- | --- | --- |
| [Text, logo, graphics, or watermarks](https://sellercentral.amazon.com/gp/help/GB6V3RU3M5XG24GC) | Main image has text, logo, graphic, or watermark. Submit a compliant image to lift the suppression. | Any main image |
| [Non-white background](https://sellercentral.amazon.com/gp/help/G75PWC4THA8J269P) | Main image has a non-pure white background (RGB 255 255 255). Submit a compliant image to lift the suppression. | Any main image |
| [Cropped product](https://sellercentral.amazon.com/gp/help/GMPJ3FNUF4LZV8GR) | Main image has a portion of the product cropped (missing). Submit a compliant image to lift the suppression. | Any main image |
| [Product not outside of packaging or has package tags](https://sellercentral.amazon.com/gp/help/GJ7NW9R96FAUEK3D) | Main image has your product in packaging, or brand or swing tags. Submit a compliant image to lift the suppression. | Any main image |
| [Propping](https://sellercentral.amazon.com/gp/help/G5SD576VXDFLCR32) | Main image has props that are inside your product, or obscure or surround your product. Submit a compliant image to lift the suppression. | Any main image |
| [Blurriness or pixelatation](https://sellercentral.amazon.com/gp/help/GN9G8EM6GUAX4ZY6) | Main image has a blurred or pixelated product. Submit a compliant image to lift the suppression. | Any image |
| [Product too small](https://sellercentral.amazon.com/gp/help/GKPLUEFR7TJ9EDAN) | Main image has a product that is too small in the image frame. Submit a compliant image to lift the suppression. | Any image |
| [Prurience](https://sellercentral.amazon.com/gp/help/G98ZNV6HDKK5NZ8C) | Main image has prurience. Submit a compliant image to lift the suppression. | Any image |
| [Multiple product images](https://sellercentral.amazon.com/gp/help/G4VZLFFU7KJP7PBH) | Main image has multiple images of a single product. Submit a compliant image to lift the suppression. | Any main image in Apparel |
| [Human model](https://sellercentral.amazon.com/gp/help/GBESJNTVU5XPKVVU) | Main image has a human model for a non-clothing product. Submit a compliant image to lift the suppression. | Any main image in Softlines, such as Kids, Baby, Shoes, Luggage, Watch, Jewelry, except Adult Apparel |
| [Mannequin or hanger](https://sellercentral.amazon.com/gp/help/G684P2ZPKPTDLSQW) | Main image has a mannequin or hanger, which is not permitted for this product type. Submit a compliant image to lift the suppression. | Any image in Apparel or Accessories |
| [Model in non-standing position](https://sellercentral.amazon.com/gp/help/GLBZSXRFB5VX32HC) | Main image has a model that is not in standing position. Submit a compliant image to lift the suppression. | Any main image of Apparel |
| [Bad ASIN or variant](https://sellercentral.amazon.com/gp/help/GP8W3L6D7G2ZFVME) | Your file could not be associated with an ASIN or variant. Upload a file that meets naming requirements. | Any main image |
| [Unsupported file suffix](https://sellercentral.amazon.com/gp/help/G2AHG9AAHGG2DPVH) | Your file type is not allowed. Upload a file in an accepted format. | Any main image |
| [Image file was corrupted or is in unexpected format](https://sellercentral.amazon.com/gp/help/G7HVPM8H8YTKXTAW) | Confirm that your file is smaller than 10,000 pixels on the longest side, is not corrupt, and is in the correct file format (JPG, TIF, PNG, GIF in either RGB or CMYK). | Any main image |
| [Image dimensions too small](https://sellercentral.amazon.com/gp/help/GLZCW6ZLJBDYS922) | Upload an image that is larger than 500 pixels on its longest side. Images that are larger than 1000 pixels will enable zoom functionality. | Any main image |
| [Authoritative image already exists](https://sellercentral.amazon.com/gp/help/G864APBMA4HCKXGS) | If a preferred image already exists for your ASIN and variant, your image will be rejected. | Any main image |
| [Resubmission of previously accepted or rejected images](https://sellercentral.amazon.com/gp/help/GD4EQJXHH6RNTDGA) | This exact image file has already been submitted. If your ASIN still requires an image for this variant, make sure that you are uploading an image that meets requirements. | Any main image |
| [Unknown internal error](https://sellercentral.amazon.com/gp/help/G74GGME6P8ELPLGU) | An unknown problem occurred. Try to upload again later. | Any main image |
| [Image with identical ASIN and variant submitted](https://sellercentral.amazon.com/gp/help/GXP59A6ZVJUFJTFN) | An image with this ASIN and variant was submitted after this file had been submitted. We always accept the latest image submission. Make sure that you are uploading the correct image. | Any main image |
