# Fee Schedule

Source: https://sellercentral.amazon.com/gp/help/external/201074400

This article applies to selling in: **United States**

#  FBA features, services, and fees

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201074400)

On this page

FBA Overview

FBA features

FBA services

FBA fees

FBA fee tools

As part of Fulfillment by Amazon (FBA), you have access to optional features
and services to help you manage and grow your business. FBA fees cover the
cost of storing your products in Amazon's fulfillment centers; picking,
packing, and shipping orders; and providing customer service for products
sold.

##  FBA Overview

##  FBA features

[ Customer service for FBA orders ](/gp/help/external/200298130) : Amazon
provides customer service on your behalf when you sell products through FBA.

[ Global selling ](/gp/help/external/201101640) : Use FBA and the tools
available in your seller account to expand your business globally.

##  FBA services

[ Amazon Partnered Carrier program ](/gp/help/external/201119120) : Amazon
partnered carriers offer discounted rates for shipping your inventory to
fulfillment centers.

[ Multi-Channel Fulfillment ](/gp/help/external/200332450) : Have Amazon fill
orders for inventory that you sell on your own website and other channels.

[ FBA Label Service ](/gp/help/external/200483750) : Amazon will apply barcode
labels to your inventory for you. A per-item fee applies.

[ FBA Prep Service ](/gp/help/external/201023020) : Amazon will prepare your
inventory so it meets FBA prep requirements. A per-item fee applies.

[ FBA Repackaging Service ](/gp/help/external/201505310) : Amazon will
repackage your eligible FBA items that buyers have returned so the items can
be resold.

[ Inventory Placement Service ](/gp/help/external/200735910) : When you create
a shipping plan, your shipment may be divided into multiple shipments going to
different fulfillment centers. With the Inventory Placement Service, you can
send all of your inventory to a single fulfillment center, and Amazon will
distribute it for you. A per-item fee applies.

[ Manual Processing Service ](/gp/help/external/G202061550) : If you do not
provide box content information when you ship inventory to FBA, Amazon will
manually process your boxes at the fulfillment center. A per-item fee applies.

[ Scan & Label ](/gp/help/external/G200621530) : Scan & Label allows you to
scan your products using a barcode scanner, and then print and apply labels
one at a time, making it easier to ensure the right label is applied to the
right unit.

##  FBA fees

[ Fulfillment fees for FBA orders ](/gp/help/external/GPDC3KPYAGDTVDJP) : An
overview of FBA fees for order fulfillment and related services.  1

[ Monthly inventory storage fees ](/gp/help/external/G3EDYEF6KUCFQTNM) :
Storage fees are charged for all items stored in an Amazon fulfillment center
based on calendar month and your daily average volume of inventory.

[ Long-term storage fees ](/gp/help/external/GJQNPA23YWVA4SBD) : Inventory in
Amazon fulfillment centers is assessed a long-term storage fee in addition to
the monthly storage fee.

[ Removal order fees ](/gp/help/external/G9W7FVTLY343ZBKN) and [ disposal
order fees ](/gp/help/external/G5FKTA8LXU4TZPD5) : You can have Amazon return
or dispose of your inventory in Amazon fulfillment centers. A per-item fee
applies.

[ Returns processing fees ](/gp/help/external/G64LS955WNFT6EDP) : A returns
processing fee is charged for orders for which Amazon offers free return
shipping.

[ Unplanned service fees ](/gp/help/external/201000230) : When inventory
arrives at a fulfillment center without proper preparation or labeling, Amazon
provides those services for you. A per-item fee applies.

**Note:** Amazon regularly reviews FBA fulfillment fees. Go to [ FBA
fulfillment fee changes ](/gp/help/external/GABBX6GZPA8MSZGW) for latest
information.

##  FBA fee tools

**Fee estimating tools**

|  
  
---|---  
[ Revenue Calculator ](/gp/help/external/GWYBC38TZGCUNRKW) |  Estimate fees
and profit based on fulfillment channel. ( [ Visit tool
](/fba/revenuecalculator/index) )  
[ Fee Preview report ](/gp/help/external/201115050) |  Download a report that
shows the estimated selling on Amazon and fulfillment fees for your current
listings. (Accessible in [ Fulfillment reports ](/gp/ssof/reports.html) )  
[ Estimated fee per unit sold widget ](/gp/help/external/G200680700) |
Preview the core fees for selling on Amazon and Fulfillment by Amazon when a
unit is sold of a specific SKU. (Accessible on [ Manage inventory
](/inventory) )  
[ Referral Fee Preview report ](/gp/help/external/G201631600) |  Download a
report that provides the estimated referral fee based on your current listed
item price. (Accessible in [ Inventory reports ](/gp/item-
manager/ezdpc/openPickup.html) )  
[ GetMyFeesEstimate API
](https://docs.developer.amazonservices.com/en_US/products/Products_GetMyFeesEstimate.html)
|  The GetMyFeesEstimate API takes a list of products and returns the selling
on Amazon and fulfillment fees for those products.  
  
**Tools to review fees paid**

|  
  
---|---  
[ Amazon fees card ](/gp/help/external/NG95QWKFKSAMYJV) |  Review fees charged
on a SKU over time. (Accessible in SKU Central, by clicking the SKU within [
Manage inventory ](/inventory) )  
[ Payments ](/gp/help/external/G200913190) |  This page provides summary
information on payments, including fees paid. The linked reports provide a
detailed breakdown of fees paid on specific transactions and events. ( [ Visit
page ](/gp/payments-account/settlement-summary.html) )  
[ Fee Explainer ](/gp/help/external/201822160) |  See more details about how
your selling fees were calculated on a specific transaction with the Fee
Explainer. (Accessible in [ Payments – Transaction View ](/gp/payments-
account/view-transactions.html) , when viewing a specific transaction’s
details)  
[ Monthly Storage Fees report ](/gp/help/external/G202086720) |  Download a
report that shows the estimated monthly storage fees for each ASIN of your
inventory stored in Amazon fulfillment centers. (Accessible in [ Fulfillment
reports ](/gp/ssof/reports.html) )  
[ Long-Term Storage Fee Charges report ](/gp/help/external/200725880) |
Download a report that provides itemized long-term storage fee charges for
your inventory stored in Amazon fulfillment centers. (Accessible in [
Fulfillment reports ](/gp/ssof/reports.html) )  
[ Inventory storage overage fees report ](/gp/help/external/GV8JEETWV9Q33CMX)
|  Download a report that shows the estimated inventory storage overage fees,
based on storage type, for your inventory in Amazon fulfillment centers that
exceeds your storage limits. (Accessible in [ Fulfillment reports
](/gp/ssof/reports.html) )  
  
1  [ Lithium batteries fee ](/gp/help/external/G9RJJ3KFHSF6YRAG) and [ Special
handling fee ](/gp/help/external/PBBZR3MDYRS8L36) will be added when
applicable.

Top

##  FBA features, services, and fees

* [ 2023 FBA removal and disposal order fee changes  ](/help/hub/reference/external/GZ5Q2VW5WF4JWRGC)
* [ 2023 FBA Small and Light fee changes  ](/help/hub/reference/external/G3Z4AX6UNV5EN2VR)
* [ FBA manual processing fee  ](/help/hub/reference/external/G202061550)
* [ FBA resources  ](/help/hub/reference/external/G200288170)
* [ Unplanned services  ](/help/hub/reference/external/G201000230)
* [ Scan & Label  ](/help/hub/reference/external/G200621530)
* [ FBA Label Service  ](/help/hub/reference/external/G200483750)
* [ FBA Prep Service  ](/help/hub/reference/external/G201023020)
* [ Add-on program  ](/help/hub/reference/external/G202182410)
* [ Estimated fee per unit sold  ](/help/hub/reference/external/G200680700)
* [ 2023 US referral and FBA fee changes summary  ](/help/hub/reference/external/G201411300)
* [ 2023 FBA New Selection program changes  ](/help/hub/reference/external/G6JNRB2KP2KWT4RA)
* [ Selling full-size appliances  ](/help/hub/reference/external/GGH3QLLAE3N8PM83)
* [ 2023 US FBA fulfillment fee changes  ](/help/hub/reference/external/GABBX6GZPA8MSZGW)
* [ FBA fees  ](/help/hub/reference/external/G200209150)
* [ FBA Subscribe & Save  ](/help/hub/reference/external/G201620110)
* [ FBA Inventory Placement Service  ](/help/hub/reference/external/G200735910)
* [ How Amazon receives and stores your inventory  ](/help/hub/reference/external/G201081250)
* [ FBA customer service  ](/help/hub/reference/external/G200298130)
* [ FBA Global Selling  ](/help/hub/reference/external/G201101640)
* [ FBA repackaging and refurbishment services  ](/help/hub/reference/external/G201505310)
* [ FBA Small and Light  ](/help/hub/reference/external/G201706140)
* [ Extra-large FBA inventory  ](/help/hub/reference/external/GDM5Z5F5FUZVMN7T)
* [ FBA inventory storage overage fees  ](/help/hub/reference/external/GV8JEETWV9Q33CMX)
* [ Remote Fulfillment with FBA  ](/help/hub/reference/external/G5P3CDUHZWSZLXLB)
* [ Fulfillment programs portal  ](/help/hub/reference/external/G2NZU6KZ8FMWHYMP)
* [ FBA New Selection  ](/help/hub/reference/external/GWHQRT98SAZC29VQ)
* [ Virtual product bundles  ](/help/hub/reference/external/G87HAE6PMKKM23Z7)
* [ Sales reports for virtual product bundles  ](/help/hub/reference/external/GG7X74YD2PZLZN9R)
* [ Troubleshooting FAQ for virtual product bundles  ](/help/hub/reference/external/G2BTQWUUDS3RV7WB)
* [ FBA Same-Day Delivery  ](/help/hub/reference/external/GUUSS6CXMUYXGTEC)
* [ Capacity Manager  ](/help/hub/reference/external/GM6SJGQDA625AUCJ)
* [ FBA Capacity Limits  ](/help/hub/reference/external/GAFNWEYTJUV2GBFC)
* [ ](/help/hub/reference/external/G200612770)
* [ ](/help/hub/reference/external/G200685050)
* [ 2023 FBA monthly storage fee and aged inventory surcharge changes  ](/help/hub/reference/external/GJ9NNG7RK4TU6E3Z)

