# FBA product requirements and restrictions

Source: https://sellercentral.amazon.com/gp/help/external/G200140860

This article applies to selling in: **United States**

#  FBA product restrictions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200140860)

Before listing products for Fulfillment by Amazon, it's important to know what
is suitable for our fulfillment process and what is unsuitable. Be sure to
review all sections below for additional product requirements and
restrictions.

**Important:** Failure to comply with FBA product preparation requirements,
safety requirements, and product restrictions may result in the refusal,
disposal or return of inventory upon reception at the Amazon fulfillment
center, the blocking of future shipments to the Amazon fulfillment centers,
charges for preparation or for noncompliance, the deactivation of your selling
account, or fines.

##  FBA product requirements and restrictions

Certain products may be eligible for sale on Amazon, but are not eligible for
Fulfillment by Amazon.  FBA products must also adhere to specific expiration
date and temperature-sensitive product requirements to be eligible for FBA.
For more information, see:

  * [ FBA prohibited products ](/gp/help/external/G201730840)
  * [ Expiration-dated FBA inventory ](/gp/help/external/G201003420)
  * [ Meltable FBA inventory ](/gp/help/external/G202125070)

The products you offer for sale on Amazon must also comply with your [ seller
agreement ](/gp/help/external/G1791) , Amazon’s [ Program Policies
](/gp/help/external/521) , and all applicable laws and regulations.

##  Dangerous goods (Hazmat)

Most products that are regulated as a hazardous material by the U.S.
Department of Transportation (DOT) cannot be processed by Fulfillment by
Amazon. For more information, see:

  * [ Dangerous goods identification guide ](/gp/help/external/201003400)
  * [ Examples of Amazon products that may be regulated as dangerous goods ](/gp/help/external/200525640)
  * [ Requirements for lithium batteries and products that ship with lithium batteries ](/gp/help/external/200383420)
  * [ Required documentation for products regulated as dangerous goods ](/gp/help/external/201371860)
  * [ Upload dangerous goods documents ](/gp/help/external/201371860)

Top

##  FBA product restrictions

* [ FBA prohibited products  ](/help/hub/reference/external/G201730840)
* [ Dangerous goods identification guide (hazmat)  ](/help/hub/reference/external/G201003400)
* [ Expiration dates on FBA products  ](/help/hub/reference/external/G201003420)
* [ Meltable FBA inventory  ](/help/hub/reference/external/G202125070)

