# Payments reference

Source: https://sellercentral.amazon.com/help/hub/reference/external/G69039

This article applies to selling in: **United States**

#  Payments reference

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG69039)

Top

* [ Selling account reviews for seller-fulfilled orders  ](/help/hub/reference/external/G200320980)

