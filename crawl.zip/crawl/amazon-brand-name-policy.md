# Amazon brand name policy

Source: https://sellercentral.amazon.com/gp/help/external/G2N3GKE5SGSHWYRZ

This article applies to selling in: **United States**

#  Amazon Brand Name Policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG2N3GKE5SGSHWYRZ)

On this page

Error messages you may receive related to Amazon’s Brand Name Policy

How to list non-branded products as generic in the Amazon store

What is a brand? What is a non-branded product?

Using the brand attribute correctly

Frequently asked questions

Exceptions to Amazon’s Brand Name policy

This page explains Amazon’s Brand Name Policy, which includes:

  * Error messages you may receive related to Amazon’s Brand Name Policy 
  * What is a brand? What is a non-branded product? 
  * Using the brand attribute correctly 
  * Frequently asked questions 
  * Exceptions to Amazon’s Brand Name Policy 

The Amazon Brand Name policy explains how to use the brand attribute on your
ASINs. The brand attribute on a listing should match the name of the brand
that produced the product (that is, an AmazonBasics product should always show
"by AmazonBasics" on the detail page).

Amazon considers a brand to be a name that represents a product or set of
products. Products from the same brand share a common name, logo, or other
identifying mark that appears on the product or its packaging and are
distinguished from similar products that do not belong to that brand.

  * All new brand attributes must be approved by Amazon before listing products with a new brand attribute. See the list of potential listing error codes you may receive at the bottom of the page and their corresponding next steps. 
  * If you are listing a non-branded product, use _Generic_ in the brand attribute field. 

##  Error messages you may receive related to Amazon’s Brand Name Policy

If you encounter one of the error messages listed below while trying to create
a new ASIN click the link in the error message to automatically create and
route you to a selling application and begin your brand name approval process.
To reduce the time it will take for your request to be reviewed, ensure your
documents meet all the requirements listed in the selling application.

Error code  |  Error message  |  Requested information  
---|---|---  
5664  |  We have identified that you may be listing a generic product and not
using _Generic_ as the brand name, which is not compliant with the [ Brand
Name Policy ](/gp/help/external/G2N3GKE5SGSHWYRZ) . If you believe you are
complying with our policy, [ contact
](/help/hub/support/SOA_Listings_Other_issues) Selling Partner Support and
mention error code 5664.

When contacting Selling Partner Support, provide the following information:

  * The brand name used when creating the listing. 
  * Real-world images of the product, packaging, or both, showing branding on either. The images can show the product, packaging, or both, held in hand, or placed on a table. The branding must be permanently affixed. 
  * If using inventory file templates, also provide the Batch ID of the inventory file process report. 

For more information, go to [ Brand Name Policy
](/gp/help/external/G2N3GKE5SGSHWYRZ) .

|

The brand name used when creating the listing. We will reject your application
if the brand name attribute is a product type, product description, model
number, or anything else besides a brand name.

Images of the product, packaging, or both, must meet the following criteria:

  * Branding is permanently affixed 
  * Branding on the product, packaging, or both, is an exact match for the brand name used when creating the listing 
  * Images do not need to be ASIN-level quality. The product, packaging, or both, can be held in hand, or placed on a table 

Example of an image that meets all requirements for brand name AmazonBasics:

  

If using inventory file templates, also provide the Batch ID of the inventory
file process report.  
  
5665  |

Request approval for your brand.

The brand name you have entered has not been approved by Amazon. Request
approval by submitting an application for your brand for review. If approved,
you will be able to use this brand name in your product listings.  
  
##  How to list non-branded products as generic in the Amazon store

To learn how to resolve error code 5665, watch this Seller University video:

##  What is a brand? What is a non-branded product?

####  What is considered a brand on Amazon?

Amazon considers a brand to be a name that represents a product or set of
products. Products from the same brand share a common name, logo, or other
identifying mark that appears on the product or packaging, and are
distinguished from similar products that do not belong to that brand. Brands
often have trademarks that act as a common name or logo.

For example, the AmazonBasics brand produces a number of different products
such as backpacks, batteries, and kitchen supplies. All AmazonBasics products
should have _AmazonBasics_ in the brand attribute, regardless of the ASIN
title or seller.

The brand attribute is the field in ASIN creation or ASIN editing where
sellers input a value, also known as a brand value. The brand value should
match the name of the brand that produced the product and not be a product
type or product description.

Customers today see brand attribute as a byline on an ASIN’s product detail
page, either above or below the item name. Buyers can click the brand
attribute on an ASIN to find other products from the same brand, which is why
it’s important that accurate information is provided.

A brand cannot be an ASIN’s SKU, a description of the ASIN, or any other name
that is not reflected in branded products or packaging. Your seller account
name will not be considered a valid brand unless your products or their
packaging are branded with that name as well. Branding on products and
packaging must also be permanently affixed.

If your products or packaging are not branded, but you have a registered
trademark for your brand, you can enroll in [ Brand Registry
](https://brandservices.amazon.com/) , which will allow you to list ASINs with
your brand’s name as the brand value.

Sellers are prohibited from using a misrepresentation of an existing brand on
their ASINs. For example, you cannot use _Amaz0nB4$1c$_ in your ASIN’s brand
attribute if you are trying to list an AmazonBasics product.

The detail page below has the brand value _AmazonBasics_ in the brand
attribute (red square), as well as permanently affixed to the product.

####  What is a non-branded product?

When a product is non-branded, it means the product does not belong to any
brand. In these cases, you must use the value _Generic_ in the brand attribute
to indicate the product is unaffiliated with a brand. Non-branded products do
not have a common name, logo, or other name that labels its products or
packaging.

If a product does not have a product identifier such as a Global Trade Item
Number (GTIN) or a Universal Product Code (UPC), you must request and receive
approval from Amazon to list generic products in the desired country and
product category. For more information on getting approval to list products
without an identifier, go to [ How to list products that do not have a Product
ID ](/gp/help/external/G200426310) . You must request this approval for each
country and product category in which you would like to list generic products
without a product identifier.

##  Using the brand attribute correctly

####  When should sellers use a brand’s name as their ASIN’s brand value?

Use the brand’s name as your brand value when the product you are selling
belongs to said brand. Brands apply their name to their products, packaging,
or both, which you can use to determine which value to use in the brand
attribute. For example, a container of protein powder from OWN PWR will have
the name _OWN PWR_ printed on the packaging, so the ASIN should also use the
value _OWN PWR_ in the brand attribute.

ASIN  |  ASIN’s brand value  |  Comments  
---|---|---  
|  _OWN PWR_ |  This brand value is **correct** . The brand value is _OWN PWR_
since the product is from OWN PWR, and branded with OWN PWR’s name.  
|  _OWN PWR_ whey protein  |

This brand value is **incorrect** . The ASIN’s brand value does not match the
branding on the product.

Since the product is from OWN PWR and has its name on the product, the correct
brand value is _OWN PWR_ .  
  
|  _AmazonBasics_ |  This use of the brand attribute is **correct** . The
brand attribute is _AmazonBasics_ since the product is from AmazonBasics, and
branded with AmazonBasics’s brand name.  
|  _Value Resale Shop_ |

This use of the brand attribute is **incorrect** . The brand attribute is the
seller’s account name, not the brand name on the product.

Since the product is from AmazonBasics and has its brand name on the product,
the correct brand attribute is _AmazonBasics_ .  
  
_amazonbasics_mouse_black_ |

This use of the brand attribute is **incorrect** . The brand attribute is the
ASIN’s SKU, not the brand name on the product.

Since the product is from AmazonBasics and has its brand name on the product,
the correct brand attribute is _AmazonBasics_ .  
  
_GBbFP054dfo78_ |

This use of the brand attribute is **incorrect** . The brand attribute is
random letters and numbers, not the brand name on the product.

Since the product is from AmazonBasics and has its brand name on the product,
the correct brand attribute is _AmazonBasics_ .  
  
####  **When should sellers use _Generic_ as their ASIN’s brand value? **

Use the brand value _Generic_ when the product you are selling does not belong
to any brand. For example, a pack of paper towels that does not belong to a
brand would not have any branding, so the ASIN should use the brand value
_Generic_ .

_Generic_ should not be used when a product contains branding from a brand.
For example, a computer mouse that is permanently affixed with the
AmazonBasics branding should not use _Generic_ as the brand value. Instead,
the brand value should be _AmazonBasics_ .

ASIN  |  ASIN’s brand value  |  Comments  
---|---|---  
|  _Generic_ |  This brand value is **correct** . The brand attribute is
_Generic_ since the product is not from any brand, and is not branded with any
brand’s name.  
|  _Generic_ |

This brand value is **incorrect** . The brand attribute is _Generic_ , despite
the product belonging to a brand.

Since the product is from AmazonBasics and has its name on the product, the
correct brand value is _AmazonBasics_ .  
  
####  For bundles that contain more than one branded product, which brand
value should the ASIN use?

Consult our [ Product Bundling Policy ](/gp/help/external/G200442350) for more
information.

####  What brand value should the ASIN use if the product is branded with more
than one brand’s name?

Brand your products in accordance with the manufacturer or rights owner’s
branding guidelines.

####  What brand value should an ASIN use if its product is compatible with a
differently branded product?

The ASIN should use the brand value that matches the product itself. For
example, if a product was a non-branded USB charging cable that is compatible
with AmazonBasics speakers, the brand value should be _Generic_ . To learn
more about compatibility terms, go to the [ Amazon Intellectual Property
Policy ](/gp/help/external/201361070) .

ASIN  |  ASIN’s brand value  |  Comments  
---|---|---  
|  _AmazonBasics_ |  This brand value is **correct** . The brand value is
_AmazonBasics_ since the product is from AmazonBasics, and branded with
AmazonBasic’s name.  
|  _Generic_ |  This brand value is **correct** . Title indicates
compatibility without implying that this is an AmazonBasics branded product.
The brand value is _Generic_ since the product is not from any brand, and is
not branded with any brand’s name.  
Six foot USB charging cable, compatible with AmazonBasics speaker  |
_AmazonBasics_ |

This brand value is **incorrect** . The brand value is _AmazonBasics_ , but
the product is not part of the AmazonBasics brand.

Since the product is not part of any brand, and the product does not have a
brand’s name on it, the correct brand value is _Generic_ .  
  
Wireless Speaker Inc. Six foot USB charging cable, compatible with
AmazonBasics speaker  |  _Wireless Speaker Inc._ |  This brand value is
**correct** . Title indicates compatibility without implying that this is an
AmazonBasics branded product. The brand value is _Wireless Speaker Inc._ since
the product is from Wireless Speaker Inc., and branded with Wireless Speaker
Inc.’s name.  
  
##  Frequently asked questions

####  Should Print on Demand products use _Generic_ or a Print on Demand
brand’s name?

Print on Demand businesses print designs on a number of different products
such as shirts, coffee mugs, and curtains at the time of a customer order.

Print on Demand products should use the brand value _Generic_ if the product
or packaging is not branded, unless you have a registered trademark. In that
case, you can enroll in [ Brand Registry ](https://brandservices.amazon.com/)
, which will allow you to list ASINs with your brand’s name as the brand
value. If the product or packaging from the Print on Demand business is
branded, the ASINs should use that business’s name as the brand value.

####  How should sellers brand Amazon Renewed ASINs?

Amazon Renewed ASINs should still use the brand value of the original product.
For example, if you are listing an Amazon Renewed AmazonBasics Wireless Mouse,
the brand value should still be _AmazonBasics_ .

####  What does permanently affixed branding mean?

A brand name printed on packaging would be considered permanently affixed. A
sticker would not be considered permanently affixed branding as it can be
added after production. If a product or packaging does not have any branding,
the brand value should be _Generic_ .

Some products cannot be permanently affixed, like furniture or jewelry. In
these cases, the packaging must show evidence of the brand being permanently
affixed upon it. Other products, like phone cases or clothing, can have
branding on the products themselves.

####  What if my brand’s products do not have a product ID, such as a UPC,
EAN, or JAN?

UPC requirements may vary across categories or for different types of products
in the same category. Certain categories may allow you to request UPC
exemptions.  For more information, go to [ Guidelines for UPC and GTIN
](/gp/help/external/G5JQC6VY6BVYWDPT) .

####  I’m unable to edit the ASIN brand name to correct a typo,
capitalization, or legal abbreviation showing incorrectly on the Detail page.

Regardless of error type, brand name corrections for a Brand Registered ASIN
will only be supported if requested by the registered Brand owner.

If your ASIN brand name attribute is listed incorrectly due to a typo,
capitalization, or legal abbreviation issue, navigate to our [ Contact Us
](/help/hub/support) page and search “update brand name”. Select your use case
and follow the instructions provided by the workflow. Or, browse for your
issue in the menu by selecting **Products, Listings, or Inventory > Fix a
product page ** and following the workflow. Note that images showing the
product, brand, and product identifier (if applicable), manufacturer proof, or
both, are required to accommodate your request.

Brand name change requests beyond these minor corrections are considered re-
branding and will not be supported. To protect Customer trust and ensure
catalog quality, we ask that you create a new ASIN for the new product in
accordance with [ Amazon’s Product Detail page Rules
](/gp/help/external/G200390640) .

##  Exceptions to Amazon’s Brand Name policy

####  Do all ASINs require a brand value?

No. Products that are part of the Books, Music, Video, DVD, or Digital (BMVD)
categories do not need a brand value, non-branded, or otherwise. Their brand
attributes can be left blank on ASIN creation. To learn more about BMVD
products, go to [ What does BMVD mean ](/gp/help/external/G200384340) .

Top

