# How do I read my Payments report

Source: https://sellercentral.amazon.com/gp/help/external/14921

This article applies to selling in: **United States**

#  How do I read my Payments report?

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F14921)

The Payments (settlements) reports you download from Seller Central are tab-
delimited text files. The easiest way to read a Payments report is to save it
to your computer and then open it in your favorite spreadsheet or database
application. Then you can easily summarize, manipulate, or reformat the data
the way you want.

Some web browsers automatically open reports with your computer's default text
editor. To avoid this, save a copy of the report to your computer before
opening it in another application.

For more information about what each column means in a Payments report, see [
Downloading Payment Reports ](/gp/help/external/791) .

Top

