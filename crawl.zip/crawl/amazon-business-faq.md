# Amazon Business FAQ

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201740290

This article applies to selling in: **United States**

#  Amazon Business FAQ

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201740290)

Top

* [ Pay by Invoice FAQ  ](/help/hub/reference/external/G202085520)

