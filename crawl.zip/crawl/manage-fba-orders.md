# Manage FBA orders

Source: https://sellercentral.amazon.com/gp/help/external/200141600

This article applies to selling in: **United States**

#  Manage FBA Orders

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200141600)

To review the status of FBA orders placed on Amazon on your **Manage Orders**
page, click the **view FBA orders** link.  If you sell your inventory on
Amazon using Fulfillment by Amazon, Amazon manages your orders for you.

Payments for completed orders appear in your [ Payments ](/gp/payments-
account/settlement-summary.html) report.

[ Manage Orders ](/gp/orders-v2/list) displays a list of all Unshipped,
Pending, Shipped, and Canceled orders, including:

  * Order details, including order ID, product name, quantity ordered, ASIN, SKU, sales channel, fulfillment method, and billing country. 
  * Shipping information, including shipping method, payment status, and any pending actions. 
  * Tools for managing your orders, such as cancellations and refunds, shipping tools (purchase shipping and print packing slips), and more. For orders fulfilled by Amazon, Amazon customer service handles these actions. 

For more information on how the **Manage Orders** page works, see [ Manage
Orders ](/gp/help/external/G28141) .

For information about how to search for and filter orders, see [ Search Orders
](/gp/help/external/28151) .

##  Amazon-fulfilled orders

An Amazon-fulfilled order status can be either:

  * **Pending** \- Some of the items in the order have not shipped. Orders may be pending because: 
    * The order is pending while other items are consolidated for free shipping. 
    * The credit card payment has not been authorized. 
    * An item in the order is out of stock. In cases where Amazon splits the order, the status will be **Pending** until the final item has shipped, even if the payment is complete. 
  * **Payment Complete** \- The order has been paid for. 

##  Multi-channel Fulfillment Orders

Multi-channel fulfillment orders are identified as "Non-Amazon" in the **Sales
Channel** field in the **Order Details** .

A Multi-channel Fulfillment order status can be one of the following:

  * **Unfulfillable** \- The order cannot be completed because the product is out of stock or the shipping address is invalid. 
  * **Planning** \- The order has been received. 
  * **Shipping** \- The order is being packed for shipment. 
  * **Complete** \- The order has shipped. 

For more information about managing Multi-channel Fulfillment orders, see [
Multi-Channel Fulfillment ](/gp/help/external/200332450) .

Top

