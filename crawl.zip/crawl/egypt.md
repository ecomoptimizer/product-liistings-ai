# Egypt

Source: https://sellercentral.amazon.com/gp/help/external/G9GFNKKWR5MVPFXB

This article applies to selling in: **United States**

#  If your business location is Egypt

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG9GFNKKWR5MVPFXB)

##  If your business location is Egypt

**Identity document** : We accept ID documents such as national ID cards,
resident ID cards, Gulf Cooperation Council (GCC) ID cards issued by the Arab
Emirates, Saudi Arabia, Oman, Bahrain, Kuwait, or Qatar and foreign residence
ID.

**Note:** If you are a business type seller, you can provide: passport,
passport card, Driving license (DL), Enhanced DL (EDL), citizenship card,
permanent residency card, health card or military identification card.

Make sure your document also meets the following criteria:

  

  1. Digital national and residential ID card are accepted. 
  2. ID document from Egypt can be either in color or in black and white. 
  3. If the date of birth or expiration date is in the Hijri calendar format, we accept a variation margin of 5 days (+/- 5 days). 

**Proof of Address document:**

**If you do not have a business and registered as an individual**

We accept only bank account statements, credit card statements, loan
Statements, bank letter issued by any bank or statements from any payment
service providers, utility bill for electricity, water, gas, mobile phone,
fixed-line phone, or internet service issued by an official public
institution.

Make sure your document also meets the following criteria:

  

  1. It is not a payment receipt, ATM receipt or money transfer receipts. 
  2. Bank document or utility bill must be from country of residence/registration. 
  3. Name of the bank account or credit card holder must match the name of the ID document's holder. 

**If you registered as a business**

We accept only listed government-issued business documents from the United
Arab Emirates, business licenses issued by the Ministry of Commerce and
investment from Saudi Arabia, municipality license (business activity license)
from Saudi Arabia, commercial registrations issued by the commercial registry
office of Egypt.

Make sure your document also meets the following criteria:

  

  1. It displays the name of the business owner or legal representative. Names (business owner/partner/representative) in the business document must match the name on the identity document uploaded during registration. If the name is not matching, a power of attorney (POA) or a letter of authorization (LOA) confirming that the company's legal representative or point of contact (POC) is authorized to register, manage the account and transact on behalf of the company can be accepted. 
  2. Business-operating entity name. 
  3. Business address from the Egypt (if applicable). 
  4. License number/registration number/company register number. 
  5. Official seal or stamp of the issuing authority. 

**Note:** Screenshots are acceptable if all the required details are available
and clearly visible. While submitting your LOA or POA, merge either of the
documents (POA+BL or LOA+BL along with the BL and upload it within BL document
upload section as a single document.

For more information, go to [ Frequently asked questions about Global SIV
](/gp/help/external/G2MJXHQCR62DZSSM) .

Top

