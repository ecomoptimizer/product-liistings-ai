# Fulfillment by Amazon (FBA) Policies

Source: https://sellercentral.amazon.com/gp/help/external/G201030350

This article applies to selling in: **United States**

#  FBA policies and requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201030350)

Before listing products for Fulfillment by Amazon, it's important to know what
are the policies and requirements that impact you as a seller using Amazon to
fulfill orders for your products.

##  FBA policies

  * [ Customer Feedback for FBA Listings ](/gp/help/external/201101660)

Customers can leave feedback for you on orders fulfilled by Amazon. Negative
feedback related to order fulfillment or customer service provided by Amazon
can be stricken through.

  * [ Customer Returns for Orders Placed on Amazon ](/gp/help/external/200379860)

Amazon's return policies determine how FBA customer returns are handled and
under what circumstances you may be eligible for a full or partial
reimbursement for a return accepted by Amazon.

  * Customer Service for Multi-Channel Fulfillment orders 

You are responsible for replacements, refunds, and returns for multi-channel
fulfillment orders.

  * [ FBA Lost and Damaged Inventory Reimbursement Policy ](/gp/help/external/200213130)

You may be eligible for a full or partial reimbursement for inventory that is
either lost or damaged when it is under Amazon's control (damaged by an Amazon
partnered carrier, in the fulfillment center, or during delivery to a
customer).

##  FBA requirements

  * [ FBA Product Restrictions ](/gp/help/external/200140860)

Some products require prior approval before you can sell them on Amazon. In
addition, there are certain products that either cannot be sold using FBA, or
must meet certain requirements before they can be sold using FBA.

  * [ Inventory Requirements ](/gp/help/external/201100890)

Certain requirements, including requirements for labeling, packaging, and
shipping inventory, must be met for inventory shipped to Amazon fulfillment
centers.

Top

##  FBA policies and requirements

* [ FBA product restrictions  ](/help/hub/reference/external/G200140860)
* [ FBA inventory requirements  ](/help/hub/reference/external/G201100890)
* [ FBA customer returns policy  ](/help/hub/reference/external/G200379860)
* [ ](/help/hub/reference/external/G201101660)
* [ FBA fees reimbursement policy: Weight and dimensions  ](/help/hub/reference/external/GGL7U4JFSDXUTQAJ)
* [ Understanding item package weight and dimensions  ](/help/hub/reference/external/G6WAEPTECPT2JUH3)
* [ Expiration-dated COVID-19 products  ](/help/hub/reference/external/GZ6CL7V77FSV883F)

