# How to set up efficient budgets

Source: https://sellercentral.amazon.com/gp/help/external/GYARGFE3ZG77FBLJ

This article applies to selling in: **United States**

#  How to set up efficient budgets

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGYARGFE3ZG77FBLJ)

An efficient budget covers the cost of the customer demand that your coupon
generates, for the duration you set. For example, if a product is selling an
average of 20 units per day without a coupon, and you want to run a $5 off
coupon for 10 days for this product, then the minimum budget you can set must
be (number of days x number of average daily units) x (discount amount +
redemption fee). In this example (10 x 20) x (5.60). $1,120 is your minimum
budget.Budget over-spending occurs during high traffic events and when your
coupon is combined with other promotions, such as lightning deals.

Avoid creating low budgets (less than $500) for deep discount coupons such as
80% off or $35 off. Low budgets for high discounts will cause your budget to
expire rapidly in a couple of hours. As a result, only few customers will be
able to see and interact with your coupon.

Top

