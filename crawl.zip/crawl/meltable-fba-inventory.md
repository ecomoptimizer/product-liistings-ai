# Meltable FBA inventory

Source: https://sellercentral.amazon.com/gp/help/external/G202125070

This article applies to selling in: **United States**

#  Meltable FBA inventory

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202125070)

Before listing products with Fulfillment by Amazon, it’s important to know
what’s suitable for fulfillment and what isn’t. For information on product
requirements and restrictions, go to the following Help pages:

  * [ Expiration-dated FBA inventory ](/gp/help/external/201003420)
  * [ Category approval ](/gp/help/external/G200333160)
  * [ Amazon product restrictions ](/gp/help/external/200164330)

##  Meltable inventory requirements

FBA accepts meltable products from October 16 to April 14 only. Meltable
inventory stored or arriving at our fulfillment centers from April 15 to
October 15 is marked unfulfillable and disposed of for a fee.

"Meltable" refers to all heat-sensitive products, including but not limited to
chocolate, gummies, and select jelly- and wax-based products.

Products in Amazon fulfillment centers must meet quality standards during the
summer months (75 to 155 degrees Fahrenheit). This temperature range is set to
protect product integrity during product storage and shipping.

**Note:** If you believe your product should be exempt from the meltable
category, send a letter from the manufacturer to [ Selling Partner Support
](/cu/contact-us) . The letter must be written on manufacturer letterhead, and
must include the following information:

  * Specific products and/or ASINs 
  * Explicit confirmation that the ASIN or ASINs can be stored at a maximum temperature of 155 degrees Fahrenheit for extended periods 
  * Point of contact for verification 

Products requiring refrigeration, air conditioning, or freezing are prohibited
throughout the year. Perishable products, including but not limited to fresh
meats, fruits, or vegetables are also prohibited throughout the year.

##  Removing meltable inventory

Removal orders for meltable inventory must be submitted before April 15 of
each year. For more information, go to [ Remove inventory from a fulfillment
center ](/gp/help/external/201436560) .

To download a list of meltable ASINs, go to: [ Meltable ASINs (Excel)
](https://m.media-
amazon.com/images/G/01/AmazonServices/Site/US/Product/FBA/MeltablesList-
SummerShip.xlsx) . This list is updated periodically, and no later than March
1 for the upcoming April 15 disposal start date.

Top

