# Create edit or delete shipping  templates

Source: https://sellercentral.amazon.com/gp/help/external/G201834090

This article applies to selling in: **United States**

#  Create, edit, or delete shipping templates

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201834090)

On this page

Create a new shipping template

Edit an existing shipping template

Delete an existing shipping template

Review past changes in a shipping template

**Note:** To enable Prime in your shipping template, refer to [ Configure
shipping settings for Seller Fulfilled Prime ](/gp/help/external/G201860010)

Before you create a template, make sure you understand the [ requirements
](/gp/help/external/202115770) for shipping templates and verify that your
default shipping address is accurate.

##  Create a new shipping template

  

  1. From the **Settings** menu, click [ Shipping Settings ](/sbr/ref=xx_shipset_dnav_xx#shipping_templates) , then verify your **Default Shipping Address** is correct before creating a new shipping template. 
  2. On the **Shipping Templates** tab: 
    * Click **Create New Shipping Template** , or 
    * Choose an option under **No, I want to copy the content from** . 
  3. Click **OK** . 
  4. Enter the template name (for example, "Free Shipping"). 
  5. Choose the [ rate model ](/gp/help/external/201841310) for your shipping rates:   

    1. **Per item / weight-based** , or 
    2. **Price banded**
  6. Enable or disable **Prime delivery** as required. 
  7. Select or deselect **Same day** for **Handling Time Settings** . 
  8. Edit **Shipping Options** , **Regions** , and **Rates** as applicable. 
    * Enable **Domestic** or **International** shipping options (such as Expedited) by selecting the checkbox next to the shipping option name. 
    * Select the regions by clicking either **Edit** or **Add New Region** . 
    * Within the **Select Deliverable Regions** pop-up window, select or deselect the region(s) you want to use for the same transit time and shipping cost. 
  9. Click **OK** . 
  10. Select the **Address Type** for the region(s). See [ Minimum requirements ](/gp/help/external/202115770) for more information. 
  11. Set your **Shipping Time** (in business days) for the region(s). 
  12. [ Set your shipping rates ](/gp/help/external/201841310) . Click **Save** . 

**Tip:** We recommend simplifying your shipping rates as much as possible.
Offering free shipping can increase sales and improve your chances of winning
the buy box. You can create multiple rules for the same shipping option to
customize the settings by region.

You are now ready to [ assign SKUs to the shipping template
](/gp/help/external/201841600) .

##  Edit an existing shipping template

If you need to edit the ship-from address for your template, see above.  

  1. From the **Settings** menu, click [ Shipping Settings ](/sbr/ref=xx_shipset_dnav_xx#shipping_templates) . 
  2. Under the **Shipping Templates** list, select the template you want to edit. 
  3. Click **Edit Template** on the right side of the screen. 
  4. Enable or disable **Prime delivery** as required. 
  5. Select or deselect **Same day** for **Handling Time Settings** . 
  6. Edit **Shipping Options** , **Regions** , and **Rates** as applicable. 
    * Enable **Domestic** or **International** shipping options (for example: Expedited) by selecting the checkbox next to the shipping option name. 
    * Select the regions by clicking either **Edit** or **Add New Region** . 
    * Within the **Select Deliverable Regions** pop-up window, select or deselect the region(s) you want to use for the same transit time and shipping cost. 
  7. Select the **regions** by clicking either **Edit** or **Add New Region** . 
  8. Click **OK** . 
  9. Select the **Address Type** for the regions.  Go to [ Minimum requirements ](/gp/help/external/202115770) for more information. 
  10. Set your **Shipping Time** (in business days) for the regions. 
  11. Set the [ shipping rates ](/gp/help/external/201841310) . 

**Tip:** We recommend simplifying your shipping rates as much as possible.
Offering free shipping can increase sales and improve your chances of [
Becoming the Featured Offer ](/gp/help/external/201687550) . Also, you can
create multiple rules for the same shipping option to customize the settings
by region.

  12. Repeat this process as needed. 
  13. Click **Save** . 

##  Delete an existing shipping template

You cannot delete the default shipping template or migrated template. To
delete any of the other templates, follow these steps.  

  1. From the **Settings** menu, click **Shipping Settings** . 
  2. On the **Shipping Templates** tab, select a template from the list. 
  3. Click drop-down menu from the **Edit Template** button, and click **Delete** . 

**Note:** You must first re-assign SKUs to another template before you can
delete a template. To know more, refer [ Assign SKUs to shipping templates
](/gp/help/external/201841600) .

##  Review past changes in a shipping template

  

  1. From the **Settings** menu, click **Shipping Settings** . 
  2. On the **Shipping Templates** tab, select a template from the list of templates. 
  3. Click **Revision History** from the drop-down menu to the right of the **Edit Template** button. 

Top

