# Payment options

Source: https://sellercentral.amazon.com/gp/help/external/201950990

This article applies to selling in: **United States**

#  Payment Options

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201950990)

Certain business transactions need to be recorded by Amazon under separate
legal entities (Amazon Payments Inc. and Amazon Services LLC), so these
transactions are displayed separately. You will continue to be paid in the
bank account you have designated.

**Note:** This is available for business orders only. [ Learn more
](https://sellercentral.amazon.com/hz/b2bregistration)

If you receive an order from an Amazon Business customer, you may see a new
tab in your Payments view, because a small portion of business transactions
need to be processed through a separate Amazon legal entity. This does not
change the timing or amount of your payment.  

  1. From your seller account, select **Reports** , then select **Payments** . 
  2. Your payment details are displayed on two tabs. You can switch between the two tabs, **Amazon Payments Inc.** and **Amazon Services LLC** . Business orders are displayed under the **Amazon Services LLC** tab. 

**Note:** When you log into your seller account, the **Balance** field under
Payments Summary does **not** include payments related to business orders from
Amazon Services LLC; it only includes payments from Amazon Payments Inc.
Payments related to business orders are under the Amazon Services LLC tab.

[ Frequently Asked Questions
](https://sellercentral.amazon.com/gp/help/external/201953040)

Top

