# initial-url

Source: https://sellercentral.amazon.com/help/hub/reference/external/G2

This article applies to selling in: **United States**

#  Help for Amazon Sellers

If you are already a seller, [ sign in ](/gp/sign-in/sign-
in.html?destination=%2Fgp%2Fhelp%2Fhelp%3Fref%3Defph_login_subtitle_helphome)
to search all of our help content and self-service tools.

##  [ Account settings  ](/help/hub/reference/external/G181)

* [ Selling on Amazon  ](/help/hub/reference/external/G200421970)
* [ Get Started with Selling Services  ](/help/hub/reference/external/G201484560)
* [ Global seller identity verification  ](/help/hub/reference/external/GQRP483PDN88Q3M9)
* [ Two-Step Verification  ](/help/hub/reference/external/G202110760)
* [ Manage account settings  ](/help/hub/reference/external/G69035)
* [ Seller-fulfilled shipping  ](/help/hub/reference/external/G200342080)
* [ Selling on Amazon video tutorials  ](/help/hub/reference/external/G201813650)
* [ Bank account and credit card information for your seller account  ](/help/hub/reference/external/G19791)
* [ Selling on Amazon reference  ](/help/hub/reference/external/G69036)

##  [ Policies, agreements, and guidelines
](/help/hub/reference/external/GSNV3657R94YP9DZ)

* [ Amazon Services Business Solutions Agreement  ](/help/hub/reference/external/G1791)
* [ Changes to the Amazon Services Business Solutions Agreement  ](/help/hub/reference/external/G47071)
* [ Program Policies  ](/help/hub/reference/external/G521)
* [ Changes to program policies  ](/help/hub/reference/external/GQHQGBTD7XB7EECN)
* [ Intellectual Property for Rights Owners  ](/help/hub/reference/external/GU5SQCEKADDAQRLZ)
* [ International selling agreements  ](/help/hub/reference/external/GEENGDB2JGLEK3PZ)
* [ Additional Guidelines  ](/help/hub/reference/external/G69G3YF8A6VG7C2Y)
* [ About seller facial data  ](/help/hub/reference/external/GVQRRK8ZNHUVNQ6Y)
* [ Use of business credit reports  ](/help/hub/reference/external/G6TS99MYVGUEAKJW)

##  [ Increase sales  ](/help/hub/reference/external/G43381)

* [ Start selling  ](/help/hub/reference/external/G69064)
* [ Amazon promotions  ](/help/hub/reference/external/G60951)
* [ Seller Fulfilled Prime  ](/help/hub/reference/external/G201812230)
* [ Advertise with Amazon  ](/help/hub/reference/external/G200663330)
* [ Amazon deals  ](/help/hub/reference/external/G202043110)
* [ Coupons  ](/help/hub/reference/external/G3QLEV6W2QK84C57)
* [ Prime Exclusive Discount  ](/help/hub/reference/external/GZG6D3FZA9VSP4XH)
* [ Amazon Outlet  ](/help/hub/reference/external/GHLYT4TPVCY2MJE3)
* [ Manage Your Experiments  ](/help/hub/reference/external/GVP453K5XRBJS7Y9)
* [ A+ content  ](/help/hub/reference/external/G202102930)
* [ Amazon Vine  ](/help/hub/reference/external/G92T8UV339NZ98TN)
* [ Brand Referral Bonus  ](/help/hub/reference/external/GL9HPJ34VBFP76HX)
* [ Manage Your Customer Engagement  ](/help/hub/reference/external/GF85G8KLPFJZZV5K)
* [ Opportunity Explorer  ](/help/hub/reference/external/GNJ4YRTXWLMBY38U)
* [ FBA Opportunities  ](/help/hub/reference/external/GLVZKY7AM8CKEBU6)
* [ New Seller Incentives  ](/help/hub/reference/external/GXMJ38VA95GUN5XU)
* [ Additional tips for increasing sales  ](/help/hub/reference/external/G69065)
* [ Additional resources for increasing sales  ](/help/hub/reference/external/G69066)

##  [ Get started with Fulfillment by Amazon (FBA)
](/help/hub/reference/external/G53921)

* [ FBA Global Selling  ](/help/hub/reference/external/G5KV5DGG6UMQAKL4)
* [ Ship products to Amazon  ](/help/hub/reference/external/G200141420)
* [ FBA policies and requirements  ](/help/hub/reference/external/G201030350)
* [ FBA features, services, and fees  ](/help/hub/reference/external/G201074400)
* [ FBA inventory  ](/help/hub/reference/external/G201074410)
* [ Multi-Channel Fulfillment: Fulfill orders for your sales channels  ](/help/hub/reference/external/G200332450)
* [ Amazon Warehousing and Distribution (AWD)  ](/help/hub/reference/external/GF6ZC8VEBM7HCEGV)

##  [ Amazon Global Selling  ](/help/hub/reference/external/G201062890)

* [ Merge accounts  ](/help/hub/reference/external/G201841950)
* [ Get started with Amazon Global Selling  ](/help/hub/reference/external/G201468440)
* [ Payments for global accounts  ](/help/hub/reference/external/G201468470)
* [ Global registration  ](/help/hub/reference/external/GKMK7CM7F9Q8FKUG)
* [ Where and what to sell with Amazon Global Selling  ](/help/hub/reference/external/G201468340)
* [ Amazon North American stores  ](/help/hub/reference/external/G201394090)
* [ Amazon EU and UK stores  ](/help/hub/reference/external/G200671260)
* [ Build International Listings  ](/help/hub/reference/external/G202121570)
* [ Ship and fulfill with Amazon Global Selling  ](/help/hub/reference/external/G201468490)
* [ Taxes and regulations for Amazon Global Selling  ](/help/hub/reference/external/G201468380)
* [ Customer support and returns for international sales  ](/help/hub/reference/external/G201468530)
* [ Find help from external solution providers with Selling Partner Appstore  ](/help/hub/reference/external/G201687890)
* [ Customer Service by Amazon program  ](/help/hub/reference/external/GYGMNGX67ZJZMZNP)
* [ Unify global accounts  ](/help/hub/reference/external/GJZJNMG4UX3DXSGV)

##  [ Payments  ](/help/hub/reference/external/G211)

* [ Payments FAQ  ](/help/hub/reference/external/G69122)
* [ Payments tasks and tools  ](/help/hub/reference/external/G69038)
* [ Payments reference  ](/help/hub/reference/external/G69039)
* [ Seller Lending program  ](/help/hub/reference/external/GZN5DX64LP2QYZ69)
* [ Funds withholding policy  ](/help/hub/reference/external/G9RA9LYBJ3QP27M6)
* [ Acceptable bank accounts and payment service providers  ](/help/hub/reference/external/GKLETRP8MLF7CVFX)
* [ Payment Service Provider FAQ  ](/help/hub/reference/external/GY8JTVAWBPQT2XFC)
* [ Payment Service Provider updates  ](/help/hub/reference/external/GHP8M87Z5W6XTSTL)
* [ Seller Wallet FAQ  ](/help/hub/reference/external/GW57DZACAZGNREVQ)
* [ Express Payout frequently asked questions  ](/help/hub/reference/external/GA24UN79VBPKXZXX)
* [ Express Payout Bank Account and Visa Debit Card Policies  ](/help/hub/reference/external/GHRCBB7RE3HSLGHC)
* [ Buy with Prime lending program  ](/help/hub/reference/external/GY28S6RDW7Z4N5NS)

##  [ Manage inventory  ](/help/hub/reference/external/G41)

* [ Featured Offer  ](/help/hub/reference/external/G37911)
* [ Create and manage offers  ](/help/hub/reference/external/GFQ8J5JPKERTHQPP)
* [ Manage your offers one at a time  ](/help/hub/reference/external/G201186860)
* [ Manage your offers in bulk  ](/help/hub/reference/external/G9DZLGS87GVDT94B)
* [ Price your item  ](/help/hub/reference/external/G62551)
* [ Catalog and drafts  ](/help/hub/reference/external/G202078860)
* [ Custom Report Builder  ](/help/hub/reference/external/GEQ8JEWH5KJC5QCG)

##  [ Manage Orders  ](/help/hub/reference/external/G28141)

* [ Order Reports  ](/help/hub/reference/external/G651)
* [ The order process  ](/help/hub/reference/external/G200200040)
* [ Search orders  ](/help/hub/reference/external/G28151)
* [ Communicate with buyers using the Buyer-Seller Messaging Service  ](/help/hub/reference/external/G200389080)
* [ Options for managing orders  ](/help/hub/reference/external/G200198170)
* [ Your orders list  ](/help/hub/reference/external/G201724060)
* [ View your orders  ](/help/hub/reference/external/G201724070)
* [ Pending Orders  ](/help/hub/reference/external/G40571)
* [ Manage Orders FAQ  ](/help/hub/reference/external/G69124)

##  [ Returns, refunds, cancellations, and claims
](/help/hub/reference/external/G69126)

* [ Manage seller-fulfilled returns  ](/help/hub/reference/external/G200708210)
* [ Issue refunds and concessions for seller-fulfilled orders  ](/help/hub/reference/external/GU7K5N5GUP67M4X9)
* [ Cancellations  ](/help/hub/reference/external/GBN4AZVWUS29ZUJX)
* [ ](/help/hub/reference/external/GQ6762Y9AB2FYDY8)

##  [ Monitor feedback and performance  ](/help/hub/reference/external/G171)

* [ Getting Started  ](/help/hub/reference/external/G69031)
* [ Tasks & tools  ](/help/hub/reference/external/G69032)
* [ Reference  ](/help/hub/reference/external/G69033)
* [ E-Learning Tutorials  ](/help/hub/reference/external/G200289490)
* [ Frequently Asked Questions  ](/help/hub/reference/external/G69120)
* [ Prepare for the Holiday Season  ](/help/hub/reference/external/G8ZDWEJB9Z9YPFQ8)

##  [ Amazon Business  ](/help/hub/reference/external/G201542150)

* [ Amazon Business terms  ](/help/hub/reference/external/G202087450)
* [ B2B product opportunities  ](/help/hub/reference/external/GG6RSFHJVGD653MV)
* [ Troubleshoot Amazon Business errors  ](/help/hub/reference/external/G201812760)
* [ B2B Central  ](/help/hub/reference/external/G202161480)
* [ Amazon Business features  ](/help/hub/reference/external/G201741830)
* [ Amazon Business glossary  ](/help/hub/reference/external/G201760900)
* [ Amazon Business FAQ  ](/help/hub/reference/external/G201740290)
* [ Amazon Business Professional Healthcare program  ](/help/hub/reference/external/GFFRHXRJSRGPZ9UL)
* [ COVID-19 infection control and recovery  ](/help/hub/reference/external/GGLKLPJ5DCN6CMLW)
* [ Amazon Bulk Services: Overview  ](/help/hub/reference/external/GXNDQS697S3JVFK6)
* [ Amazon Bulk Services: Creating a package hierarchy  ](/help/hub/reference/external/GQ4S7SV9K4GXH3WX)

##  [ Amazon Handmade  ](/help/hub/reference/external/G201817090)

* [ Get started with Amazon Handmade  ](/help/hub/reference/external/G2NVGK9X3Y4XRT9H)
* [ Amazon Handmade terms and conditions  ](/help/hub/reference/external/G201817290)
* [ Maker profile for Handmade  ](/help/hub/reference/external/G201817720)
* [ Amazon Handmade: List your products  ](/help/hub/reference/external/G201817280)
* [ Amazon Handmade: Category listing policies & requirements  ](/help/hub/reference/external/GNGMMFQ5FPLJFBJP)
* [ Common reasons you cannot find your Handmade listings  ](/help/hub/reference/external/GRCWJ4KHBNQ3SNTB)
* [ Relisting ‘Inactive’ Handmade listings  ](/help/hub/reference/external/G2YC8BRR324G39TY)
* [ Policies for Amazon Handmade returns, refunds, restocking fees, and cancellations  ](/help/hub/reference/external/G201817830)
* [ Amazon Handmade: Referral fees  ](/help/hub/reference/external/G201814220)
* [ Amazon Handmade: Best practices for fulfilling orders  ](/help/hub/reference/external/G201835090)
* [ Leave Amazon Handmade  ](/help/hub/reference/external/G201816790)

