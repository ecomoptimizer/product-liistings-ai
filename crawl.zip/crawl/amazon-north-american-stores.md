# Amazon North American stores

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201394090

This article applies to selling in: **United States**

#  Amazon North American stores

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201394090)

On this page

Managing Inventory in Your North America Unified Account

Global SKU

Marketplace-specific SKU

See also

With a North America Unified Account, you can conveniently switch in Seller
Central between Amazon.com, Amazon.ca, and Amazon.com.mx seller tools to list
products and manage orders in multiple marketplaces. You have the option to
list in one, two, or all three of the available North American marketplaces.

The North America Unified Account allows you to more easily:

  * Share listing information and manage your inventory consistently across Amazon's U.S., Canada, and Mexico marketplaces 
  * Keep track of orders on multiple North American sales channels in Manage Orders or with one combined Order Report 
  * Access tools and services to help you manage your business across the U.S., Canada, and Mexico marketplaces 
  * Pay a single monthly Professional selling plan subscription fee for your North America Unified Account* 
  * Update account information through a consolidated user interface 
  * Get paid to your local bank in your local currency thanks to the [ Amazon Currency Converter for Sellers ](/gp/help/external/200381250)

*Note: The single monthly Professional selling plan subscription fee is applied based on the Amazon marketplace to which you initially registered. For example, if you initially registered to sell on Amazon.com, your monthly subscription fee is listed on the Amazon.com [ Selling on Amazon Fee Schedule ](/gp/help/external/200336920) . 

##  Managing Inventory in Your North America Unified Account

When managing your Amazon inventory across Amazon's United States, Canada, and
Mexico marketplaces, it is important to understand the difference between the
Global SKU and the marketplace-specific SKU in Seller Central.

##  Global SKU

A Global SKU uses a shared inventory pool between the United States, Canada,
and/or Mexico. You can create a Global SKU by selecting " **Existing Offer** "
when you go to create an offer in Seller Central. When using a Global SKU, the
total amount of inventory applies to all marketplaces. For example, if you
have 100 units of inventory, it will display that there are 100 units in
United States, 100 units in Canada, and 100 units in Mexico. The 100 applies
to all three countries and **DOES NOT** add up to a total of 300 units. If an
item sells in Canada, then all marketplaces would show 99 units available.

**Note:** Pricing is managed separately in each marketplace.

**If you are shipping an order yourself** , you should use a Global SKU to
manage inventory across the United States, Canada, and/or Mexico. Inventory
fulfilled by Amazon is not eligible to list as a Global SKU. Note that if you
change a Global SKU from seller-fulfilled to Amazon-fulfilled, this change
will impact the SKU across every marketplace.

**If you are shipping an order yourself** , you should use a Global SKU to
manage inventory across the United States, Canada, Mexico, and/or Brazil.
Inventory fulfilled by Amazon is not eligible to list as a Global SKU. Note
that if you change a Global SKU from seller-fulfilled to Amazon-fulfilled,
this change will impact the SKU across every marketplace.

**If you are shipping from the United States to Mexico, consider the following
when choosing you shipping carrier:** Not all shipping options deliver the
transit speeds that Amazon customers worldwide have come to expect. For
example, a recent study of orders fulfilled by sellers shipping from the
United States to Mexico showed that approximately 69% of orders shipped via
United States Postal Service (USPS), which uses Correos de México/Servicio
Postal Mexicano (SEPOMEX) for delivery within Mexico, did not meet Amazon's
international shipping transit time requirements. To provide a great customer
experience on shipments from the United States to Mexico, we strongly
recommend that you use other carriers (e.g., FedEx, DHL, UPS).

##  Marketplace-specific SKU

A marketplace-specific SKU is managed as a marketplace-level inventory pool,
which means you will manage distinct pools of inventory across the United
States, Canada, and Mexico. You can create a marketplace-specific SKU by
selecting **Unique Offer** when you go to create an offer in Seller Central.
The listing is managed separately in each marketplace for both inventory and
pricing.

**Note:** If you want to list a product on more than one marketplace, but you
want to fulfill it yourself in one case and fulfill by Amazon in another, you
need to create separate SKUs for your seller-fulfilled and Amazon-fulfilled
listings.

**If you are using Fulfillment by Amazon** , you can use a marketplace-
specific SKU and manage your inventory in Amazon fulfillment centers in the
United States, Canada, and Mexico as separate pools. Please note that
inventory going to U.S. fulfillment centers should be shipped from the
Amazon.com section of your North America Unified Account and vice versa for
Canada and Mexico. For example, if you have a FBA listing on the Canada
marketplace, your "Ships from" address must be in Canada.

**Note:** When using inventory files in the North America Unified Account, it
is critical to upload a value for the quantity of available inventory units.
If the quantity column is left blank, it will be read as "0" by the system and
will change the original listing to display "0" available units.

##  See also

  * [ Amazon Fee Schedule ](/gp/help/external/200336920)
  * [ Business Information ](/gp/help/external/841)
  * [ Sharing Your Available Inventory ](/gp/help/external/200663530)
  * [ FBA Shipment Creation Workflow ](/gp/help/external/201021830)
  * [ Amazon Currency Converter for Sellers ](/gp/help/external/200381250)

Top

##  Amazon North American stores

* [ North America Unified Account FAQs  ](/help/hub/reference/external/G201642980)
* [ Shipping to Mexico through Buy Shipping Services  ](/help/hub/reference/external/G202078950)

