# FBA product title requirements

Source: https://sellercentral.amazon.com/gp/help/external/201051300

This article applies to selling in: **United States**

#  FBA product title requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201051300)

Title requirements apply to all non-media products on all of Amazon’s
worldwide stores, whether you use Fulfillment by Amazon or seller fulfilled
orders. Amazon has four main criteria for product titles:  

  1. Titles must not contain promotional phrases, such as "  free shipping  ", "  100% quality guaranteed  ". 
  2. Titles must not contain characters for decoration, such as  ~ ! * $ ? _ ~ { } # < > | * ; ^ ¬ ¦ 
  3. Titles must contain product-identifying information, such as "  hiking boots  " or "  umbrella  ". 

Failure to comply with these requirements may cause a product to be suppressed
from Amazon search results.

Further guidance, including tips to optimize your product titles, is available
on our main [ Product title requirements ](/gp/help/external/GYTR6SYGFA5E3EQC)
page.

**Important:** To send inventory to Amazon your products must have tax
attributes, learn "Shipment Creation Requirements for FBA" how to update.

Top

