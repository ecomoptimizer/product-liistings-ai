# Amazon’s prepaid return label program

Source: https://sellercentral.amazon.com/gp/help/external/help-page.html?itemID=202072200&ref=ag_202072200_bred_G202103400

This article applies to selling in: **United States**

#  Prepaid returns for seller-fulfilled orders

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F202072200%3Fref%3Dag_202072200_bred_G202103400)

Amazon authorizes US returns that fall within [ Amazon’s returns policy
](https://www.amazon.com/gp/help/customer/display.html?nodeId=15015721) . We
provide customers with prepaid return shipping labels on your behalf through
Buy Shipping services.  Seller-filed SKU exemptions will be automatically
authorized, and will continue to be exempt from prepaid returns for seller-
fulfilled orders, and you will have the option to upload a seller-paid label.
Go to [ Return Settings ](/gp/returns/settings/) in Seller Central to select
the return label you would like to provide for exempt items.

**Note:** You are required to issue a refund within two business days of
receipt of a return. If you do not take action regarding the refund, Amazon
might refund the customer on your behalf and charge the amount to your seller
account.

Review the relevant sections to familiarize yourself with the specific details
of prepaid returns.

Table 1. Prepaid return details  Item  |  Policy or requirements  
---|---  
Maintain account requirements  |  You must ensure that your account is kept up
to date.  

  1. Set up a default return address for your account. The selling on Amazon policy requires a US domestic address for the Prepaid Returns Label program. We will use this domestic address for all prepaid returns.  To learn how to set up your default return address, see [ Return address settings ](/gp/help/external/G201711720) . 

**Note:** Sellers are required to provide a valid return shipping address. If
returns are undeliverable due to an outdated or incorrect return address
provided by you, then the returns will be deemed abandoned and Amazon may
elect to dispose of them as appropriate (for example, by selling, recycling,
donating, or otherwise disposing of it) and retain any proceeds that we may
receive from the disposal.The continued use of an outdated or incorrect
address for returns may result in a revocation of your right to sell on
Amazon. To learn more, go to [ Returns, refunds, cancellations, and claims
](/gp/help/external/G69126) **.**

  2. Maintain and update accurate weight and size information entered for products you sell. We calculate return shipping costs based on this information. Amazon will charge your seller account for the cost of the return shipping once the buyer ships the product. The costs for return shipments in each weight band are outlined on the [ Shipping costs for seller-fulfilled returns ](/gp/help/external/G202103400) . 

**Note:** Sellers who have opted into **Free Returns** will not be able to
deduct the return shipping fee for in policy returns. To learn more, go to [
Free returns for seller-fulfilled orders ](/gp/help/external/G8EKQAPUCQA9RAP8)
.

  
The return process  |  You receive an email notification each time a customer
requests a return and receives a prepaid return shipping label.  The [ Manage
seller-fulfilled returns tool ](/gp/returns/list/ref=ag_xx_cont_200708210) in
Seller Central will display all returns.  For details, go to [ Manage seller-
fulfilled returns ](/gp/help/external/G200708210) .  
Multiple return addresses  |  You can configure multiple return addresses for
each of the stores you offer listings. You can either configure a rule or
specify SKUs for which you want different return addresses. For details, go to
[ Multiple return addresses ](/gp/help/external/202183780) .  
Returnless resolutions  |  You can offer returnless resolutions which is when
you issue a refund or replacement and let the buyer keep the product. If a
buyer requests a return that is eligible for a returnless resolution, they
will receive either a full refund or the option to receive a replacement item
once they submit their return request. Even though you will not need to do
anything to complete the request, you can still find these return requests in
Manage Returns. You will no longer have to process refunds for these returns
manually. For details, see [ Returnless resolutions
](/gp/help/external/G202174940) .  
Return shipping  |  UPS and USPS provide return shipping for seller fulfilled
orders through Buy Shipping services. For details, go to [ Prepaid return
shipping carriers ](/gp/help/external/G202175020) .

**Important:** We will charge your account for the return label cost only when
the buyer tenders the package to the carrier.  
  
Refunds and cost of shipping  |

For handling refunds and cost of shipping, go to [ Refunding shipping cost
](/gp/help/external/G202175040) and [ Shipping costs for seller fulfilled
returns ](/gp/help/external/G202103400) .

For Fashion Items, see [ Free returns on Fashion items for seller-fulfilled
orders ](/gp/help/external/GEKBRFKQE38CQA6V) for more details.  
  
Reports for prepaid returns  |  All prepaid returns are recorded in your
Settlement and Payments report and the Returns report.

  * **Settlement and Payments report** : Each return shipping charge will be displayed in your Settlement and Payments reports, as shipping services purchased through Amazon. These costs will be separate from the order charges. 
  * **Return reports** : You will receive an email notification each time a customer requests a return and receives a prepaid shipping label. Additionally, you can download a report of all return requests you have received, including the status of each return, using Return Reports in Seller Central.  Both the email and the report will include the Order ID, Tracking ID, Return Reason, Label Cost, Date Requested, RMA ID, and Comments. 

  
Ineligible items  |  Prepaid return shipping labels are not always provided
for automatically authorized returns. For details, go to [ Ineligible items
for prepaid returns ](/gp/help/external/G202174960) .  
Category Exemptions from prepaid returns labels  |  Several categories and
subcategories are automatically exempt from prepaid return labels.  You do not
need to request exemptions for these categories.

  * Handmade 
  * Certified preowned watches 
  * Non-physical items (for example, warranties, digital software, or digital coupons) 
  * Items that are non-returnable by law and dangerous goods 
  * Extra large or heavy items 

  
  
SKU Exemptions from prepaid return labels  |

You can request exemptions from prepaid return labels only for SKUs that fall
under the following categories:

  * High Price Items: High-valued items (price exceeding $100) that need special shipping (for example, items that require special shipping insurance) 

The exempted SKUs will be validated against the ASIN price and item condition
across Amazon and the exemption reason code ‘HIGH_PRICE_GREATER_USD100’. Only
active SKUs are eligible for exemptions from prepaid return labels. You can
view the status of your SKUs in Seller Central by going to the **Inventory**
drop-down and selecting **Manage Inventory** .

For details, go to [ Request exemption from prepaid returns for seller-
fulfilled orders ](/gp/help/external/G202174980) .

**Note:** To offer returnless resolutions for specific SKU’s, go to [
Returnless resolutions ](/gp/help/external/G202174940) .  
  
Appeal a refund  |

You can file an appeal if Amazon issued a refund on your behalf that you don’t
believe should have been authorized.

**For customer-returned damaged items** : Provide appropriate photographic
evidence linking the return to the purchased product when creating your claim.
Also, attach all additional supporting documentation. For example, provide
images of the damaged items, image of a non-damaged original item, image of
the shipping label, Tracking ID, delivery proof, or any additional information
necessary to review your claim.

**Note:** Per the Restocking Fee Policy, for customer-damaged products, the
reimbursement will be limited to a maximum of 50% of the order value of the
product.

For details, go to [ Reimbursement policy for Prepaid Return Labels (PRL) in
the seller-fulfilled network ](/gp/help/external/G202175000) .  
  
##  Frequently asked questions

####  How can I enroll in the Prepaid Return Label program?

US sellers are automatically enrolled into the Prepaid Return Label program.

####  What happens if the return is lost or damaged in transit?

Sellers are responsible for filing a claim directly with the carrier if a
return is lost or damaged in transit. If this happens, process a full refund
to the customer and file a claim directly with the carrier to receive a
reimbursement.

####  Where does the shipping weight used to calculate the price of return
shipping come from?

The shipping weight used to calculate the price of return shipping is the
listed weight displayed on the Product Detail page. However, if you have
bought a label through Amazon’s Buy Shipping Services for fulfilling your
orders, we will use that weight instead. If there is no weight on the Product
Detail and you have not used Buy Shipping services, we will default to 4.9 lb.

If the shipping weight displayed on the Product Detail has been provided by
another seller, Selling Partner Support will require proof of the correct
shipping weight in order to initiate a change.

For more details, go to [ Shipping costs for seller-fulfilled returns
](/gp/help/external/G202103400) .

####  Why can't I change or upload my own prepaid return label?

By enrolling your account into prepaid returns, Seller Fulfilled Prime (SFP),
or Prime Now, eligible returns are automatically authorized and an Amazon
prepaid return label is issued to the buyer.

A merchant prepaid return label can be provided for returns that are exempt
from the Amazon prepaid return label program or for international returns
where a default US return address is not provided.

####  What should I do if the customer can't print the return label?

You can consider the following options:

  * The buyer can contact Amazon Customer Service to have a physical label mailed to them for a small fee. 
  * The buyer can arrange to ship the return product on their own. Go to [ Return Reason codes for Prepaid Returns ](/gp/help/external/202080050) for seller-fulfilled orders to understand the return reason. Where a buyer selects the option, and you are accountable for the return, you must add the cost of return shipping to the refund. 

####  What if I want to unenroll from the Prepaid Return Label program?

All US sellers are automatically enrolled into Amazon's Prepaid Returns Label
program per the [ Amazon's Return policy
](https://www.amazon.com/gp/help/customer/display.html/?nodeId=15015721) .

Top

##  Prepaid returns for seller-fulfilled orders

* [ Shipping costs for seller-fulfilled returns  ](/help/hub/reference/external/G202103400?ref=ag_202072200_bred_G202103400)
* [ Multiple return addresses  ](/help/hub/reference/external/G202183780?ref=ag_202072200_bred_G202103400)
* [ Ineligible items for prepaid returns  ](/help/hub/reference/external/G202174960?ref=ag_202072200_bred_G202103400)
* [ Request exemption from prepaid returns for Seller-fulfilled orders  ](/help/hub/reference/external/G202174980?ref=ag_202072200_bred_G202103400)
* [ Reimbursement policy for Prepaid Return Labels (PRL) in the seller-fulfilled network  ](/help/hub/reference/external/G202175000?ref=ag_202072200_bred_G202103400)
* [ Prepaid return shipping carriers  ](/help/hub/reference/external/G202175020?ref=ag_202072200_bred_G202103400)
* [ Refunding shipping cost  ](/help/hub/reference/external/G202175040?ref=ag_202072200_bred_G202103400)
* [ Replacements for seller-fulfilled returns  ](/help/hub/reference/external/G9675EJHNZ2ZE3M5?ref=ag_202072200_bred_G202103400)
* [ Free returns for seller-fulfilled orders  ](/help/hub/reference/external/G8EKQAPUCQA9RAP8?ref=ag_202072200_bred_G202103400)

