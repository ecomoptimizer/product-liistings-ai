# Manage your offers one at a time

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201186860

This article applies to selling in: **United States**

#  Manage your offers one at a time

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201186860)

The Manage Inventory page provides you with tools for searching, viewing, and
updating your product and inventory listing information.

Click here to go to [ Manage Inventory
](https://sellercentral.amazon.com/inventory) .

To get started, watch the video on Manage Inventory for more information.

To view, copy, delete, or close listings, see the following.

  * You can view and sort your inventory by Status, SKU, Product name, and more by using the following Help topic. [ View your inventory ](/gp/help/external/8GKMW7345AV3LCY)
  * You can change your product information quickly and easily by using the following Help topic. [ Edit a listing ](/gp/help/external/SGKAPSNT53G5B2P)
  * You can use the Copy Listing feature to create a new detail page by using the following Help topic. [ Copy a listing ](/gp/help/external/JAQ5MM8LB7MMZB7)
  * You can delete a listing from your seller account by using the following Help topic. [ Delete a product ](/gp/help/external/DMU6WZNPLTKM9J3)
  * You can close a listing by using the following Help topic. [ Close a listing ](/gp/help/external/DJZDBNYUAS8C7QB)

To relist, manage pricing, view sales history, and set page preferences, see
the following:

  * You can relist a product by using the following Help topic. [ Relist a product that is Inactive (Closed) - Inactive Listings ](/gp/help/external/F5ES9LFB2RNU6R8)
  * To help you find reasons for Blocked listings, see the following Help topic. [ Reasons for Blocked listings ](/gp/help/external/GGKKCTPTVTF95E5)
  * You can add images and video to your listing by using the following Help topic. [ Add product images and video ](/gp/help/external/200216080)
  * You can change the category of a product by using the following Help topic. [ Change a product’s category ](/gp/help/external/201950630)
  * You can manage product pricing by using the following Help topic. [ Manage pricing ](/gp/help/external/PTFQ566449VXXCP)
  * You can view sales history by using the following Help topic. [ Sales history ](/gp/help/external/S3S7TP5FM7D5MEQ)
  * You can customize your page preferences by using the following Help topic. [ Set your Manage Inventory page preferences ](/gp/help/external/E7UVMSSJREL55WA)

Top

##  Manage your offers one at a time

* [ View your inventory  ](/help/hub/reference/external/G8GKMW7345AV3LCY)
* [ Edit a listing  ](/help/hub/reference/external/GSGKAPSNT53G5B2P)
* [ Copy a listing  ](/help/hub/reference/external/GJAQ5MM8LB7MMZB7)
* [ Delete a product  ](/help/hub/reference/external/GDMU6WZNPLTKM9J3)
* [ Close a listing  ](/help/hub/reference/external/GDJZDBNYUAS8C7QB)
* [ Relist a product that is Inactive (Closed) - Inactive Listings  ](/help/hub/reference/external/GF5ES9LFB2RNU6R8)
* [ Reasons for Blocked listings  ](/help/hub/reference/external/GGGKKCTPTVTF95E5)
* [ Add product images and video  ](/help/hub/reference/external/G200216080)
* [ Change a product’s category  ](/help/hub/reference/external/G201950630)
* [ Manage pricing  ](/help/hub/reference/external/GPTFQ566449VXXCP)
* [ Sales history  ](/help/hub/reference/external/GS3S7TP5FM7D5MEQ)
* [ Set your Manage Inventory page preferences  ](/help/hub/reference/external/GE7UVMSSJREL55WA)
* [ Pricing status  ](/help/hub/reference/external/GS9A4Q8K4Q6KT8TV)
* [ Troubleshooting steps for listings suppressed due to suspected Intellectual Property violations  ](/help/hub/reference/external/G7A839WDJKYVT627)

