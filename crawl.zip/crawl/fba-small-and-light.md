# FBA Small and Light

Source: https://sellercentral.amazon.com/gp/help/external/G201706140

This article applies to selling in: **United States**

#  FBA Small and Light

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201706140)

On this page

Product eligibility

Product enrollment

Shipping Small and Light inventory to Amazon

Program fees

Troubleshooting

The FBA Small and Light program is a seller-enrolled program that helps reduce
the cost of fulfilling orders for small and lightweight FBA inventory priced
under $12. ASINs that are enrolled in the program are available with free
shipping for Prime customers and standard shipping for non-Prime customers.
Small and Light is subject to the [ FBA Small and Light Terms and Conditions
](/gp/help/external/GZKHKFS7YLKWR5CC) .

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201706140)

##  Product eligibility

Products must meet all three conditions:

  * Measure 18 length x 14 width x 8 height or less in inches 

**Note:** Measurement for each dimension is the maximum for that dimension.
For example, a product that measures 19 x 12 x 6 inches would not be eligible
for enrollment.

  * [ Shipping Weight ](/gp/help/external/GEVWP48HPBLEFJEY) should be 3 lb or less 

**Note:** For “large standard” size tier, shipping weight is defined as the
greater of the unit weight or dimensional weight. Learn how to [ determine
your product's shipping weight ](/gp/help/external/GEVWP48HPBLEFJEY) .

  * Priced $12 or less 

The product types below are not eligible. (Crushable products, such as potato
chips and glass, are eligible as long as they are [ properly packaged
](/gp/help/external/GCFL9GA7ZXSRS6RL) .)

  * [ Restricted products ](/gp/help/external/200164330)
  * [ FBA prohibited products ](/gp/help/external/201730840)
  * [ Adult products ](/gp/help/external/G200339940)
  * [ Dangerous goods identification guide (hazmat) ](/gp/help/external/G201003400)
  * [ Temperature-sensitive products (such as chocolates) ](/gp/help/external/G202125070)

##  Product enrollment

Enroll eligible products through the [ Small and Light product enrollment
](/gp/ssof/workflow/upload/upload-uno-offer-enrollment.html) page. Here are
some tips:

  * Make sure that package dimensions and weights have been entered in Seller Central before enrollment. 
  * Remove extra spaces before and after your MSKUs to prevent upload errors. 
  * Make sure that you have entered MSKUs, not ASINs, into the enrollment file. 
  * Always review your processing reports for errors (for Professional selling plans only). 

For help creating new MSKUs for Small and Light, download our [ offer creation
guide ](https://m.media-amazon.com/images/G/01/fba-
help/How_to_Create_a_New_Listing_in_Seller_Central-1.pdf) . For more
information about product enrollment, download our [ enrollment guide
](https://images-na.ssl-images-amazon.com/images/G/01/fba-
help/FBASnLEnrollmentGuide.pdf) . Chinese versions of both guides also are
available:

  * [ Offer creation guide (Chinese) ](https://m.media-amazon.com/images/G/01/fba-help/How_to_Create_a_New_Listing_in_Seller_Central-1_CN-updated.pdf)
  * [ Enrollment guide (Chinese) ](https://m.media-amazon.com/images/G/01/fba-help/FBASnLEnrollmentGuide_CN.pdf)

##  Shipping Small and Light inventory to Amazon

FBA Small and Light has the same [ prep and packaging requirements
](/gp/help/external/G200141500) as standard FBA.  Review our [ Small and Light
prep and packaging guide ](/gp/help/external/GCFL9GA7ZXSRS6RL) and ship your
products to the fulfillment center specified by Amazon.

If you have a China-based vendor, manufacturer, or warehouse partner, you can
download a Chinese version of the prep and packaging guide:

  * [ Small and Light prep and packaging guide (Chinese) ](/gp/help/external/GCFL9GA7ZXSRS6RL?language=zh_CN)

##  Program fees

Products enrolled in the Small and Light program have reduced fulfillment fees
as shown below. All other standard selling on Amazon fees and FBA fees still
apply.

Size tier  |  Shipping weight  1  |  Dimensions  |  Small and Light
fulfillment fee per unit  
---|---|---|---  
Small standard  |  4 oz or less  |  15 x 12 x 0.75 inches or less  |  $2.47  
4+ to 8 oz  |  $2.54  
8+ to 12 oz  |  $2.61  
12+ to 16 oz  |  $3.15  
Large standard  |  4 oz or less  |  18 x 14 x 8 inches or less  |  $2.66  
4+ to 8 oz  |  $2.77  
8+ to 12 oz  |  $2.94  
12+ to 16 oz  |  $3.77  
16 oz+ to 1.5 lb  |  $4.42  
1.5+ to 2 lb  |  $4.68  
2+ to 2.5 lb  |  $5.19  
2.5+ to 3 lb  |  $5.40  
  
1  Shipping weight is calculated based on the item’s unit weight or
dimensional weight. Learn how to [ determine your product's shipping weight
](/gp/help/external/GEVWP48HPBLEFJEY) .

FBA Label Service for Small and Light items: The FBA Label Service fee for
Small and Light items is $0.10 per unit.

##  Troubleshooting

You may see an error message when you try to enroll an item in Small and Light
if your submission is missing information or if the product isn’t eligible.

Go to [ Small and Light error messages ](/gp/help/external/GNPD9AY5D63R4W66)
for more information about common errors and how to fix them.

Top

##  FBA Small and Light

* [ FBA Small and Light Terms and Conditions  ](/help/hub/reference/external/GZKHKFS7YLKWR5CC)
* [ FBA Small and Light frequently asked questions  ](/help/hub/reference/external/GZDNMETPWLQ5TR7J)
* [ Small and Light error messages  ](/help/hub/reference/external/GNPD9AY5D63R4W66)
* [ Small and Light prep and packaging guide  ](/help/hub/reference/external/GCFL9GA7ZXSRS6RL)
* [ Adding or removing products from FBA Small and Light  ](/help/hub/reference/external/G201952590)
* [ Create offers in both FBA Small and Light and standard FBA  ](/help/hub/reference/external/G201858900)
* [ Removing products from the Small and Light program using the Quick Disenroll feature  ](/help/hub/reference/external/GK546RW3P56NX533)

