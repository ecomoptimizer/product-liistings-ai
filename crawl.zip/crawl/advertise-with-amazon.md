# Advertise with Amazon

Source: https://sellercentral.amazon.com/help/hub/reference/external/G200663330

This article applies to selling in: **United States**

#  Advertise with Amazon

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200663330)

Advertising with Amazon can help you grow awareness of your brand and reach
shoppers searching for products like yours.

You can now find all advertising help directly in the [ Advertising Console
Support Center ](https://advertising.amazon.com/help) . This is your go-to
place for how-to's, troubleshooting, videos, and more!

Here are some popular topics that we think might be helpful:

  * [ Stores ](https://advertising.amazon.com/help?#GPAJWPX4T4NRMWPP)
  * [ Billing and payments ](https://advertising.amazon.com/help?#G6MMLSDPL4JAJPFR)
  * [ Targeting ](https://advertising.amazon.com/help?#GQCBASRVERXSARL3)
  * [ Bidding ](https://advertising.amazon.com/help?#GAWZKCXHNMSTRR87)
  * [ Reports and metrics ](https://advertising.amazon.com/help?#G3ZFBYGFNUEGJUKX)

**Note:** If you aren't advertising with Amazon yet, get started at: [ Amazon
Advertising ](https://advertising.amazon.com) .

Top

