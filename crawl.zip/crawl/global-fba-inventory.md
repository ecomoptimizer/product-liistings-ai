# Global FBA Inventory

Source: https://sellercentral.amazon.com/gp/help/external/G23EYVCM6YH7CHL8

This article applies to selling in: **United States**

#  Global FBA Inventory

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG23EYVCM6YH7CHL8)

On this page

Review inventory supply and performance

Create shipping plans or removal orders

Fix automated replenishment errors

Pause automated replenishment

Request additional replenishment

Track add-on requests

[ Global FBA Inventory ](/fba-inventory/gim/inventory-list) shows real-time
inventory performance, supply, and demand information to help you manage your
FBA products worldwide. On a single page, you can review real-time data for
every SKU and store, then create shipping plans or removal orders.

##  Review inventory supply and performance

Inventory supply and performance data appear as a list that you can filter by
product and store. All of the data is real time except for shipped units, days
of supply, and sell-through, which are refreshed daily.

Sort inventory data for your SKUs by clicking on a column (for example,
**Inbound to FC** ). To view a subset of inventory information, do the
following:

  1. Click **Add filters** and choose a filter. 

  2. Select the information to filter, such as a range of sold units. 

  3. Click **Apply filters** to review your filtered results. Change the filter as needed. 

You can view the following information:  **Product SKU** |  Stock-keeping
units (SKUs) are unique blocks of letters or numbers that you assign to your
products to identify them.  
---|---  
**FNSKU** |  Fulfillment network stock-keeping units (FNSKUs) are unique
identifiers that Amazon assigns to items in fulfillment centers. An FNSKU
identifies an individual seller's offer for a specific ASIN.  
**ASIN** |  Amazon standard identification numbers (ASINs) are unique blocks
of 10 letters or numbers that Amazon assigns to identify products. ASINs
appear on product detail pages.  
**Product name** |  The name of your product.  
**Merchant ID** |  The merchant ID is the string of numbers and letters that
were created when you registered as a seller. Find your merchant ID by
selecting **Account info** from the **Settings** drop-down menu and clicking
**Merchant token** .  
**Marketplaces** |  The fulfillment network that stores your inventory and
fulfills customer orders. It’s often the same as the store from which you
manage your business, except for the EU stores (Germany, France, Italy, Spain,
the Netherlands, Belgium, and Sweden). They are treated as one fulfillment
network.  
**Inbound to FC** |  The number of units for an FNSKU in all shipments that
you have sent to fulfillment centers but that have not yet been received into
your sellable inventory.  
**Future supply** |  The number of units for an FNSKU in shipments to a
fulfillment center that are eligible for customers to order before the items
arrive at the fulfillment center. Future supply buyable quantity is included
in inbound quantity.  For more information, go to [ In-Stock Head Start
](/gc/fulfillment-by-amazon/instock-head-start) .  
**Available in FC** |  The number of units for an FNSKU that can be used for
customer orders. **Available in FC** includes inventory that is stored in a
fulfillment center Prime bin and that can be picked, packed, and shipped to
customers immediately. Transfer quantity between fulfillment centers is also
included.  
**Reserved in FC** |  The number of units for an FNSKU that are allocated to
customer orders or removal orders but that are not picked (or in the process
of being picked, packed, and shipped). Or, these units are sidelined for
additional processing.  
**Units shipped last 30 days** |  The number of units for an FNSKU that are
shipped to customers in the past 30 days (refreshed daily).  
**Days of supply** |  The estimated number of days that your total supply for
an FNSKU will last, based on the projected future demand. The value is
refreshed daily. The total supply includes inbound quantity, Prime bin
available quantity, FC transfer quantity, and future supply buyable quantity.  
**Sell-through** |  The number of units sold and shipped over the past 90 days
divided by the average number of units available at fulfillment centers during
that time period.  
**Available in AWD** |  The number of units for an FNSKU that can be used to
replenish orders in Amazon Warehousing and Distribution.  
**In-Transit from AWD to FC** |  The number of units for an FNSKU that are in-
transit status. This number includes **Shipped quantity** and **Received
quantity** .  
**Automated replenishment status** |

The current status for automated replenishment. The statuses are as follows:

Active: Automated replenishment is activated.

Failed: Automated replenishment is inactive due to an error. All errors must
be fixed in order to reactivate automated replenishment. To fix an error,
review the error details and click the **Fix issue** link.

Paused: Automated replenishment is paused for a scheduled duration.  
**Auto-replenishment quantity** |  The number of units that are planned to be
replenished for the current week. To view the replenishment quantity for the
next two weeks, click **Details** in the column.  
  
##  Create shipping plans or removal orders

As with other inventory pages, you can create both shipping plans and removal
orders by using the **Action** drop-down menu to the right.

Begin by selecting a single or multiple SKUs for a single store. After
selecting **Create shipping plan** or **Create removal order** , you will be
taken to the target Seller Central page without having to sign in again. For
the EU, you will be asked to select a specific country.

For more information, go to [ Send to Amazon: Choose inventory to send
](/gp/help/external/G8SXKYFWPG6DAW6T) and [ Remove inventory (overview)
](/gp/help/external/200280650) .

##  Fix automated replenishment errors

In the **Automated replenishment status** column of [ Global FBA Inventory
](/fba-inventory/gim/inventory-list) , you can fix errors for SKUs with a
**Failed** status by clicking the **Fix issue** link.

If there’s no link provided, contact Seller Partner Support to resolve the
issue. All errors must be resolved in order to reactivate automated
replenishment.

##  Pause automated replenishment

To schedule a pause of your automated replenishment, follow these steps on
Global FBA Inventory:

  1. From the **Action** drop-down menu next to the SKU, select **Pause or resume automated replenishment** . 

  2. Select the start and end, then click **Submit** . 

To cancel a scheduled pause before it has started, click **Cancel scheduled
pause** . To reactivate automated replenishment after a pause has started,
click **Activate automated replenishment** . If a pause of your automated
replenishment is initiated by Amazon due to system limitations, you cannot
make changes.

##  Request additional replenishment

You can request that additional inventory be shipped to fulfillment centers to
supplement the automated replenishment by Amazon Warehousing and Distribution.
You can decide the replenishment quantity from the distribution center when
you believe that the automated replenishment won’t be enough to meet expected
sales.

To request additional replenishment, follow these steps on Global FBA
Inventory:

  1. From the **Action** drop-down menu next to the SKU, select **Request add-on replenishment** . 

  2. From the **Reason for add-on replenishment** drop-down menu, select a reason for changing the quantity for automated replenishment. Reasons include deals, price discount, and promotions. 

  3. In the **Specify quantity** field, enter the additional units that you want to send to the fulfillment center. 

  4. Click **Submit** . 

You may not be able to request additional replenishment for the following
reasons:

  * The automated replenishment status is **Failed** or **Disenrolled** . 
  * The quantity that you entered is greater than the units available in Amazon Warehousing and Distribution. 
  * The storage type limit for the request has already been met. 

When you select **Request add-on replenishment** , you can view the following
information to help you with your request:

Available in FC  |  The number of units for an FNSKU that can be used for
customer orders. **Available in FC** includes inventory that is stored in a
fulfillment center Prime bin and that can be picked, packed, and shipped to
customers immediately. Transfer quantity between fulfillment centers is also
included.  
---|---  
Inbound to FC  |  The number of units for an FNSKU that are in transit,
including units that you send directly to fulfillment centers and units sent
from Amazon Warehousing and Distribution to fulfillment centers.  
Available in AWD  |  The number of units for an FNSKU that can be used to
replenish orders in Amazon Warehousing and Distribution.  
Optimum level of supply to be maintained in FCs  |  The optimal level of
inventory to maintain at fulfillment centers for an FNSKU.  
Auto replenishment quantity (current week)  |  The estimated automated
replenishment quantity for the current week.  
Upcoming replenishment quantity  |  The estimated automated replenishment
quantity for the week that follows the current week.  
  
##  Track add-on requests

After successful submission of your request for additional replenishment, the
replenishment will be triggered, subject to the specified criteria.

To track your requests on Global FBA Inventory, select **Track add-on
requests** from the **Action** drop-down menu next to the SKU.

If the request has failed, the reason will appear in the **Shipments created
or errors encountered** column.

Top

