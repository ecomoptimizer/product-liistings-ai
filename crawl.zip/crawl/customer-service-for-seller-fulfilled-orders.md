# Customer service for seller-fulfilled orders

Source: https://sellercentral.amazon.com/gp/help/external/G797533XQVR4S6RG

This article applies to selling in: **United States**

#  Customer service for seller-fulfilled orders

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG797533XQVR4S6RG)

On this page

What is Customer Service by Amazon (CSBA)?

CSBA benefits

CSBA Fee

CSBA requirements

Return and refund policy

Opt-in or Opt-out of CSBA

Frequently asked questions

##  What is Customer Service by Amazon (CSBA)?

Customer Service by Amazon is a paid service where Amazon takes care of
customer service on your behalf for your seller-fulfilled orders. We will
direct customer inquiries for these orders to Amazon Customer Service so that
you do not need to handle them yourself. You will enjoy a 30-day free trial
after joining CSBA for the first time. After your 30-day trial, you will be
charged the CSBA fee per seller-fulfilled shipped unit based on your customer
service performance. You can opt-out of CSBA at any time.

##  CSBA benefits

  * CSBA improves the customer experience by providing a 24-hour, high-quality customer service throughout the year. 
  * CSBA supports customers in the store-supported languages via phone, instant message, and email. 
  * CSBA's customer service can help you reduce [ A-to-z Guarantee claims ](/gp/help/external/G27951) , [ Order Defect Rates (ODR) ](/gp/help/external/G200285170) , and negative reviews. 
  * CSBA can help you remove your customer service burdens by managing customer service in response to changing demands (for example, during the holiday period). 
  * CSBA saves time and can help reduce your customer service cost. 

##  CSBA Fee

The CSBA fee is charged on each seller-fulfilled shipped unit according to
your customer service performance, which is measured by Contacts per Unit
(CPU). For more information, go to [ Customer Service by Amazon fees
](/gp/help/external/G92LV47D9LP2MXEF) .

##  CSBA requirements

To use CSBA, you have to do the following:

  * Agree to the [ Customer Service by Amazon Terms & Conditions ](/gp/help/external/G65T4N3XGC3MJB38) . 
  * Be registered as a professional seller in good standing on Amazon. 
  * Reply to CSBA inquiry. Amazon Customer Service will answer customer inquiries without requesting your input as much as possible. However, in some cases, CSBA will reach out to sellers for additional information. Sellers are required to reply to CSBA inquiry within 24 hours (including weekends and holidays). Otherwise, CSBA will handle the customer inquiry using its judgment to best serve the customer.  Amazon Customer Service will communicate with sellers in English or Chinese. 

##  Return and refund policy

  * Amazon Customer Service follows standard [ Amazon return policies ](https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-2?ie=UTF8&nodeId=201819200&qid=1591322986&sr=1-2) for handling customer inquiries.  To ensure a consistent customer experience, Amazon requires CSBA sellers to set return policies that are at least as favorable as the Amazon return policies. CSBA sellers with superior return or refund policies that provide a better customer experience than Amazon's return policies should update their return policy page.  Once CSBA approves the seller's return policy, the CSBA team will follow the terms set by the seller to proceed with return or refund requests pertaining to seller-fulfilled orders. 
  * Out of country CSBA sellers are required to follow the information on the [ Customer returns for international sales ](/gp/help/external/G201468550) page. 

##  Opt-in or Opt-out of CSBA

####  How do I opt-in to CSBA?

  

  1. On Seller Central, go to [ Account Info ](/hz/sc/account-information) . 
  2. In the **Your Services** section, select **Manage** . 
  3. In the **You are signed up for** section, select **Ready to Opt-in** . 

This redirects you to the opt-in page with information about the CSBA service.

  4. Select **Opt-in Now** . 

Once you enroll, you will be able to view this service as **Active** under the
**Your Services** section.

If you are interested in CSBA, click [ CSBA Overview
](https://amazon51.au1.qualtrics.com/jfe/form/SV_3RgScILovfPQ3el) .

Newly registered sellers on Amazon.com are enrolled in CSBA by default. You
can opt-out of the program at any time.

**Important:** Once you opt-in, CSBA service will start within an hour.
Customer inquiries for orders placed before your CSBA enrollment will not be
covered by CSBA.

####  How can I opt-out of CSBA?

  

  1. In Seller Central, go to [ Account Info ](/hz/sc/account-information) . 
  2. In the **Your Services** section, select **Manage** . 
  3. In the **You are signed up for** section, select **Opt-out of CSBA** next to **Customer Service by Amazon** . 
  4. Select **Opt-out now** . 

**Important:** You can choose to register again for CSBA later. However, once
you opt-out, you must handle all customer inquiries for any new seller-
fulfilled orders. Existing orders continue to be handled by Amazon.

##  Frequently asked questions

####  What kind of customer inquiries are not included in CSBA?

CSBA provides customer service for all post-order inquiries for your seller-
fulfilled orders except queries related to Invoice and Product Customization.
CSBA does not provide customer service for pre-order customer inquiries. To
handle these types of inquiries, use the [ Buyer-Seller Messaging Service
](/messaging/inbox) .

####  Do I need to handle Buyer-Seller Messages after using CSBA?

Yes, you still need to answer pre-order inquiries or Fulfillment by Amazon
(FBA) order related inquiries in the **Buyer-Seller Messaging Service** . If a
customer contacts you for a seller-fulfilled order related inquiry, transfer
it to the CSBA team and they will handle it on your behalf. US-based sellers
can reach the CSBA team at [ csba-ustous@amazon.com ](mailto:csba-
ustous@amazon.com) and China based sellers can reach us at [ csba-
cn2us@amazon.com ](mailto:csba-cn2us@amazon.com) .

####  How will CSBA handle customer inquiries?

CSBA provides high-quality, real-time customer service by Amazon through
phone, instant message, and email channels. In some cases, the CSBA team will
need to work with you to find a resolution and reply to the customer.  Our
commitment to the customer is typically within two days.

####  How will CSBA handle returns?

CSBA uses the standard [ Amazon return policies
](https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-2?ie=UTF8&nodeId=201819200&qid=1591322986&sr=1-2)
to handle customer returns.  Out of country sellers are required to follow the
[ Customer returns for international sales ](/gp/help/external/G201468550)
when addressing returns and refunds.

####  How will I receive communication from CSBA?

You will be able to receive and reply to messages from the CSBA team in your [
Case Log ](/cu/case-lobby?ref=xx_caselog_count_home) in Seller Central. You
will also receive CSBA notifications in your default email address in your
Seller Central account.

####  Can I get the communication history between CSBA and customer?

No. We do not share communication history between CSBA and the customer.
Communications for customer service are not recorded in Seller Central and
cannot be viewed by you. Contact Selling Partner Support from [ Contact Us
](/cu/contact-us) on Seller Central, if you have questions regarding
resolution of the order.

####  What happens, if CS refunds the customer but I don't think I should be
held responsible for the refund?

When Amazon issues a refund to a customer and you think that you should not be
held financially responsible for the charge, you may file a claim for
reimbursement via the Seller Assurance for E-commerce Transactions (SAFE-T).
Amazon may reimburse you, if your claim meets the criteria in the [ Customer
Service by Amazon refund reimbursement policy
](/gp/help/external/G7KCD8BYQER79WWJ) .

####  How will CSBA answer product related customer inquiries?

CSBA will answer a customer inquiry based on information available on the
product detail page. If we cannot solve a customer's inquiry, we will send a
message to your account via [ Case Log ](/cu/case-
lobby?ref=xx_caselog_count_home) for further assistance. We encourage you to
review and update the product detail page regularly to ensure the quality of
the content when viewed by customers and customer service.

####  Whom should I contact if I have questions about CSBA?

You can contact Selling Partner Support from [ Contact Us ](/cu/contact-us) on
Seller Central.

Top

##  Customer service for seller-fulfilled orders

* [ Customer Service by Amazon fees  ](/help/hub/reference/external/G92LV47D9LP2MXEF)
* [ Customer Service by Amazon refund reimbursement policy  ](/help/hub/reference/external/G7KCD8BYQER79WWJ)

