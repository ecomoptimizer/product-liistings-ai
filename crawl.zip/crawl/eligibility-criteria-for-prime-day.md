# Eligibility criteria for Prime Day

Source: https://sellercentral.amazon.com/help/hub/reference/external/GLREB2WH9JA7R63D

This article applies to selling in: **United States**

#  Eligibility criteria for Prime Day

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGLREB2WH9JA7R63D)

On Prime Day, products with Prime Exclusive Discounts will display a badge to
Prime members. To be eligible for the badge, your Prime Exclusive Discount
must meet the following criteria:

  * The Prime Exclusive Discount must meet all [ regular eligibility criteria ](/gp/help/external/GNC7446W4QUUSXEU) . 
  * You must be a seller with at least four seller feedback ratings. Sellers that haven't received any feedback ratings from buyers are also eligible. 
  * The product must have at least a three-and-half star rating, or no rating. 
  * The discount must be at least 20% off the non-member, non-promotional price (that is, your price or sale price, whichever is lower). 
  * The Prime Exclusive Discount price must be 10% lower than the reference price (that is, the List Price or Was Price). For more information, go to [ Amazon policy on reference prices ](/gp/help/external/G202170370) and [ Show a reference price to your products ](/gp/help/external/G27XM55CQM3SBMD2) . 
  * The Prime Exclusive Discounted price must beat the lowest price for the ASIN in the past 30 days. The lowest price in the last 30 days is the lowest customer bought price for the ASIN in that period including all deals, promotional, and sale prices across all sellers. 

Top

