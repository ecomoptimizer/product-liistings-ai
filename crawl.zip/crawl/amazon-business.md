# Amazon Business

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201542150

This article applies to selling in: **United States**

#  Amazon Business

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201542150)

The Amazon Business Seller Program enables you to optimize your offerings to
grow sales to business customers.

While business customers can already purchase your products on the Amazon
site, Amazon Business provides access to additional pricing, business profile,
and brand-building features designed to reach a growing population of
procurement professionals. Features like Business-only offers, Quantity
pricing, and the ability to list credentials like small business, veteran-
owned business, ISO 9001, and others give Amazon Business sellers tools to
leverage the Amazon marketplace to reach business buyers.

##  What happens when you join the Amazon Business Seller Program?

You can access B2B features through your existing Seller Central account and
MWS-APIs. [ Go to the linked page for more about the Amazon Business Seller
Program ](/learn/courses?courseId=20&moduleId=89) .

Amazon Business sellers can take advantage of tiered referral fees that result
in a lower fee percentage when business customers buy in bulk. [ Learn more
about Amazon Business fees ](/gp/help/external/G201762480) .

The Amazon Business Seller Program includes the following features:

  * [ Business Pricing and Quantity Discounts ](/gp/help/external/201740300) : Pricing and payment features that simplify buying from you in larger quantities. [ Watch this video to learn how to add business pricing though a flat file ](/learn/courses?courseId=20&moduleId=91) . 
  * [ B2B Product Opportunities (BPO) ](/gp/help/external/GG6RSFHJVGD653MV) : Get personalized product recommendations based on customer demand signals. APIs are also available. 
  * [ Business-Only Offers ](/gp/help/external/201740310) : The ability to offer products available only to business customers. [ Watch this video to learn how to add a Business-Only Offer ](/learn/courses?courseId=20&moduleId=92) . 
  * [ Business-Only Selection ](/gp/help/external/201958670) : The ability to add offers to products designated by Amazon as business-only. 
  * [ Enhanced Content ](/gp/help/external/201818520) : Enhanced product content, such as User Guides and Material Safety Data Sheets (MSDS), can be uploaded for products that you offer in a number of categories. 
  * [ Seller Credential Program ](/gp/help/external/201740330) : Claim quality, diversity and ownership credentials and certifications to distinguish your business to Amazon Business customers. [ Watch this video to learn how to add a credential ](/learn/courses?courseId=20&moduleId=93) . 
  * [ Business Seller Profile ](/gp/help/external/201818900) : Add additional business-relevant information to your profile such as enhanced logo, year established, business type, etc. These attributes are shown to business customers on your public profile page. [ Watch this video to learn how to edit your profile ](/learn/courses?courseId=20&moduleId=94) . 
  * [ Business Reporting ](/gp/help/external/200633570) : Access a number of reports, including data on when business customers place orders and how many businesses are buying from you. 

  * [ Business Pricing and Quantity Discounts ](/gp/help/external/201740300) : pricing and payment features that simplify buying from you in larger quantities. 
  * [ Business-Only Offers ](/gp/help/external/201740310) : the ability to offer products available only to business customers. 
  * [ Business Reporting ](/gp/help/external/200633570) : access a number of reports, including data on when business customers place orders and how many businesses are buying from you. 

Top

##  Amazon Business

* [ Amazon Business terms  ](/help/hub/reference/external/G202087450)
* [ B2B product opportunities  ](/help/hub/reference/external/GG6RSFHJVGD653MV)
* [ Troubleshoot Amazon Business errors  ](/help/hub/reference/external/G201812760)
* [ B2B Central  ](/help/hub/reference/external/G202161480)
* [ Amazon Business features  ](/help/hub/reference/external/G201741830)
* [ Amazon Business glossary  ](/help/hub/reference/external/G201760900)
* [ Amazon Business FAQ  ](/help/hub/reference/external/G201740290)
* [ Amazon Business Professional Healthcare program  ](/help/hub/reference/external/GFFRHXRJSRGPZ9UL)
* [ COVID-19 infection control and recovery  ](/help/hub/reference/external/GGLKLPJ5DCN6CMLW)
* [ Amazon Bulk Services: Overview  ](/help/hub/reference/external/GXNDQS697S3JVFK6)
* [ Amazon Bulk Services: Creating a package hierarchy  ](/help/hub/reference/external/GQ4S7SV9K4GXH3WX)

