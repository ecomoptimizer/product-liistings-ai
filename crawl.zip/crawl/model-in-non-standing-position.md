# Model in non-standing position

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Add your favorite pages here by clicking this icon in the navigation menu.

---
Add your favorite pages here by clicking this icon in the navigation menu.

Hide

## Model in non-standing position

Apparel imaged on a human model must show the model in a standing position. Seated or reclining models, unless using a wheelchair, are not allowed. Suggestive poses are not allowed.

| Allowed | Not Allowed |
| --- | --- |
| 
![](https://m.media-amazon.com/images/G/01/image_requirements/standing_model1.jpg)

![](https://m.media-amazon.com/images/G/01/image_requirements/standing_model2.jpg)

 | 

![](https://m.media-amazon.com/images/G/01/image_requirements/non_standing1.png)

![](https://m.media-amazon.com/images/G/01/image_requirements/non_standing2.png)

 |

Top

Was this article helpful?
