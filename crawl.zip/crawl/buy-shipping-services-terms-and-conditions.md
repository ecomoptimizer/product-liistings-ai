# Buy Shipping Services Terms and Conditions

Source: https://sellercentral.amazon.com/gp/help/external/G200672320

This article applies to selling in: **United States**

#  Buy Shipping Services - Terms and Conditions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200672320)

**Your purchase and use of delivery or related services are subject to the
terms and conditions described on this page, the policies we make available in
connection with your Selling partner account, and the[ third-party carrier
](/buy-shipping/terms-and-conditions.html) and other terms available via links
below. You agree to these terms and conditions by clicking the checkbox and/or
the "Buy delivery services & confirm dispatch" button presented with these
terms and conditions or, if earlier, using any of the services described in
these terms and conditions. **

**Your purchase** . You are purchasing delivery and any related services you
request (such as liability coverage) from third parties and not from Amazon.
Amazon is not responsible for and will not have any liability regarding
services you purchase from third parties.

**Charges to Selling partner account** . By purchasing delivery or related
services from third parties via your Selling partner account, you agree to pay
the fees associated with those services. You authorize us to charge your
Selling partner account for any fees associated with the services you purchase
(including by offsetting any amounts payable by you against any amounts
otherwise payable by us to you). Also, we may seek payment or reimbursement of
fees by any other means permitted by your Selling partner agreement or
applicable law. We reserve the right to adjust charges after they are
initially posted to reflect adjustments by the applicable carrier or other
service provider. We may limit or disallow services in our discretion.

**Compliance with laws** . You will comply with all applicable policies, laws,
and regulations with respect to delivery and related third-party services you
purchase.

**Third-Party Service Terms apply** . Your purchase and use of delivery and
related services are also subject to the policies, terms, conditions, and
other agreements between you and the applicable carrier or other service
provider. You are responsible for reviewing and complying with them.

Top

##  Buy Shipping Services - Terms and Conditions

* [ DHL US Terms and Conditions and Shipping Instructions  ](/help/hub/reference/external/G202079190)
* [ UPS Terms and Conditions  ](/help/hub/reference/external/GV5HXM3KAHZYXHTE)
* [ DHL Mexico Terms and Conditions and Shipping Instructions  ](/help/hub/reference/external/G202119530)
* [ DHL eCommerce Terms and Conditions  ](/help/hub/reference/external/G3AMVDU4ESSRYC8F)
* [ OnTrac Terms and Conditions  ](/help/hub/reference/external/G3YDQYBJR85QFETF)
* [ China Post Terms and Conditions  ](/help/hub/reference/external/GWZURZG9EMV26ZT4)
* [ Yanwen Terms and Conditions  ](/help/hub/reference/external/G76GET9ABGSRMTPH)
* [ Hop Nhat International Terms and Conditions  ](/help/hub/reference/external/GK97LD5ARSE9GBQ4)
* [ Amazon Horizon Shipping Terms and Conditions  ](/help/hub/reference/external/GSJL546R2LMFANKG)
* [ Yun Express Terms and Conditions  ](/help/hub/reference/external/G68AKJS77CQNC9F6)
* [ 4PX Terms and Conditions  ](/help/hub/reference/external/G3KUHLWEZUGXKBJC)

