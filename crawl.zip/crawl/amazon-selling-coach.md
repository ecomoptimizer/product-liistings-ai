# Amazon Selling Coach

Source: https://sellercentral.amazon.com/gp/help/external/200380250

This article applies to selling in: **United States**

#  Amazon Selling Coach

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200380250)

**Individual sellers:** This feature is available to sellers with [
Professional selling plans ](/gp/help/external/64491) .

Amazon Selling Coach offers personalized recommendations to help you increase
your success on Amazon.

We are always looking for ways to help you to be more successful on Amazon. As
we identify selling opportunities, we will notify you in the following ways.

####  Amazon Selling Coach in Seller Central

You can find the Amazon Selling Coach on your seller account [ home page
](/gp/homepage.html/) . You can learn more about it on the [ Selling Coach
](/hz/sellingcoach) page.

####  Email recommendations

To verify the email address and other settings for your Amazon Selling Coach
notifications, see [ Notification preferences ](/gp/help/external/871) . You
can view your email notifications on the [ Amazon Selling Coach Communication
](/hz/sellingcoach/communications) page. You can receive email recommendations
in your home marketplace language, English, or simplified Chinese. [ Learn
more. ](/gp/help/external/201642900)

##  Notifications

Amazon Selling Coach notifies you about the following types of opportunities.
To see a detailed list of notifications, select **Amazon Selling Coach** on
the **Reports** menu. Then click the **Email Settings** tab.

####  Inventory Opportunities

Find out when you’re running low on products based on your recent inventory
and sales data. Learn when it’s time to restock so you can avoid running out
and risking cancellations. (Inventory projections are based on your sales over
the past seven days.)

####  Product Opportunities

Increase your selection by adding products that have been popular with
customers recently but have limited availability on Amazon. You can set your
preferences to include or exclude brands, categories, or products. If you’ve
listed similar products in the past, we let you know about customer interest
and help you identify business growth opportunities.

####  Global Selling Opportunities

Make your products available to international customers through Amazon
Marketplace global selling programs. You can list your products in other
marketplaces to expand the number of customers who see them.

####  Fulfillment Opportunities

Learn when there is a high level of customer interest in products you offer
that are not offered through Fulfillment by Amazon (FBA). If you offer these
products through FBA, they might be eligible for free shipping, Amazon Prime,
or other popular FBA benefits.

**Note:** To see fulfillment opportunities, you must be enrolled in FBA. See [
Getting started with Fulfillment by Amazon (FBA) ](/gp/help/external/53921) .

####  Low Price Opportunities

Find out when there are comparable offers with lower prices. The [ Match Low
Price ](/gp/help/external/200836360) feature finds the lowest price currently
available for active listings on Amazon.

##  Preferred language for your notifications

You can choose which email recommendations you receive and in which language
you want to receive them. [ Learn more. ](/gp/help/external/201642900)

####  Amazon Marketplace Web Service (Amazon MWS)

**Important:** You must be an Amazon MWS developer in order to send a Reports
request.

You can download your recommendations in bulk from Amazon Marketplace Web
Services (Amazon MWS). [ Learn more ](/gp/help/external/200389230) .

**Note:** All the notifications on the Selling Coach widget will appear in the
report section. “Reports” are a comprehensive list of notifications.

Top

##  Amazon Selling Coach

* [ Low Price Opportunities  ](/help/hub/reference/external/G200909550)
* [ Email settings for Selling Coach  ](/help/hub/reference/external/G201642900)
* [ Amazon Selling Coach  ](/help/hub/reference/external/G200909560)
* [ Low or out of stock items  ](/help/hub/reference/external/G200909600)
* [ Product Opportunities  ](/help/hub/reference/external/G200909610)
* [ Fulfillment Opportunities  ](/help/hub/reference/external/G200909620)
* [ Customize Amazon Selling Coach  ](/help/hub/reference/external/G201721220)

