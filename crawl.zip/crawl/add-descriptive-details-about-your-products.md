
# Amazon

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> Next, you need to enter a description, keywords, add other optional details, and upload product images. The rest of the tabs allow you to enter this information. The more product information you supply, the easier it is for customers to make educated purchasing decisions. Following Amazon's standards for detail page descriptions and product images will also make it easier for buyers to compare your product with similar products in the Amazon catalog.

---
Next, you need to enter a description, keywords, add other optional details, and upload product images. The rest of the tabs allow you to enter this information. The more product information you supply, the easier it is for customers to make educated purchasing decisions. Following Amazon's standards for detail page descriptions and product images will also make it easier for buyers to compare your product with similar products in the Amazon catalog.

See [Product Detail Page Rules](https://sellercentral.amazon.com/gp/help/200390640) to learn more about what kinds of details should and should not be included.

For instructions on adding images, see [Adding Product Images](https://sellercentral.amazon.com/gp/help/200216080).

Top

Was this article helpful?
