# Oversize

Source: https://sellercentral.amazon.com/gp/help/external/201105770

This article applies to selling in: **United States**

#  Product size tiers

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201105770)

On this page

How to determine the product size tier

Product size tier examples

Frequently asked questions

**Definition** |  Product size tiers are measurement categories based on the
unit weight, product dimensions, and dimensional weight of a packaged item.  
---|---  
**Using this article** |  The product size tier of an item is used to
calculate certain fees. After reading this article, you will be able to
determine the product size tier for an item. To accomplish this task, you
should first know the unit weight, product volume and dimensions, and the
dimensional weight of the item.  
**Fees that use this attribute** |

[ FBA fulfillment fees ](/gp/help/external/GPDC3KPYAGDTVDJP)

[ Monthly inventory storage fees ](/gp/help/external/G3EDYEF6KUCFQTNM)

[ Long-term storage fees ](/gp/help/external/GJQNPA23YWVA4SBD)

[ FBA inventory storage overage fees ](/gp/help/external/GV8JEETWV9Q33CMX)

[ FBA removal order fees ](/gp/help/external/G9W7FVTLY343ZBKN)

[ FBA disposal order fees ](/gp/help/external/G5FKTA8LXU4TZPD5)

[ Fulfillment fees for Multi-Channel Fulfillment orders
](/gp/help/external/201112650)

[ FBA Inventory Placement Service fees ](/gp/help/external/G200735910)

[ FBA Prep Service fees ](/gp/help/external/201023020)  
  
**Related terms** |

[ Dimensional weight ](/gp/help/external/G53Z9EKF8VVZVH29)

[ Product dimensions and volume ](/gp/help/external/G37G73BJXHF75ACH)

[ Unit weight ](/gp/help/external/GE3VC5FGJE9TYJKM)

[ FBA fees reimbursement policy: Weight and dimensions
](/gp/help/external/GL7U4JFSDXUTQAJ)

[ Shipping weight ](/gp/help/external/GEVWP48HPBLEFJEY)  
  
##  How to determine the product size tier

  1. Determine the volume and dimensions of the item. 

  2. Determine the unit weight and dimensional weight* of the item. 

  3. Use the above values and the table below to determine the product size tier. 

Find the row in the table below with measurements that do not exceed the
weight or the dimensions of your item.

Product size tier  |  Unit weight*  |  Longest side  |  Median side  |
Shortest side  |  Length + girth  
---|---|---|---|---|---  
**Small standard-size** |  16 oz  |  15 inches  |  12 inches  |  0.75 inch  |
n/a  
**Large standard-size** |  20 lb  |  18 inches  |  14 inches  |  8 inches  |
n/a  
**Small oversize** |  70 lb  |  60 inches  |  30 inches  |  n/a  |  130 inches  
**Medium oversize** |  150 lb  |  108 inches  |  n/a  |  n/a  |  130 inches  
**Large oversize** |  150 lb  |  108 inches  |  n/a  |  n/a  |  165 inches  
**Special oversize** |  Over 150 lb  |  Over 108 inches  |  n/a  |  n/a  |
Over 165 inche  
  
For apparel, Amazon uses dimensional weight when it’s greater than the unit
weight for the following FBA units:

  * Small standard-size and large standard-size units weighing more than 0.75 lb 
  * All small oversize, medium oversize, and large oversize units 

For non-apparel, Amazon uses dimensional weight when it’s greater than the
unit weight for all large standard, small oversize, medium oversize, and large
oversize FBA units.

For Multi-Channel Fulfillment (MCF), the dimensional weight is calculated for
all large standard, small oversize, medium oversize, and large oversize items,
regardless of whether the item is apparel.

Go to [ Dimensional weight ](/gp/help/external/G53Z9EKF8VVZVH29) for more
details. For products you currently have in FBA inventory, you can also look
up your unit weight using the [ Fee Preview
](/reportcentral/ESTIMATED_FBA_FEES/1) report. To do so:

  * Download the report. 
  * Identify the product you want to look up using its FNSKU. 
  * View the product size tier in the **product-size-tier** field. 

##  Product size tier examples

|  **Mobile device case**

Dimensions: 13.8 x 9 x 0.7 inches

Unit weight: 2.88 oz

Product size tier: Small standard size  
  
---|---  
|  **T-shirt**

Dimensions: 8.5 x 4.8 x 1 inches

Unit weight: 6.08 oz

Product size tier: Large standard size  
  
##  Frequently asked questions

####  Which measurement system does Amazon use to measure products and
calculate fees, imperial or metric?

The measurement system for product dimensions and volume vary depending on the
local standard in which the fees are calculated. The fee Help content for the
region indicates which measurement system and units are used for that region.

Top

