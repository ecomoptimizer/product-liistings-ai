# Edit a listing

Source: https://sellercentral.amazon.com/help/hub/reference/external/GSGKAPSNT53G5B2P

This article applies to selling in: **United States**

#  Edit a listing

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGSGKAPSNT53G5B2P)

In most cases, changes you make to product information appear on Amazon within
5 minutes. However, some updates can take up to 6 hours. Product descriptions
longer than 500 characters are generally updated at 8:00 AM PST the following
day. Images may take up to 24 hours to appear on a product detail page.

To edit details for an existing listing:

  1. On the **Inventory** menu, select **Manage Inventory** . 

  2. Select the **Active** status filter above the product list. 

  3. Find the listing you want to edit, and select **Edit** from the drop-down menu for that listing. 

  4. Click the links at the top of the page to add, edit, or change the listing's content. You can also type price and quantity updates in the text boxes in the **Price** and **Quantity** columns. 

  5. Click **Save and finish** . 

Top

