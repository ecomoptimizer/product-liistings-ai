# Pricing status

Source: https://sellercentral.amazon.com/help/hub/reference/external/GS9A4Q8K4Q6KT8TV

This article applies to selling in: **United States**

#  Pricing status

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGS9A4Q8K4Q6KT8TV)

You can view how your price compares to other prices on Amazon or outside of
Amazon in the **Pricing Status** section of the **Price + Shipping** column on
the **Manage Inventory** page. This column will compare your price to:

  * Featured Offer, which is the offer at the top of a product detail page. Customers can 'buy now' or add it to their shopping carts. Sellers must meet performance-based requirements, including pricing competitively, to be eligible to compete for Featured Offer placement. For more information, go to [ How the Featured Offer works ](/gp/help/external/G37911) . 
  * Competitive price, which is the lowest price for the item from other major retailers outside Amazon. It does not include prices from other sellers in the Amazon store. To be considered competitively priced, your Price + Shipping must be less than or equal to the competitive price. For more information, go to [ Pricing Health ](/gp/help/external/GSTH6YN3BR8XNWBW) . 
  * Lowest price, which is the current lowest price on Amazon for this product. Current lowest price is based on your **Manage Inventory preferences** page, which allows you to compare offers by taking into account the listing condition and the fulfillment method.  For more information, go to [ Set your Manage Inventory page preferences ](/gp/help/external/GE7UVMSSJREL55WA) . 

For each of these prices, a green check mark will appear if your price is less
than or equal to the respective price and a red cross will appear if your
price is higher than the respective price.

**Note:** We reserve Featured Offer placement for seller offers that maintain
our customer experience standards, including timely shipping, competitive
pricing, accurate listing, and prompt delivery. For your offer to be eligible
to be a Featured Offer on the **Product Detail** page, you need to meet the [
qualifying criteria ](/gp/help/external/200418100) .

Top

