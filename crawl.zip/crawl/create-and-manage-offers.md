# Create and manage offers

Source: https://sellercentral.amazon.com/help/hub/reference/external/GFQ8J5JPKERTHQPP

This article applies to selling in: **United States**

#  Create and manage offers

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGFQ8J5JPKERTHQPP)

To list products on Amazon, you have to create offers. There are several ways
to create an offer.

If the product you want to sell is already in Amazon’s catalog, create a new
product listing by matching it to the existing product detail page. If you
want to create multiple product listings at once, you can do so by using
inventory file templates.

If the product you want to sell is not in Amazon’s catalog, create a new
product listing and a new product detail page. In order to successfully list
your products, you must upload at least one image that meets the image
requirements.

In this set of pages, you can find information necessary to create and manage
offers. Select a page from left navigation pane to see more information.

Top

##  Create and manage offers

* [ Qualify to Made in France / Fabriqué en France  ](/help/hub/reference/external/G4C9SLZZ2EG4AR8B)
* [ Lost Sales Dashboard  ](/help/hub/reference/external/GVBF5JR9AJCU65FF)
* [ About Product Documents  ](/help/hub/reference/external/GZJNHR2M4GDNM3Q3)
* [ Compare and Choose Listing Methods  ](/help/hub/reference/external/G201576400)
* [ Start Listing Your Products Now  ](/help/hub/reference/external/G201474070)
* [ Create listings one at a time  ](/help/hub/reference/external/G39EFY66ZLSJQ7PM)
* [ Create listings in bulk  ](/help/hub/reference/external/GZ4ZQ4HZQM2R4B2X)
* [ About products and listings  ](/help/hub/reference/external/G200182950)
* [ Amazon Search  ](/help/hub/reference/external/GS6TQLG64JYD4LSY)
* [ Product page style guide  ](/help/hub/reference/external/G200270100)
* [ Assign category and browse terms to your listings  ](/help/hub/reference/external/G200986940)
* [ Product detail pages and offers  ](/help/hub/reference/external/G51)
* [ Novelty SKU Limits  ](/help/hub/reference/external/G201440840)
* [ Image manager  ](/help/hub/reference/external/GUGPCYWV2P8KVFUT)
* [ Product 3D models  ](/help/hub/reference/external/G7RGSNQFZ2BAG7K3)
* [ Product images  ](/help/hub/reference/external/G200986900)
* [ Image variants  ](/help/hub/reference/external/G8HQAHPDXA9ANPH4)
* [ Multipack imaging standards  ](/help/hub/reference/external/G94GSFMC79RSLDBY)
* [ Image Troubleshooting  ](/help/hub/reference/external/G17771)
* [ Listing photos  ](/help/hub/reference/external/G201270290)
* [ Amazon Merchant Transport Utility  ](/help/hub/reference/external/G16481)
* [ Potential Duplicates and Split Variations  ](/help/hub/reference/external/G202105450)
* [ Suppressed listings  ](/help/hub/reference/external/G200898440)
* [ Listing blocked due to potential pricing error  ](/help/hub/reference/external/G201141430)
* [ Use Amazon Selling Coach to help increase your selling success  ](/help/hub/reference/external/G200966670)
* [ How the Other Sellers on Amazon box works  ](/help/hub/reference/external/G200418110)
* [ Error code explanations  ](/help/hub/reference/external/G17781)
* [ Create and manage inventory FAQ  ](/help/hub/reference/external/GSXJTLLHYLVQCWQZ)
* [ Newer version widget  ](/help/hub/reference/external/GAEG57678UHDZ3EP)
* [ Enroll products in our Climate Pledge Friendly program  ](/help/hub/reference/external/GE94565V5PDYL5MZ)
* [ Enroll textile products in Climate Pledge Friendly (CPF)  ](/help/hub/reference/external/GKQ2X9KZ9EU7AK53)
* [ Qualify for Compact by Design  ](/help/hub/reference/external/G8K5K99JHR3ACAXM)
* [ Updated dimension attributes for product types  ](/help/hub/reference/external/GMYRLMMPMNR7UQSE)
* [ Size Normalization FAQ  ](/help/hub/reference/external/GZJRCRLWW7WKKDAH)
* [ Conditional Unit Count based on Item Form, Normalized Value of Size, Item Form, Number of Items and Net Content details  ](/help/hub/reference/external/G2RCDMZR4SKGQFAY)
* [ Warning code 18367: Product type modified by Amazon  ](/help/hub/reference/external/GXMA2QU3JZTG8JNL)

