# Manage Your Customer Engagement

Source: https://sellercentral.amazon.com/help/hub/reference/external/GF85G8KLPFJZZV5K

This article applies to selling in: **United States**

#  Manage Your Customer Engagement

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGF85G8KLPFJZZV5K)

On this page

Campaign setup

Including promotional details on the campaign primary product

Scheduling and sending a campaign

Campaign approvals

Manage Your Customer Engagement (MYCE) lets you engage directly with your
Amazon customers. MYCE helps your brand build loyal relationships with Amazon
customers and helps increase visibility of your products.

The Manage Your Customer Engagement program currently supports new product
announcements, 7-day deal details, and gift event guides. More creative
options will be added in the future.

The Manage Your Customer Engagement tool is available to registered brands
that have an Amazon Stores page with Brand Followers. If your brand is not
already registered, visit [ Amazon Brand Registry
](https://brandservices.amazon.com/) to see if you are eligible. Once you have
a [ Stores page ](https://advertising.amazon.com/solutions/products/stores) ,
[ create a post ](https://advertising.amazon.com/solutions/products/posts)
that features quality content to increase your [ followers
](https://www.amazon.com/gp/help/customer/display.html?nodeId=GNUPK6RZMQDSL52X)
.

##  Campaign setup

Setting up an email campaign in the Manage Your Customer Engagement tool is
easy, and requires just a few steps:  

  1. **Select a shopping event theme:** Optionally selecting a shopping event theme will update the visual style of the email, providing more engaging and timely content for your customers to view. 
  2. **Select a primary product:** Add a product that you want to feature prominently in your email campaign. It can be a new product launch, a gift idea, and can include promotional details if the product is part of an eligible promotion. By entering your primary ASIN and clicking “submit”, you will be able to select promotional details if there is an eligible promotion (see below section entitled, “Including promotional details on the campaign primary product”) on the product. 
  3. **Select a supporting image:** Select or upload a lifestyle image or an image that explains the benefits of the product. Image must adhere to Amazon’s [ product image requirements ](/gp/help/external/GUHDLPWYZ6FW3N42) . 
  4. **Select supporting products:** You can select up to four supporting products to add to your campaign. They will appear below your primary product. This step is optional, and can help customers learn about complimentary products and other products from your Brand that they may be interested in. 
  5. **Schedule your campaign:** Select the date you want your campaign to start sending. Your campaign will be sent in the 5-day period starting on the date you select, subject to several restrictions. Learn more below in section “How Do I Schedule a Campaign?” 
  6. **Configure your campaign email settings:**   

    1. **Select your subject line and section header:** The subject line is the title of the email that will appear when your customer receives the campaign email in their inbox. The section header is the visible text that appears at the top of the email body (For example, “New product from a Brand you follow” in the below email campaign example). 
    2. **Upload your brand logo and header style:** Logos must be in horizontal layout (3:1 or narrower) and can have a black or white background (JPG) or a transparent background (PNG). For the email header, you can select between a dark and a light version. The header color may change based on the event theme you select. 
  7. **Name your campaign:** Pick a nickname for your campaign. Your customers will not see this title - it is for your reference when reviewing campaign performance. 

**Email campaign example** :

##  Including promotional details on the campaign primary product

To feature promotional details on the primary product of an MYCE email
campaign, it must meet certain requirements:

  * **Promotion Type:** Eligible promotions type is “7-day Deal”. 
  * **Date Range:** Eligible promotions must run for at least the duration of the email campaign. Specifically, the promotion must start on midnight (Pacific Standard Time) on the selected campaign start date or earlier, and must have a scheduled end date six days or more from your campaign start date. 
  * **Shopping Event Time Constraint:** If you selected a shopping event theme, then you will only be able to select an eligible promotion that is running during the time window of the shopping event. 
  * **Promotion Creation Time:** The promotion must have been created more than 24 hours prior to adding to an MYCE campaign. If you just created a promotion, wait for 24 hours before attempting to select the promotion in the MYCE campaign creation workflow. 

You will be able to select eligible promotional details when you enter a
primary campaign ASIN and click “Submit”. A window will appear to select the
promotional details of any eligible promotion on the primary product. If a
promotion doesn’t meet the above requirements, it will not appear. If you
don’t see a promotion that you expected to see, please review the promotion
requirements above for a promotion that is eligible to include promotional
details on the primary ASIN in an MYCE campaign.

**Note:** The promotion you selected should not be cancelled while your
campaign is sending to customers. If the selected promotion is rejected or
canceled prior to campaign start, the campaign will be suspended and will not
be sent to customers.

##  Scheduling and sending a campaign

In the “Campaign Delivery Window” step of campaign creation, you can select
the date on which your campaign will start sending to customers. Your campaign
will be sent to customers over a 5-day window starting on the date you select.
When viewing the date picker, you will see several colors indicating potential
conflict with other campaigns:

  * **Grey dates:** These dates are un-selectable. We require a 6-day period to moderate your campaign and to prepare to send to Customers. 
  * **Green dates:** These dates are selectable, and don’t have any overlap with other campaigns you created. 
  * **Yellow dates:** These dates are selectable, but will overlap with another campaign that you have scheduled. You can schedule your campaign for this date, but your reach may be significantly impacted by the overlapping campaign. 

To learn more about campaign frequency and audience engagement, go to [
Customer engagement tailored audiences
](/help/hub/reference/external/GB6ALLF64SPZ3ZFQ) .

**Date restrictions with shopping events and promotional details:** If you
select a shopping event theme, the window to schedule a campaign will be
constrained to the time window of that shopping event. If you added
promotional details to your primary ASIN, the window to schedule a campaign
will be further constrained to within the start and end date of the promotion
you selected.

##  Campaign approvals

Campaigns are reviewed by our moderation team, who will determine if your
content meets our requirements. It takes a minimum of 72 hours for your image
assets to be reviewed. As you schedule your campaign, make sure you plan ahead
to allow ample time for reviews. If your campaign is rejected during
moderation, its status will change to **suspended** , and you will need to
create a new campaign that adheres to our [ content requirements
](/gp/help/external/GUHDLPWYZ6FW3N42) .

Top

##  Manage Your Customer Engagement

* [ Guidelines to grow your followers using Posts and Stores  ](/help/hub/reference/external/GC2U5769RXRTWVNW)
* [ Manage Your Customer Engagement campaign requirements  ](/help/hub/reference/external/GUHDLPWYZ6FW3N42)
* [ Customer engagement campaign metrics  ](/help/hub/reference/external/GDVLURHWMGV22CBU)
* [ Customer engagement best practices  ](/help/hub/reference/external/GE6NX6CSZ7ML75YN)
* [ Customer engagement tailored audiences  ](/help/hub/reference/external/GB6ALLF64SPZ3ZFQ)

