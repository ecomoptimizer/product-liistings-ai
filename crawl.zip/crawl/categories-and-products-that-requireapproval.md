# Categories and products that requireapproval

Source: https://sellercentral.amazon.com/gp/help/external/G200333160

This article applies to selling in: **United States**

#  Categories and products that require approval

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200333160)

On this page

Applying to list existing products that require approval

Applying to list new products in categories that require approval

Learn more

See other products and programs requiring approval

We want customers to be able to shop with confidence on Amazon. For certain
products, brands, categories, and sub-categories, we require sellers to obtain
approval before listing products. The approval process may include document
requests, performance checks, and other qualifications.

Watch the video below to learn about the brand approval process and products
that may require approval before listing.

##  Applying to list existing products that require approval

To apply to list a product that already exists in Amazon’s catalog and
requires approval, follow these steps:

From the Seller Central Home page, click on **Catalog** menu and select **Add
a Product** .  

  1. Search for the item you want to sell. 
  2. In the search results, click the **Show limitations** link next to the item. 
  3. Click the **Apply to sell** button to begin the application process. 

##  Applying to list new products in categories that require approval

To add a new product to Amazon’s catalog in one of the categories with
restrictions listed below, follow the link to the application and submit the
required information related to your product.

**Note:** Additional listing limitations may apply for certain products, at
either the ASIN, brand, or the sub-category level. When attempting to list
products with additional requirements, you will see a **Listing Limitations
Apply** link next to the product.

Product Category  |  Submit Application  
---|---  
[ Jewelry
](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=200332590&language=en_US&ref=ag_200332590_cont_200333160)
|  [ Request Approval
](https://sellercentral.amazon.com/hz/approvalrequest/restrictions/approve?asin=B08H5CPL25)  
[ Music
](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=202188990&language=en_US&ref=ag_202188990_cont_200333160)
|  [ Request Approval
](https://sellercentral.amazon.com/hz/approvalrequest?gl=gl_music)  
[ Video, DVD & Blu-ray
](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=201607580&language=en_US&ref=ag_201607580_cont_200333160)
|  [ Request Approval
](https://sellercentral.amazon.com/hz/approvalrequest?gl=gl_dvd)  
  
For a comprehensive list of product categories in which you can sell, see [
Overview of Categories ](/gp/help/external/G200332540)

Sellers may apply in advance to sell the specific products or categories of
products listed below. The links below provide more information about the
approval requirements or process for each product or category.

##  Learn more

  * [ Selling Applications FAQ ](https://sellercentral.amazon.com/help/hub/reference/external/G84EFS4CKK43USMF)
  * [ Introduction to Invoice Requirements (PDF) ](https://sellercentral.amazon.com/learn/courses?ref_=su_course_accordion&moduleId=5cdb82d3-e43b-4835-b105-b7c5477ded5f&courseId=64ccd43f-756e-4944-aafb-b1e3a5cfd742&modLanguage=English)
  * [ Product Packaging Picture Requirements (PDF) ](https://sellercentral.amazon.com/learn/courses?ref_=su_course_accordion&moduleId=6fc60eb1-e90f-49e5-9664-aa44fcea49ad&courseId=64ccd43f-756e-4944-aafb-b1e3a5cfd742&modLanguage=English)
  * [ Invoices for Selling Applications (Video) ](https://sellercentral.amazon.com/learn/courses?ref_=su_course_accordion&moduleId=b133c6c0-aa5a-405a-b58f-ac352e7e78c5&courseId=64ccd43f-756e-4944-aafb-b1e3a5cfd742&modLanguage=English&videoPlayer=youtube)
  * [ Product Packaging Pictures for Selling Applications (Video) ](https://sellercentral.amazon.com/learn/courses?ref_=su_course_accordion&moduleId=b133c6c0-aa5a-405a-b58f-ac352e7e78c5&courseId=64ccd43f-756e-4944-aafb-b1e3a5cfd742&modLanguage=English&videoPlayer=youtube)

##  See other products and programs requiring approval

  * [ Electronic mobility (e-mobility) devices ](/gp/help/external/GMUW6CKYLY4AP8MK)
  * [ Laser pointers and other laser products ](/gp/help/external/201689020)
  * [ Launchpad ](/gp/help/external/202033750)
  * [ Amazon Renewed ](/gp/help/external/201648580)
  * [ Amazon Accelerator ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=52NQJE353XZGWN7&ref=ag_52NQJE353XZGWN7_cont_xx)

Top

##  Categories and products that require approval

* [ Postage stamps  ](/help/hub/reference/external/GWHRWJTHCX9MQU46)
* [ Collectible Coins  ](/help/hub/reference/external/G201526800)
* [ Fine Art  ](/help/hub/reference/external/G201257400)
* [ Jewelry  ](/help/hub/reference/external/G200332590)
* [ Join Amazon Subscription Boxes  ](/help/hub/reference/external/GGGBPUVL7H6VEME9)
* [ ](/help/hub/reference/external/G201852310)
* [ Music & DVD  ](/help/hub/reference/external/G202188990)
* [ Services  ](/help/hub/reference/external/G201613540)
* [ Sports Collectibles  ](/help/hub/reference/external/G200800780)
* [ Streaming Media Players  ](/help/hub/reference/external/G202183590)
* [ Video, DVD, & Blu-ray  ](/help/hub/reference/external/G201607580)
* [ Watches  ](/help/hub/reference/external/G200316090)
* [ Sony PlayStation Requirements in Video Games  ](/help/hub/reference/external/GR7X85TSR4YR6RY9)
* [ Selling Applications FAQ  ](/help/hub/reference/external/G84EFS4CKK43USMF)

