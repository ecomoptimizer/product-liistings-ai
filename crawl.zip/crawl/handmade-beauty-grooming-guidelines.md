# Handmade Beauty & Grooming guidelines

Source: https://sellercentral.amazon.com/gp/help/external/G202102450

This article applies to selling in: **United States**

#  Handmade Beauty & Grooming guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202102450)

As a Maker, your handmade Beauty and Grooming products must adhere to the
following guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must follow the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * All products must comply with all applicable laws and regulations. 
  * All products must display materials used in the creation of the final product. 
  * All products must follow the [ Cosmetic & Skin/Hair Care ](/gp/help/external/G200164470) listing restrictions. 
  * All products must be authentic. We do not allow any counterfeit, replica, or knock-off products. 
  * Makers must employ quality control and inspection procedures. 
  * Products containing cannabis are prohibited. 
  * Adult products must comply with the [ Adult products policies & guidelines ](/gp/help/external/G200339940) and must be flagged as 'Adult'. 
  * Wigs must be created by hand stitching wefts or braids of hair onto a lace or other fabric base. 

Top

