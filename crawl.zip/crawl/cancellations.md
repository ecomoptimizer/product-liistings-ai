# Cancellations

Source: https://sellercentral.amazon.com/help/hub/reference/external/GBN4AZVWUS29ZUJX

This article applies to selling in: **United States**

#  Cancellations

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGBN4AZVWUS29ZUJX)

If you are unable to ship an order, or if a buyer asks you to cancel an order,
refer to the following help topics:

  * [ Cancel an item, order, or multiple orders ](/help/hub/reference/external/G200198080) \- Cancel any unshipped item or order from your **Manage Orders** page. 
  * [ Order cancellations ](/help/hub/reference/external/G201722390) \- Process cancellation requests from buyers. 
  * [ Cancellations FAQ ](/help/hub/reference/external/GRXAS2XTAYEF77BG) \- Find solutionsto buyer cancellations, Pending status, or solve mistakes in cancelling. 

Canceled orders are listed on the **Manage Orders** page. This page provides
basic details about canceled orders. No action is necessary on canceled
orders.

Canceled orders are complete when the **Pending status** is resolved. While
some orders are canceled by a buyer before they entering the processing stage,
other orders are canceled by Amazon after hours or days of processing. You
will not be able to communicate with a buyer once their order is canceled. If
the buyer has questions after their order is canceled, direct them to Amazon
customer service.

Top

##  Cancellations

* [ Cancel an item, order, or multiple orders  ](/help/hub/reference/external/G200198080)
* [ Cancel Multiple Orders  ](/help/hub/reference/external/G50791)
* [ Cancellations FAQ  ](/help/hub/reference/external/GRXAS2XTAYEF77BG)

