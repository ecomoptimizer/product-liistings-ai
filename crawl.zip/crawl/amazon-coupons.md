# Amazon Coupons

Source: https://sellercentral.amazon.com/gp/help/external/G202189350

This article applies to selling in: **United States**

#  Create a coupon

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202189350)

On this page

Add products

Edit a coupon

Cancel a coupon

Advertise (optional)

To create a coupon, follow the steps below:

  

  1. Go to **Advertising** , and select **Coupons** . 
  2. Click a tab by Coupon Type from either **Standard Coupon** or **Subscribe and Save Coupon** . 
  3. Click **Create a new coupon** . 

**Note:** If this is your first coupon, click **Create your first coupon** .

  4. To create one coupon at a time, follow the below steps. To create coupons in bulk by using a spreadsheet, follow the instructions in [ How to create coupons in bulk ](/gp/help/external/G363YLQW4NB5L38V) . 
  5. On the left pane, search for the products you want to add to the coupon and click **Add to coupon** . The added products are displayed on the right pane. 
  6. Click **Show variations** in the related product's box to find the variation you want to remove and click **Remove** . 
  7. Click **Continue to next step** after you select the products to add. 
  8. Choose between **Percentage Off** and **Money Off** discounts and specify the discount.  This value must be a percentage for **Percentage Off** and a USD amount for **Money Off** discounts.  The minimum and maximum discounts for coupons are 5% and 80% respectively. 

**Note:** Percentage Off and Money Off coupons will be combined with discounts
from other promotions that are running at the same time.This includes
Lightning Deals, Promotions, Sale Price, Business Price, and Outlet deals. For
example, if a Lightning Deal offers a 20% discount on a $100 ASIN and that
same ASIN also has a 5% off coupon running at the same time, the 5% off
discount from the coupon will combine with the 20% discount from the Lightning
Deal. This will result in a total discount of $25.

Standard Price: $100

Lightning Deal Discount: 20%

Coupon Discount: 5%

Total Discount: (100 * 0.2) + (100 * 0.05) = $25

A coupon discount will apply to one unit per order. This can be multiple units
of the same coupon ASIN or two units from two different coupon ASINs. If they
are in the same order, then the coupon discount will apply to the lowest-
priced item at checkout.

**Important:** After you decide the promotions you want to apply to your
offers, you can combine promotions. For example, combine a lightning deal with
a coupon. This can cause unexpected customer spike and excess budget. If you
do not intend to combine promotions, then cancel overlapping promotions you
don't want to run.

  9. To set a budget for your coupon, go to [ How do coupon budgets work? ](/gp/help/external/G202189370)
  10. Click **Continue to next step** . 
  11. Select a **Title** , **Start date** , and **End date** for your coupon. You can choose to target your coupon to a customer segment from this step. For details, go to [ How does coupon targeting work? ](/gp/help/external/202189390)
  12. Click **Continue to next step** . 
  13. The earliest a coupon can go live is six hours after creation. For more information, go to [ Edit a coupon ](/gp/help/external/G202189350) . We currently do not allow the creation of coupons more than six months in advance. The start date of the coupon cannot be more than six months from the day of creation. 
  14. After you review your coupon, click **Submit coupon** . 

##  Add products

You can add up to 200 parent ASINs to one coupon. To provide a better customer
experience, select products within the same sub-category, price level, or
product group. For products that are selected as **Featured Offer** , your
coupon offer will be more visible throughout the website.

##  Edit a coupon

Approximately six hours before the start time, your coupon will be locked. At
this time, our systems run validation rules on your coupon to make sure it
offers a good value to our customers. Once locked, you cannot make any changes
to your coupon until it goes live. After the coupon goes live, you can
increase your budget or extend the duration for up to 90 days.

##  Cancel a coupon

Click **Deactivate** to cancel your coupons.

  * Cancelations don't happen immediately because customers who have already clipped your coupon before cancelation will be allowed to check out those coupons for approximately 30 minutes after cancelation. 
  * Offensive words, discount percentages, or reference to events such as Prime Day or Black Friday in coupon titles are prohibited. Failure to comply with these rules can result in your coupon being deactivated by Amazon. 
  * As you consider running promotions for your products, promotions cannot be provided as an incentive for customer reviews either explicitly or implicitly. 
  * Customer reviews from purchases with promotions don't always get the 'Amazon Verified Purchase' badge. To learn more, go to [ Customer product reviews policies ](/gp/help/external/GYRKB5RU3FS5TURN) and [ Amazon Verified Purchase Reviews ](https://www.amazon.com/gp/help/customer/display.html?ref_=help_search_1-1&nodeId=G75XTB7MBMBTXP6W&qid=1678968828213&sr=1-1) . 

##

**Important:** Entering offensive words, discount percentages, or referring to
events (such as Prime Day or Black Friday) in voucher titles are prohibited.
Failure to comply with these rules may result in your voucher being
deactivated by Amazon.  Entering offensive words, discount amounts, or
referring to events (such as Prime Day or Black Friday) in coupon titles are
prohibited.

**Note:** As you consider running promotions for your products, keep in mind
that promotions cannot be provided as an incentive for customer reviews
(either explicitly or implicitly).

Also note that customer reviews from purchases with promotions might not
always get the 'Amazon Verified Purchase' badge.  To learn more, go to [
Customer product reviews policies ](/gp/help/external/YRKB5RU3FS5TURN) and [
Amazon Verified Purchase Reviews
](/gp/help/customer/display.html?nodeId=202076110) .

##  Advertise (optional)

After you submit your coupon, you can create a **Sponsored Products** campaign
for your coupon ASINs to potentially elevate search placement and increase
page views.  To learn more, go to [ Sponsored Products for Coupons
](/gp/help/external/G6RSCSVSXA9GALMD) .

Top

##  Create a coupon

* [ Coupon recommendation FAQ  ](/help/hub/reference/external/GFZBLSDY458YS7TF)

