# Fulfillment center operations

Source: https://sellercentral.amazon.com/gp/help/external/GGEV4254LJJ9BAEG

This article applies to selling in: **United States**

#  FBA inventory reimbursement policy: Fulfillment center operations claim

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGGEV4254LJJ9BAEG)

On this page

Claim window

Before you submit a claim

Submit your claim

This page applies to eligible items that are lost or damaged by an Amazon
fulfillment center or a facility operated on behalf of Amazon, after we
receive them from you. These lost or damaged items are reported in your [
Inventory Adjustments report ](/reportcentral/INVENTORY_ADJUSTMENT/0) .

The process to a file a claim varies by where in the fulfillment process your
item is lost or damaged:

  * [ Shipment to Amazon ](/gp/help/external/GEYPWTSQRTXXXMVB)
  * Fulfillment center operations 
  * [ FBA customer returns ](/gp/help/external/G9N934L7Y4SFWPJ4)
  * [ Removals ](/gp/help/external/G9ZB3H4DP4H72U6R)

##  Claim window

You must submit your claim no later than 18 months after the date the item was
reported lost or damaged in your Inventory Adjustment report. Claims submitted
outside of this window are not eligible for reimbursement.

##  Before you submit a claim

  * Check your [ Inventory Adjustments report ](/reportcentral/INVENTORY_ADJUSTMENT/0) to confirm the date and adjustment code of the loss or damage to your items. 
  * Check your [ Manage FBA Inventory report ](/reportcentral/FBA_MYI_UNSUPPRESSED_INVENTORY/1) to confirm that the lost or damaged item was not found or restored to your inventory in a sellable condition or in a damaged condition for which Amazon was not at fault (for example, the item was defective). 
  * Check your [ Reimbursements report ](/reportcentral/REIMBURSEMENTS/0) to see if you have already been reimbursed for the lost or damaged item. Search by FNSKU and date to filter the results. 

##  Submit your claim

After reviewing and reconciling the reports above, if you still believe a lost
or damaged item is eligible for a reimbursement, you can file a claim.

You may be asked to provide additional information such as the date or
location (for example, the Amazon fulfillment center ID) of the loss or damage
to your item.

For damaged items, enter the transaction item ID in the following tool to
check your eligibility and file a claim. You can find the transaction item ID
in the [ Inventory Adjustments report ](/reportcentral/INVENTORY_ADJUSTMENT/0)
.

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGGEV4254LJJ9BAEG)

For lost items, enter the FNSKU in the following tool to check your
eligibility and file a claim. You can find the FNSKU in the [ Inventory
Adjustments report ](/reportcentral/INVENTORY_ADJUSTMENT/0) .

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGGEV4254LJJ9BAEG)

Top

