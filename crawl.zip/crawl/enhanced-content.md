# Enhanced Content

Source: https://sellercentral.amazon.com/gp/help/external/201818520

This article applies to selling in: **United States**

#  Product documents

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201818520)

You can add product documents in the following categories.

  * Automotive & Powersports 
  * Electronics 
  * Tools & Home Improvement 
  * Home & Garden 
  * Patio, Lawn & Garden 
  * Luggage & Travel Accessories 
  * Appliances 
  * Musical Instruments 
  * Office Products 
  * Computers 
  * Industrial & Scientific 
  * Camera & Photo 
  * Toys & Games 
  * Wine 
  * Amazon Kindle 
  * Grocery & Gourmet Food 
  * Kitchen 

Top

##  Product documents

* [ Delete product documents  ](/help/hub/reference/external/G201824220)
* [ Frequently asked questions  ](/help/hub/reference/external/G201824230)

