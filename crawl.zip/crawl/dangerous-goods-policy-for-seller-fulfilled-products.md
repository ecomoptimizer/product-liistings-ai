# Dangerous Goods policy for seller-fulfilled products

Source: https://sellercentral.amazon.com/gp/help/external/GN4SW35Y4KXHX8BT

This article applies to selling in: **United States**

#  Dangerous Goods policy for seller-fulfilled products

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGN4SW35Y4KXHX8BT)

Dangerous goods products fulfilled through Amazon must be shipped in
compliance with local and international transportation regulations. If you are
fulfilling orders, you are the shipper of record. As the shipper, it is your
responsibility to ensure that any order that contains dangerous goods complies
with the applicable packaging and labeling requirements. Any violations of
dangerous goods regulations may result in a restriction of your ability to
sell and fulfill orders.

For more information about dangerous goods products and requirements, go to
the following help pages:

  * [ Examples of products that may be regulated as dangerous goods ](/gp/help/external/G200525640)
  * [ Requirements for lithium batteries and products that are shipped with lithium batteries ](/gp/help/external/G200383420)

You can also refer to the [ Dangerous goods overview
](/learn/courses?moduleId=401) video.

Top

