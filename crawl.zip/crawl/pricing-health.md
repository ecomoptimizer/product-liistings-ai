# Pricing  Health

Source: https://sellercentral.amazon.com/gp/help/external/GSTH6YN3BR8XNWBW

This article applies to selling in: **United States**

#  Pricing Health

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGSTH6YN3BR8XNWBW)

The Pricing Health page provides an overview of your Featured Offer (Buy Box)
eligibility, sales conversion from a pricing point of view, and any inactive
offers with potential pricing errors.

The Featured Offer tab lists:

  * All offers currently ineligible to be a Featured Offer on the Product Detail page because they are not priced competitively compared to other retailers outside of Amazon (the Competitive Price) or they are priced much higher than recent prices observed in Amazon's store. To resolve this issue where: 
    * offers are not competitive, consider setting your offer's total price (price + shipping) at or below the Competitive Price. 
    * offers are priced higher than recent prices, consider setting your offer’s total price (price + shipping) in line with the Reference Price(s). 

**Note:** Reference prices may include any of the Featured Offer price, 60-day
average selling price, highest 14-day price (shipped and sold by Amazon), or
the product’s list price, or both.

  * Offers currently eligible to be the Featured Offer, but are not currently the Featured Offer are the result of not being priced competitively compared to other retailers on Amazon (the current Featured Offer price). You can improve your chances of being the Featured Offer by setting your offer’s total price (price + shipping) so that it matches or is lower than the current Featured Offer price. 

The Sales conversion tab lists. All offers with customer views but no sales in
the last seven days. You may improve sales conversion by considering lowering
your total price (price + shipping) so that it is at or below the suggested
lower price.

The Inactive Offers tab lists all offers currently deactivated because of
potential pricing errors. Amazon detects potential pricing errors based on
several factors including our [ Marketplace Fair Pricing Policy
](/gp/help/external/G5TUVJKZHUVMN77V) , and the Featured Offer price. When
Amazon detects potential pricing errors in your listings, we will notify you,
and in more serious cases, might deactivate the affected listings to avoid a
potentially negative customer experience. Reconsidering your price inputs in
Pricing Health in light of the Reference Prices and in accordance with
Amazon’s Marketplace Fair Pricing Policy may resolve this pricing issue and
reactivate your offer.

**Note:** Reference prices include the Featured Offer (Buy Box) price, price
derived from the per unit Featured Offer price from a smaller sized bundle for
the same product, 60-day average selling price, highest 14-day price (shipped
and sold by Amazon), and/or the product’s list price.

Providing a great customer experience is essential to successful selling on
Amazon.  We reserve Featured Offer placement for seller offers that maintain
our customer experience standards, including price competitiveness.

##  Frequently asked questions

####  I received a message that one or more of my items are not eligible to be
a Featured Offer on the Product Detail page. What does this mean?

We notify you when your offer becomes ineligible to be a Featured Offer on the
Product Detail page.  This happens when your total price (price + shipping) is
above the Competitive Price or your total price (price + shipping) is much
higher than recent prices.

For your offer to be eligible to be a Featured Offer on the Product Detail
page, you need to be priced competitively and meet [ qualifying criteria
](/gp/help/external/200418100) .

####  What is the Competitive Price and how is it determined?

The Competitive Price is the lowest price for this item from other major
retailers. It does not include the prices from other sellers in the Amazon
store.

While we do not reveal the names of competitors, this list is reviewed
regularly to ensure competitors are relevant for each country and product
group.

####  What is the Average Selling Price and how is it determined?

The average selling price of a product is calculated based on the prices that
customers have purchased in the last 60 days weighted by units sold. Prices
and quantity sold during promotions (for example, Best Deals, Lightning Deals)
are excluded.

####  What is the price by Amazon and how is it determined?

The price by Amazon is the highest price listed for the product in the last 14
days that is shipped and sold by Amazon.

####  What is the Per Unit Derived Price and how is it determined?

The per unit derived price is the price per unit of the Featured Offer from a
smaller sized bundle for the same product multiplied by number of units in
your listing.

####  What is the product’s list price and how is it determined?

For more information on list price, go to  [ Amazon Policy on Reference Prices
](/gp/help/external/202170370) .

####  Why do some offers have no applicable Reference prices?

We display the average selling price, price by Amazon, and/or the product’s
list price. For some products, we do not have those reference prices
available.

####  Are all uncompetitive seller offers ineligible to be a Featured Offer on
the Product Detail page?

Yes, Featured Offer qualifications apply to all sellers.

####  How is the Featured Offer percentage calculated?

The Featured Offer percentage is calculated as the total page views in which
you are the Featured Offer divided by the total page views received by
products you list. Only active items are considered. You will see ‘—‘ if we
are unable to calculate your Featured Offer percentage.

####  How is sales conversion rate calculated?

Sales conversion rate is calculated as your total orders (minus returns)
divided by the total page views received on products you list. You will see
‘—‘ if we are unable to calculate your sales conversion rate.

####  What is the recent lower price and how is it determined?

The recent lower price is based on a range of factors including historical
selling prices, recent Featured Offer eligible prices, lowest price for this
item from other major retailers, and input from customers for your products.

####  Do you have any Automate Pricing rules to ensure that my offers remain
competitive?

Yes, you can use [ Automate Pricing ](/automatepricing/home/) to create a
pricing rule to keep your selected offers competitive on an ongoing basis. For
more information, go to [ Compare Prices with External Prices
](/gp/help/external/GTRQ3LS3WA8N9753) .

\-

####  How do I keep my offers competitive if I use third-party repricing
services or MWS APIs?

The Competitive Price, Featured Offer price, and suggested lower price are
published through our MWS APIs. The AnyOfferChanged notification provides this
data through the CompetitivePriceThreshold element, BuyBoxPrice element, and
SuggestedLowerPricePlusShipping element, respectively. Ask your repricer for
more information on how you can stay competitive.

Top

##  Pricing Health

* [ Pricing Health warning and error messages  ](/help/hub/reference/external/GM665AS5HYKFJB8Z)

