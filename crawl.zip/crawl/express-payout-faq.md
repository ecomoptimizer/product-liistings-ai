# Express Payout FAQ

Source: https://sellercentral.amazon.com/gp/help/external/GA24UN79VBPKXZXX

This article applies to selling in: **United States**

#  Express Payout frequently asked questions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGA24UN79VBPKXZXX)

On this page

Express Payout (Bank Account) FAQ

Troubleshooting

Express Payout (Visa Debit Card) FAQ

Troubleshooting

##  Express Payout (Bank Account) FAQ

####  What is Express Payout (Bank Account)?

Express Payout allows eligible US store sellers to receive their payouts from
accrued Seller Central balances to their bank accounts within 24 hours instead
of the current 3 to 5 business days delivery quote. Sellers may also receive
payouts with Visa debit cards.

Express Payout is different than Disburse on Demand, which allows a seller to
request a payout manually by clicking the **Request Payment** button on the [
Payments Dashboard ](/payments/dashboard/index.html) and would disburse funds
within 3 to 5 business days, unless concurrently enrolled in Express Payout.

####  Am I eligible for Express Payout (Bank Account) service?

You must meet the following criteria for Express Payout if you are using a
bank account:  

  1. Have a US bank account that is in network. For in-network banks, go to [ Routing/Transit Numbers ](https://www.theclearinghouse.org/payment-systems/rtp/rtn) . Please check that your bank routing number is found on this list before enrolling in Express Payout. 
  2. Your business must reside in any of the 50 US states. US territories are not eligible for Express Payout (Bank Account). 
  3. Your transaction is $1MM or below at the time of the payment initiation. Partial payouts are not allowed. 

If you meet these criteria, then you can opt-into the Express Payout (Bank
Account) service in [ Deposit Methods
](/sw/AccountInfo/DepositMethodView/step/DepositMethodView) .

####  Once I sign up for Express Payout (Bank Account), which disbursements
are impacted?

Once you’ve enrolled in Express Payout (Bank Account), all payouts for that
specific financial account will be completed through this service, unless you
decide to opt-out or no longer meet all Express Payout (Bank Account)
criteria. This includes both automatically scheduled payments through a
seller’s settlement cycle and any manual payout initiations from the [
Payments Dashboard ](/payments/dashboard/index.html) .

####  Are there any fees for Express Payout (Bank Account)?

There are no fees at this time. You will receive a written notice in advance
regarding any fee changes.

####  Can I make partial payments from the available balance in Seller
Central?

No, you may not make partial payments. Amazon only makes payouts of the entire
balance amount in Seller Central.

####  What happens if my balance exceeds the Express Payout (Bank Account) per
transaction limit?

For bank account payouts, if the entire balance exceeds the $1MM limit for
Express Payout set by Amazon’s financial services partners, then Amazon must
use Standard Payout, which is 3 to 5 business days for that transaction.

####  How do I deactivate Express Payout?

You can deactivate the Express Payout (Bank Account) service at any time by
choosing the Standard Payout option in [ Deposit Methods
](/sw/AccountInfo/DepositMethodView/step/DepositMethodView) . Also, if you [
assign another bank account
](/sw/AccountInfo/DepositMethod/step/DepositMethod?&contextMarketplaceID=ATVPDKIKX0DER&addDepositMethod=false)
to your US profile as the default deposit method, it will have the Standard
Payout setting unless previously enrolled in Express Payout.

##  Troubleshooting

####  Why didn’t I get my Express Payout (Bank Account) funds within 24 hours?

Delays may occur due to the following:

  * Amazon systems or bank partners encountered a problem with Express Payout and returned the money to your Seller Central balance. 
  * Amazon’s financial services partners or networks experienced service issues. Amazon determined that the fastest way to send your payment was through Standard Payout. 
  * Amazon’s systems encountered suspicious activity, and Amazon is working to resolve the matter. 
  * The payout initiated during scheduled maintenance times on Sundays between 12 and 6 a.m. EST. In this case, Amazon will hold the payout and initiate it at 6:01 a.m. EST. 

####  What happens if my transaction does not arrive in my bank account within
24 hours, but I chose Express Payout (Bank Account)?

Amazon’s systems will automatically determine the fastest way to complete the
transaction and get the funds to you as soon as possible. We will send the
funds to you via Express Payout unless technical issues prevent us from doing
so. If the transaction is canceled for any reason, the funds will be returned
to you for payout in the next settlement cycle, as determined within your
selling account. Amazon will send an email confirming which payout method was
used for the transaction.

####  Although I signed up for Express Payout (Bank Account), I got my money
through Standard Payout instead. Why?

This could happen in the following scenarios:

  * The payout exceeds the $1MM per transaction limit. 
  * Your business address changed to a location outside of the 50 US states. Sellers living in the US Territories currently are not eligible for Express Payout. 
  * Your default bank account in Seller Central is out-of-network. 

####  What can I do if I need my payment through Express Payout (Bank
Account), but the funds were returned to my Seller Central balance?

You may manually initiate a payout for any available balances in Seller
Central, which can take another 24 hours to be deposited into your Account via
Express Payout. Otherwise, Amazon will initiate your payout automatically on
your next scheduled payout date, which may be up to 14 days later. For more
information, go to [ Payments dashboard ](/payments/dashboard/index.html) .

For more information, go to the [ Express Payout (Bank Account) Policy.
](/gp/help/external/GHRCBB7RE3HSLGHC)

##  Express Payout (Visa Debit Card) FAQ

####  What is Express Payout (Visa Debit Card)?

Express Payout allows eligible US sellers to receive their payouts from their
accrued Seller Central balances to their Visa debit cards within 24 hours
instead of the current 3 to 5 business days delivery quote. Sellers also may
receive payouts to eligible bank accounts.

Express Payout is different than Disburse on Demand, which allows a seller to
request a payout manually by clicking the **Request Payment** button on the [
Payment Dashboard ](/payments/dashboard/index.html) . Under Disburse on Demand
to a Visa debit card, Amazon will payout funds within 24 hours.

####  Am I eligible for Express Payout (Visa Debit Card) service?

You may choose to receive payouts using a US Visa debit card. Most US Visa
debit cards are eligible for Express Payout. To enroll in Express Payout,
complete the registration process via [ Deposit Methods
](/mario/v2/rf/flow/DebitCardCollection/page/AddDebitCard/global/render) on
Seller Central. Amazon will confirm whether your Visa debit card is approved
for use. Visa debit cards have a $50K per payout limit and the following
thresholds:

Table 1. Express Payout (Visa Debit Card) Thresholds  Max 1 Calendar Day  |
Max 7 Calendar Days  |  Max 30 Calendar Days  
---|---|---  
150 payouts, not to exceed $250K  |  250 payouts, not to exceed $600K  |  750
payouts, not to exceed $1,250K  
Resets at 12:00 PM UTC Time Zone daily  |  Resets at 12:00 PM UTC Time Zone on
a rolling seven-day basis  |  Resets at 12:00 PM UTC Time Zone on a rolling
thirty-day basis  
  
####  Once I sign up for Express Payout (Visa Debit Card), which payouts are
impacted?

Once you’ve enrolled in Express Payout (Visa Debit Card), all payouts for that
specific deposit method will be completed through this service, unless you
decide to change your deposit method or if you no longer meet all program
criteria. This includes both automatically scheduled payments through a
seller’s settlement cycle and any manual payment initiations from the [
Payments Dashboard ](/payments/dashboard/index.html) .

Receiving Express Payout (Visa Debit Card) does not mean that you are enrolled
into Express Payout (Bank account). Any individual payouts ineligible for
Express Payout (Visa Debit Card) will be rerouted to your active bank account.
Active bank accounts not enrolled in Express Payout may take the standard 3 to
5 days to receive the fund deposits.

If you have a Visa debit card as your primary deposit method, and you may also
enroll your active bank account into Express Payout. Your current and previous
payouts amounts will determine whether your transaction will be received via
your Visa Debit Card or eligible Express Payout Bank Account. Please see the
table below for clarification.

Table 2. Rerouting Express Payout (Visa Debit Card) Transactions  Payout
Amount  |  Financial Account That Will Receive Funds  |  Time to Deposit  
---|---|---  
$50,000 or less  |  Visa debit card  |  24 hours  
Above $50,000 and up to $1,000,000  |  Bank Account (Express Payout)  |  24
hours  
Above $1,000,000  |  Bank Account (Standard Payout)  |  3 to 5 days  
  
Please refer back to Table 1 above for other payout limits.

####  Are there any fees for Express Payout (Visa Debit Card)?

There are no fees at this time. You will get advanced written notice for any
changes in fees, and you can deactivate the service at any time.

####  Can I make partial payments from my available balance in Seller Central?

No, you may not make partial payments. Amazon only makes payouts of the entire
Seller Central account balance.

####  What happens if my balance exceeds the Express Payout (Visa Debit Card)
per transaction limit?

For Visa debit card payouts, if the entire balance exceeds the $50K limit set
by Visa, Amazon must reroute the payout to your active bank account. In this
case, Amazon will disburse according to whether your active bank account is
enrolled in Express Payout (Bank Account), as explained in Table 2 above. If
your bank account is enrolled in Express Payout, you should receive your
payout within the 24 hours. However, if your bank account is not enrolled in
Express Payout, your funds will be disbursed in accordance to the traditional
ACH processing time of 3 to 5 days.

####  How do I deactivate Express Payout (Visa Debit Card)?

To deactivate Express Payout (Visa Debit Card), you must replace your debit
card with a bank account as their [ default deposit method in Seller Central
](/sw/AccountInfo/DepositMethod/step/DepositMethod?&contextMarketplaceID=ATVPDKIKX0DER&addDepositMethod=false)
. All payouts to Visa debit cards by Amazon must go through Express Payout.

##  Troubleshooting

####  Why didn’t I get my Express Payout (Visa Debit Card) funds within 24
hours?

Delays may occur due to the following:

  * Amazon’s systems or financial services partners encountered a problem with Express Payout and returned the money to your Seller Central balance. 
  * Visa will not accept payout deposits to an expired debit card. To avoid failures, Amazon will reroute your payout from an expired debit card to the active bank account in Seller Central. If the active bank account is not enrolled in Express Payout, the transaction will go through Standard Payout, which may take 3 to 5 business days. 
  * Visa will not accept individual payout deposits over $50K. To avoid failures, Amazon will reroute your payout of over $50K to the active bank account in Seller Central. If the active bank account is not enrolled in Express Payout, or this payout exceeds $1MM, the transaction will go through Standard Payout, which may take 3 to 5 business days. 
  * Amazon systems encountered suspicious activity and is working to resolve the matter. 
  * Visa will not accept payout deposits that exceed the Visa Debit card daily, weekly, and monthly dollar payout limits listed in Table 1 above. Amazon will return these funds to your available balance. 

####  What happens if my transaction does not arrive to Visa Debit Card within
24 hours, but I chose Express Payout (Visa Debit Card)?

Amazon’s systems will automatically determine the fastest way to complete the
transaction and get the funds to you as soon as possible. We will send the
funds to you via Express Payout unless technical issues prevent us from doing
so. If the payout is canceled for any reason, the funds will be returned to
you for payment in the next settlement cycle, as determined within your
selling account. Amazon will send an email confirming which payout method was
used for the transaction.

####  Although I signed up for Express Payout (Visa Debit Card), I got my
money through Standard Payout instead. Why?

This could happen in the following scenarios:

  * Visa will not accept payout deposits to an expired debit card. To avoid failures, Amazon will reroute your payout from an expired debit card to the active bank account in Seller Central. If the active bank account is not enrolled in Express Payout, the transaction will go through Standard Payout, which may take 3 to 5 business days. 
  * Visa will not accept individual payout deposits over $50K. To avoid failures, Amazon will reroute your payout over $50K to the active bank account in Seller Central. If the active bank account is not enrolled in Express Payout, or this payout exceeds $1MM, the transaction will go through Standard Payout, which may take 3 to 5 business days. 

In both cases above, if the active bank account is not enrolled in Express
Payout, the transaction will go through Standard Payout.

####  What can I do if I need my payment through Express Payout (Visa Debit
Card), but the funds were returned to my Seller Central balance?

You may manually initiate a payout for any available balances in Seller
Central, which can take another 24 hours to be deposited into your Account via
Express Payout. Otherwise, Amazon will initiate your payout automatically on
your next scheduled payout date, which may be up to 14 days later. For more
information, go to [ Payments dashboard ](/payments/dashboard/index.html) .

For more information, go to the [ Express Payout (Visa Debit Card) policy
](/gp/help/external/GHRCBB7RE3HSLGHC) .

Top

