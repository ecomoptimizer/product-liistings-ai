# How to add your Product ID (UPC, EAN, JAN, and ISBN) when listing products

source: https://sellercentral.amazon.com/help/hub/reference/G202009940

> Most product categories require you to provide a GTIN (Global Trade Item Number), also called a Product ID, to create new product listings and offers on Amazon.

---
Most product categories require you to provide a GTIN (Global Trade Item Number), also called a Product ID, to create new product listings and offers on Amazon.

If you don't provide a Product ID, such as a UPC, EAN, JAN, or ISBN, when creating a new product listing, you will receive an error message. If you don't have a Product ID for your product, see [How to list products that do not have a Product ID (UPC, EAN, JAN, or ISBN)](https://sellercentral.amazon.com/gp/help/200426310).

The Product ID field is required whether you are using the Add a Product tool, Add Product via Upload, or XML feeds. More details below.

## Add a Product

The [Add a Product](https://sellercentral.amazon.com/productsearch) tool will allow you to create new product detail pages and offerings one at a time. If you search for a product in the tool and find it in our catalog, the Product ID will be automatically entered for you and you can continue to create your offer. If you create a new product listing, you can enter the Product ID on the **Add a Product** page after completing the product classification.

## Add Products via Upload

**Individual sellers:** This feature is only available to sellers with a Professional selling plan. Learn more by visiting [Selling plan comparison](https://sellercentral.amazon.com/gp/help/64491).

The **Add Products via Upload** tool allows you to use a pre-formatted spreadsheet to enter data for multiple products and then upload the completed file to Amazon. We will either match your data to existing products in our catalog or create a new product page if no match is found.

When preparing an [inventory file template](https://sellercentral.amazon.com/gp/help/1641), enter data into both of these fields:

-   **product-id:** The product's unique identifier, which is the actual UPC (12-digit number), EAN, JAN, or ISBN (all 13-digit numbers).
-   **product-id-type:** The type of unique identifier entered in the product-id field, either UPC, EAN, JAN, or ISBN.
    
    **Note:** These fields may have slightly different names depending on the template you use. For example, your template might have a field for **standard-product-id** or **StandardProductID** instead of **product-id**.
    

## XML feeds

**Individual sellers:** This feature is only available to sellers with a Professional selling plan. Learn more by visiting [Selling plan comparison](https://sellercentral.amazon.com/gp/help/64491).

If you use [XML feeds](https://sellercentral.amazon.com/gp/help/221), provide the UPC in the **StandardProductID** element. For example:

> ```
> <StandardProductID>
> <Type>UPC</Type>
> <Value>009309013872</Value>
> </StandardProductID>
> ```
