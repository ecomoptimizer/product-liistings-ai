# Categorization of Fine vs.  Fashion

Source: https://sellercentral.amazon.com/gp/help/external/G201450260

This article applies to selling in: **United States**

#  Categorization of Fine vs. Fashion Jewelry

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201450260)

On this page

1.0 Fine Jewelry

2.0 Fashion Jewelry

3.0 Helpful Links

Jewelry listed on Amazon can be classified as either a "fine" or "fashion"
jewelry item depending on the jewelry materials. Follow these guidelines to
determine whether your product is considered "fine" or "fashion". Incorrectly
listing and/or misrepresenting fashion jewelry materials as fine jewelry or
fine jewelry materials as fashion jewelry may result in suspension or removal
of your selling privileges.

If any part of your jewelry item includes a fine jewelry material – that is,
if it includes a cultured or natural pearl, a diamond, or a fine gemstone
listed in section 1.2 or 1.3; or if the metal is composed of a fine metal
material listed in section 1.1 – then the item is considered a fine jewelry
item.

Amazon uses a variety of criteria to determine site placement to provide a
better browse experience for our customers.  For more information on product
placement, go to [ Jewelry Help Page ](/gp/help/external/200332590) .

##  1.0 Fine Jewelry

Fine jewelry is made of precious metal and/or set with precious or semi-
precious gemstones and/or cultured or natural pearls:

1.1 Fine jewelry metals are precious metals in the gold and platinum families.
Amazon classifies an item as "Fine Jewelry" if it has one or more components
made with one of these precious metals, or an underlying precious metal
covered with another precious metal (including vermeil). More specifically,
fine jewelry metal compositions include gold, vermeil, and platinum family
metals. Fine jewelry also includes jewelry made with an underlying precious
metal, with the addition of silver, and plated with a precious metal.

More specifically, fine jewelry metals include bonded-gold-and-silver, gold,
gold-plated-silver, palladium, platinum, platinum-and-sterling-silver,
platinum-and-white-gold, platinum-and-yellow-gold, platinum-flashed-silver,
platinum-plated-gold, platinum-plated-silver, rhodium-plated-gold, rhodium-
plated-gold-and-silver, rhodium-plated-white-gold, rhodium-plated-yellow-gold,
rose-and-white-gold, rose-and-yellow-gold, rose-gold, rose-gold-and-sterling-
silver, rose-gold-flashed-silver, tri-color-gold, two-tone-silver-and-gold-
plated, vermeil, white-and-yellow-gold, white-gold, white-gold-and-sterling-
silver, white-gold-plated-silver, yellow-gold, yellow-gold-and-sterling-
silver, yellow-gold-flashed-silver, and yellow-gold-plated-silver.

1.2 Fine jewelry gems include faceted, smooth, or rough stones or beads of the
following:

Fine jewelry gems include alexandrite, almandite-garnet, amethyst, ametrine,
ammolite, andalusite, andradite-garnet, apatite, aquamarine, beryl, black-
diamond, black-opal, blue-diamond, blue-opal, blue-sapphire, blue-topaz, blue-
zircon, boulder-opal, brown-diamond, champagne-diamond, chrome-diopside,
chrome-tourmaline, chrysoberyl, chrysocolla, chrysoprase, citrine, corundum,
demantoid-garnet, diamond, emerald, ethiopian-opal, fire-opal, garnet, golden-
topaz, green-garnet, green-quartz, green-sapphire, green-tourmaline,
grossular-garnet, heliodor, hessonite, hiddenite, imperial-topaz, indicolite,
indicolite-tourmaline, iolite, jade, jadeite, jet, kunzite, kyanite, lab-
grown-diamond, labradorite, lapis-lazuli, lemon-quartz, london-blue-topaz,
madeira-citrine, malachite, mandarin-garnet, medusa-quartz, mint-tourmaline,
moldavite, moonstone, morganite, nephrite-jade, opal, ouro-verde-quartz,
padparadscha, paraiba-tourmaline, peridot, peruvian-opal, pink-amethyst, pink-
diamond, pink-quartz, pink-sapphire, pink-topaz, pink-tourmaline, prasiolite-
quartz, pyrope-garnet, quartz, red-diamond, rhodolite-garnet, rose-quartz,
rubellite-tourmaline, ruby, rutilated-quartz, sapphire, smoky-quartz,
spessartite-garnet, sphene, spinel, star-ruby, star-sapphire, swiss-blue-
topaz, tanzanite, tiger-eye, topaz, tourmaline, tsavorite, turquoise,
watermelon-tourmaline, white-diamond, white-sapphire, white-topaz, yellow-
diamond, yellow-sapphire, yellow-topaz, zircon-gemstone, and zoisite.

1.3 Fine jewelry pearls include the following types of natural and cultured
pearls:

Fine jewelry pearls include akoya-cultured, biwa-cultured, chinese-freshwater-
cultured, freshwater-cultured, hybrid-cultured, keshi-cultured, mabe-cultured,
natural-pearl, south-sea-baroque-cultured, south-sea-cultured, and tahitian-
cultured.

##  2.0 Fashion Jewelry

Fashion jewelry is not made of precious metals (except precious metal plating
over non-precious/base metal) and does not contain any of the precious or
semi-precious gemstones, pearls, or other materials listed above in Section
1.0, Fine Jewelry.

2.1 Fashion jewelry metals include base metals, such as brass, cobalt, copper,
iron pyrite, stainless steel, titanium, and tungsten. Fashion jewelry also
includes jewelry made with an underlying base metal and plated with a precious
metal.

More specifically, fashion jewelry metals include alloy, argentium-plated-
base, argentium-plated-brass, argentium-plated-bronze, argentium-plated-
silver, argentium-plated-stainless-steel, argentium-plated-titanium,
argentium-silver, base, black-rhodium-plated-silver, brass, bronze, cobalt,
copper, gold-filled-base, gold-plated-base, gold-plated-brass, gold-plated-
bronze, gold-plated-copper, gold-plated-stainless-steel, gold-plated-titanium,
nickel, pewter, platinum-and-gold-plated-base, platinum-plated-base, platinum-
plated-brass, platinum-plated-bronze, platinum-plated-stainless-steel,
platinum-plated-titanium, rhodium-flashed-silver, rhodium-plated-base-metal,
rhodium-plated-brass, rhodium-plated-bronze, rhodium-plated-silver, rhodium-
plated-stainless-steel, rhodium-plated-titanium, rose-gold-plated-base, rose-
gold-plated-brass, rose-gold-plated-bronze, rose-gold-plated-stainless-steel,
rose-gold-plated-titanium, silver-and-gold-plated-base, silver-plated-base,
silver-plated-brass, silver-plated-bronze, silver-plated-stainless-steel,
silver-plated-titanium, stainless-steel, sterling-silver, tantalum, titanium,
titanium-and-stainless-steel, tungsten, yellow-gold-plated-base, yellow-gold-
plated-brass, yellow-gold-plated-bronze, yellow-gold-plated-stainless-steel,
and yellow-gold-plated-titanium.

2.2 Fashion jewelry gems include agate, amazonite, amber, amblygonite,
aventurine, azurite, bloodstone, blue-agate, blue-amber, blue-chalcedony,
botswana-agate, brazilianite , butterscotch-amber, calcite,caribbean-amber,
carnelian, celestite, chalcedony,c haroite, cherry-amber, cinnabar,
compressed-turquoise, copper-sunstone, cream-amber, created-alexandrite,
created-amethyst, created-aquamarine, created-blue-sapphire, created-citrine,
created-emerald, created-garnet, created-opal, created-padparadscha, created-
peridot, created-pink-sapphire, created-quartz, created-ruby, created-
sapphire, created-spinel, created-topaz, created-turquoise, created-white-
sapphire, created-yellow-sapphire, cubic-zirconia, danburite, diaspore,
diopside, drusy-quartz, dumortierite, dyed-howlite, epidote, fluorite,
fuchsite, gaspeite, goshenite, green-amber, green-chalcedony, gypsum, hauyne,
hematite, hickoryite, honey-amber, howlite, iron-pyrite, jasper, larimar,
lavender-chalcedony, lemon-amber, magnesite, marcasite, moissanite, multi-
color-amber, mystic-topaz, obsidian, onyx, orange-agate, orange-chalcedony,
petalite, pezzottaite, pink-chalcedony, prehnite, quartzite, red-agate,
rhodochrosite, rhodonite, rose-de-france, sardonyx, scapolite, sea-blue-
chalcedony, selenite, serpentine, sodalite, spectrolite, sphalerite,
stabilized-turquoise, strontium-titanate, sunstone-feldspar, swedish-slag,
tashmarine-diopside, triplet-opal, white-agate, yellow-amber, yellow-
scapolite, yttrium-aluminium-garnet, and zandrite.

2.3 Fashion jewelry pearls include composite-shell-pearls and imitation-
pearls.

2.4 Other fashion jewelry materials include bamboo, bone, ceramic, coral,
crystal, enamel, epoxy, fabric, feather, glass, horn, leather, plastic, resin,
rhinestone, rubber, shell, and wood.

If you need further assistance with jewelry categories, contact Seller
Support.

##  3.0 Helpful Links

3.1 [ FTC Jewelry Guidelines
](https://www.ecfr.gov/current/title-16/chapter-I/subchapter-B/part-23)

3.2 [ Amazon Jewelry Quality Assurance Standards
](/gp/help/external/201269180)

Top

