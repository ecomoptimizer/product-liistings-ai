# Amazon Vine

Source: https://sellercentral.amazon.com/gp/help/external/G92T8UV339NZ98TN

This article applies to selling in: **United States**

#  Amazon Vine

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG92T8UV339NZ98TN)

Amazon Vine invites the most trusted reviewers on Amazon to post opinions
about new products to help their fellow customers make informed purchase
decisions.  Amazon invites buyers to become Vine reviewers, also known as Vine
Voices, based on the insightfulness of the reviews they published on their
Amazon buys. If you participate, you can provide free units of your products
for this selected group of Vine Voices to post customer reviews for the
products you submit. You can build awareness of your product, boosts the sales
of your slow and cold start ASINs, and helps customers make informed decisions
about new products you offer by participating in Vine.

Here are some prerequisites to participate in Vine:

  * You must be a Professional Selling Partner. 
  * You must have registered a brand in [ Amazon Brand Registry ](https://brandservices.amazon.com/)
  * You must be identified as a brand owner. 
  * You must have eligible FBA offers 

Go to [ Brand Benefit Eligibility ](/brands/brand-
relationships?ref=brnd_vine_bssi_help) to identify as brand owner and gain
access to Vine and your other brand-exclusive benefits.  Once your enrollment
is complete, Vine Voices will have the opportunity to request your enrolled
products to review.  You will be charged $200 enrollment fee once per parent
ASIN after the first Vine review is published.  You will not be charged a fee
if the enrolled product does not receive any reviews within 90 days of
enrollment.

We monitor the active participation of Vine Voices and their contribution to
the program. Only the best reviewers will remain in Vine.

In order to be eligible, the items you enroll must meet the following
criteria:

  * Be brand registered in Amazon Brand Registry 
  * Have fewer than 30 reviews on the product detail page 
  * Have a buyable FBA offer in "New" condition 
  * Not be an adult product 
  * Have already launched at the time of enrollment 
  * Have available inventory 
  * Have an image and a description 

In addition to our [ general restrictions ](/gp/help/external/G200164330) ,
products are excluded from Vine for the following scenarios:

  * The products require to bundle multiple products for delivery or review. 
  * The products require the reviewers to separately order another product in order to conduct a review. 

**Note:** Accessories for widely-owned products are permitted such as, cases
for popular mobile phones can be enrolled, but you must not enroll an ink
cartridge that requires a specific printer or a replacement battery that only
works in a particular camera.

  * The products do not correspond to the exact product listed on the FBA offer. 

Top

##  Amazon Vine

* [ Enroll a product in Vine  ](/help/hub/reference/external/GSTY2Q2TD5E84RXJ)
* [ Manage your Vine products  ](/help/hub/reference/external/GFPUL8XZS2XJLJFL)
* [ Track your Vine reviews  ](/help/hub/reference/external/GQGXHUH63WG79ELA)
* [ Vine errors  ](/help/hub/reference/external/GFW53X4JYHRCU9YH)
* [ Vine frequently asked questions  ](/help/hub/reference/external/GX3CEV63Y4ZZAP37)
* [ Vine Selling Partner eligibility  ](/help/hub/reference/external/GMWK4XNWMHTTUQSD)
* [ Vine enrollment fee for sellers  ](/help/hub/reference/external/G4GZ9J4UZ35VEH6G)

