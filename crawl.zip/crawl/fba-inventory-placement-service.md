# FBA  Inventory Placement Service

Source: https://sellercentral.amazon.com/gp/help/external/G200735910

This article applies to selling in: **United States**

#  FBA Inventory Placement Service

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200735910)

On this page

Inventory placement settings

Inventory placement exceptions

Inventory Placement Service fees

By default, when you create a shipping plan, your shipment may be divided into
multiple shipments, each directed to a different receive center or fulfillment
center (referred to as distributed inventory placement). The fulfillment
centers are selected based on the products you're shipping and where you are
shipping from. By having your inventory spread across multiple fulfillment
centers across the country, customers who buy your product may receive it
faster than they would if your inventory was located farther away.

To better spread your products, Amazon may route your shipment through a
receive center, which receives units and then reships them to other
fulfillment centers in our network. Your products are available for sale as
soon as we successfully receive them at any of our receive centers or
fulfillment centers. Units that are being reshipped to other fulfillment
centers are available for customers to buy, but customers may be shown a
future ship date if no other units are available for immediate fulfillment.

You can sign up for the Inventory Placement Service and send all of your
eligible inventory to a single receive center or fulfillment center (see the
**Inventory placement exceptions** section below). When the shipment arrives,
it is split up and sent to different fulfillment centers for you. A per-item
service fee applies.

When you use the Inventory Placement Service, the destination receive center
or fulfillment center is determined by Amazon. You cannot choose the receive
center or fulfillment center to which you send your shipment. The destination
chosen by Amazon may vary from shipment to shipment.

##  Inventory placement settings

To change your inventory placement settings:  

  1. Under **Settings** , select [ Fulfillment by Amazon ](/gp/ssof/configuration/index.html) . 
  2. Under **Inbound Settings** , click **Edit** . 
  3. Under **Inventory Placement Option** , select **Inventory Placement Service** . 
  4. Click **Update** . 

**Tip:** Any in-progress shipments are not affected when you change your
inventory placement option. The new setting applies only to shipments created
after you update your settings. In order to apply this change to your current
shipment, delete the shipping plan and then re-create it after you change your
settings. To quickly re-create your shipping plan, in the **Shipping Queue** ,
select **Deleted/canceled** , and then click the shipping plan that you want.
On the **Send/Replenish Inventory** page, at the bottom left, click
**Duplicate** .

##  Inventory placement exceptions

If you sign up for the Inventory Placement Service, most of your standard-size
items will be directed to a single receive center or fulfillment center.
However, items in the following categories may be directed to a different
receive center or fulfillment center even if you use the Inventory Placement
Service:

  * Apparel 
  * Jewelry 
  * Shoes 
  * Media 
  * Inventory tracked with a manufacturer barcode 
  * Oversize items 
  * Amazon prep required 
  * Amazon labeling required 
  * Hazardous materials 

**Tip:** When you add products to a shipment one at a time from your inventory
list, the destination fulfillment center is re-evaluated every time. For best
results, choose all of the items that you want to include in a shipment at the
same time from the **Manage Inventory** page, and then select **Send/replenish
inventory** from the **Actions on** menu.

##  Inventory Placement Service fees

Standard size (per item)  
---  
1 lb or less  |  $0.30  
1-2 lb  |  $0.40  
Over 2 lb  |  $0.40 + $0.10/lb above the first 2 lb  
Oversize (per item)  
---  
5 lb or less  |  $1.30  
Over 5 lb  |  $1.30 + $0.20/lb above the first 5 lb  
  
**Note:** The weight used to calculate the per-item fee is the dimensional
weight or unit weight (whichever is greater) for large standard-size non-media
items weighing more than 1 lb and for all small, medium, and large oversize
units. The unit weight is the weight of an individual item. The dimensional
weight is the volume (based on length x width x height in inches) divided by
139. Amazon may verify the weight and dimensions of a product using
representative samples. Amazon’s information about a product’s weight and
dimensions will be used to calculate fees if there is a difference between
Amazon’s information and a seller’s information. Amazon may change its
information about a product’s weight and dimensions from time to time to
reflect updated measurements. Fees based on the weight and dimensions of a
product are calculated using Amazon’s information about the weight and
dimensions of that product at the time the fee is calculated.

Your participation in this service is subject to the [ FBA Inventory Placement
Service Terms and Conditions ](/gp/help/external/200943420) .

Top

