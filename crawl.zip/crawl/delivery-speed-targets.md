# delivery speed targets

Source: https://sellercentral.amazon.com/gp/help/external/GM2KN7HAZM4WHA6L

This article applies to selling in: **United States**

#  Delivery Speed metrics

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGM2KN7HAZM4WHA6L)

On this page

Delivery speed targets are outlined below:

Delivery Speed (standard-size)

Delivery Speed (oversize)

Performance metrics

Download Speed Report

Delivery speed metrics are defined as the number calendar days between when a
customer views an offer on the product detail page and the Promised Delivery
Date provided on the product detail page.  The metrics are reported as a
distribution of delivery promises weighted by the product detail page views.
The metrics measure the percentage of the product detail page views that
displayed a 1 or 2-day delivery promise for both standard-size and oversize
products.

To provide insights on metrics that improve the customer experience, we
recommend you review the delivery speed targets below for each type of product
across all of your Seller Fulfilled Prime offers:

**Note:** Delivery Speed targets are different for standard size and oversize
products.

Performance metrics are communicated as less than or equal to using (<=) and
greater than or equal to using (>=) for one or two day delivery promises.

Less than or equal to (<=) One-Day product detail page view percentage is the
percentage of your products’ detail page views with a delivery speed of one
calendar day or less. Less than or equal to (<=) 2-Day product detail page
view percentage is the percentage of your products’ detail page views with a
delivery speed of two calendar days or less. The number of product detail page
views with a less than or equal to One-Day or Two-Day divided by the total
number of product detail page views is used to calculate the percentages of
each metric shown on the [ Seller Fulfilled Prime Performance ](/seller-
fulfilled-prime/seller-performance) page.

##  Delivery speed targets are outlined below:

**Note:** Any changes to delivery speed targets will be communicated with at
least 45 days' notice.

For standard-size products:

  * <= One-Day product detail page view percentage is 20% 
  * <= Two-Day product detail page view percentage is 55% (includes <= One-Day) 

For oversize products:

  * <= One-Day product detail page view percentage is 5% 
  * <= Two-Day product detail page view percentage is 30% (includes <= One-Day) 

##  Delivery Speed (standard-size)

Standard-size is defined as any item that, when fully packaged, weighs 20lb or
less and does not exceed 18 x 14 x 8 inches in item packaging dimensions. Any
item exceeding these dimensions is considered oversize. For more information
on product size, go to [ SFP Item Size, Weights and Dimensions
](/gp/help/external/G8Z8W3UU58Q9KDT7) .

##  Delivery Speed (oversize)

Oversize products are defined as products weighing over 20lb, or having
dimensions exceeding 18 x 14 x 8 inches in item packaging dimensions.

**Note:** If you sell only standard-size products, then you only need to look
at metrics with the product detail page view percentage of <= One-Day, <= Two-
Day and >Two-Day delivery promises for standard-size items, similarly if you
only sell oversize products.

If you sell both standard-size and oversize products, then you can find your
actual product detail page view percentage for both selection types and the
targets.

##  Performance metrics

Your [ Seller Fulfilled Prime Performance ](/seller-fulfilled-prime/seller-
performance) page shows the Delivery Speed metrics at the top, followed by
other metrics (On-time Shipment, Buy Shipping usage, Cancellation Rate, and
On-time Delivery) at the bottom. Delivery Speed metrics are categorized under
**Delivery Speed Metrics** and other metrics are categorized under
**Eligibility Metrics** .

You are able to filter the delivery speed metrics for a time period of 7 days,
30 days, 6 months, 1 year, and an option of custom ranges.

##  Download Speed Report

The **Download Speed Report** link generates a report that shows an ASIN that
has affected your Delivery Speed metrics. Learn more about the [ speed report
](/gp/help/external/G4EPNZYYU6ELW96U) .

**How to improve Delivery Speed metrics**

Here are a few things you can do to improve Delivery Speed metrics:

  * Enable or increase Prime coverage of One-Day Delivery. You may do so manually by adding more states to your Prime shipping templates. If you are using Shipping Region Automation to set your Prime regions, you may improve coverage by adding additional shipping services and/or updating the delivery zone limit of the shipping services. Learn more about [ Shipping Region Automation ](/gp/help/external/G237WEY9JD2VQQZQ) . 
  * Set your order cut-off time to a later time in the day and adjust your pick up time accordingly based on your local carrier’s pick-up schedule. If you are shipping with multiple carriers and have pick-up schedules that vary by day of the week, we encourage you to adjust the order cut-off times for every day of the week for each carrier that you use. 
  * Use shipping services that pick-up and/or deliver to customers over the weekend. [ Learn more ](/gp/help/external/G202096730) on how you can customize your fulfillment settings including order cut-off times, weekend operations, and weekend delivery. 

Top

