# Image with Identical ASIN and Variant Submitted

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Add your favorite pages here by clicking this icon in the navigation menu.

---
Add your favorite pages here by clicking this icon in the navigation menu.

Hide

An image will fail to upload if another newer image was uploaded for the ASIN and variant while your image was still in process of being uploaded to the site.

A newer image takes precedence over older images.

Top

Was this article helpful?
