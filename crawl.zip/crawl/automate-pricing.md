# Automate Pricing

Source: https://sellercentral.amazon.com/gp/help/external/G201994820

This article applies to selling in: **United States**

#  Automate Pricing

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201994820)

Automate Pricing allows you to automatically adjust prices on SKUs in your
catalog in response to events such as the Featured Offer (Buy Box) price,
without having to revisit the SKU every time you want to change your price.

Watch the following videos to learn more about automated pricing:

  * [ Introduction to Automate Pricing ](https://youtu.be/btS45RGqEec)
  * [ Edit a Pricing Rule ](https://youtu.be/QOKZa_i_NpI)

Learn how to use the Automate Pricing feature

You create a pricing rule, set the rule parameters, and then select the SKUs
to which the rule applies. This is because automated pricing is applied only
to the SKUs you designate, not to your entire catalog. You can start and stop
automated pricing rules at any time, as well as change your rules or the SKUs
to which your rules apply. You control the prices by defining rule parameters,
setting minimum price and maximum price (optional) boundaries, and selecting
the SKUs on which to automate pricing.  If you do not set a maximum price,
Automate Pricing will protect customer trust on your behalf by ensuring that
your offers are not priced significantly higher than recent prices so that
your offers remain eligible to become the Featured Offer.

You can manage your SKUs either with the [ Automate Pricing tool
](/automatepricing/home) , or using the Automate Pricing file.

If you set your listings to Inactive, any pricing rules that apply to those
listings are paused until your listings are set to Active again. For more
information on how to set your listings to Active or Inactive, go to [ listing
status for vacations, holidays, and other absences
](/gp/help/external/200135620) .

Amazon Business sellers: Automate Pricing can also be used to automatically
update your business prices based upon changes to your consumer prices. See [
Create a business pricing rule ](/gp/help/external/GD29LN5JBS94EL4L) for more
details.

Top

##  Automate Pricing

* [ My offer is suppressed after using Automate Pricing  ](/help/hub/reference/external/G202129000)
* [ Price not changing: troubleshooting guide  ](/help/hub/reference/external/G202128960)
* [ Create a Pricing Rule  ](/help/hub/reference/external/G201995750)
* [ Add SKUs to a pricing rule  ](/help/hub/reference/external/G201995760)
* [ Create a sales-based pricing rule  ](/help/hub/reference/external/GFRJDFLFPWZSAG67)
* [ Pause, resume, or delete a pricing rule  ](/help/hub/reference/external/G201995770)
* [ Price Update Policy  ](/help/hub/reference/external/G3VA4VWKFMR9R48M)
* [ Move SKUs to a new pricing rule  ](/help/hub/reference/external/G201995780)
* [ Modify a pricing rule  ](/help/hub/reference/external/G201995790)
* [ Review price history for SKUs with automated pricing  ](/help/hub/reference/external/G201995800)
* [ Remove a SKU from a pricing rule  ](/help/hub/reference/external/G201996540)
* [ What happens to my price if ...  ](/help/hub/reference/external/G201996550)
* [ Stop repricing a SKU in a pricing rule  ](/help/hub/reference/external/G202015020)
* [ Frequently Asked Questions about Automate Pricing  ](/help/hub/reference/external/G202015620)
* [ Minimum and Maximum Price Validation  ](/help/hub/reference/external/G202024630)
* [ Manage SKUs using the Automate Pricing file  ](/help/hub/reference/external/G202166010)
* [ External prices  ](/help/hub/reference/external/GTRQ3LS3WA8N9753)
* [ Compare prices off Amazon  ](/help/hub/reference/external/GH9F6MR8T6U62YPE)
* [ How does the Competitive External Price rule work?  ](/help/hub/reference/external/GE85R4NP368X5KKB)
* [ Create a business pricing rule  ](/help/hub/reference/external/GD29LN5JBS94EL4L)
* [ Frequently Asked Questions about business pricing rules  ](/help/hub/reference/external/GEL9SQEG8XPZWDSM)
* [ Manage SKUs in business pricing rules using Regional Automate Pricing file  ](/help/hub/reference/external/GK6MARDVE75B2WXM)
* [ Continue or Pause Repricing After Manual Price update  ](/help/hub/reference/external/GC98RTHZYTBDA2V4)
* [ Pre-defined Automate Pricing Rules  ](/help/hub/reference/external/GT23CNJUTWXGLK7A)
* [ Set minimum and maximum price limits  ](/help/hub/reference/external/G8W6EA4T6SWK55N9)
* [ Create a Business Competitive Featured Offer Rule  ](/help/hub/reference/external/G9YMN8EZTNYE7YJH)

