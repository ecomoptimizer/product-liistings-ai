# How to appeal an A-to-z Guarantee claim

Source: https://sellercentral.amazon.com/gp/help/external/G202041210

This article applies to selling in: **United States**

#  Investigate and appeal an A-to-z Guarantee Claim

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202041210)

You have the opportunity to resolve the issue directly with the buyer.

If a claim is filed, there are four possible outcomes:

  * The buyer withdraws the claim and the claim is closed, with no impact to your account health or ODR. 
  * You can decide to issue a full refund to the buyer by clicking **refund customer** as the investigation is under progress and the claim will be closed. This will be reflected in your [ ODR ](/gp/help/external/G200285170) , therefore, the best scenario is to resolve any issues directly with the buyer within the first 48 hours of it being raised through [ Buyer-Seller Messages ](/gp/help/external/200389080) or [ Return request ](/gp/help/external/G9DH343PLXALFTUW) . If you refund the buyer’s payment, you may choose to request that the buyer returns the item before you process the refund. 
  * Amazon investigates the claim manually and decides as to whether to grant, or not grant, the claim in favor of buyer. Manually investigated claims are resolved based on several factors, including your response (if any) on [ Buyer-Seller Messages ](/gp/help/external/200389080) or [ Return Request ](/gp/help/external/G9DH343PLXALFTUW) with the buyer. During this process, Amazon may ask you for additional information and represent your version of events. Go to [ Respond to an A-to-z Guarantee Claim notification ](/gp/help/external/1781) . It is important for you to provide as much additional, relevant, and compelling information about the transaction or specific actions taken regarding the transaction. If you do not respond to our information request within 48 hours, Amazon may grant the claim in favor of the buyer, which will be reflected in your account health or order defect rate (ODR). 
  * Amazon automatically grants claims and debits claim amount from your account when any of the below criteria are met:   

    1. Order did not have a trackable shipping method and not provided valid order tracking IDs in the **Manage orders** page when order was placed. 
    2. The customer contacted you via [ Buyer-Seller Messages ](/gp/help/external/200389080) for delivery related issue or via [ Return Request ](/gp/help/external/G9DH343PLXALFTUW) for product related issue and has not received a response within 48 hours. 
    3. You have not shipped the order by the expected ship date. 
    4. You have not delivered the order by the estimated delivery date. 

These outcomes would also be reflected in your account health or [ order
defect rate (ODR) ](/gp/help/external/G200285170) .

**Important:** If you appeal a claim decision and a previous determination is
reversed, the claim’s impact to your order defect rate (ODR) will be reversed.
It may take up to five days for ODR reversal to be reflected on the Orders
page.

##  Steps to appeal an A-to-z Gurantee Claim:

Once a claim is granted to the buyer and your account has been debited, you
have 30 calendar days to submit an appeal if you disagree with our decision,
and have new information for our investigation.

To appeal a claim:  

  1. From the **Performance** menu, select [ A-to-z Guarantee Claims ](/gp/guarantee-claims/home.html/) . 
  2. Click the **Option to Appeal** tab, find the relevant Claim, and select **Appeal decision** . 
  3. Enter your comments in the text box and include any new information that may help us better understand the Claim and your position on whether it should be granted. 

**Note:** The text box does not support attachments. If you must attach any
documents, use [ Buyer-Seller Messages
](/messaging/inbox-v2?ct=&fi=RESPONSE_NEEDED&bt=&nt=&pn=1&pd=NONE&sd=&ed=&si=)
to attach documents and send it to the buyer. Additionally state in your
A-to-z Guarantee Claim response that you have attached as additional
information (example POD) in Buyer-Seller Messages.

  4. Select **Submit** . 

If we determine that additional information is required during our
investigation, we will reach out to you through email and you must respond
within 48 hours. For help on how to respond to claim notifications, go to [
Respond to an A-to-z Guarantee Claim ](/gp/help/external/G1781) notification.

**Note:** For information about how to appeal A-to-z claims covering property
damage or personal injury caused by a defective product, go to [ A-to-z Claims
Process for Property Damage and Personal Injury
](/gp/help/external/GTY6NYZDFD5CENYH) .

For more information about claims, go to [ Amazon’s A-to-z Guarantee Claims
](/gp/help/external/GQ6762Y9AB2FYDY8) .

Top

