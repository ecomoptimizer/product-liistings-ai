# Get started with Amazon Global Selling

Source: https://sellercentral.amazon.com/help/hub/reference/external/G201468440

This article applies to selling in: **United States**

#  Get started with Amazon Global Selling

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201468440)

Once you've figured out [ where you want to sell
](https://sell.amazon.com/global-selling/guide.html) and have an understanding
of the taxes and regulations for the marketplaces of your choice, registration
is only a few clicks away. In the following section, we review the process of
creating a Seller Central account in your selected Amazon marketplaces and
creating product offers to start selling.

If you are already selling on any of our Amazon marketplaces, visit the [ sell
globally dashboard ](/global-selling/dashboard/?linkTab=EU) to register and
start selling on another marketplace. If you are new to selling on Amazon,
register your Seller Central account in the country you want to start selling
in using the links below:

Europe  |  Asia-Pacific  |  Middle East and North Africa  |  Americas  
---|---|---|---  
  
  * [ Europe (Germany, United Kingdom, France, Italy, Spain, Netherlands) ](https://sellercentral.amazon.co.uk/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

|

  * [ Japan ](http://www.amazon.com/start-selling-in-japan)
  * [ Australia ](https://sellercentral.amazon.com.au/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Singapore ](https://services.amazon.sg)
  * [ India ](https://services.amazon.in/)

|

  * [ Middle East ](https://sellercentral.amazon.ae/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Turkey ](https://sellercentral.amazon.com.tr/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

|

  * [ North America (United States, Canada, and Mexico) ](https://sellercentral.amazon.com/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)
  * [ Brazil ](https://sellercentral.amazon.com.br/gp/on-board/workflow/Registration/login.html?passthrough%2Faccount=fba_soa&passthrough%2FmarketplaceID=ATVPDKIKX0DER&passthrough%2FsuperSource=OAR&ref_=sdus_gs_guide_rp_h)

  
  
Top

##  Get started with Amazon Global Selling

* [ Setting up your Amazon Global Selling Account  ](/help/hub/reference/external/G201468450)
* [ Registration requirements by marketplace  ](/help/hub/reference/external/G201468460)
* [ Listing Creation for Global Accounts  ](/help/hub/reference/external/G201468480)

