# Amazon Renewed Program Terms

Source: https://sellercentral.amazon.com.au/gp/help/external/G202190320

This article applies to selling in: **Australia**

#  Amazon Renewed – Quality Requirements (Australia)

Sign in to use the tool and get personalised help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202190320)

This document covers the general quality requirements for a product to be
eligible for sale on Amazon Renewed in Australia  . The requirements outlined
below are intended to serve as a minimum required quality bar across all
Renewed product categories. Any category-specific requirements are noted in
Appendix A and will supersede the general product quality requirements. Any
brand-specific requirements are noted in Appendix B and will supersede both
category-specific requirements and general product quality requirements.

**A. General product quality requirements.** All Renewed products must meet
the following requirements:

Permitted products

  * All Renewed products must be capable of being repaired and tested to look and work like new. Repair capability means products must have components that can be replaced or upgraded to work and look like new.  For more details, please see our listing restrictions [ here. ](/gp/help/external/G201648580)

  

  1. Product inspection and testing 
    * Each product must be inspected, repaired (if applicable), cleaned and tested to function and look like new. 
    * Any potential refurbishing operation will only utilise Original Equipment Manufacturer (OEM) parts. Such parts can be new or refurbished to a like-new condition (with the exception of Apple for which no harvested parts can be used – see Appendix B.1). 
    * No signs of cosmetic damage (scratches, dents) should be visible when the product is held 30 centimetres away  unless stated otherwise in Appendix A or B. 
    * Any markings on external surfaces of the product must be intact (such as product logo). No additional markings (for example, supplier logo, engravings) are allowed. 
    * All products must be restored to their original factory settings and be fully unlocked for use. 
    * Where present, batteries must have a capacity that exceeds 80% of the new equivalent. 
    * Where present, displays should have no dead or stuck pixels, and show no signs of dimming. 
    * Where applicable, products must be upgradeable to the latest firmware supported by the OEM (with the exception of Microsoft PCs, which must already be sold with the latest available version of Windows – see Appendix A.2). 
    * Products that have speakers and microphones must be tested to ensure they are fully operational with no humming, cracking or buzzing. 
  2. Accessories 
    * Products must include all accessories that come with a new equivalent  (see Appendix A and B for any exceptions)  . 
    * Accessories may not be sold as standalone ASINs. 
    * Accessories provided must be OEM, either new or refurbished to a like-new condition  (see Appendix A and B for any exceptions).  Consumable accessories (example, air and water filters, brushes, strings.) must be in new condition. 
    * Where present, wall plugs must meet Australian standards. Adapters are not allowed as an alternative. 
    * The inclusion of instruction manuals is encouraged (but not required). In the absence of physical instruction manuals, a link / reference to the manufacturer’s instruction manual can be included. Safety instructions must be included where required by law. 
    * Products that come with a remote control should have a remote control that is already paired with the receiver. Alternatively, the package must contain an instruction manual on how the customer can pair the remote with the receiver and troubleshoot communication issues. 
    * Cables and cords should not have exposed wires or cracked wire insulation. 
  3. Personally Identifiable Information (PII) 
    * Products will be free of any PII before being circulated for sale. Examples of PII include but are not limited to name, date of birth, fingerprints or other biometric data, street address, email address, cloud storage account and credit card information. 
    * Any  PII  must be removed in accordance with the National Institute of Standards and Technology (NIST) Standard on Media Sanitization or other applicable local regulations and standards. Please refer to NIST-SP.800-88.rev.1 for additional information. 
  4. Packaging 
    * Products must be packaged in their original packaging or in a new cardboard box. No product can be mailed in an envelope. 
    * Packaging must be clean and free of any damage, markings and non-product related labels and stickers. 
    * If the original packaging is used, the serial numbers on the box and product must match. In addition, labeling should be applied on at least two sides of the package, explicitly identifying the product as “Renewed”, “Refurbished” (or another applicable derivative). 
    * Products and accessories must be compartmentalised and must not be in direct contact with each other. All OEM accessories must be sealed in a bag. They will be secured and not able to move inside the box during handling and shipping. 
    * Packaging must pass drop-tests based on widely adopted standards like those of the International Safe Transit Association (ISTA). 
    * Products containing lithium ion or lithium metal batteries are classified as Class 9 – Miscellaneous Dangerous Goods. Refer to IATA and ICAO requirements as the product might require proper identification, classification, packaging, marking and labeling. 

**B. Product Sourcing & Distribution. ** As per Amazon’s policy on
international product versions (see [ here
](/gp/help/external/GH582CNKSZAGWGX7) ), all Renewed products must be
authorised for sale in Australia. Selling partners listing products sourced
outside of Australia must seek expert legal advice and make sure the rights
owner does not object to such parallel import.

**C. Warranty.** All products must come with the following terms, to be
honoured by the manufacturer, refurbisher, reseller or third-party provider:

  

  1. Type of Coverage 
    * The warranty covers any product sold under the Amazon Renewed program 
    * The warranty will cover any defects that arise over the period of coverage. 
    * The customer has the right to return a defective product and receive a replacement without incurring shipping or handling fees. 
    * The warranty does not affect the customer's rights under the Australian Consumer Law, including any rights the customer may have in respect of faulty items. 
    * The warranty does not apply to defects caused by insufficient maintenance or improper installation, operation and use by the customer. 
  2. Period of Coverage 
    * The Amazon Renewed warranty period for products sold under the Renewed program is 180 days from the date of sale. The Amazon Renewed warranty does not limit, restrict or modify any consumer right or remedy the customer may have under law, including against the seller or manufacturer under Australian Consumer Law. 
  3. Representations 
    * Warranty information (terms, contact information) must be included in each package. Products must include the Amazon Renewed warranty card template, or an equivalent warranty card. 
    * Products that are sealed and contain adequate warranty terms and information by the manufacturer do not require any further action. 
    * All warranty information and documents must comply with the requirements under the Australian Consumer Law (e.g. contain all mandatory content required by section 90 in the Competition and Consumer Regulations 2010 including details on how to claim the warranty, contact information of the person providing the warranty, warranty period, and the mandatory text). The mandatory text is: 

"Our goods come with guarantees that cannot be excluded under the Australian
Consumer Law. You are entitled to a replacement or refund for a major failure
and compensation for any other reasonably foreseeable loss or damage. You are
also entitled to have the goods repaired or replaced if the goods fail to be
of acceptable quality and the failure does not amount to a major failure."

**D. Quality controls and enforcement**  

  1. Seller Quality Management System (QMS) 
    * The seller will maintain an internal QMS that enables the timely identification and reduction of product quality and operational defects.  While certification is currently not required, adherence to the ISO 9001 policies and guidelines is highly encouraged. 
  2. Performance monitoring 
    * If approved to list an Amazon Renewed, sellers must meet the following performance metrics: 
      * Order Defect Rate < 0.8% 
      * % of Negative Reviews (1 and 2-star reviews) over Renewed orders (NRO) < 1% as a percentage of all Renewed orders 
      * Product Quality Return Rate (PQRR) <8% (returns for product quality reasons as a percentage of all Renewed orders shipped) 
      * Overall Average Product Rating (APR) should be >4% 
    * Amazon Renewed reserves the right to conduct test buys at its own discretion. Products purchased for this purpose will be returned to the seller as per the regular returns process and will not affect any performance metrics. 
    * Failure to comply with  the Australian quality requirements  may lead to the removal of selling privileges on Amazon Renewed, and may require the submission of a "Plan of Action" to remediate and regain said privileges. 
    * At any given point and at its sole discretion, Amazon Renewed reserves the right to remove any selling privileges if it is believed that an optimal customer experience is compromised. 

For any questions and clarifications, contact your Amazon representative or
reach out to us via Selling Partner Support.

##  Appendix A: Requirements by Product Category

  

  1. Wireless 
    * Phones with a built-in, mandatory camera shutter sound are not permitted (e.g. phones originating from Japan or South Korea). 
    * All devices must undergo diagnostic tests with the use of external applications in order to ensure functionality and data sanitisperation. Said devices must be restored to their original factory settings. 
    * All devices must undergo IMEI checks to ensure that they are not blocklisted or stolen. Sellers must maintain IMEI check records for at least 180 days to support periodic inventory and order-level audits. 
    * All wireless products, including accessories, must fully operate in Australia. This includes, but not limited to: wall plugs, charger voltage and frequency, cellular connectivity on all bands (including 4G, LTE and 5G), and the ability to set the product to the English language. 
    * Phones that are branded and/or locked to a specific network are not permitted. 
    * Headphones and SIM cards are not mandatory accessory inclusions. 
    * Any device that requires a SIM card must carry a SIM removal tool (original or generic). 
    * The use of OEM accessories is encouraged (but not required). Any generic accessories must meet Australian standards. 
    * Screen protectors must be used whenever the screen could be in direct contact with any other item in the box. Screen protection should come in the form of device seal wraps that can be removed upon unboxing, not tempered glass / liquid screen protectors that remain attached to the device. 
  2. Personal Computers 
    * All Microsoft laptops, tablets and PCs must come pre-installed with a Windows operating system that is supported by Microsoft. 
    * All Microsoft laptops, tablets and PCs must be equipped with authentic software licenses sourced from a Microsoft Authorised Refurbisher, or must be factory refurbished by an OEM. Sellers must offer either physical or electronic Windows licensing on all Windows (Home or Pro) items. Additionally, all sellers listing devices containing a Windows (Home or Pro) operating system must be able to provide proof of purchase of Windows from a Microsoft Authorised Refurbisher (MAR) upon request, including upon review of any performance related suspension. 
    * The use of OEM accessories (e.g. keyboards and mice) is encouraged (but not required). Any generic accessories must be compatible with regional requirements where the product is sold. 
    * During packaging, it is encouraged (but not required) for monitor screens to be separated from their base and any other attachments. 
    * All laptops, tablets and PCs, operating on Chrome operating system, must come pre-installed with a Chrome operating system that is supported by Google. All Chrome devices must be eligible for Auto Update Support for at least one year from when the product is listed on Amazon Renewed. The list with every model’s Automatic Update Expiration date is available on this page. Sellers must consult the list before listing a Chrome device on Amazon Renewed. 
  3. Vinyl skinning, if used, must be applied without any visual blemishes to the skin (including air bubbles and peeling edges). The skin should not visually appear to be crooked. Vinyl skinning cannot be used to cover up major cosmetic damage, for example, cracks in PC casing). 
  4. Small Kitchen Appliances 
    * Food processing products will only contain material that is safe, non-toxic and compliant for sale in Australia. All surfaces that could be in direct contact with food or liquids must be cleaned and sanitized in accordance with applicable local regulations and standards. 
    * Upon cleaning and before packaging, all products must be thoroughly dried. Products containing liquid tanks (for example, espresso machine boilers, tea kettles) must be drained in full. 
    * No external stains or signs of calcified water or grease should be visible, and no smell should be detected. 
    * Moving parts such as doors, trays and containers must be taped and secured during transit. 
    * Where present, wall plugs must meet Australian standards. Adapters are not allowed as an alternative. 
    * All vents are free of contamination, dust, debris, and any damage. 
    * Labels, serial numbers, and safety indications/signs should remain intact. 
  5. Power tools 
    * Minor cosmetic wear that does not affect the functionality of the product is acceptable. Blades should not be dull, and no rust should be visible on the blades or chainsaw. 
    * Petrol-operated products must be fully drained and wrapped in plastic bags in order to avoid any leaks and contamination within the package. 
  6. Cameras 
    * Camera lens autofocus must be inspected to ensure the feature works properly. 
    * Camera digital card reader must be inspected to ensure it properly stores and retrieves saved pictures. 
    * Wi-Fi or Bluetooth functionality must be inspected to work properly. 
    * Camera lens cover must be secured on to lens when packaged. 
    * All necessary items for the camera to charge and function properly must be included. 
  7. Vacuums 
    * Products can be charged properly (i.e. such that the battery holds the charge), and each nozzle should be operable. 
    * All parts, for example, vacuum brush, brush roller, cylinder, filter should be cleaned properly without visible particles. New filter replacements are recommended. 
  8. Video game consoles 
    * Gaming consoles must be tested for overheating and ensure full functionality of the optical disc drive or cartridge slot, and of all input and output ports (for example: A/C power, video, gaming controller, memory card). 
    * Remote controller buttons, joysticks and connectivity (both wired and wireless) must be fully functional. Remote controllers sold in bundles must be pre-paired with their gaming console. 
  9. Office Products 
    * Moving parts such as doors and print heads must be taped and secured during transit. External paper trays must be disconnected and packed separately. 
    * Printers featuring Wi-Fi must have both their wired and wireless connectivity fully functional. 
    * All ink and laser printers must come with compatible, new printing cartridges. Printing cartridges must be removed from the printer and placed inside a sealed plastic bag to prevent ink or powder from leaking into the box. 
    * Renewed ink and toner cartridges (remanufactured, refurbished, refilled or other derivative) will not be allowed under stand-alone ASINs. 
    * A quick start guide must be included with all Printers and Landline Telephones (including conference call systems as well as VoIP, Landline, PBX, corded and cordless telephones). When a quick start guide is not available, the user manual must be included in paper or digital format. Alternatively, the documentation can be affixed to the side of the box. 

##  Appendix B: Requirements by Brand

  

  1. **Apple**

  * The Renewed store currently supports Apple iPhone models: 8/8 Plus, X, XS/XS Max, XR, 11, 11 Pro/11 Pro Max and SE (2nd Generation), (iPhone 12/12 Mini, and iPhone 12 Pro/ 12 Pro Max, iPhone 13/13mini, and iPhone 13 Pro/Pro Max. 
  * Apple-branded (OEM) charging cables and wall chargers will not be permitted with iPhone products. Only generic accessories that are purchased directly from an approved list of authorized brands will be permitted. The current list of approved accessory brands are: 
    * Mophie 
    * Boxgear 
    * Anker 
    * Sharkk 
    * Amazon Basics 
    * Syncwire 
  * Additional accessory brands will be considered on a case-by-case basis. Please contact your Account Manager or renewed-au@amazon.com.au to learn more. 
  * Sellers are required to maintain records of purchase for accessories. We will monitor compliance through our ongoing test buy operations and performance enforcements. 
  * For non-iPhone Apple products, the use of OEM accessories is encouraged but not mandatory. If generic accessories are used, cables must be MFi (‘Made for iPhone’) certified and chargers must be RCM safety certified. 
  * As part of the restoration to original factory settings, the "Find my iPhone" (or equivalent feature) must be disabled from all devices. 
  * Accessories and parts like chargers, charging cables, headphones, and batteries are not permitted to be sold as standalone products. 
  * The use of harvested or refurbished Apple batteries is not allowed, for any of the Apple product categories. Any potential battery swaps will require the use of new Apple batteries only. 

Top

