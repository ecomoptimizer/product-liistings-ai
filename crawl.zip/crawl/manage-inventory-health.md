# Manage Inventory Health

Source: https://sellercentral.amazon.com/gp/help/external/GTMXYZN64UJL7TT6

This article applies to selling in: **United States**

#  FBA Inventory overview

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGTMXYZN64UJL7TT6)

On this page

Page features

What FBA Inventory can help you do

Frequently asked questions

The FBA Inventory page simplifies FBA inventory management by consolidating
useful information about your inventory into one location. On this page, you
can view data and recommendations for all your products and take actions such
as restocking, reducing excess and aged inventory, and fixing stranded
inventory.

The default page view presents ASIN-level information along with suggested
actions to improve inventory health for items stored in our fulfillment
centers. It also provides access to all inventory-planning actions so you can
save time managing your inventory. Use **Table preferences** to customize this
view to add more detailed metrics across all inventory-planning areas.

The FBA Inventory page can help you optimize your inventory within your
capacity limits, reduce costs, and improve your Inventory Performance Index
(IPI) score.

##  Page features

The [ FBA Inventory page
](/inventoryplanning/manageinventoryhealth?ref_=xx_invplan_dnav_xx) offers
many features to help you make the right decisions about your excess and aged
inventory.

  * **Customize your metrics** : Click **Table preferences** on the right of the page to choose which metrics you want to see for sales, fees, pricing, inventory age, and excess units. You can also view units that are in working, shipped, or receiving status. These metrics can help you make better-informed decisions about your inventory. 
    * **Learn about the metrics** : Hover over the "i" icon for each metric to see the definition and other important information. 
    * **Sort the data** : Metrics that can be sorted in ascending or descending order appear in bold. Click the metric name to sort the column. 
  * **Filter for inventory similarities** : Choose among multiple filters simultaneously to group products with similar inventory characteristics, including inventory age, storage type, and product condition. These filters can make it easier to find similar products, to analyze them, and to carry out the recommended actions. 
  * **Recommended actions** : We suggest specific actions for items with excess inventory. These recommendations are designed to maximize your long-term return on investment.  The recommendations are based on predicted demand for each item, units in stock, days of supply, estimated storage cost, and item eligibility for programs such as Outlet deals or FBA Liquidations. You can view the recommendations and take actions to reduce your excess inventory through value-recovery options.  The key recommended actions are as follows: 
    * **Create a Sponsored Products ad:** This option helps you to create product advertisements that appear in related shopping results and product pages when your product matches what the customer is looking for. 
    * **Create sale:** This option helps you discount the product to make it more attractive for customers and increase your sell-through rate. Click this option to view our recommended sale price and duration. You can also customize the sale price, start date, and end date. 
    * **Create Outlet deal:** This option offers a deeper discount on eligible products and additional opportunities for customers to discover your product on Amazon Outlet. Similar to the Create sale option, click the button to view our recommended sale price and duration. Outlet deals have different requirements than a regular sale, so if you customize the price or duration, the item may no longer qualify for Outlet. However, it will still have a price reduction to help drive sales. 
    * **Create removal order:** Choose this option to remove the inventory from our fulfillment centers.  These items can be returned to you, liquidated, or donated, based on your removal settings  . You can view and edit the recommended removal quantity. 
  * **Actions** : Select an action from the drop-down menu, such as **Create removal order** . 
  * **View up to 250 ASINs per page** : Use the drop-down menu at the bottom of the page to choose the number of products that you want to see on the page. 
  * **Search for related products to evaluate inventory performance** : Use the **Search** feature to find items that have similar product characteristics, for example, "blue" or "12-pack." You can then sort, filter, and take action on these items. 
  * **Bulk action:** Select the check box to the left of each product to include in the bulk action. 
    * **Create a sale in bulk:** Create a sale for up to 250 products at a time by selecting **Create sale** from the bulk-action drop-down menu. Then, select the check box to accept the price that we recommend, or specify a bulk discount percentage or dollar amount for a given date range. To change the price only for SKUs that don’t already have a price preview, select **Apply only to blank SKUs** . 
    * **Create a single or bulk order for removal or liquidation** : Select the check box to the left of each product that you want to remove or liquidate. Then, open the drop-down menu for bulk action and select **Create removal order** above the **Recommendations** column. Your inventory will be entered automatically into the removal or liquidation order workflow. You can remove or liquidate up to 50 products at a time. 

**Note:** Only eligible products can be liquidated. For more information, go
to [ FBA Liquidations ](/gp/help/external/GYVCG5Q3BEJ6MLMF) .

##  What FBA Inventory can help you do

  * **Avoid aged inventory and reduce storage costs** : We recommend maintaining enough inventory to cover 30 to 60 days of your expected sales over the same time period. **FBA sell-through** is a good metric to help you maintain this level of cover. Aim to maintain at least a 2.0+ sell-through on your products. 
  * **Optimize within your capacity limits** : Add the **Storage volume** metric to your page from **Table preferences** , which will allow you to sort by your largest-volume products.  Filter your products by **Storage type** , find the products that have the highest number of excess units, the lowest sell-through rate, or both, and then take action on those products. 

##  Frequently asked questions

####  What units are shown in the Inventory age column view?

The **Inventory age** column includes available plus reserved units minus
units that are pending removal or liquidation.

####  What is the estimated aged inventory surcharge?

Inventory that has been in a fulfillment center for 181 days or more is
subject to the aged inventory surcharge. The fee is assessed on the 15th of
each month. **Inventory age** shows the number of units that would be subject
to the aged inventory surcharge and the estimated fee amount as of the next
charge date, assuming no further sales. For more information, go to [ Aged
inventory surcharge ](/gp/help/external/GJQNPA23YWVA4SBD) .

####  Why are my sales summary amounts and units different from my sales on
the orders detail page?

FBA Inventory shows sales shipped, and the orders detail page shows sales
ordered. FBA Inventory sales and unit data rely on sources that cause a one-
day delay, whereas orders detail data is in real time.

####  Why is my total storage volume by storage type in the Inventory Age
report different from my storage-type usage (aka storage volume) in my
Capacity Monitor?

Storage volume in the Inventory Age report equals the available inventory.
Storage-type usage shown on your Capacity Monitor equals the available
inventory plus unfulfillable and reserved units, minus units that are pending
removal or liquidation.

Top

