# Plan of Action

Source: https://sellercentral.amazon.com/gp/help/external/G201857560

This article applies to selling in: **United States**

#  Submit a Plan of Action for Premium Shipping Options

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201857560)

**Note:** Submitting a Plan of Action only applies to accounts that show a
status of **Restricted** in the **Premium Shipping Eligibility** tool. If your
account shows a status of **Not eligible** , see the [ One-Day
](/gp/help/external/G202166970) and [ Two-Day ](/gp/help/external/201728210)
help pages for more information.

If we have revoked your eligibility to offer Two-Day Shipping, One-Day
Shipping, or Same-Day Delivery and you continue to fail to meet the
Requirements for Two-Day Shipping for the trailing 90 days, we might remove
you from Premium Shipping options. At this stage, we'll ask you to provide us
with a Plan of Action to improve your performance. In such a case, your status
will change to **Restricted** in the **Premium Shipping Eligibility** tool.

If you see that you were restricted in the **Premium Shipping Eligibility**
tool, you can pull detailed performance reports from the [ Customer Metrics
page ](/gp/customer-experience/summary.html) . Send us a Plan of Action that
includes a root cause analysis of the performance issues and a plan to address
these issues within a defined time period. Send your Plan of Action by
responding to the Performance Notification in your Account Health dashboard.

If our team approves your plan of action, we'll restore your eligibility to
offer Premium Shipping options.

Top

