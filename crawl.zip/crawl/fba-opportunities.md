# FBA Opportunities

Source: https://sellercentral.amazon.com/help/hub/reference/external/GLVZKY7AM8CKEBU6

This article applies to selling in: **United States**

#  FBA Opportunities

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGLVZKY7AM8CKEBU6)

On this page

How FBA Opportunities work

Benefits of FBA Opportunities

Limitations of recommendations

How to find more data

When to act on recommendations

How to use FBA Opportunities

Frequently asked questions

[ FBA Opportunities ](/next/fba?) is a tool that analyzes your catalog and
recommends which ASINs to enroll in various Prime programs, such as FBA and [
FBA Small and Light ](/fba/programs/snl/about) .

##  How FBA Opportunities work

[ FBA Opportunities ](/next/fba?) can help you identify which ASINs to enroll
in which FBA programs. The tool uses a machine-learning system to identify
products in your catalog that would benefit from an FBA program. For instance,
an ASIN that is eligible for FBA may also qualify for [ FBA Small and Light
](/next/snl?ref=help) , which offers lower fees.

In addition, FBA Opportunities recommends any promotions that your products
are eligible for.

##  Benefits of FBA Opportunities

The recommendations tool is designed to help guide your selling decisions.
Recommendations can help you find key information about an ASIN, such as the
number of Prime offers or the price of the Featured Offer.

Though we can’t guarantee perfect recommendations 100% of the time, our
machine-learning system is constantly building on existing data to offer
increasingly accurate and comprehensive recommendations.

##  Limitations of recommendations

Though we try our best to constantly improve recommendations, no system is
perfect. If you find errors in your recommendations, please contact [ Selling
Partner Support ](/help/hub/support) . We read every comment and use your
feedback to guide our improvement efforts.

##  How to find more data

Because we can’t access your cost data, recommendations don’t factor in your
costs. Therefore, in response to feedback from sellers like you, we’ve made it
possible to download all the data points for each of your recommendations.
Note that higher costs for certain channels may be offset by an increase in
sales.

##  When to act on recommendations

We recommend that you act on recommendations at the time that they’re listed.
If you wait to act, make sure to go back and check that the ASIN is still
recommended for the respective program.

##  How to use FBA Opportunities

  1. Once signed in to Seller Central, go to [ FBA Opportunities ](/next/fba?) . 

  2. View the opportunity list. 

  3. To download all of the data for your recommendations, click **Download all recommendations** on the top right. 

  4. To enroll ASINs into FBA or FBA Small and Light, choose the appropriate tab, and then select the ASIN. Under the **Action** column, click **Enroll** .  You can also select multiple ASINs and click **Enroll Multiple** at the top right of the recommendation list. 

##  Frequently asked questions

####  How do I use the “Why this ASIN” column?

This column lists the main rationales behind each recommendation. Here’s when
you’d see each of the most common rationales:

  * **Delivery promise:** If the ASIN’s average delivery time is greater than three days, converting it to FBA would ensure faster delivery and a better customer experience. 
  * **Demand:** If the established demand for this product is high enough, converting it to FBA would help you reach more customers. We get this information from glance views, sales velocity, and units sold. 
  * **Offer density:** If there aren’t enough offers for this ASIN, enrolling the ASIN in FBA could help increase sales. 

####  How do I use the “Potential sales lift” column?

The Potential sales lift for a recommendation estimates the incremental sales
you could have gained over 90 days if you had taken this action, on this
product, 90 days ago. It is based on a wide range of factors, including but
not limited to: seasonality, selling price, and existing fulfillment solution.

####  How do I provide feedback on an ASIN?

Click the ellipsis at the end of any row to choose a feedback option.

####  How often do recommendations get updated?

Recommendations are refreshed each week on the FBA Opportunities page. Make
sure to download the data file for each new set of recommendations.

Top

