# Amazon

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Note: Products that are radio frequency devices must have values for the FCC Radio Frequency Emission Compliance Attribute. For more information, including what is considered a radio frequency device, see the Radio Frequency Devices Help page.

---
**Note:** Products that are radio frequency devices must have values for the FCC Radio Frequency Emission Compliance Attribute. For more information, including what is considered a radio frequency device, see the [Radio Frequency Devices](https://sellercentral.amazon.com/gp/help/GHXJGN6T5K8HGGWW) Help page.

You can modify information for products and listings either one at a time using the [Manage Inventory](https://sellercentral.amazon.com/myi/search/DefaultView.amzn) tool in your seller account, or through an inventory file upload that is listed below.

If you are not the only seller contributing information to a product detail page, you might find that some of your requested changes do not appear. For more information, see [There is a mistake on a product detail page. How can I correct it?](https://sellercentral.amazon.com/gp/help/G26571)

## Edit product details one at a time

To edit product details one at a time, do the following:

1.  Go to **Inventory** and select **Manage Inventory**.
2.  Find the listing you want to edit, and select **Edit** from the drop-down menu for that listing.
3.  Select **Advanced** View and navigate to the **Compliance** tab to find the **FCC Radio Frequency Emission Compliance** attribute.
4.  Select one of the following options from the **Radio Frequency Emission & Authorization Status** drop-down menu:
    -   Product not capable of emitting radio frequency energy
        
        **Note:** If you select this option, you do not need to complete the additional fields.
        
    -   Product has an FCC ID
    -   Product has a Supplier's Declaration of Conformity (SDoC) with the FCC Rules
    -   Product is an incidental radiator, as defined by the FCC, that is not designed to intentionally use, generate, or emit radio frequency energy over 9 kHz and not required to obtain an FCC RF equipment authorization
5.  If your product has an FCC ID, enter the ID in the **FCC ID** field.
6.  If your product has a Supplier's Declaration of Conformity (SDoC):
    -   Enter the name of the point of contact for the Responsible Party, as defined by the FCC, in the **SDoC Contact Name** field.
    -   Enter the US mailing address for the Responsible Party in the **SDoC Contact US Mailing Address** field.
    -   Enter the email address for the Responsible Party in the **SDoC Contact Email Address** field. If the email address is not available, you can enter the US phone number for the Responsible Party in the **SDoC Contact US Phone Number** field.
7.  Click **Save and Finish**.

## Update products with an inventory file upload

To change more than one product at a time through an inventory file upload, do the following:

**Note:** Download the most recent version of the Inventory file to view the FCC Radio Frequency Emission Compliance attribute as previous versions of Inventory files will not have this attribute.

The **Custom** option allows you to choose attribute groups associated with the selected products that you can add to your template.

1.  Go to **Inventory**, select [Add Products via Upload](https://sellercentral.amazon.com/listing/download?ref), and click the **Download Inventory File** tab.
2.  Identify the applicable categories and sub-categories from the **Search tool** or the **Product Classifier** that is located in the **Step 1: Select the types of products you want to sell** section.
3.  Click **Select** to add the categories to the Inventory File template.
4.  In the **Step 2: Select the type of template** section, select **Custom Mode**, and select the **Basic** and **Compliance** attributes from the available Attribute Groups options.
5.  Click **Add to Selected Attribute Groups**.
6.  Click **Generate Template**. This will generate an excel spreadsheet.
7.  Open the excel spreadsheet. In the **template** tab, enter the SKUs that need to be updated in the **item\_sku** column.
    
    **Important:** Select **partial\_update** from the drop-down options in the **update\_delete** column.
    
8.  Navigate to the **FCC Radio Frequency Emission Compliance** column in the **Compliance** section.
9.  Select one of the following options from the **Radio Frequency Emission & Authorization Status** drop-down menu:
    -   Product not capable of emitting radio frequency energy
        
        **Note:** If you select this option, you do not need to complete the additional fields.
        
    -   Product has an FCC ID
    -   Product has a Supplier's Declaration of Conformity (SDoC) with the FCC Rules
    -   Product is an incidental radiator, as defined by the FCC, that is not designed to intentionally use, generate, or emit radio frequency energy over 9 kHz and not required to obtain an FCC RF equipment authorization
10.  If your product has an FCC ID, enter the ID in the **FCC ID** field.
11.  If your product has a Supplier's Declaration of Conformity (SDoC):
    -   Enter the name of the point of contact for the Responsible Party, as defined by the FCC, in the **SDoC Contact Name** field.
    -   Enter the US mailing address for the Responsible Party in the **SDoC Contact US Mailing Address** field.
    -   Enter the email address for the Responsible Party in the **SDoC Contact Email Address** field. If the email address is not available, enter the US phone number for the Responsible Party in the **SDoC Contact US Phone Number** field.
12.  After you build your inventory file, save the file either as tab-delimited text (.txt) or excel (.xls) format.
13.  Go to the **Inventory** tab, select [Add Products via Upload](https://sellercentral.amazon.com/listing/download?ref), and click on the **Upload your Inventory File** tab.
14.  Complete the fields in the **Upload File** section and click **Upload**.
15.  Click the **Monitor Upload Status** tab. The date, time, batch ID, status, and results of your most recent upload are displayed here.
16.  Click **Download your Processing Report** to review the Processing Report after each upload. If your processing report shows errors, modify your inventory file and upload the file again.

## About Advanced option

The Advanced option contains all attributes groups associated with the selected products.

1.  Go to the Inventory tab, select [Add Products via Upload](https://sellercentral.amazon.com/listing/download?ref), and click on the **Download Inventory File** tab.
2.  Identify the applicable categories and sub-categories from the **Search tool** or the **Product Classifier** that is located in the **Step 1: Select the types of products you want to sell** section.
3.  Click **Select** to add the categories to the Inventory File template.
4.  In the **Step 2: Select the type of template** section, select **Advanced Mode** and click **Generate Template**. This will generate an excel spreadsheet.
5.  Open the excel spreadsheet. In the **template** tab, enter the SKUs that need to be updated in the **item\_sku** column.
    
    **Important:** Select **partial\_update** from the drop-down options in the **update\_delete** column.
    
6.  Navigate to the **FCC Radio Frequency Emission Compliance** column in the **Compliance** section.
7.  Select one of the following options from the **Radio Frequency Emission & Authorization Status** drop-down menu:
    -   Product not capable of emitting radio frequency energy
    -   Product has an FCC ID
    -   Product has a Supplier's Declaration of Conformity (SDoC) with the FCC Rules
    -   Product is an incidental radiator, as defined by the FCC, that is not designed to intentionally use, generate, or emit radio frequency energy over 9 kHz and not required to obtain an FCC RF equipment authorization
8.  If your product has an FCC ID, enter the ID in the **FCC ID** field.
9.  If your product has a Supplier's Declaration of Conformity (SDoC):
    -   Enter the name of the point of contact for the Responsible Party, as defined by the FCC, in the **SDoC Contact Name** field.
    -   Enter the US mailing address for the Responsible Party in the **SDoC Contact US Mailing Address** field.
    -   Enter the email address for the Responsible Party in the **SDoC Contact Email Address** field. If the email address is not available, enter the US phone number for the Responsible Party in the **SDOC Contact US Phone Number** field.
10.  After you build your inventory file, Save the file either as tab-delimited text (.txt) or excel (.xls) format.
11.  Go to the **Inventory** tab, select [Add Products via Upload](https://sellercentral.amazon.com/listing/download?ref), and click on the **Upload your Inventory File** tab.
12.  Complete the fields in the **Upload File** section and click **Upload**.
13.  Click the **Monitor Upload Status** tab. The date, time, batch ID, status and results of your most recent upload are displayed here.
14.  Click **Download your Processing Report** to review the Processing Report after each upload. If your processing report shows errors, modify your inventory file and upload the file again.

To learn more about adding a new listing, see the [Create and manage inventory](https://sellercentral.amazon.com/gp/help/GFQ8J5JPKERTHQPP) Help page. In addition, you can find more information on creating your listings on [Create listings one at a time](https://sellercentral.amazon.com/gp/help/G39EFY66ZLSJQ7PM) or [Create listings in bulk](https://sellercentral.amazon.com/gp/help/GZ4ZQ4HZQM2R4B2X). The steps for adding the FCC Radio Frequency Emission Compliance attribute are the same on these Help pages as outlined above with additional information.

## Frequently asked questions

#### Where do I find FCC RF compliance information on a product?

An FCC ID is a unique identifier consisting of two elements:

-   A grantee code: The first portion of the FCC ID, is either a three or five character alphanumeric string assigned by the FCC permanently to a company for use in the identification of radio frequency equipment authorized under the FCC certification procedure.
-   An equipment product code: The second portion of the FCC ID that begins after the grantee code. The product code may include hyphens and/or dashes (-).

The FCC ID is often preceded by the phrase “FCC ID,” and may appear on a physical label on the product or an electronic label (e-label). If the product is too small for a physical label and does not use electronic labeling, then the FCC ID may appear in the user manual and either the product packaging or a removable label attached to the product.

Information regarding a Supplier’s Declaration of Conformity (SDoC) may be located on a product or product packaging, or in an included manual or other documentation. SDoC information is often, but not always, proceeded with a heading that refers to “FCC Compliance,” and often refers to part 15 of the FCC Rules.

#### I previously provided an FCC ID to have my product reinstated. Why do I have to do this again?

We are implementing these requirements in order to provide our customers with the best possible experience. FCC IDs may sometimes change, and we need to provide our customers with the most up to date compliance information. Therefore, even if you previously provided this information, it will still need to be added to the listing.

#### What if I do not believe my listed ASIN(s) is a radio frequency device?

If you think your product was incorrectly identified as a radio frequency device, refer to the [Radio Frequency Devices](https://sellercentral.amazon.com/gp/help/GHXJGN6T5K8HGGWW) Help page, and select the option indicating that your product is not capable of emitting radio frequency energy when listing your product.

#### How can I get additional information?

For more information, see Amazon’s [Radio Frequency Devices](https://sellercentral.amazon.com/gp/help/GHXJGN6T5K8HGGWW) policy.
