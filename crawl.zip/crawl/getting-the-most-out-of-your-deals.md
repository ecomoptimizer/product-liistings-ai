# Getting the most out of your Deals

Source: https://sellercentral.amazon.com/help/hub/reference/external/GSY3EMGXT9UCKB4F

This article applies to selling in: **United States**

#  Getting the most out of your Deals

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGSY3EMGXT9UCKB4F)

Lightning Deals and Best Deals are time-bound, promotional offers where a
product is featured on the Amazon Deals page. You can use the **Deals
Dashboard** to submit Lightning Deals and Best Deals for a fee. All the
proposed Lightning Deals and Best Deals require Amazon approval to run on the
Amazon Deals page. For more information, see [ the Deals help pages
](/gp/help/external/202043110) .

As you choose and create your Deals, take into account the following tips that
may improve the success of your Deal:

##  Before creating your Deal

  * Rich product detail pages: The way you present your products in Amazon Stores can influence a customer’s buying decision.  Get the most out of your deals by ensuring your product pages have meaningful information for customers with high quality images. 

See the [ Product Style Guides
](/learn/courses?ref_=selleru_athena_c4_m23&courseId=4&moduleId=23&modLanguage=English&videoPlayer=youtube)
to learn how to create great product detail pages.

  * Enhanced Brand Content: Brand owners can add [ Enhanced Brand Content ](/enhanced-content/) to their listings to enhance the product description section with additional images and text. This feature is only available to sellers who have been approved as brand owners through the [ Amazon Brand Registry process ](https://services.amazon.com/brand-registry.html) . 
  * Surfacing your Deal to the right customers: Make sure that your products are listed in the appropriate category.  The category that the ASIN or parent ASIN is listed in on Amazon will also be the category that the Deal will be shown in on the [ Today’s Deals ](https://www.amazon.com/gp/goldbox/) page.  Having your products listed in the correct category will help ensure that it surfaces to the right customers when filtering by department within **Today’s Deals** . 
  * Seasonality: All products have an optimal time of year to sell to customers. Choose the week that best optimizes the seasonality of your product. 
  * On-Amazon competition: Your Deal might be the best priced product on Amazon, but consider whether the price is competitive to similar products from other brands and sellers. 
  * Off-Amazon prices: The suggested price ensures that your product is the best priced product in Amazon Stores. However, consider whether the Deal price is competitive to prices on websites outside of Amazon. 

##  After creating a Deal

  * Monitor the Status of your Upcoming Deals:  Actively monitor your upcoming Deals from the [ Deals Dashboard ](/merchandising#/dashboard/) in the days leading up to the deal start date to ensure they continue to meet the [ eligibility requirements. ](/gp/help/external/202111490) If any of your scheduled Deals becomes suppressed, you’ll need to make the appropriate updates to the Deal within the **Deals Dashboard** . See [ Troubleshooting Suppressed and Live Deals ](/gp/help/external/GKN9A84DGTYWYHWY) for more information. 
  * Check Upcoming Deals page on Amazon:  Your Deal will be shown in the [ Upcoming section ](https://www.amazon.com/gp/goldbox/ref=gbps_ftr_s-3_0ee9_dlt_LD?gb_f_GB-SUPPLE=sortOrder:BY_SCORE,dealStates:UPCOMING,dealTypes:LIGHTNING_DEAL&pf_rd_p=30c09623-33cf-4469-be4c-3e8293ae0ee9&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=CX7K9Z5FRK9C1358XF1G&ie=UTF8) of **Today’s Deals** 24 hours before your Deal is scheduled to run.  Use this 24 hour window to review your upcoming Deals. Any deal that is suppressed will need to be fixed 25 hours before the scheduled start time or it will not surface in the **Upcoming Deals** section and may be canceled. Below are some helpful tips: 
    * Your upcoming Deals surface in the expected category. Locate your upcoming deals using the Department and Availability filters within **Today’s Deals** to ensure customers are able to see them. 
    * The Deal image is of good quality and accurately represents the product. You can update the deal image from Seller Central if necessary. 
    * The Deal price provides a great discount for customers. You can increase the percentage off by lowering your Deal price and increase your Quantity for Deal allowing more customers purchase from your Deal. 
  * Avoid making changes to ASIN(s): For Deals in Upcoming status, avoid making major changes to the ASIN(s) or parent ASIN participating in the Deal. This includes: 
    * Pricing Edits: If you lower the price on a participating ASIN(s), you may also be required to lower the Deal price for the same ASIN(s) to avoid Deal suppression. 
    * Delete or Close Listings: Do not change the status of any ASIN(s) participating in Deals to Closed within the **Manage Inventory** page. Doing so will cancel any Deal currently scheduled for that ASIN. Canceled Deals cannot be reactivated. 
    * Create new child ASINs: For Deals that include variations, avoid creating or assigning new child ASINs to the variation family after the Deal has been submitted. Doing so will result in the existing Deal to revalidate with the new child ASINs which will cause the Deal to become suppressed or canceled. 

Top

