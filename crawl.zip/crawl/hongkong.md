# Hongkong

Source: https://sellercentral.amazon.com/gp/help/external/GVEGSMPP7CJP2Z2F

This article applies to selling in: **United States**

#  If your business location is Hong Kong

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGVEGSMPP7CJP2Z2F)

**dentity document** : We accept ID documents such as passport and national ID
card.

Make sure your document also meets the following criteria:

  

  1. We do not accept electronic IDs. 
  2. ID holder must be above 18 years of age. 

**Proof of Address document:**

We accept one of the below documents:

  * Business registration ordinance (for both corporations and individual/ business relationship companies). 
  * Certificate of incorporation or certificate of change of name (for corporations companies). 

Make sure your document also meets the following criteria:

  

  1. Must be a Hong Kong-based company or branch office. 
  2. Must be valid for at least 45 days from the date of your submission. 
  3. Must be with information that matches with the information on the Hong Kong company register websites. 
  4. Must be with “normal/live/active” status, without being listed to any abnormal business status. 

For more information, go to [ Frequently asked questions about Global SIV
](/gp/help/external/G2MJXHQCR62DZSSM) .

Top

