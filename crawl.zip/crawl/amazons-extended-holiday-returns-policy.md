# Amazon’s extended holiday returns policy

Source: https://sellercentral.amazon.com/gp/help/external/G201725760

This article applies to selling in: **United States**

#  Extended Holiday Returns policy

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201725760)

We have revised the return window from past years to ensure most early holiday
shoppers’ purchases during the new Prime Early Access Sale will also be
eligible.

The Amazon **Extended Holiday Returns Policy** for 2022 requires that most of
the items purchased between October 11 and December 25, 2022, be eligible for
return through January 31, 2023.

We will automatically authorize returns on your behalf to reflect the Extended
Holiday Returns Policy.

For more information, go to our [ Returns and refunds policy page
](https://www.amazon.com/gp/help/customer/display.html/?nodeId=15015721)

Top

