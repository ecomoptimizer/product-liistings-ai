# Price your item

Source: https://sellercentral.amazon.com/help/hub/reference/external/G62551

This article applies to selling in: **United States**

#  Price your item

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG62551)

You may list items at any price you feel is fair, regardless of the Amazon
price or list price, within the limits set by Amazon, and so long as your
price adheres to the [ Amazon Marketplace Fair Pricing Policy
](/gp/help/external/G5TUVJKZHUVMN77V) and [ Amazon Policy on Reference Prices
](/gp/help/external/G202170370) .

Sellers on the Individual selling plan may not list items at a price in excess
of $10,000. Sellers on the Professional selling plan may not list items at a
price in excess of $300,000.

These price limits do not apply to Collectibles listings. For more information
about Collectibles category requirements, search for "collectibles" in seller
Help.

##  Pricing definitions

The item price is the amount payable by a customer, excluding shipping and
handling, as it appears when you list an item.

The total price is the amount payable by a customer as well as all terms of
offer/sale. This includes all of the following:

  * Shipping and handling charges 
  * Discounts, rebates, or special sales/promotions you offer/make with respect to purchases 
  * Shipping method 
  * Business practices, such as any reduction or elimination of shipping charges on an order, or of any other order-related fees and expenses 
  * Low-price guarantees 

The total price does not include discounts, sales, rebates, or other
promotional offers you attempt to make available through the Amazon Store that
we do not honor or support.

Top

##  Price your item

* [ Automate Pricing  ](/help/hub/reference/external/G201994820)
* [ Match Low Price  ](/help/hub/reference/external/G200836360)
* [ Amazon Policy on Reference Prices  ](/help/hub/reference/external/G202170370)
* [ Amazon Marketplace Fair Pricing Policy  ](/help/hub/reference/external/G5TUVJKZHUVMN77V)
* [ Pricing Health  ](/help/hub/reference/external/GSTH6YN3BR8XNWBW)
* [ Price per unit requirements  ](/help/hub/reference/external/G201618190)

