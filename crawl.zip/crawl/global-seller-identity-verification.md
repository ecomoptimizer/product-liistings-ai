# Global seller identity verification

Source: https://sellercentral.amazon.com/help/hub/reference/external/GQRP483PDN88Q3M9

This article applies to selling in: **United States**

#  Global seller identity verification

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGQRP483PDN88Q3M9)

On this page

If you've already submitted your documents

If you haven't submitted your documents

Document requirements

Verification Requirements

If your business location is China, Hong Kong, Taiwan, Saudi Arabia, the
United Arab Emirates or Egypt

What to expect after you upload your document

Frequently asked questions about Global Seller Identity Verification

To maintain a trusted store for buyers and sellers, we need to verify the
information that you provided during registration. Here you can find
information on the global seller identity verification process and the
documents that you have to provide to create and verify your selling on Amazon
account.

##  If you've already submitted your documents

The review process can take up to two business days from the time we receive
your documents. We will keep you informed via an email to your email address
provided during registration. You also will be able to see a pop-up message on
your Seller Central account.

**Note:** You cannot begin selling on Amazon until the verification of your
identity documents is complete.

##  If you haven't submitted your documents

Before activating your seller account, you must complete the verification
process: Updating the business information, seller information, billing, store
section and submit relevant documentation in the verification section.

  

  1. Sign in to [ Seller Central ](https://sellercentral.amazon.com/) and you will be will be redirected to the **Verification** page. 
  2. You will have to confirm your primary contact person information and upload the required documents. 
    * In the identity data section, upload your identity document per the instructions on this page. 
    * In the proof of address section, upload you proof of address document per the instructions on this page. 

##  Document requirements

We require an identity document and an additional document in order to verify
your identity. The registration page will display your customized options. You
might be asked to submit an additional document based on:

  

  1. The country, state, or region in which your business is located or where you reside. 
  2. The ‘Business type’ you selected, such as privately-owned business, sole proprietor, charity, individual. 

An **identity document** is a government-issued photo identity document that
is used to confirm one’s identity, such as a passport or national ID. This
document must match the proof of identity information selected under
**Identity data** .

An **additional document** is a statement issued by a reputable third party
displaying information on your business or country of residence or address.

Usually, we collect a proof of address document, such as bank statement or
credit card statement. A bank statement is an official document issued by your
bank or other financial institution that summarizes your account activity over
a certain period of time—typically one month.

Alternatively, we require a document that proves that your business is valid,
such as a business license or equivalent business document.

**Important:** We may request additional information after your submission. We
reject documents we cannot verify or when they do not meet our criteria.

In order to ensure your documents are not rejected, make sure that they meet
the following criteria:

**All documents must match the below requirements:**

  * Be valid (not expired, revoked, inactive or closed). 
  * Be high resolution and unobstructed (clear, readable, visible and in focus). 
  * Be complete and not cut off from any sides (not angled or cropped). 
  * Be a scanned image or photo of the original document taken from your mobile device's camera. 
  * Display the full document (front and back, if applicable). 
  * Be less than 50MB in size. 
  * Be in one of these formats: TIF, TIFF, PNG, JPG, PDF, and JPEG. Do not include special characters in the file name (examples: $, &, or #). 
  * Be authentic and unaltered. 
  * Must not be password-protected. 
  * Be in one of these supported languages: Arabic, Simplified Chinese, Dutch, English, French, German, Hindi, Italian, Japanese, Polish, Portuguese, Spanish, Swedish, Tamil, Thai, Turkish, and Vietnamese. If your documents are not in a supported language, you must submit a notarized translation in a supported language along with the original document. 

##  Verification Requirements

**Important:** The issuing country of either of the two requested documents
(Identity document or Proof of Address document) must match with the business
location provided during registration.

**Identity document:** We accept ID documents such as passport, passport card,
national identity card, driving license, enhanced driving license, citizenship
card, permanent residency card, health card, or military identification card.

Make sure that your identity document also meets the following criteria:

  

  1. Must be a government issued photo identity document which is recognized and issued by the country where you are a citizen or resident. 
  2. Must show first and last name. The name must match the name entered under primary contact person information. 
  3. Must include the date of birth. The number entered must be an exact match as we do not accept typos. 

**Note:** ID holder must be above 18 years of age.

  4. Must show the unique ID number. The number entered must be an exact match as we do not accept typos. 
  5. Have an expiry date (If applicable). The number entered must be an exact match as we do not accept typos. 
  6. Have bearer's signature (If applicable) - Certain passports are signed on the initial pages or at the back. 
  7. Must provide both sides of the ID if there is any vital information at the back of the ID like: signature, date of expiry, date of birth, or barcodes. 

**Note:** If the upload page does not ask for separate front and back image
uploads, be sure to merge the images into one file to upload.

  8. Must be a color copy. 

**Proof of Address document:** We accept bank statements (including current
account, saving account, or loan account statement), credit card statements or
account statement provided by an e-commerce payment service provider such as
Payoneer, Hyper wallet, World First, and Alipay.

Make sure your document also meets the following criteria:

  

  1. Must be issued within the last 180 days and show the issuing date, due date or transaction dates. 
  2. Must have the financial institution details to show at least one of the following details: bank name, bank stamp, bank signature or bank logo. 

##  If your business location is China, Hong Kong, Taiwan, Saudi Arabia, the
United Arab Emirates or Egypt

[ China ](/gp/help/external/GSTQGS38CC9867UF)

[ Hongkong ](/gp/help/external/GVEGSMPP7CJP2Z2F)

[ Taiwan ](/gp/help/external/GSB8S8BQF68WHN9W)

[ United Arab Emirates ](/gp/help/external/GM9MYVG9NBJCDFVT)

[ Saudi ](/gp/help/external/GHSP9MFQ33KW5LSX)

[ Egypt ](/gp/help/external/G9GFNKKWR5MVPFXB)

##  What to expect after you upload your document

Once you upload all necessary documents and information, Seller Central will
display a confirmation message. You can close the tab in your browse and
Amazon will review your information and may contact you for further
clarification, if needed, within two business days.

**Important:** If we are unable to verify the information you provided and
request that you resubmit your documents, you will have 30 days to complete
this request. If we do not receive your documents within this timeframe, your
seller onboarding process will be closed and we will not be able to activate
your account to sell on Amazon. For security reasons, we can only accept
documents uploaded through the [ Seller Identity Verification
](https://sellercentral.amazon.com/hz/approvalrequest/registration) page on
Seller Central.

##  Frequently asked questions about Global Seller Identity Verification

For more information on Global Seller Identity Verification, go to [
Frequently asked questions about Global SIV
](/gp/help/external/G2MJXHQCR62DZSSM) .

Top

##  Global seller identity verification

* [ Frequently asked questions about Global SIV  ](/help/hub/reference/external/G2MJXHQCR62DZSSM)
* [ If your business location is China  ](/help/hub/reference/external/GSTQGS38CC9867UF)
* [ If your business location is Hong Kong  ](/help/hub/reference/external/GVEGSMPP7CJP2Z2F)
* [ If your business location is Taiwan  ](/help/hub/reference/external/GSB8S8BQF68WHN9W)
* [ If your business location is the United Arab Emirates  ](/help/hub/reference/external/GM9MYVG9NBJCDFVT)
* [ If your business location is Saudi Arabia  ](/help/hub/reference/external/GHSP9MFQ33KW5LSX)
* [ If your business location is Egypt  ](/help/hub/reference/external/G9GFNKKWR5MVPFXB)

