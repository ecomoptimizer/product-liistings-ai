---
created: 2023-04-06T00:03:20 (UTC -07:00)
tags: []
source: https://sellercentral.amazon.com/help/hub/reference/G202009940
author: 
---

# Amazon

> ## Excerpt
> Bullet points help you to sell features and benefits of your product. They are descriptive
        text about specific aspects of a product, which appear on the detail page. Up to five bullet
        points can be included for each product.

---
## Overview

Bullet points help you to sell features and benefits of your product. They are descriptive text about specific aspects of a product, which appear on the detail page. Up to five bullet points can be included for each product.

![](https://images-na.ssl-images-amazon.com/images/G/01/rainer/help/Bulletpoints._CB1568066692_.png)

#### Good bullets points

Some bullet points are so long that customers have to click a **more** button to see all of them. Some bullet points are stuffed with keywords and are not easy to read. Some bullet points are poorly written.

It is better to keep bullet points clear and concise. A general piece of advice is to keep your bullet points under 1,000 characters in total i.e. for all five bullets, not per bullet. Being less than 1,000 characters improves their readability. And, if bullet points are indexed for your product, being shorter than 1,000 characters improves discoverability of content in the bullet points.

Well-written bullet points will naturally contain keywords, but the first priority should be to communicate clearly and help customers make a buying decision. One approach is to start a bullet point with a feature and then state the benefit(s) of that feature.

For example, '50-minute run-time trims up to 1,200 square feet per charge' states that the feature of a 50-minute run-time delivers the benefit of being able to trim up to 1,200 square feet per charge.

#### Why are my bullet points not discoverable?

Bullet points always appear in full on product detail pages. However, not all content is discoverable because bullet points are not always indexed by the Amazon shopping algorithm.

The Amazon shopping algorithm is constantly evolving. Even if the algorithm does not index all bullet points or changes how it indexes bullet points, there will always be value in making your listings as good as they can be.

**Note:** To ensure a better customer experience, some categories include additional bullet points that are directly pulled from other ASIN attribute data. In the categories ‘shoes’ and ‘clothing’, for example, we will show attributes like material, heel height or sleeve type dependent on the product. It is important that you provide as many details in your listings as possible. These additional bullet points cannot be remove from the detail page, but you edit the value for those attributes in your Seller Central account.
