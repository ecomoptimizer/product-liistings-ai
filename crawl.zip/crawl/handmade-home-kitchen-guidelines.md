# Handmade Home & Kitchen guidelines

Source: https://sellercentral.amazon.com/gp/help/external/GVA9JWUJ37GWA57B

This article applies to selling in: **United States**

#  Handmade Home & Kitchen guidelines

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGVA9JWUJ37GWA57B)

As a Maker, your handmade Home Decor, Furniture, Kitchen & Dining products
must adhere to the following guidelines:

  * All products must adhere to [ Amazon’s general policies and agreements ](/gp/help/external/G521) . 
  * All products must adhere to the [ Category, product, and listing restrictions ](/gp/help/external/G200301050) . 
  * All products must meet the overall [ Amazon Handmade: Category Listing Policies & Requirements ](/gp/help/external/GNGMMFQ5FPLJFBJP) . 
  * We permit use of hand tools and light machinery; machinery should be used by you in your home studio or workspace. 
  * We will allow you to hand alter pre-made items; for example, we will allow you to apply your own designs via these approved processes: screen printing, press printing, or heat transfer. 
  * Custom vinyl and stickers are permitted as long as they are original designs, created by you in your studio. 
  * Unauthorized copies or reproductions of artwork that violate any copyright or trademark are not allowed.  Read more about [ Intellectual Property for Rights Owners ](/gp/help/external/GU5SQCEKADDAQRLZ) . 

Top

