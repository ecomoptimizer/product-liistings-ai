# Drugs and Drug Paraphernalia

Source: https://sellercentral.amazon.com/gp/help/external/200164490

This article applies to selling in: **United States**

#  Drugs and drug paraphernalia

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F200164490)

On this page

Compliance checklist for drugs and drug paraphernalia

Known prohibited products

Age restriction

Additional useful resources

Related Amazon help pages

**Important:** If you supply products for sale on Amazon, you must comply with
all federal, state, and local laws and Amazon policies applicable to those
products and product listings.

This page covers drugs, controlled substances, and drug paraphernalia. A drug
is a substance used to diagnose, cure, treat, or prevent diseases in people or
animals. Drugs can also be used to change the structure or function of the
body, such as to treat some kinds of acne. Some drugs require a prescription
for sale, such as most antibiotics, while other drugs may be sold without a
prescription because they are approved by the FDA to be sold over the counter.

“Controlled substances” are drugs that are illegal, such as cocaine or heroin.
Products used with controlled substances may be considered drug paraphernalia.
Drug paraphernalia includes products primarily intended or designed for use in
making, preparing, or using a controlled substance.

Please use the checklist below to be sure your product can be sold on Amazon.

##  Compliance checklist for drugs and drug paraphernalia

**Packaging**  

  1. Drugs must be sealed in the original manufacturer’s packaging 
  2. Drugs must be new and unused 
  3. Drugs must clearly display identifying codes placed on the packaging by the manufacturer or distributor, such as matrix codes, lot numbers, or serial numbers 

**Labeling**  

  1. Drugs must be labeled in English with the following information:   

    1. The title of the drug 
    2. The “Drug Facts” panel 
    3. The active ingredient(s) 
    4. The purpose(s) of the drug 
    5. The use(s) of the drug 
    6. Any required warning(s) 
    7. The directions for using the drug 
    8. Any other information, as required for the specific product 
    9. The inactive ingredients 
  2. Drug must use the claim “FDA approved” appropriately 
  3. Drug labels must not use the FDA logo 

For more information, see the U.S. Food and Drug Administration’s [ Guidance
on Labeling ](https://www.fda.gov/drugs/drug-information-consumers/otc-drug-
facts-label) and [ Is It Really 'FDA Approved?'
](https://www.fda.gov/forconsumers/consumerupdates/ucm047470.htm)

**Detail page**  

  1. Detail pages must include the following information:   

    1. The name of the drug 
    2. The active ingredients 
    3. An image of the “Drug Facts” panel (and any “Drug Facts (Continued)” panels, if applicable) from the product label 
  2. Detail pages must comply with the approved labeling for the drug 
  3. Drug must use the claim “FDA approved” appropriately 
  4. Drug labels must not use the FDA logo 

**Drug products and ingredients**  

  1. Drug products must be approved by the FDA for over-the-counter (OTC) sale 
  2. Drug products must not require a prescription or a medical professional's supervision or direction for their use, such as:   

    1. Prescription drugs and their active ingredients 
    2. Antibiotics (including "fish" antibiotics, both over-the-counter and prescription) 
    3. Prescription veterinary products and their active ingredients 
    4. Vaccines (including human and animal vaccines) 
  3. Drug products must not be named in an FDA recall or safety alert (for more information, see: [ Recalls, Market Withdrawals, & Safety Alerts ](https://www.fda.gov/Safety/Recalls/default.htm) ) 
  4. Drug products must not have been the subject of a Drug Enforcement Administration (DEA) emergency scheduling (for more information, see: [ DEA Press Releases ](https://admin.dea.gov/press-releases) ) 
  5. Drug products must not be named by the Federal Trade Commission (FTC) as making untrue marketing claims (for more information, see: [ Federal Trade Commission Press Releases ](https://www.ftc.gov/news-events/press-releases) ) 
  6. Drug products must not be identified as adulterated (e.g. unsafe or lacking evidence of safety) or misbranded (e.g. having false or misleading information on the label) in an FDA warning letter (for more information, see: [ FDA Warning Letters ](https://www.fda.gov/ICECI/EnforcementActions/WarningLetters/default.htm) ) 
  7. Drug listings must not be for controlled substances or products containing controlled substances, such as:   

    1. Hemp products containing Resin or tetrahydrocannabinol (THC) 
    2. Hemp (or any cannabis Sativa spp. strain) seeds capable of germination 
    3. Anything listed in Schedules I, II, III, IV or V of the Controlled Substances Act (for more information, see: [ Schedules of Controlled Substances ](https://www.deadiversion.usdoj.gov/schedules/) ), such as:   

      1. Coca Leaves, including all variations of leaves, tea, and coca extract 
      2. Hallucinogenic mushrooms 
      3. Poppy pods, poppy straw, and poppy straw concentrate 
    4. "List I" chemicals or their derivatives as designated by the Drug Enforcement Administration (DEA) (for more information, see: [ List I and List II Chemicals ](https://www.deadiversion.usdoj.gov/chem_prog/34chems.htm) ), such as:   

      1. Ephedrine 
      2. Phenylpropanolamine 
      3. Pseudoephedrine 
      4. Ergotamine 

**Note:** Amazon prohibits the sale of Lugol's Solution containing more than
2.2% iodine

  8. Drugs listings must not be for substances identified by the Drug Enforcement Administration (DEA) as a drug or chemical of concern, such as:   

    1. Jimson Weed 
    2. Kratom 
    3. Salvia Divinorum 
  9. Drug listings must comply with Amazon policies:   

    1. Loperamide listings are restricted to 48 mg of loperamide. Capsule and tablet loperamide must be packaged in blister packs. Images of the “Drug Facts” panel and Heart Alert Warning from the product label must be present on the detail page. 
    2. Listings for poppy seeds that make certain claims, including listings for poppy seeds that reference poppy tea, poppy seeds that are “unwashed,” poppy seeds that reference alkaloid content, and poppy seeds that reference opium are prohibited 
    3. Listings for products claiming to have psychoactive or hallucinogenic effects are prohibited, including “designer drugs” such as methoxetamine 
    4. Listings for products claiming to produce an effect similar to that of an anabolic steroid such as "Legal Steroids" are prohibited 
    5. Listings for products claiming to imitate the effects of a controlled substance, prescription drug, or substance identified by the FDA as an unapproved new drug or tainted supplement are prohibited, including synthetic cannabinoids and bath salts 
    6. Listings for homeopathic teething tablets, pills, and similar products, and topical creams, gels, and similar products are prohibited 
    7. Listings for the active ingredients in prescription-only drugs are prohibited 
    8. Listing for injectable drugs are prohibited 
    9. Listings for products containing cannabidiol (CBD) are prohibited, including but not limited to:   

      1. Full spectrum hemp oil 
      2. Rich hemp oil 
      3. Products that have been identified as containing CBD by [ LegitScript ](https://www.legitscript.com/)

**Note:**

1\. Certain CBD topical products that have been verified to be compliant with
applicable laws, regulations and policies are allowed in Amazon Fresh and
Whole Foods Market on Amazon. We don’t have plans at this time to allow the
sale of CBD products on Amazon.com beyond Amazon Fresh and Whole Foods Market,
whether through Amazon or our third-party sellers.

2\. The approved CBD-containing topical products in Amazon Fresh and Whole
Foods Market on Amazon are subject to geographic sales restrictions.

**Products associated with drugs and controlled substances**  

  1. Products must not be primarily used for making, preparing, or using a controlled substance, such as:   

    1. Butane Honey Oil "BHO" extractors and kits 
    2. Bongs and all related accessories 
    3. Dab kits 
    4. Pipes made from metal, most woods, acrylic, glass, stone, plastic or ceramic 
    5. "Rose in a Glass" pipes and similar products 
    6. Vaporizers and all related accessories 
    7. Wired cigarette papers 
    8. Nitrous Oxide Crackers 
    9. Drug purity testing kits 

**Note:** Fentanyl testing strips are permitted for sale in Amazon’s online
store but are subject to geographic sales restrictions.

    10. The term "drug paraphernalia" includes any equipment, product, or material of any kind which is primarily intended or designed for use in: manufacturing, compounding, converting, concealing, producing, processing, preparing, injecting, ingesting, inhaling, or otherwise introducing into the human body a controlled substance. 
    11. Mylar bags, which are not clear or single colored 
  2. Product listings must comply with Amazon policies:   

    1. Products intended to defeat a drug test, such as urine additives and synthetic urine are prohibited 
    2. Tableting machines (commonly known as “pill presses”) or encapsulating machine (commonly known as “capsule fillers”), whether those devices are mechanical or manual, are prohibited 
    3. Tablet presses or molds used to press or imprint a pharmaceutical drug name or identification number onto a tablet or pill are prohibited 
    4. Listings for products that reference a product’s use with illegal drugs are prohibited 
    5. Listings for drug products that contain more than 2.2% iodine are prohibited, even those in an aqueous solution 

##  Known prohibited products

Amazon specifically prohibits the following drug products, controlled
substances, and products imitating drug products and controlled substances.
These products are prohibited because they do not meet the checklist
requirements. This list does not include all drug products prohibited by
Amazon.

  * 1,4-Butanediol 
  * Amanita muscaria 
  * Clenbuterol 
  * Coca Leaves, including all variations of leaves, tea, and coca extract 
  * Codeine 
  * Damiana 
  * Dimethyltryptamine (DMT) 
  * Drotebanol 
  * Ephedrine 
  * Ergotamine 
  * Gamma-Hydroxybutyric Acid (GHB) 
  * Hawaiian Baby Woodrose or Argyreia Nervosa seeds 
  * Jimson Weed 
  * Kanna 
  * Ketamine 
  * Klip Dagga 
  * Kratom 
  * Marshmallow Leaf 
  * Panther amanitas 
  * Peyote or mescaline 
  * Phenylpropanolamine 
  * Poppers, amyl nitrite products, or related products 
  * Poppy pods, poppy straw, and poppy straw concentrate 
  * Poppy tea (tea brewed from poppy seeds, pods, or straw) 
  * Pseudoephedrine 
  * Psilocybe Cubensis 
  * Psilocybin 
  * Salvia Divinorum 
  * Sonoran Song Mimosa Hostilis 
  * Syrian Rue 
  * Wild Dagga 
  * Yopo Seeds 

##  Age restriction

In certain jurisdictions, Amazon will implement age restriction (18+) as
required for certain products.

##  Additional useful resources

[ LegitScript ](https://www.legitscript.com/) has a searchable database that
may help when determining if a supplement includes a prohibited ingredient.

##  Related Amazon help pages

  * [ Restricted Products: Animals & Animal Products ](/gp/help/external/200164370)
  * [ Restricted Products: Cosmetics & Skin/Hair Care ](/gp/help/external/200164470)
  * [ Restricted Products: Food & Beverage ](/gp/help/external/200164550)
  * [ Restricted Products: Dietary Supplements ](/gp/help/external/201829010)
  * [ Restricted Products: Medical Devices & Accessories ](/gp/help/external/200164650)
  * [ Restricted Products: Tobacco & Tobacco-Related Products ](/gp/help/external/200164910)
  * [ Listing Restrictions ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=200832300&language=en_US&ref=su_200832300_cont_200301050&)
  * [ Prohibited Product Claims ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=202024200&language=en_US&ref=su_202024200_cont_200301050&)
  * [ Restricted Products ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=200164330&language=en_US&ref=su_200164330_cont_200301050&)
  * [ General Listing Restrictions ](https://sellercentral.amazon.com/gp/help/external/help.html?itemID=201707070&language=en_US&ref=su_201707070_cont_200832300&)

Last updated 3/7/2023

Top

