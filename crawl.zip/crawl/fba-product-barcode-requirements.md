# FBA product barcode requirements

Source: https://sellercentral.amazon.com/gp/help/external/201100910

This article applies to selling in: **United States**

#  FBA product barcode requirements

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2F201100910)

On this page

Manufacturer barcodes

Amazon barcodes

Transparency authenticity codes

Fulfillment by Amazon uses barcodes to identify and track inventory throughout
the fulfillment process. Each item that you send to an Amazon fulfillment
center requires a barcode.

There are three kinds of barcodes for identifying products:

  * Manufacturer barcodes (eligible barcodes include UPC, EAN, JAN, and ISBN) 
  * Amazon barcodes (such as FNSKU) 
  * [ Transparency ](https://brandservices.amazon.com/transparency) authenticity code (brand owner only, may be required to help prevent counterfeit) 

**Note:** If your brand has been approved for [ Amazon Brand Registry
](/gp/help/external/G202130410) and you don’t have a manufacturer barcode for
your products, you can apply for a [ GTIN exemption ](/gtinx/browser) .

##  Manufacturer barcodes

By default, Amazon will use the manufacturer barcode to track eligible
inventory throughout the fulfillment process, unless you change your barcode
setting.  When more than one seller has inventory with the same manufacturer
barcode, Amazon may fulfill orders with the inventory that is closest to the
customer, for faster delivery.

If your product is not eligible for virtual tracking with the manufacturer
barcode, an Amazon barcode will be required. To learn more about virtual
tracking and see product eligibility requirements, go to [ Using FBA virtual
tracking ](/gp/help/external/200141480) .

If your product doesn’t meet the virtual-tracking eligibility requirements,
you may be able to get an exemption to use the manufacturer barcode by
applying with [ Amazon Brand Registry ](/gp/help/external/G202130410) and
enrolling your ASIN in the program. Non-brand-registered sellers would be
required to apply Amazon barcodes for the ineligible product.

**Note:** If you are the manufacturer or the brand owner and want to print
barcodes directly on the product packaging, you can apply for a  [ GS1
standard UPC barcode ](https://www.gs1.org/) .

##  Amazon barcodes

Amazon barcodes must be applied to all products that are not tracked using the
manufacturer barcode. These products include the following:

  * Products that are not in new condition 
  * Products that don’t have a scannable UPC, EAN, JAN, or ISBN barcode 
  * [ Restricted products ](/gp/help/external/200140860) and [ dangerous goods ](/gp/help/external/G201003400)
  * Products with an [ expiration date ](/gp/help/external/G201003420)
  * Consumable or topical products 
  * Media products 
  * Products for children or infants 

You can print Amazon barcodes and apply them to your products yourself, or you
can have Amazon print and apply them for a per-item fee. For more information,
go to [ Use an Amazon barcode to track inventory
](/gp/help/external/200141490) and [ FBA Label Service
](/gp/help/external/200483750) .

**Note:** Products that require additional packaging such as bagging or bubble
wrap can be tracked by manufacturer barcode or Amazon barcode. However,
prepped item will require labeling. For more information, go to  [
Send/replenish inventory: Label products ](/gp/help/external/201021860) .

##  Transparency authenticity codes

Transparency codes are item-level authentication stickers that help protect
brand owners and customers from counterfeit. Transparency codes are
accompanied by a Transparency “T” logo and must not cover or be covered by any
other label. To learn more and see a sample sticker, go to [ Transparency
](https://brandservices.amazon.com/transparency) .

**Note:** Products enrolled in the [ Transparency
](https://brandservices.amazon.com/transparency) program are eligible for
virtual tracking, except for products in the Toys & Games and Baby Products
categories, dangerous goods, and expiration-dated products. The categories
eligible for Transparency may be subject to change by Amazon. To learn more,
go to [ Transparency 2D barcode requirements ](/gp/help/external/G202008510) .

Top

##  FBA product barcode requirements

* [ Use an Amazon barcode to track inventory  ](/help/hub/reference/external/G200141490)
* [ Using FBA virtual tracking  ](/help/hub/reference/external/G200141480)
* [ Change to Amazon barcode by creating a new product offer  ](/help/hub/reference/external/G9P8W8RZ96JFHVZH)

