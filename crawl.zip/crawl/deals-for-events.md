# Deals for Events

Source: https://sellercentral.amazon.com/help/hub/reference/external/G202183600

This article applies to selling in: **United States**

#  Deals for Events

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG202183600)

To submit a Deal for event consideration:  

  1. On the [ Deals dashboard ](/merchandising#/dashboard/create) , check **Upcoming Events** to see the events that are open for Deals submissions. Events include Prime Day, Black Friday, Cyber Monday, and others. 
  2. Select the desired event in the **Schedule** box as part of the Deal. You can submit Deals for multiple event and non-event weeks. 

##  FAQ

####  How do I know if I am eligible to submit a Deal for event consideration?

You can see if an ASIN is eligible for event consideration in two places:

  * On the [ Deals dashboard ](/merchandising#/dashboard/create) , the event options are in the **Date** column drop down. 
  * As part of creating a new Deal choose the desired event when you select **Schedule** for the Deal. 

If you do not see the event available in the **Schedule** , your ASIN
currently does not meet the criteria to be considered for the event.

####  What if I don't see the ASINs that I want to submit for the event?

Products must pass certain criteria in order to qualify to be an eligible
ASIN. If you don't have any eligible ASINs on your Deals dashboard, your
products currently don't meet the Deals criteria. Learn how to [ make your
products eligible for Deals ](/gp/help/external/202111490) .

####  It says that my ASIN is not eligible for an event. What does that mean,
and how can I make it eligible?

Events may require different criteria in order to qualify for as an eligible
ASIN. If the **Create a Deal** page states that your ASIN is not eligible for
the event, your ASIN currently does not meet the criteria to be considered for
the event.

####  How can I guarantee that my Deal is selected for the event?

We cannot guarantee that your Deal will be selected to run on the event. After
all Deals have been submitted for event consideration, Amazon will review the
Deals scheduled to run on the event. In order to improve the probability of
your Deal being selected, select the Deals that you believe will get customers
most excited to purchase. Deals with greater available quantity and inventory
may also have an advantage in being selected.

####  What are the criteria for my Deal to be selected for the event?

All eligible ASINs with the event in the **Schedule** option meet the base
criteria for event consideration. Learn how to [ make your products eligible
for Deals ](/gp/help/external/202111490) . Amazon will then choose the Deals
that have a large available quantity and inventory and provide a diverse mix
of Deals for customers.

####  What is the fee to run a Deal during the event?

The event week includes a time period during which customer traffic in Amazon
Stores may be significantly higher, which may lead to greater exposure and
potential sales for your Deal.

Depending on your locale, you could see a fee variation. The fee or fee
variation is displayed when you select **Schedule** as you create the Deal. If
your Deal is scheduled during a higher traffic time period, you could be
charged a higher fee. If your Deal is scheduled outside of the higher traffic
time period, you could be charged a lower fee.

If you are unsatisfied with the resulting fee, you can cancel the Deal before
the Deal is expected to run. Get information about [ Deals fees
](/gp/help/external/202111590) .

####  When will I know when my Deal is expected to run?

The date and time of your Deal will be revealed in Seller Central at least one
week before the Deal is scheduled to run. If your Deal has been selected for
the event, the start and end dates will state the name of the event (e.g.
Prime Day  , Cyber Monday, etc.), along with the time your Deal will run. If
your Deal has not been selected for the event, the start and end dates will
reflect the week-long timeframe.

####  If I have a Deal chosen for the event, how do I manage my Deal?

In order to ensure that your Deal runs on the event, monitor your Deal
regularly and make any relevant changes to keep it in the **Upcoming** status.
Consider following the  **Tips for running successful Deals** section on the
**Deals** page to promote your products further.

Top

