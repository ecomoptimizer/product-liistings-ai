# Fulfillment fees for FBA orders

Source: https://sellercentral.amazon.com/gp/help/external/GPDC3KPYAGDTVDJP

This article applies to selling in: **United States**

#  FBA fulfillment fee

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGPDC3KPYAGDTVDJP)

On this page

Fees overview

Fee details

Values used to calculate fee

Your rates

Fulfillment fee

Product size examples

Tools

The FBA fulfillment fee is a per-unit fee charged to fulfill items to
customers for purchases in the Amazon store. The fee varies depending on an
item’s category, size and weight. It’s sometimes referred to as the “pick and
pack” fee.

**Program specifics:** The details, calculations, or rates for this fee may
vary for products enrolled in FBA Small and Light or Multi-Channel
fulfillment. For more information, go to the following help pages:

  * [ FBA Small and Light ](/gp/help/external/G201706140)
  * [ FBA fulfillment fees for Multi-Channel fulfillment orders ](/gp/help/external/G201112650)

##  Fees overview

For more information on the fees in this program, view the following video:

##  Fee details

**Time of charge** |  When the buyer’s order is shipped  
---|---  
**Fee structure** |  Per unit fulfilled. Rate is based on product type, size
tier, and shipping weight.  
  
##  Values used to calculate fee

**Product size tier** |  Product size tiers are measurement categories based
on the unit weight, product dimensions, and dimensional weight of a packaged
item. Learn how to [ determine your product size tier
](/gp/help/external/GG5KW835AHDJCH8W) , or use the [ Monthly Storage Fees
report
](/gp/ssof/reports/search.html?recordType=STORAGE_FEE_CHARGES&language=en_US&ref=au_fbafulrpts_cont_GPDC3KPYAGDTVDJP)
to view the size tier information for products that you’ve previously sent to
fulfillment centers.  
---|---  
**Shipping weight** |  Shipping weight is the weight used to determine fees.
The shipping weight is calculated based on the item’s unit weight or
dimensional weight. Learn how to [ determine your product's shipping weight
](/gp/help/external/GEVWP48HPBLEFJEY) .  
**Dimensional weight** |  In certain cases, dimensional weight is used instead
of unit weight to determine the shipping weight. Learn how to [ calculate
dimensional weight ](/gp/help/external/G53Z9EKF8VVZVH29) .  
**Fee category** |  [ Fee categories ](/gp/help/external/GCZM532MZ9A4GU46)
determine which rates apply to a particular product for certain fee types.  
  
For more information, go to [ Unit weight
](/gp/help/external/GE3VC5FGJE9TYJKM) and [ Product dimensions and volume
](/gp/help/external/G37G73BJXHF75ACH) .

##  Your rates

To determine which rates apply to your product, do the following:  

  1. To determine whether the product is considered apparel, go to [ Fee category guidelines for your products ](/gc/fee-category-guidelines) . 
  2. To determine whether the product must be sold through the [ FBA Dangerous Goods program ](/gp/help/external/GZLZBQ7W6QZRKWWK) , use the Look up an ASIN tool on that program page. For more information, go to [ Dangerous goods identification guide (hazmat) ](/gp/help/external/G201003400) . 
  3. To determine the [ product size tier ](/gp/help/external/GG5KW835AHDJCH8W) and calculate the [ shipping weight ](/gp/help/external/GEVWP48HPBLEFJEY) , use the tables below to determine which fee will apply. 

**Note:** Additional fees will apply for items fulfilled by Amazon that
contain [ lithium batteries ](/gp/help/external/9RJJ3KFHSF6YRAG) and
televisions with screens that are 42 inches or larger that require [ special
handling ](/gp/help/external/GPBBZR3MDYRS8L36) .

##  Fulfillment fee

Standard-size product tiers  
---  
Product type  |  Size tier  |  Shipping weight  |  Fulfillment fee  
**Most products (non-dangerous goods, non-apparel)** |  Small standard  |  4
oz or less  |  $3.22  
4+ to 8 oz  |  $3.40  
8+ to 12 oz  |  $3.58  
12+ to 16 oz  |  $3.77  
Large standard  |  4 oz or less  |  $3.86  
4+ to 8 oz  |  $4.08  
8+ to 12 oz  |  $4.24  
12+ to 16 oz  |  $4.75  
1+ to 1.5 lb  |  $5.40  
1.5+ to 2 lb  |  $5.69  
2+ to 2.5 lb  |  $6.10  
2.5+ to 3 lb  |  $6.39  
3+ lb to 20 lb  |  $7.17 + $0.16/half-lb above first 3 lb  
**Apparel 1  ** |  Small standard  |  4 oz or less  |  $3.43  
4+ to 8 oz  |  $3.58  
8+ to 12 oz  |  $3.87  
12+ to 16 oz  |  $4.15  
Large standard  |  4 oz or less  |  $4.43  
4+ to 8 oz  |  $4.63  
8+ to 12 oz  |  $4.84  
12+ to 16 oz  |  $5.32  
1+ to 1.5 lb  |  $6.10  
1.5+ to 2 lb  |  $6.37  
2+ to 2.5 lb  |  $6.83  
2.5+ to 3 lb  |  $7.05  
3+ lb to 20 lb  |  $7.17 + $0.16/half-lb above first 3 lb  
**Dangerous goods** |  Small standard  |  4 oz or less  |  $4.19  
4+ to 8 oz  |  $4.48  
8+ to 12 oz  |  $4.64  
12+ to 16 oz  |  $4.37  
Large standard  |  4 oz or less  |  $4.64  
4+ to 8 oz  |  $4.89  
8+ to 12 oz  |  $5.03  
12+ to 16 oz  |  $5.34  
1+ to 1.5 lb  |  $6.00  
1.5+ to 2 lb  |  $6.29  
2+ to 2.5 lb  |  $6.56  
2.5+ to 3 lb  |  $6.85  
3+ lb to 20 lb  |  $7.63 + $0.16/half-lb above first 3 lb  
  
Oversize product tiers  2  
---  
Product type  |  Size tier  |  Shipping weight  |  Fulfillment fee  
**Non-dangerous goods (both apparel and non-apparel)** |  Small oversize  |
70 lb or less  |  $9.73 + $0.42/lb above first lb  
Medium oversize  |  150 lb or less  |  $19.05 + $0.42/lb above first lb  
Large oversize  |  150 lb or less  |  $89.98 + $0.83/lb above first 90 lb  
Special oversize  |  Over 150 lb  |  $158.49 + $0.83/lb above first 90 lb  
**Dangerous goods (both apparel and non-apparel)** |  Small oversize  |  70 lb
or less  |  $10.48 + $0.42/lb above first lb  
Medium oversize  |  150 lb or less  |  $19.92 + $0.42/lb above first lb  
Large oversize  |  150 lb or less  |  $101.91 + $0.83/lb above first 90 lb  
Special oversize  |  Over 150 lb  |  $179.28 + $0.83/lb above first 90 lb  
  
1  _Starting on February 16, 2023, for apparel items, the greater of unit
weight or dimensional weight will be used to calculate the shipping weight for
all large standard-size and oversize units, except for special oversize._

2  _For oversize products, go to[ Product size tiers
](/gp/help/external/GG5KW835AHDJCH8W) for detailed definitions. _

##  Product size examples

Small standard size (4 oz or less)  
---  
  
  
|

**Mobile device case**

Dimensions: 13.8 x 9 x 0.7 inches

Unit weight: 2.88 oz

Shipping weight range: 4 oz or less  
  
**Fulfillment fee (per unit)** |  $3.22  
  
Large standard size  
---  
|

**T-shirt**

Dimensions: 13 x 9 x 0.85 inches

Dimensional weight: 11.45 oz

Unit weight: 5.40 oz

Shipping weight range: 4+ to 8 oz

_(From January 17 to February 15, 2023)_

Shipping weight range: 8+ to 12 oz

_(Starting February 16, 2023)*_  
  
**Fulfillment fee (per unit)**

_(From January 17 to February 15, 2023)_

|  $4.63  
  
**Fulfillment fee (per unit)**

_(Starting February 16, 2023)_

|  $4.84  
  
|  _* The greater of unit weight or dimensional weight will be applied._  
  
Large standard size (over 3 lb)  
---  
  
  
|

**Iron**

Dimensions: 12.6 x 6.6 x 5.5 inches

Dimensional weight: 3.29 lb

Unit weight: 3.35 lb

Shipping weight range: 3+ to 3.5 lb  
  
**Fulfillment fee (per unit)** |  $7.33 ($7.17 for first 3 lb plus $0.16 for
each additional 0.5 lb interval)  
  
Small oversize  
---  
  
  
|

**Baby cot**

Dimensions: 24 x 7.5 x 6 inches

Dimensional weight: 7.77 lb

Unit weight: 7.90 lb

Shipping weight range: 7+ to 8 lb  
  
**Fulfillment fee (per unit)** |  $12.67 ($9.73 for first 1 lb plus $0.42 for
each additional 1 lb interval)  
  
Large oversize  
---  
|

**Monitor**

Dimensions: 54 x 35 x 3.5 inches (This product’s length plus girth is 131,
putting it in the large oversize tier.)

Dimensional weight: 47.59 lb

Unit weight: 41 lb

Shipping weight range: 47+ to 48 lb (This weight is calculated based on the
product’s dimensional weight, which is 47.59 lb and greater than the unit
weight.)  
  
**Fulfillment fee (per unit)** |  $89.98 ($89.98 for first 90 lb)  
  
##  Tools

**Estimating fees** |

[ Revenue Calculator ](/revcal)

[ Manage Your Inventory – Estimated Fees per Unit Sold ](/inventory)

[ Fee Preview report ](/reportcentral/ESTIMATED_FBA_FEES/1)  
  
---|---  
**Reporting fees** |

[ Payments - Transaction View ](/gp/payments-account/view-transactions.html)  
  
Top

