# How to respond to an A-to-z Guarantee claim notification

Source: https://sellercentral.amazon.com/gp/help/external/G1781

This article applies to selling in: **United States**

#  Respond to an A-to-z Guarantee Claim

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG1781)

If we determine that additional information is required during an A-to-z
Guarantee Claim investigation, we will contact you via email with a request
for more information and provide an A-to-z Guarantee Claim notification on
your Seller Central homepage that requires your attention. This may include
but is not limited to the following information:

  * For delivery related claims: Dispatch method, proof of delivery, tracking number, and carrier details 
  * For returns related claims: Eligibility of return request, domestic return address, returns shipping details (like return label) 
  * Proof of any correspondence between the buyer and you with an acknowledgement of receipt of the order and satisfaction with the transaction 

If you do not respond to our request for additional information within 48
hours, the claim will be granted in favor of the buyer, and your account will
be debited for the claim amount. This Claim will reflect in your account
health or order defect rate (ODR) metrics.

**Note:** The A-to-z Guarantee policy is different for Amazon Pay
transactions. You can review the [ Amazon A-to-z Guarantee for merchants
](https://pay.amazon.com/us/help/201212410) on the Amazon Pay website.

To respond to a Claim notification:  

  1. From the **Performance** menu, select [ A-to-z Guarantee Claims ](/gp/guarantee-claims/home.html?language=en_US&ref=ag_gclaims_cont_G1781) . 
  2. In the **Action required** tab (which is the default tab), find the relevant claim and select **Respond to Amazon** . 
  3. Enter your comments in the text box and include any information that may help us better understand the claim and your position on whether it should be granted. Note that the text box does not support attachments. If you have to attach any documents, use [ Buyer-Seller Messages ](/messaging/inbox-v2?ct=&fi=RESPONSE_NEEDED&bt=&nt=&pn=1&pd=NONE&sd=&ed=&si=) to attach documents and send it to the buyer. Additionally, state in your A-to-z Guarantee Claim response that you have attached additional information (For example, Print on demand) in Buyer-Seller Messages. 
  4. Click **Submit** . 

We encourage you to check your email often so that you are aware of when you
have to take action on claims. Promptly responding to claims is critical for
reaching amicable outcomes. Review our [ order defect rate
](/gp/help/external/200285170) (ODR) for more information on how claims
impacts your account health.

For information about how to respond to A-to-z claims covering property damage
or personal injury caused by a defective product, go to [ A-to-z Claims
Process for Property Damage and Personal Injury
](/gp/help/external/GTY6NYZDFD5CENYH) .

**Important:** If Amazon grants a claim in favor of a buyer, you have 30 days
to [ appeal ](/gp/help/external/G202041210) and request a further
investigation. Based on the results of the appeals investigation, Amazon will
make a final decision on whether to reverse the initial decision and reimburse
you for the claim incurred. For more information about claims, go to [
Amazon’s A to-z Guarantee Claims ](/gp/help/external/GQ6762Y9AB2FYDY8) .

Top

