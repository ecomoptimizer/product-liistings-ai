# Amazon Merchant Transport Utility

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> On this page

## Amazon Merchant Transport Utility

On this page

[Use the Amazon Merchant Transport Utility](https://sellercentral.amazon.com/help/hub/reference/G17781#GUID-780CC8F4-0115-4548-BD02-F7948524A82B__SECTION_B1636B5D101E4752B0E9FDE412C51644)

[Upgrading from a previous version of AMTU](https://sellercentral.amazon.com/help/hub/reference/G17781#GUID-780CC8F4-0115-4548-BD02-F7948524A82B__SECTION_CBD497D3404942D291C8FC7F36D8FF1F)

[Download and install AMTU 2.6.1](https://sellercentral.amazon.com/help/hub/reference/G17781#GUID-780CC8F4-0115-4548-BD02-F7948524A82B__section_u2n_mcx_hkb)

## Use the Amazon Merchant Transport Utility

The Amazon Merchant Transport Utility (AMTU) is designed to make sending files to Amazon and receiving reports from Amazon as simple as dragging and dropping files into a directory. AMTU runs automatically behind the scenes, uploading files from the relevant directory to Amazon and retrieving the results of the uploads. AMTU can also retrieve order reports from Amazon.

AMTU is available to all sellers and can be used in addition to other methods of exchanging data with Amazon. Starting on April 1, 2020, Amazon will no longer accept contributions submitted using AMTU versions 2.5 or earlier. Users must install version 2.6.1 to continue using AMTU after April 1, 2020. See the [AMTU 2.6 User Guide](https://d28hcfptedr5ia.cloudfront.net/ug/AMTU_2.6_UserGuide.pdf) for further details.

## AMTU 2.6 Features

-   Support for the recommended MWS Auth Model
-   Support for multiple seller accounts in a single AMTU installation, with the ability to customize settings independently for each account
-   Support for uploading UTF-8 encoded files
-   An optional graphical user interface (GUI) as well as a graphical install and uninstall program
-   Automatic program updates
-   Support for Windows, Mac, and Linux
-   An option to install AMTU as a Windows service
-   Proxy support
-   Archive logs

## New in Version 2.6

-   Support for the recommended MWS Auth Model
-   Various bug fixes

## System requirements

#### Important:

-   AMTU 2.6 requires an operating system compatible with Java 8

#### Hardware

-   Processor speed: at least 166 MHz
-   Memory: at least 64 MB
-   Hard-disk space available: at least 70 MB

#### Software

-   Windows 10 (8u51 and above)
-   Windows 8.x (Desktop)
-   Windows 7 (SP1)
-   Windows Server 2016
-   Mac OS X versions including 10.8.3 or later+, 10.9+, excluding Catalina
-   Any general Linux installation that supports Java 8

## Upgrading from a previous version of AMTU

If you have AMTU 1.0 installed, you must uninstall that before attempting to install AMTU 2.6.1. The uninstall process is covered in the "AMTU 1.0 Uninstall Process" section of the [AMTU 2.6 User Guide](https://d28hcfptedr5ia.cloudfront.net/ug/AMTU_2.6_UserGuide.pdf).

## Download and install AMTU 2.6.1

Before installing AMTU, download and carefully read the [AMTU 2.6 User Guide](https://d28hcfptedr5ia.cloudfront.net/ug/AMTU_2.6_UserGuide.pdf). By downloading any of the application installer files below, you agree to the terms and conditions of the Apache 2.0 license contained within the User Guide.

#### Platform Versions

-   [AMTU 2.6.1 for Windows (x64)](https://d28hcfptedr5ia.cloudfront.net/install/AMTU_windows_2_6_1_x64.exe)
-   [AMTU 2.6.1 for Windows (x86)](https://d28hcfptedr5ia.cloudfront.net/install/AMTU_windows_2_6_1_x86.exe)
-   [AMTU 2.6.1 for Mac OS (x64)](https://d28hcfptedr5ia.cloudfront.net/install/AMTU_macos_2_6_1.dmg)
-   [AMTU 2.6.1 for Linux (x64)](https://d28hcfptedr5ia.cloudfront.net/install/AMTU_unix_2_6_1_x64.sh)
-   [AMTU 2.6.1 for Linux (x86)](https://d28hcfptedr5ia.cloudfront.net/install/AMTU_unix_2_6_1_x86.sh)

[MD5](https://d3hm6dod2yb6x4.cloudfront.net/md5sums.txt) / [SHA256](https://d3hm6dod2yb6x4.cloudfront.net/sha256sums.txt)

Top

Was this article helpful?
