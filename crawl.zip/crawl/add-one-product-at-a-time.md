# Add one  product at a time

Source: https://sellercentral.amazon.com/gp/help/external/G200220550

This article applies to selling in: **United States**

#  Add one product at a time

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG200220550)

On this page

Match to an existing product listing

Create a new product listing

Listing in multiple stores

See also

**Add a Product** is an interactive web-based interface used to list a small
number of products, one at a time. This tool is available within the
**Catalog** drop-down menu of your seller account. The Add a Product tool can
be used to:

  * **Match to an existing product listing:** If you have a product you want to sell which already exists on Amazon, you must match to the existing product detail page. 
  * **Create a new product listing:** If the product you want to sell does not exist on Amazon, you can list a new product and Amazon will create a new product detail page. 

**Note:** If you have a Professional selling plan, and prefer to work with
your product listings offline, we recommend using an [ inventory template
](/gp/help/external/G201576410) .

Watch the introductory video on ways to list a product

##  Match to an existing product listing

**Note:** This option is not available to Amazon Handmade sellers.

Before you match your product to the existing product listing on Amazon,
ensure that you have the following information available:

Information to provide  |  Description  
---|---  
Offer Details  |  Offer includes the product's condition, price, quantity,
shipping options, etc. You can update your offer information at any time.  
Follow these steps to match to an existing product listing:  

  1. Select [ Add a Product ](https://sellercentral.amazon.com/productsearch/ref=xx_addlisting_dnav_xx) from the Catalog drop-down. 
  2. Search for the product you want to sell on Amazon within the **Find your products in Amazon’s catalog** section. 

**Note:** Results are more accurate if you search for a product identifier
such as a UPC, EAN, JAN, or an ISBN.

  3. If you locate the product you want to sell, perform these steps:   

    1. Click on **Show variations** (if applicable). 
    2. Select a condition. 
    3. Click **Sell this Product** . 
    4. Enter your offer details in the provided data fields. 

**Note:** Required fields are marked with an asterisk.

    5. Click **Save** . 

##  Create a new product listing

If you are unable to locate your product using Add a Product, you can [ Create
a new product listing ](/hz/productclassify) on Amazon. Before creating a new
listing on Amazon, ensure that you have the following information available:

Information to provide  |  Description  
---|---  
Product Identifier  |

Most products have a unique identification code, such as a UPC, EAN, JAN, or
ISBN. It ensures accurate information on the product detail page.

**Note:** Handmade listings do not require a unique identifier.  
  
Offer Details  |  Offer details includes the product's condition, price,
quantity, shipping options, etc. You can update your offer information at any
time.  
Product Details  |  Product details include product name (title), brand,
category, description, and images. These details give buyers a clear view of
the product being offered and can be used to highlight special features.
Mandatory attributes are subject to change depending on the category you are
listing your products in.  
Keywords and search terms  |  Strong keywords can help make your products
easier for buyers to find. To learn more, see [ Using search terms effectively
](/gp/help/external/G23501) .  
  
Follow these steps to create a new product listing on Amazon:

  1. Select [ Add a Product ](/productsearch/ref=xx_addlisting_dnav_xx) from the Catalog drop-down. 

  2. Click **I’m adding a product not sold on Amazon** . 

**Note:** This is not applicable to Handmade listings.

  3. You can choose one of the following options to create a new product listing: 
    * Search for your product’s category and click the **Search icon** button. 
    * Browse the **Select a Product Category** option for the category that matches the product you want to sell and click **Select category** . Choosing your category accurately can help buyers find products more easily. 

**Note:** You can favorite frequently used categories by clicking on the star.
These categories will subsequently appear under Favorites at the top of
**Select a product category** .

  4. Enter the required information within the **Vital Info** and **Offer tabs** . 

**Note:** You can select the Advanced View option to enter additional
information about your product.

  5. Once you enter the required information in the tabs provided, you can click **Save changes** to complete the listing process. You can edit the information for your product listings anytime. 

**Note:**

    * Detail pages are shared with other sellers who can offer the same product. (Note: This is not true for Handmade detail pages.) Amazon chooses what information to include on the product detail page based on manufacturer and seller contributions. To learn more, refer to [ Product detail pages and offers ](/gp/help/external/G51) . 
    * Amazon displays listings with relevant and accurate information on the detail page. It is highly recommended that you provide appropriate information for your product listings, to help buyers make a well-informed purchase. Review the following help guides for best practices while listing a product: 
      * [ Amazon Services Quick Start Style Guide ](https://m.media-amazon.com/images/G/01/rainier/help/Selling_on_Amazon_Quick_Start_Style_Guide_2018.pdf)
      * [ Product image requirements ](/gp/help/external/G1881)
      * [ Product Listing Guidelines ](/gp/help/external/G202073140)

The information you provide will be published on Amazon typically within 15
minutes and your offer becomes visible to customers through search and browse.
After you add new products or listings, confirm if you can find your products
by searching or browsing for them. If you cannot find your products, see [
Using search terms effectively ](/gp/help/external/G23501) and [ How do I find
my products on the Amazon website ](/gp/help/external/G21251) .

##  Listing in multiple stores

Whether you are matching to an existing product listing or creating a new one,
you have the option to reach more Customers by making your listing available
across multiple Amazon stores during the listing process. Provide additional
attributes such as price for each additional store in the offer tab to create
listings in those stores in addition to the store you have selected in the
Seller Central header. Prices should be provided in the local store currency,
which is denoted in the price field. If a detail page doesn’t yet exist in
those stores, Amazon will attempt to automatically translate and create a page
on your behalf. This process can take up to 48 hours to complete, and you will
be able to suggest content changes in local language after completion.

Available stores are determined by where you are registered, and for stores
outside of regions like Europe or North America, by your linked accounts. To
find out more about listing policies for each store, go to [ Amazon’s
Category, Product and Content Restrictions ](/gp/help/external/G200301050) .

##  See also

  * [ How to list products that do not have a GTIN (UPC, EAN, JAN, or ISBN) ](/gp/help/external/G200426310)
  * [ ASIN Creation Policy ](/gp/help/external/201844590)
  * [ Enhance Your Listings ](/gp/help/external/G200403880)
  * [ Apply for GTIN exemption ](/gtinx)

Top

