# Jewelry Quality Assurance  Standards

Source: https://sellercentral.amazon.com/gp/help/external/G201269180

This article applies to selling in: **United States**

#  Jewelry Quality Assurance Standards

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG201269180)

On this page

1\. Product information and specifications

1.1 Gold

1.2 Silver

1.3 Platinum

1.4 Stamping

1.5 Metal weight

1.6 Metal plating and products containing multiple metals

1.7 Hypoallergenic standards

1.8 Variation relationships

1.9 Children's jewelry

2\. Design requirements

2.1 General

2.2 Measurement

2.3 Casting and construction

2.4 Polishing and finishing

2.5 Stone setting

2.6 Findings

3\. Pearls and colored gemstones standards

3.1 General

4\. Diamond standards

5\. Diamond Grading Report or Certificate of Authenticity

6\. Independent laboratory testing

7\. Resources

To sell jewelry products on Amazon, sellers must ensure that their products
meet Amazon's Quality Assurance Standards, which help sellers deliver
exceptional value to jewelry customers. In addition, jewelry products and
their associated listings must adhere to all applicable laws, regulations and
standards, as well as the standards outlined on this page.

This page outlines the Jewelry Quality Assurance Standards that aid sellers to
clearly and accurately describe all aspects of their products. These include
product titles, product features, specifications, and descriptions. Sellers
must ensure that their products meet or exceed the description of their
product listing on Amazon. This page also explains Amazon's review process.

We may suspend or terminate any seller's Fine Jewelry or Jewelry listing
privileges for any reason at any time upon providing notice to the seller.
Sellers may cease to list Fine Jewelry or Jewelry products for any reason at
any time.

##  1\. Product information and specifications

Sellers are required to comply with applicable metal quality mark and stamp
requirements in the US and Canada and must provide accurate metal content
information in their product listings.  The following sections provide
additional detail on metal content requirements.

##  1.1 Gold

  

  1. Sellers must comply with the following acceptable tolerance for gold fineness. For normal gold items, the tolerance is +/- 0.003 of the stamped fineness. For items constructed with solder (bracelets, for example), the overall tolerance is 0.007. 
  2. Gold fineness (for example, 10K, 14K, 24K) must be clearly disclosed when listing a product as gold. 

##  1.2 Silver

  

  1. All Sterling Silver items must assay at 92.5% sterling. For normal sterling silver items (without solder), the tolerance is +/- 0.002. With solder, the tolerance is +/- 0.006. 
  2. All Coin Silver items must assay at 90.0% sterling. For normal sterling silver items (without solder), the tolerance is +/- 0.002. With solder, the tolerance is +/- 0.006. 
  3. Silver fineness (for example 500, 750, 850, 925) must be clearly disclosed when listing a product as silver. 
  4. Certain findings on silver jewelry are exempt from assay considerations: pin stems, clasp safety tongues, etc. Nickel pin stems are acceptable. 

##  1.3 Platinum

  

  1. Products labeled "PLAT" or "PLATINUM" and presented as pure platinum must assay at 950 parts per thousand. 
  2. If the platinum content falls below 950/1000, the platinum content must be disclosed in the quality mark, such as "900 PLAT". 
  3. If the platinum content falls below 850/1000, the platinum content must be disclosed in the quality mark, such as "500 PLAT", and must be immediately followed with the content and element used in the alloy, such as "415 CO". 
  4. Bracelet and necklace snap tongues as part of the clasp are exempt from platinum assay. 

##  1.4 Stamping

Any metal stamping must be accurate, complete, and accompanied either by a
trademark or by the name of the manufacturer.

  

  1. Precious metals  Metal  |  Common stamps   
---|---  
Gold  |  6k, 9k,  10k, 14k, 18k, 22k, 24k  
Silver  |  Sterling silver, .925, .999  , 500  
Platinum  |  Plat, 950Plat  , PT950  
  2. Plated previous metals/Vermeil 

**Note:** The US and Canada require a minimum plating thickness (which varies
based on the plating method and material used) and fineness of the precious
metal for a product to be called plated. If the item has a precious metal
base, stamp should reflect the precious metal base.

Metal  |  Stamp  
---|---  
Gold-plated sterling silver  |  .925  
Rhodium-plated gold  |  14k  
  
**Note:** If you are unclear about what Vermeil is, the definition according
to FTC regulations is: An industry product may be described or marked as
"vermeil" if it consists of a base of sterling silver coated or plated on all
significant surfaces with gold, or gold alloy of not less than 10 karat
fineness, that is of substantial thickness and a minimum thickness throughout
equivalent to two and one half (2 ½) microns (or approximately
100/1,000,000ths of an inch) of fine gold.

  3. Plated Base Metals/Gold-Filled Metal 

**Note:** Base metals that are plated with a precious metal do not need to be
stamped.

Metal  |  Stamp  
---|---  
Gold-plated copper  |  None  
SIlver-plated base  |  None  
  
**Important:** For multi-metal pieces that have fine metal and base metals,
the product description needs to accurately state which part of the item has
which metal.

##  1.5 Metal weight

Provide minimum metal weight for your products within 5% accuracy. The minimum
metal weight for your items should include all components of the jewelry item
such as earring backs, posts, pendants, and chains. Different ring sizes may
have different metal weights.

##  1.6 Metal plating and products containing multiple metals

  

  1. The purity of the metal plating must be disclosed, unless the purity of the metal plating is 24K Gold, 925 Silver, or 950 PT. 
  2. Rhodium plating must be disclosed when present. 
  3. Precious metals must be listed in the order of their relative weight (for example, "Platinum Silver Ring" indicates there is more platinum than silver). However, it is acceptable to reverse the order if a plating or qualifier is used (for example, "Platinum-Plated Silver Ring" is acceptable). 

##  1.7 Hypoallergenic standards

Do not refer to the Jewelry item as being "Hypoallergenic" unless it meets one
of the following requirements:

  

  1. Free of Nickel, Cobalt, and other known allergens. 
  2. A pure metal (such as Platinum, Surgical Steel, Sterling Silver, or 18 or higher karat Gold). 
  3. You have competent and reliable scientific evidence that the product does not differ materially from pure metal in terms of its capacity to cause allergic reactions. Jewelry containing Tungsten, Stainless Steel, and Nickel plated Sterling Silver etc. may not be described as hypoallergenic. 

##  1.8 Variation relationships

All Parent and Child ASIN relationships must comply with Amazon's variation
relationship guidelines, as outlined on the [ Variation Relationships Overview
](/gp/help/external/G8831) Help page. Specifically, the Parent ASIN
information, including the product title, must represent the core product and
accurately describe all Child ASINs within the relationship.

##  1.9 Children's jewelry

All Children's jewelry must comply with all federal laws and regulations,
including the [ Consumer Product Safety Improvement Act (CPSIA)
](http://www.cpsc.gov/en/regulations-laws--standards/statutes/the-consumer-
product-safety-improvement-act/) , [ Canada Consumer Product Safety Act
](http://laws-lois.justice.gc.ca/eng/acts/C-1.68/) , the [ Children’s
Jewellery Regulations ](http://laws-
lois.justice.gc.ca/eng/regulations/SOR-2016-168/index.html) , [ Surface
Coating Materials Regulations ](http://laws-
lois.justice.gc.ca/eng/regulations/SOR-2016-193/page-1.html) and the most
stringent US state laws and Canadian provincial regulations.

##  2\. Design requirements

##  2.1 General

  

  1. All units offered against a single ASIN must be uniform with regard to design, construction, color and surface finish, and gemstones must meet the standards set forth in the gemstone guidelines (see Pearls and colored gemstone standards). 
  2. Ring shanks must be thick enough to withstand a moderate amount of hand-applied pressure. A suggested minimum thickness is .8mm thick, and 1.4mm side, but must be proportionate to the styling of the piece. 
  3. All jewelry items should have a well-finished appearance, including functional parts (clasps, earring backs, etc.). They should not be missing any removable components, such as earring backs, and should be fully and easily operational. 

##  2.2 Measurement

  

  1. Tolerance for ring size is 1/4 size over or 1/8 size under stated ring size on detail page. For narrow rings, the size will be measured at the leading edge, and for wider rings, at the center of the shank. 
  2. Tolerance for chain and bracelet length is + ¼ inch as stated on packing slip/invoice, and is based on usable length when clasped, with a zero tolerance for under-measurement. This is due to online customers' expectations that the chain not be LESS than the length ordered. The width must match the millimeter measurement on packing slip/invoice. Bangles are measured by inside circumference, and the tolerance is also + ¼ inch, with zero tolerance for under measurement. To ensure measuring accuracy, we recommend using a flexible plastic ruler, such as those used as accessories with Franklin Planners and Filofax organizers. 

##  2.3 Casting and construction

  

  1. Eye-visible porosity or holes, when viewed from a "bent elbow" distance of 12 inches, in any amount or location is a critical defect. 
  2. Castings must be free of flashing and excess metal from air bubbles. 
  3. All soldered jewelry must be of like karat with no discoloration. There can be no open seams or joints, unfilled areas, cracks, or excessive solder. 
  4. Solder must not freeze any parts that should be moveable (for example, chain links). 
  5. Ring heads must be straight and plumb when viewed from top or side profile. 
  6. Gallery work must be symmetrical and clean. 

##  2.4 Polishing and finishing

  

  1. If ordered as polished, metal surfaces should be of high polish and free of eye-visible scratches or tool marks. Design details must be clean and distinct. 
  2. If item ordered with special finish such as satin, brushed, matte, etc., the finish must be uniformly applied , and if combined with another finish must not overlap adjacent areas where not intended. 
  3. All items must be clean and dry with no fingerprints, oils, or polishing rouge remaining. 
  4. Lint left under prongs from the polishing wheels/cloths is unacceptable. 
  5. Plated surfaces, such as 18 karat white gold with rhodium plating, should be uniform in color and show no signs of peeling, cracking or tarnishing. 

##  2.5  Stone setting

  

  1. Loose stones of any kind are considered a defect. Stones will be tested with a set-testing machine to test tightness, as well as tweezers to test security. 
  2. Stones must be set level and consistent in height with respect to design. 
  3. Prongs must be even in shape, length, and placement. There should be no gaps between prongs and the stones. 
  4. Bezels must be smooth and even in thickness, and in proportion to the size of the stone they secure, with no gaps between the bezel and the stone. 
  5. In channel settings, stone tables must be set in the same plane, or follow a curve consistent with the design. The channel walls should be even and smooth, with a consistent seat cut for the girdle of the stones. Stones should be set girdle to girdle. 
  6. Stones should be set so that the culet is not exposed. Some designs may call for exposed culets, but the culet should not be felt during wear or taking item on or off. 
  7. Pearl jewelry such as earrings, rings, brooches, clasps, etc. must incorporate a cup and post for each pearl (or at least a post, depending on design/placement), with the pearl half-drilled and epoxied onto the cup and post. 
  8. Epoxy or glue may be used for pearls, inlay, and some cabochon opaque stones such as onyx, jade, etc. It may not be used for semi-precious or precious gemstones. 

##  2.6 Findings

  

  1. Findings with moveable parts must be fully functional, without significant binding during operation, and durable enough to withstand repeated operation. 
  2. Findings must be an appropriate size and weight for the item. 
  3. Pendant bales must be large enough to allow the pendant to swing freely on the chain. If pendants are sold without a chain, bales must be large enough to accommodate a normal variety of customer chains. 
  4. Earring posts must be strong enough to withstand normal use, and the ends of posts should be rounded and smooth. Ear wires and leverbacks should operate smoothly and close securely. Posts should have a usable length of approximately 9.5mm or 3/8 of an inch, and should have a thickness of approximately .70mm (+/- .04mm), depending on design/type. 
  5. Bracelets with a barrel or box clasp must have at least one figure-8 safety. 

##  3\. Pearls and colored gemstones standards

##  3.1 General

  

  1. Regardless of metal type, any gemstones used must meet the standards listed under this section. 
  2. Amazon requires that all listings in the Jewelry category follow the international grading standards as instituted by the GIA. This applies to all product titles, product descriptions, and product specifications. 
  3. Color ranges for gemstones cannot exceed two tones of saturation. 
  4. If a new gemstone, organic material, or treatment is being supplied, sellers are required to supply an identification report to support its authenticity from GIA. 
  5. Only stable, permanent treatments and enhancements will be accepted. All treatments and enhancements must be completely and fully disclosed, and independent verification of stability of treatment may be required. Glass-filled or other nonpermanent treatments or enhancements are not accepted and will be rejected. Listings for enhanced color stones must contain stone creation, stone treatment and stone care method. 
  6. Pearl creation method (that is, natural, cultured, or simulated/imitation) must be completely and fully disclosed on the product detail page. Independent verification of creation method may be required. A natural pearl is a pearl whose creation has in no way been caused or induced by humans. A cultured pearl is created when a nucleus is planted by humans inside the shell or in the mantle of a mollusk coated with nacre by the mollusk. A simulated or imitation pearl is a manufactured product that simulates a pearl or cultured pearl in appearance. 
  7. A statement as to the geographic origin of a gemstone (for example, Ceylon Sapphire) may only be used when it can be substantiated, and even then, the name of a geographic area may only be used if it denotes the area where the gemstone was mined. Amazon may require a declaration signed by the seller of the gemstones place of origin to verify the origin. Further, if the absence of treatment is denoted, Amazon may require the seller to sign a document verifying the absence of treatment, and Amazon may require a GIA lab report for a sample as proof. 
  8. Gemstones will be evaluated with eye-visible criteria. Loupes will be used for defect clarification purposes only. 
  9. Gemstones must be free of scratches, polishing lines, chips, cracks and abrasions. No obvious defects will be acceptable. 
  10. Gemstones must be symmetrical and properly cut. Faceting and depth must be appropriate to the diameter, shape, and type of material, and must be consistent throughout shipment. Stone girdles must be polished. 
  11. Ensure that the creation method, for example, lab-created, simulated, imitation, or synthetic, immediately precedes the name of all non-natural gemstones, birthstones, pearls, and diamonds. 
  12. Provide accurate minimum weight, cut, clarity, and number of stones attributes for all gemstone products. 
  13. Ensure that all pearl attributes, including pearl size, shape, length of strand, color, etc. are accurate. 

##  4\. Diamond standards

Diamonds must meet the following specific diamond standards:  

  1. Amazon prohibits sellers from selling products that include stones from any sources connected with civil conflict, criminal, or terrorist activities. By selling on Amazon, you represent and warrant that you do not knowingly buy or sell any gemstones with links to such activities. 
  2. Amazon requires that all listings in the Jewelry category follow the international grading standards as instituted by the GIA. This applies to all product titles, product descriptions, and product specifications. 
  3. Any treatments such as laser drilling, fracture-filling, clarity enhancement, or any other treatments are unacceptable and will be rejected. Listings for enhanced color stones must contain stone creation, stone treatment, and stone care method. 
  4. Diamond color will be determined by direct comparison against GIA Master Stones. 
  5. Diamond weights will be verified, by direct weighing or weight estimation formulas. For diamond weights expressed as decimals, the weight should be expressed to two decimal places. For example, 0.47 carat means the weight is at least 0.465 carats. For diamond weights expressed as fractions, carat weight tolerance is as follows:  Carat weight  |  Minimum required actual carat weight to round up   
---|---  
1/10  |  0.09  
1/5  |  0.18  
1/4  |  0.23  
1/3  |  0.30  
3/8  |  0.37  
1/2  |  0.46  
5/8  |  0.59  
3/4  |  0.71  
1  |  0.96  
1 ¼  |  1.22  
1 ½  |  1.45  
1 ¾  |  1.70  
2  |  1.95  
2 ½  |  2.45  
3  |  2.95  
  6. All diamonds must have a minimum of 17 polished symmetrical facets, and sellers may not list a product containing a stone described as a diamond that does not meet this standard. 

Amazon will not accept diamonds with the following:  

  1. Extremely thick or thin girdles. 
  2. Large culets. 
  3. Diamonds containing open-cavity inclusions. 
  4. Naturals that affect the outline of the girdle or are assessed to be a setting risk. 
  5. Diamonds that contain inclusions that may make the diamond structurally unsound for mounting or wearing due to the size, nature, and location of the inclusion. 
  6. Scratches, chips, burned facets, or polish lines that are easily visible under 10X magnification. 
  7. Major symmetry defects. 

##  5\. Diamond Grading Report or Certificate of Authenticity

A Diamond Grading Report (or Certificate of Authenticity) is required for
natural or lab-created diamonds of any clarity and any color (except black
diamonds) based on the following:  

  1. Diamond Stud Earrings: Amazon requires a grading report if the total stated carat weight of the center stones in the pair of stud-earrings is greater than 1.0. 
  2. Rings or Pendants: Amazon requires a grading report if the center stone's stated weight is ¾ carats or larger. If there are side stones with stated weight of ½ carats or larger, they also need to be accompanied with a certificate and may be included in the same certificate as that of the center stone. 

We only accept certificates of authenticity or diamond grading reports from
one of the four certification houses: GIA, IGI, AGS, and GCAL.  

  1. All grading reports must state that the carat weight, clarity, color and cut of the diamond meet or exceed the representation of your item on the Amazon website. 
  2. All treatments and enhancements must be completely and fully disclosed on the grading report. 
  3. Creation method must be clearly stated on the grading report. 

##  6\. Independent laboratory testing

From time to time, Amazon may request, source, or purchase products sold in
the Jewelry category for quality assurance testing. Amazon may submit those
products to an independent, accredited jewelry testing laboratory for thorough
quality testing. Amazon may also require Jewelry suppliers to work with
certain designated laboratories for quality testing. The products will be
tested for conformance with the Amazon product description at the time of
request or purchase, as well as for compliance with Amazon Jewelry Quality
Assurance Standards. Amazon may return any items it purchases for these
purposes to the applicable sellers.

Amazon will contact sellers if their jewelry fails quality testing. Depending
on the number of products that fail testing and the severity and type of
failures, Amazon may take further actions, including (but not limited to)
working with the seller on a remedial plan to address the underlying cause of
failures, returning some or all inventory purchased from the seller at the
seller's expense and suspending or terminating a seller's ability to sell in
the Jewelry category or on Amazon.

##  7\. Resources

[ Guides for the Jewelry, Precious Metals, and Pewter Industries (16 CFR Part
23) ](https://www.ftc.gov/enforcement/rules/rulemaking-regulatory-reform-
proceedings/jewelry-precious-metals-pewter-industries)

[ National Gold and Silver Stamping Act of 1906 (15 USC Ch. 8)
](https://www.gpo.gov/fdsys/pkg/USCODE-2009-title15/html/USCODE-2009-title15-chap8.htm)

[ Customs and Border Protection Country of Origin Marking Laws and Regulation
](https://www.cbp.gov/trade/nafta/guide-customs-procedures/country-origin-
marking)

[ Precious Metals Marking Act
](https://www.canlii.org/en/ca/laws/stat/rsc-1985-c-p-19/latest/rsc-1985-c-p-19.html)

[ Precious Metals Marking Regulations
](https://www.canlii.org/en/ca/laws/regu/crc-c-1303/latest/crc-c-1303.html)

[ Guide to the Precious Metals Marking Act and Regulations
](http://www.competitionbureau.gc.ca/eic/site/cb-bc.nsf/eng/01234.html)

[ Canada Consumer Product Safety Act (CCPSA)
](https://laws.justice.gc.ca/eng/acts/C-1.68/FullText.html)

[ Weights and Measures Act
](https://www.canlii.org/en/ca/laws/stat/rsc-1985-c-w-6/latest/rsc-1985-c-w-6.html)

[ Weights and Measures Regulations
](https://www.canlii.org/en/ca/laws/regu/crc-c-1605/latest/crc-c-1605.html)

[ Children's Jewellery Regulations
](https://www.canlii.org/en/ca/laws/regu/sor-2011-19/latest/sor-2011-19.html)

[ Jewellers Vigilance Canada ](http://www.jewellersvigilance.ca/)

[ Canadian Guidelines for Gemstones
](https://www.canadianjewellers.com/media/uploads/JVC/JVC%20pdf./Gemstone%20Guidelines%20Revised%20Edition%202015.pdf)

[ Canadian Diamond Code of Conduct
](https://www.canadiandiamondcodeofconduct.ca/EN_code.htm)

[ "Product of Canada" and "Made in Canada"
](https://www.competitionbureau.gc.ca/eic/site/cb-bc.nsf/eng/03169.html)

[ Marketing of Imported Platinum Articles
](https://www.competitionbureau.gc.ca/eic/site/cb-bc.nsf/eng/01281.html)

Top

