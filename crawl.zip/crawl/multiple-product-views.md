# Multiple Product Views

source: https://sellercentral.amazon.com/help/hub/reference/G17781

> Add your favorite pages here by clicking this icon in the navigation menu.

---
Add your favorite pages here by clicking this icon in the navigation menu.

Hide

## Multiple Product Views

Images showing multiple instances of the same product, whether showing different sides of a garment or close-up and full views, are not allowed. Upload images that show different views and demonstrate features to additional image variants.

| Allowed | Not Allowed |
| --- | --- |
| ![](https://m.media-amazon.com/images/G/01/image_requirements/not_multi_views1.jpg) | 
![](https://m.media-amazon.com/images/G/01/image_requirements/multi_product3.png)

![](https://m.media-amazon.com/images/G/01/image_requirements/multi_product2.jpg)

![](https://m.media-amazon.com/images/G/01/image_requirements/multi_product1.png)

 |

Top

Was this article helpful?
