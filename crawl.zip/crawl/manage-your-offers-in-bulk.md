# Manage your offers in bulk

Source: https://sellercentral.amazon.com/help/hub/reference/external/G9DZLGS87GVDT94B

This article applies to selling in: **United States**

#  Manage your offers in bulk

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG9DZLGS87GVDT94B)

**Individual sellers:** This feature is only available to sellers with a
Professional selling plan. Learn more by visiting [ Selling plan comparison
](/gp/help/external/64491) .

You can use inventory files to upload or manage your offers in bulk. Also, you
can view the products listed on Amazon successfully by downloading an
inventory report. For more information on how to use inventory files and
reports effectively, select a page from the left navigation pane.

Top

##  Manage your offers in bulk

* [ Create your inventory file template  ](/help/hub/reference/external/G202094740)
* [ Build your inventory file  ](/help/hub/reference/external/G581)
* [ Inventory file upload FAQ  ](/help/hub/reference/external/G201201070)
* [ Troubleshoot inventory file upload errors  ](/help/hub/reference/external/GY39J4HS7TZYXZJK)
* [ Upload your inventory file  ](/help/hub/reference/external/G601)
* [ Review my inventory results  ](/help/hub/reference/external/G611)
* [ Review a Processing Report  ](/help/hub/reference/external/G200194300)
* [ How Do I Use the Inventory Loader Template?  ](/help/hub/reference/external/G201565090)
* [ Maximize Inventory File Upload Performance  ](/help/hub/reference/external/G200894980)
* [ What do I need to know before using inventory files?  ](/help/hub/reference/external/G201420410)
* [ Populating inventory file templates  ](/help/hub/reference/external/G200986920)
* [ How do I Fill Out a Template?  ](/help/hub/reference/external/G201467230)
* [ Product information requirements for product feed templates  ](/help/hub/reference/external/G200986910)
* [ Creating Variations using Inventory File Templates  ](/help/hub/reference/external/G201979330)
* [ How do I Use the Inventory Loader Template? Tutorial  ](/help/hub/reference/external/G201467250)
* [ Product classifier tutorial  ](/help/hub/reference/external/G201420420)
* [ How to Fill Out the Jewelry Template  ](/help/hub/reference/external/G201467190)
* [ How To Fill Out the Apparel Template  ](/help/hub/reference/external/G201467210)
* [ Shipping Overrides Template tutorial  ](/help/hub/reference/external/G13531)
* [ Product feeds overview  ](/help/hub/reference/external/G200986880)
* [ Using your preferred language in your inventory File template  ](/help/hub/reference/external/G95W67HSJ4A386EN)
* [ Download an Inventory Report  ](/help/hub/reference/external/G561)
* [ How do I view my uploaded Inventory file result?  ](/help/hub/reference/external/G202010000)
* [ How do I use the different inventory templates?  ](/help/hub/reference/external/G202010020)
* [ How can I delete specific product listings, or replace all my listings?  ](/help/hub/reference/external/G202010040)

