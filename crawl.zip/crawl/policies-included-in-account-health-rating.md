# Policies included in Account Health Rating

Source: https://sellercentral.amazon.com/gp/help/external/GQ5DSES264XVXNX7

This article applies to selling in: **United States**

#  Policies included in Account Health Rating

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGQ5DSES264XVXNX7)

The Account Health Rating (AHR) indicates your selling account’s risk of
deactivation due to policy non-compliance, and it displays on the seller’s [
Account Health ](/performance/dashboard) page for each store in which they
sell worldwide. This page lists all policies included in the AHR, and will be
updated as new policies are added in the future.

Amazon has not changed any policies as a result of AHR, and not all of
Amazon’s policies are currently included in AHR. For a full list of Amazon’s
program policies, go to [ Program Policies ](/gp/help/external/G521) .

[ Amazon Anti-Counterfeiting Policy ](/gp/help/external/G201165970)

[ Amazon Brand Name Policy ](/gp/help/external/2N3GKE5SGSHWYRZ)

[ Amazon Intellectual Property Policy ](/gp/help/external/G201361070)

[ Amazon Marketplace Fair Pricing Policy ](/gp/help/external/G5TUVJKZHUVMN77V)

[ ASIN Creation Policy ](/gp/help/external/201844590)

[ Communication Guidelines ](/gp/help/external/G1701)

[ Customer Product Reviews Policies ](/gp/help/external/GYRKB5RU3FS5TURN)

[ Product Condition Guidelines ](/gp/help/external/200339950)

[ Product Detail Page Rules ](/gp/help/external/G200390640)

[ Product Guidelines for Adult Products ](/gp/help/external/200339940)

[ Product Guidelines for Selling Software ](/gp/help/external/200386270)

[ Restricted Products Policy ](/gp/help/external/G200164330)

[ Selling Policies and Seller Code of Conduct ](/gp/help/external/G1801)

Top

