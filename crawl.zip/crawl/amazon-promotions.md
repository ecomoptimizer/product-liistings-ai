# Amazon promotions

Source: https://sellercentral.amazon.com/help/hub/reference/external/G60951

This article applies to selling in: **United States**

#  Amazon promotions

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG60951)

On this page

When to create a promotion

Successful promotions

Restrictions

See also

Promotions can help your products stand out from the competition and stimulate
sales. However, promotions are most effective when your offer is the Featured
Offer (formerly known as "Buy Box"). Otherwise, the promotional messaging
cannot appear on the detail page.  For more information, go to [ How the
Featured Offer works ](/gp/help/external/G37911) .

##  When to create a promotion

Consider creating a promotion when business is slow so that you can motivate
both existing and new customers to buy. You can also distinguish your offer
from the competition and encourage existing customers to try new products.

There are several options you can choose from when creating a promotion:

  * Percentage-off 
  * Buy one, get one free 

##  Successful promotions

Successful promotions motivate customers to buy your product. To run an
effective promotion, consider the following guidelines:

  * **The customer must know about it.** Consider running social media campaigns to drive traffic to your promotion. 
  * **It is time-sensitive.** Customers respond to limited time offers when they face the possibility of missing the offer. Experiment with the duration, depending on your product. 
  * **It offers sufficient value to influence the customer's choice.** Track current sales and gather feedback to really figure out what offers your potential customers find more attractive. Then you’ll have some solid understanding to be able to refine your promotions accordingly. 

**Note:** When considering running promotions for your products, keep in mind
that promotions cannot be offered as an incentive for customer reviews, either
explicitly or implicitly.  Customer reviews for purchases made with promotions
might not necessarily get the “Amazon Verified Purchase” badge. You can learn
more about Amazon Verified Purchases  [ here
](https://www.amazon.com/gp/help/customer/display.html?nodeId=202076110) .

##  Restrictions

Amazon restricts the following categories from certain kinds of promotional
offers:

  * Books, Music, Video and DVD (BMVD) products are excluded from promotions. 
  * Wine: Excluded from all promotions. 

##  See also

  * [ Claim codes and combinability ](/gp/help/external/G200212920)
  * [ Product Selection Types ](/gp/help/external/G200210980)
  * [ Selection-based fee promotion ](/gp/help/external/201962580)
  * [ Promotions and order reports ](/gp/help/external/43531)

Top

##  Amazon promotions

* [ Use social media promo codes to promote sales for your products  ](/help/hub/reference/external/G67T7489P3LUZVZ8)
* [ Discounts Provided by Amazon  ](/help/hub/reference/external/G202170300)
* [ Create a Social Media Promo Code  ](/help/hub/reference/external/GDC3Y9ETBQ5V9HJ7)
* [ Prime Day Small Business Promotions FAQ  ](/help/hub/reference/external/GB5KQ2GS6DMQA7RC)
* [ Prime Day Small Business Promotion (Sweepstakes)  ](/help/hub/reference/external/GBHA9ZYCUHLNQT8F)
* [ Global Promotions Sales dashboard  ](/help/hub/reference/external/GBXY4PRVN87E8KL2)

