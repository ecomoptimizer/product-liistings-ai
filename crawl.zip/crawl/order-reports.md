# Order Reports

Source: https://sellercentral.amazon.com/help/hub/reference/external/G651

This article applies to selling in: **United States**

#  Order Reports

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FG651)

**Individual sellers:** This feature is available to [ Amazon Business sellers
](/hz/b2bregistration) and sellers with [ Professional selling plans
](/gp/help/external/64491) .

An order report is a tab-delimited text file that lists all products sold
during a set time period. It includes the buyer information needed to fulfill
orders. It does not include the buyer's confidential information, like billing
address or credit card information.

An order report only displays information for seller-fulfilled orders you have
received during the number of days you select, including those you have
canceled or confirmed as shipped. For Amazon-fulfilled orders (through FBA),
see the [ All Orders Report ](/help/hub/reference/external/G200547170) .

You can manually generate an order report in Seller Central at any time for
the past 1, 2, 7, 15 or 30 days. Seller Central doesn’t support generating
order reports beyond 30 days. We recommend that you archive your daily order
reports to preserve historical data. To investigate specific orders that are
older than 30 days, use the [ Search orders
](/help/hub/reference/external/G28151) feature on **Manage Orders** page.

You can also schedule recurring order reports as needed. For details on
scheduling recurring order reports, refer to [ Schedule Order reports
](/help/hub/reference/external/G201648760) .

Top

##  Order Reports

* [ Order Report field definitions  ](/help/hub/reference/external/G201648780)
* [ CustomizationInfo and CustomerOrderInfo fields  ](/help/hub/reference/external/G200747980)
* [ Download Order Reports  ](/help/hub/reference/external/G200259200)
* [ Archived Order Reports  ](/help/hub/reference/external/GQE5U7B4QEZY5HEJ)

