# Amazon Warehousing and Distribution (AWD)

Source: https://sellercentral.amazon.com/help/hub/reference/external/GF6ZC8VEBM7HCEGV

This article applies to selling in: **United States**

#  Amazon Warehousing and Distribution (AWD)

Sign in to use the tool and get personalized help (desktop browser required).

[ ](/gp/sign-in/sign-
in.html?destination=%2Fhelp%2Fhub%2Freference%2Fexternal%2FGF6ZC8VEBM7HCEGV)

Amazon Warehousing and Distribution is a third-party logistics program that
provides long-term, upstream bulk inventory storage that’s cost effective. In
addition, the program automatically replenishes your inventory in Prime-ready
fulfillment centers.

There are no fees for enrolling in the program. You’ll be charged only when
you send your inventory to Warehousing and Distribution facilities.

##  Get started

To navigate to AWD, on Seller Central, go to **Inventory** > **Store and
distribute** or go to the [ program page ](/asdn/about) directly.

To get started with Warehousing and Distribution, click **Enroll** at the top
right of our [ program page ](/asdn/about) for simple, one-click enrollment.
If **Enroll** doesn’t appear, that means you’re already enrolled.

Once enrolled, you can access the **Manage service** tab on this page to learn
how to create and send a shipment.

Within two to three days of enrollment, you can access the [ Global FBA
Inventory ](/gp/help/external/G23EYVCM6YH7CHL8) page to help you manage your
shipments. In the meantime, you can send inventory by clicking **Create
shipment** in the **Manage service** tab.

##  Grant access to users

The Warehousing and Distribution tools are visible only to users who have
permissions to use the program. If you don't have permissions, the primary
account holder for your account can grant them to you via the [ User
permissions ](/gp/account-manager/home.html/) page.

The primary account user can grant access by following these steps:

  1. From the **Settings** drop-down menu, select **User permissions** . 

  2. Add a new user, or select an existing user. 

  3. Click **Add to global account** or **Manage global permissions** to add or modify the user’s permissions. 

  4. Scroll down to the **Inventory** section and locate **Amazon Warehousing and Distribution– Secondary user access** and **Global FBA Inventory** . Select one of the following three levels of permission: 
    * **None** : These users don’t have access to inventory information. 
    * **View and edit** : These users can take actions on inventory. 
    * **View only** : These users can only view inventory information. 

  5. Click **Save changes** . 

**Important:** Be careful to grant **View and edit** permissions only to users
who are authorized to act on Warehousing and Distribution inventory or change
inventory settings.

Top

##  Amazon Warehousing and Distribution (AWD)

* [ Amazon Warehousing and Distribution (AWD) product eligibility  ](/help/hub/reference/external/GGTMT4PTMUMHDS6B)
* [ Send shipments to Amazon Warehousing and Distribution (AWD)  ](/help/hub/reference/external/GTPL7PGKU7WUKJSW)
* [ Amazon Warehousing and Distribution (AWD) fee reports  ](/help/hub/reference/external/GPB467PZW3AZC4V3)

